"""Mutabakat maili gönderim kaydı — SQLite tabanlı kalıcı günlük.

NEDEN GEREKLİ
    3000 firmalık bir gönderim yarım saat sürebilir. Ortasında bir hata
    olursa (Exchange kotası, ağ kopması, Outlook kapanması) hangi firmalara
    mail gittiği hiçbir yerde yazılı değildi. Baştan başlamak, mail almış
    firmalara **ikinci kez** mutabakat mektubu göndermek demekti — karşı
    tarafta karışıklık yaratan, geri alınamaz bir hata.

    Bu günlük üç işi yapar:
      1. Kim, ne zaman, hangi dosyalarla mail aldı — kalıcı kayıt.
      2. Aynı dönemde aynı firmaya İKİNCİ kez gönderimi engeller.
      3. Yarıda kalan bir gönderim kaldığı yerden sürdürülebilir.

TASARIM İLKESİ (audit.py ile aynı)
    Günlük ASLA gönderimi çökertmez. Veritabanı yazılamazsa hata loglanır ve
    iş devam eder. Ancak "zaten gönderildi mi?" sorgusu başarısız olursa
    çağıran taraf güvenli tarafta kalır (gönderilmemiş sayar, kullanıcıya
    sorar) — sessizce mükerrer gönderim YAPILMAZ.
"""

from __future__ import annotations

import json
import sqlite3
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Optional

from loguru import logger

from app.utils.paths import app_data_dir
from app.utils.sqlite import open_sqlite_connection

# Gönderim sonuçları.
STATUS_SENT = "SENT"          # Outlook'a verildi
STATUS_FAILED = "FAILED"      # gönderim KESİN başarısız (mail oluşmadı)
STATUS_SKIPPED = "SKIPPED"    # kasıtlı atlandı (eksik ek, dil belirsiz…)
# ``Send()`` hata verdi ama mail GİTMİŞ OLABİLİR. Tekrar göndermek mükerrer
# mutabakat mektubu demektir; bu yüzden ayrı bir durumdur ve "gönderilmedi"
# ile KARIŞTIRILMAZ.
STATUS_SEND_UNKNOWN = "SEND_UNKNOWN"

# Bu dönemde bu firmaya TEKRAR GÖNDERİLMEMESİ gereken durumlar.
# ``SEND_UNKNOWN`` buraya dahildir: belirsizlik, yeniden gönderme gerekçesi
# DEĞİLDİR — doğrulama ve insan incelemesi gerekçesidir.
NO_RESEND_STATUSES = (STATUS_SENT, STATUS_SEND_UNKNOWN)

# -- SEND_UNKNOWN için insan çözümü (send_resolutions) -----------------------
# ``mail_sends`` satırları ASLA değiştirilmez/silinmez. Bir belirsiz gönderimin
# insan tarafından çözülmesi AYRI, ekleme-yönlü bir tabloya (``send_resolutions``)
# yazılır; etkin durum bu iki kaynaktan TÜRETİLİR.
DECISION_VERIFIED_SENT = "VERIFIED_SENT"      # "gönderildi" doğrulandı (terminal)
DECISION_REOPENED = "REOPENED"                # "gönderilmedi", yeniden gönderime açıldı
DECISION_UNDER_REVIEW = "UNDER_REVIEW"        # incelemede; durum DEĞİŞMEZ
RESOLUTION_DECISIONS = (DECISION_VERIFIED_SENT, DECISION_REOPENED,
                        DECISION_UNDER_REVIEW)
# Durumu değiştiren kararlar (UNDER_REVIEW değiştirmez).
_STATE_CHANGING_DECISIONS = (DECISION_REOPENED, DECISION_VERIFIED_SENT)

# Etkin durum (dönem + firma için).
STATE_NONE = "NONE"                      # hiç SENT/SEND_UNKNOWN kaydı yok
STATE_SENT = "SENT"                      # günlükte SENT
STATE_UNKNOWN = "SEND_UNKNOWN"           # belirsiz, çözülmemiş
STATE_VERIFIED_SENT = "VERIFIED_SENT"    # belirsiz, insan "gitti" dedi
STATE_REOPENED = "REOPENED"              # belirsiz, insan "gitmedi" dedi
# Tekrar-kapısında ENGELLİ durumlar. ``REOPENED`` ve ``NONE`` engelli değildir.
BLOCKED_STATES = (STATE_SENT, STATE_UNKNOWN, STATE_VERIFIED_SENT)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _flag(value) -> bool:
    """SQLite'tan gelen bayrağı güvenle bool'a çevir.

    Eski veritabanlarında bayrak TEXT kolonda '0' olarak durabilir ve
    ``bool('0')`` True'dur — bu yüzden metin değerler ayrıca ele alınır.
    """
    if isinstance(value, str):
        return value.strip() not in ("", "0", "false", "False")
    return bool(value)


@dataclass(frozen=True)
class MailLogEntry:
    """Günlükteki tek bir kayıt."""

    company_code: str
    period: str                     # "2026-07"
    status: str
    company_name: str = ""
    locale: str = ""
    directions: str = ""            # "M,S"
    recipients: str = ""
    subject: str = ""
    attachments: tuple[str, ...] = ()
    reason: str = ""
    run_id: Optional[str] = None
    sent_at: str = ""

    # -- takip kimlikleri (gelen cevabı bu maile bağlamak için) -------------
    # Konu satırı TEK BAŞINA eşleştirme kriteri değildir: firma konuyu
    # değiştirebilir, iki dönem aynı konuyu taşıyabilir. Outlook'un ürettiği
    # kimlikler saklanırsa cevap kesin olarak doğru mutabakata bağlanır.
    message_id: str = ""            # InternetMessageID (gönderilen mail)
    conversation_id: str = ""       # Outlook ConversationID (zincir)
    # Gönderilmiş Öğeler'deki asıl öğenin YEREL kimliği. Gönderimden sonra
    # öğe Taslaklar'dan Gönderilmiş Öğeler'e TAŞINIR ve EntryID DEĞİŞİR; bu
    # yüzden burada saklanan değer, gönderim ANINDA okunan değil, gönderilmiş
    # öğeden YENİDEN OKUNAN kimliktir (bkz. outlook_client.resolve_sent_identity).
    entry_id: str = ""
    # Üç kimlik de gönderilmiş öğeden doğrulanarak okunduysa 1. Doğrulanmamış
    # kimlik, hatırlatmanın YANLIŞ/ESKİ zincire bağlanma riskini taşır.
    identity_verified: bool = False
    mail_status: str = ""           # bkz. app/services/mail_status.MailStatus

    # -- benzersiz gönderim kimliği ----------------------------------------
    # ``company_code + period`` ANAHTAR DEĞİLDİR: bir firmaya aynı dönemde
    # düzeltme/tekrar gönderimi yapılabilir. Cevabın DOĞRU pakete bağlanması
    # için her gönderimin kendi kimliği ve o gönderimin FBL1H/FBL5H
    # snapshot'ına bağı olmalıdır (bkz. app/services/send_snapshot.py).
    send_id: str = ""
    snapshot_id: str = ""
    responsible: str = ""           # Mutabakat Mailleri Excel'indeki (R) alanı

    @property
    def succeeded(self) -> bool:
        return self.status == STATUS_SENT


@dataclass(frozen=True)
class SendResolution:
    """Belirsiz bir gönderim için kaydedilmiş insan kararı (ekleme-yönlü)."""

    resolution_id: str
    period: str
    company_code: str
    decision: str
    basis_row_id: int          # kararın dayandığı ``mail_sends.id``
    prior_state: str
    new_state: str
    reason: str
    user: str
    role: str
    at: str
    evidence: dict
    id: int = 0


@dataclass(frozen=True)
class EffectiveState:
    """(dönem, firma) için günlük + çözümlerden TÜRETİLEN etkin durum."""

    state: str = STATE_NONE
    basis_row_id: int = 0          # karar verici ``mail_sends`` satırı
    basis_status: str = ""
    under_review: bool = False
    last_resolution: Optional[SendResolution] = None   # son durum-değiştiren karar
    last_review: Optional[SendResolution] = None       # son UNDER_REVIEW notu

    @property
    def blocked(self) -> bool:
        return self.state in BLOCKED_STATES


@dataclass(frozen=True)
class AppendOutcome:
    """``append_resolution`` sonucu."""

    applied: bool
    prior: EffectiveState
    resolution: Optional[SendResolution] = None


_ENTRY_COLUMNS = (
    "company_code, period, status, company_name, locale, directions, "
    "recipients, subject, attachments, reason, run_id, sent_at, message_id, "
    "conversation_id, mail_status, send_id, snapshot_id, responsible, "
    "entry_id, identity_verified")

_RESOLUTION_COLUMNS = (
    "id, resolution_id, period, company_code, decision, basis_row_id, "
    "prior_state, new_state, reason, user, role, at, evidence")


def _resolution_from_row(r) -> SendResolution:
    try:
        kanit = json.loads(r[12] or "{}")
    except (TypeError, ValueError):
        kanit = {}
    return SendResolution(
        id=int(r[0]), resolution_id=r[1], period=r[2], company_code=r[3],
        decision=r[4], basis_row_id=int(r[5]), prior_state=r[6] or "",
        new_state=r[7] or "", reason=r[8] or "", user=r[9] or "",
        role=r[10] or "", at=r[11] or "",
        evidence=kanit if isinstance(kanit, dict) else {})


class MailLog:
    """Kurulum gerektirmeyen yerel gönderim günlüğü."""

    def __init__(self, path: str | Path | None = None) -> None:
        if path is None:
            base = app_data_dir()
            base.mkdir(parents=True, exist_ok=True)
            path = base / "mail_log.db"
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    @property
    def path(self) -> Path:
        return self._path

    def _connect(self) -> sqlite3.Connection:
        return open_sqlite_connection(self._path, isolation_level=None)

    @contextmanager
    def _session(self):
        conn = self._connect()
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _ensure_schema(self) -> None:
        try:
            with self._session() as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS mail_sends (
                        id            INTEGER PRIMARY KEY AUTOINCREMENT,
                        company_code  TEXT NOT NULL,
                        period        TEXT NOT NULL,
                        status        TEXT NOT NULL,
                        company_name  TEXT,
                        locale        TEXT,
                        directions    TEXT,
                        recipients    TEXT,
                        subject       TEXT,
                        attachments   TEXT,
                        reason        TEXT,
                        run_id        TEXT,
                        sent_at       TEXT NOT NULL
                    )
                """)
                # Aynı dönem + firma için hızlı "gönderildi mi?" sorgusu.
                conn.execute("""
                    CREATE INDEX IF NOT EXISTS ix_mail_sends_period_code
                    ON mail_sends (period, company_code, status)
                """)
                # -- şema göçü: eski günlüklere takip kolonlarını ekle ------
                # Mevcut kayıtlar korunur; yeni kolonlar boş kalır.
                existing = {row[1] for row in
                            conn.execute("PRAGMA table_info(mail_sends)")}
                # (kolon, SQL tipi) — TEXT bir kolona 0/1 yazmak SQLite'ın
                # tip yakınlığı yüzünden '0' metnine dönüşür ve bool('0')
                # True'dur. Bayrak kolonu bu yüzden INTEGER'dır.
                for column, tip in (("message_id", "TEXT"),
                                    ("conversation_id", "TEXT"),
                                    ("mail_status", "TEXT"),
                                    ("send_id", "TEXT"),
                                    ("snapshot_id", "TEXT"),
                                    ("responsible", "TEXT"),
                                    ("entry_id", "TEXT"),
                                    ("identity_verified", "INTEGER")):
                    if column not in existing:
                        conn.execute(
                            f"ALTER TABLE mail_sends ADD COLUMN {column} {tip}")
                # Gelen cevabı zincire bağlarken kullanılır.
                conn.execute("""
                    CREATE INDEX IF NOT EXISTS ix_mail_sends_conversation
                    ON mail_sends (conversation_id)
                """)
                # Gönderim kimliğiyle tekil güncelleme (mükerrer gönderimlerin
                # birbirini ezmesini önler).
                conn.execute("""
                    CREATE INDEX IF NOT EXISTS ix_mail_sends_send_id
                    ON mail_sends (send_id)
                """)
                # Belirsiz gönderimlerin İNSAN çözümleri: EKLEMEYE açık, ayrı
                # tablo. ``mail_sends`` satırlarına dokunulmaz. Bilerek
                # tetikleyici YOK: ``data_reset`` her tabloda ``DELETE FROM``
                # yapar; değişmezlik güvencesi tetikleyicili ``ActionAuditLog``
                # (sıfırlamadan hariç) ile sağlanır, burada API'de güncelleme/
                # silme yöntemi bulunmaması ile.
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS send_resolutions (
                        id            INTEGER PRIMARY KEY AUTOINCREMENT,
                        resolution_id TEXT NOT NULL UNIQUE,
                        period        TEXT NOT NULL,
                        company_code  TEXT NOT NULL,
                        decision      TEXT NOT NULL,
                        basis_row_id  INTEGER NOT NULL,
                        prior_state   TEXT NOT NULL DEFAULT '',
                        new_state     TEXT NOT NULL DEFAULT '',
                        reason        TEXT NOT NULL,
                        user          TEXT NOT NULL DEFAULT '',
                        role          TEXT NOT NULL DEFAULT '',
                        at            TEXT NOT NULL,
                        evidence      TEXT NOT NULL DEFAULT '{}'
                    )
                """)
                conn.execute("""
                    CREATE INDEX IF NOT EXISTS ix_send_resolutions_key
                    ON send_resolutions (period, company_code, id)
                """)
        except sqlite3.Error as exc:  # pragma: no cover - ortam bağımlı
            logger.error(f"Mail günlüğü şeması kurulamadı: {exc}")

    # -- yazma -------------------------------------------------------------

    def record(self, entry: MailLogEntry) -> bool:
        """Tek bir sonucu yaz. Yazılamazsa loglar, False döner (çökertmez)."""
        try:
            with self._session() as conn:
                conn.execute("""
                    INSERT INTO mail_sends (
                        company_code, period, status, company_name, locale,
                        directions, recipients, subject, attachments, reason,
                        run_id, sent_at, message_id, conversation_id,
                        mail_status, send_id, snapshot_id, responsible,
                        entry_id, identity_verified
                    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (
                    entry.company_code, entry.period, entry.status,
                    entry.company_name, entry.locale, entry.directions,
                    entry.recipients, entry.subject,
                    json.dumps(list(entry.attachments), ensure_ascii=False),
                    entry.reason, entry.run_id, entry.sent_at or _now(),
                    entry.message_id, entry.conversation_id, entry.mail_status,
                    entry.send_id, entry.snapshot_id, entry.responsible,
                    entry.entry_id, 1 if entry.identity_verified else 0,
                ))
            return True
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"Mail günlüğüne yazılamadı ({entry.company_code}): {exc}")
            return False

    def record_many(self, entries: Iterable[MailLogEntry]) -> int:
        return sum(1 for e in entries if self.record(e))

    # -- okuma -------------------------------------------------------------

    def sent_codes(self, period: str) -> set[str]:
        """Bu dönemde BAŞARIYLA mail gitmiş firma kodları."""
        try:
            with self._session() as conn:
                rows = conn.execute(
                    "SELECT DISTINCT company_code FROM mail_sends "
                    "WHERE period = ? AND status = ?",
                    (period, STATUS_SENT),
                ).fetchall()
            return {r[0] for r in rows}
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"Mail günlüğü okunamadı: {exc}")
            return set()

    def already_sent(self, company_code: str, period: str) -> bool:
        return company_code in self.sent_codes(period)

    def no_resend_codes(self, period: str) -> set[str]:
        """Bu dönemde TEKRAR GÖNDERİLMEMESİ gereken firma kodları.

        ``SENT`` ∪ ``SEND_UNKNOWN``. Belirsiz kalan bir gönderim de buraya
        girer: mail gitmiş olabilir ve ikinci bir mutabakat mektubu karşı
        tarafta karışıklık yaratır, geri alınamaz. Belirsizlik insan
        incelemesiyle çözülür, otomatik yeniden gönderimle DEĞİL.

        Tek istisna: insan belirsiz kaydı "gönderilmedi" diye
        ``REOPENED`` yaptıysa (``send_resolutions``) o firma, YALNIZ o karar
        verici satır için engelden çıkar; yeni bir ``SENT``/``SEND_UNKNOWN``
        satırı oluştuğunda engel kendiliğinden geri gelir. ``VERIFIED_SENT``
        engeli kalıcı kılar. Çözüm tablosu boşken sonuç eskisiyle aynıdır.
        """
        try:
            with self._session() as conn:
                durumlar = self._effective_states(conn, period)
            return {kod for kod, d in durumlar.items() if d.blocked}
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"Mail günlüğü okunamadı: {exc}")
            # GÜVENLİ TARAF: okunamıyorsa "gönderilmemiş" varsaymak mükerrer
            # mail üretir. Boş küme dönmek yerine hatayı yükseltmek de
            # gönderimi durdurur; çağıran taraf kullanıcıya sorar.
            raise

    # -- belirsiz gönderimlerin insan çözümü ---------------------------------

    @staticmethod
    def _effective_states(conn, period: str,
                          company_code: Optional[str] = None
                          ) -> dict[str, EffectiveState]:
        """Günlük + çözümlerden etkin durumları türet. Hata YUKARI çıkar."""
        placeholders = ",".join("?" * len(NO_RESEND_STATUSES))
        sart, params = "", [period, *NO_RESEND_STATUSES]
        if company_code is not None:
            sart = " AND company_code = ?"
            params.append(company_code)
        # Karar verici satır D: dönem+firma için en yüksek id'li SENT/SEND_UNKNOWN.
        karar_vericiler = conn.execute(
            "SELECT m.company_code, m.id, m.status FROM mail_sends m JOIN ("
            "SELECT company_code, MAX(id) AS mid FROM mail_sends "
            f"WHERE period = ? AND status IN ({placeholders}){sart} "
            "GROUP BY company_code) x ON m.id = x.mid", params).fetchall()
        if not karar_vericiler:
            return {}
        rparams: list = [period]
        rsart = ""
        if company_code is not None:
            rsart = " AND company_code = ?"
            rparams.append(company_code)
        cozumler: dict[str, list[SendResolution]] = {}
        for r in conn.execute(
                f"SELECT {_RESOLUTION_COLUMNS} FROM send_resolutions "
                f"WHERE period = ?{rsart} ORDER BY id", rparams):
            cozumler.setdefault(r[3], []).append(_resolution_from_row(r))

        sonuc: dict[str, EffectiveState] = {}
        for kod, d_id, d_status in karar_vericiler:
            d_id = int(d_id)
            if d_status == STATUS_SENT:
                sonuc[kod] = EffectiveState(STATE_SENT, d_id, d_status)
                continue
            kayitlar = [c for c in cozumler.get(kod, ())
                        if c.basis_row_id >= d_id]
            kararlar = [c for c in kayitlar
                        if c.decision in _STATE_CHANGING_DECISIONS]
            son = kararlar[-1] if kararlar else None
            incelemeler = [c for c in kayitlar
                           if c.decision == DECISION_UNDER_REVIEW
                           and (son is None or c.id > son.id)]
            if son is None:
                durum = STATE_UNKNOWN
            elif son.decision == DECISION_VERIFIED_SENT:
                durum = STATE_VERIFIED_SENT
            else:
                durum = STATE_REOPENED
            sonuc[kod] = EffectiveState(
                durum, d_id, d_status, under_review=bool(incelemeler),
                last_resolution=son,
                last_review=incelemeler[-1] if incelemeler else None)
        return sonuc

    def effective_state(self, period: str, company_code: str) -> EffectiveState:
        """(dönem, firma) etkin durumu. Okuma hatası YÜKSELİR (fail-closed)."""
        with self._session() as conn:
            return (self._effective_states(conn, period, company_code)
                    .get(company_code) or EffectiveState())

    def effective_states(self, period: str) -> dict[str, EffectiveState]:
        """Dönemdeki TÜM firmaların etkin durumu. Okuma hatası YÜKSELİR."""
        with self._session() as conn:
            return self._effective_states(conn, period)

    def resolutions(self, period: str,
                    company_code: Optional[str] = None) -> list[SendResolution]:
        """Kayıtlı çözümler (eskiden yeniye). Okuma hatası YÜKSELİR."""
        sart, params = "", [period]
        if company_code is not None:
            sart = " AND company_code = ?"
            params.append(company_code)
        with self._session() as conn:
            return [_resolution_from_row(r) for r in conn.execute(
                f"SELECT {_RESOLUTION_COLUMNS} FROM send_resolutions "
                f"WHERE period = ?{sart} ORDER BY id", params)]

    def entry_by_row_id(self, row_id: int) -> Optional[MailLogEntry]:
        """``mail_sends.id`` ile tek kayıt (kanıt paneli için)."""
        with self._session() as conn:
            r = conn.execute(
                f"SELECT {_ENTRY_COLUMNS} FROM mail_sends WHERE id = ?",
                (row_id,)).fetchone()
        return self._entry_from_row(r) if r else None

    def unresolved_unknowns(self, period: Optional[str] = None
                            ) -> list[MailLogEntry]:
        """İnsan kararı BEKLEYEN belirsiz gönderimler (firma başına karar
        verici satır). Çözülmüş (``REOPENED``/``VERIFIED_SENT``) ve sonradan
        başarıyla gönderilmiş firmalar dahil değildir."""
        with self._session() as conn:
            donemler = ([period] if period else [
                r[0] for r in conn.execute(
                    "SELECT DISTINCT period FROM mail_sends "
                    "WHERE status = ?", (STATUS_SEND_UNKNOWN,))])
            idler: list[int] = []
            for donem in donemler:
                for d in self._effective_states(conn, donem).values():
                    if d.state == STATE_UNKNOWN:
                        idler.append(d.basis_row_id)
            satirlar = [conn.execute(
                f"SELECT {_ENTRY_COLUMNS} FROM mail_sends WHERE id = ?",
                (i,)).fetchone() for i in sorted(idler)]
        return [self._entry_from_row(r) for r in satirlar if r]

    def append_resolution(self, *, period: str, company_code: str,
                          decision: str, allowed_from: Iterable[str],
                          reason: str, user: str, role: str = "",
                          evidence: Optional[dict] = None,
                          resolution_id: str = "") -> AppendOutcome:
        """İnsan çözümünü EKLE (yalnız INSERT; hiçbir satır değiştirilmez).

        Etkin durum ``allowed_from`` içinde DEĞİLSE hiçbir şey yazılmaz ve
        ``applied=False`` döner (idempotensi/yarış: ikinci çağrı no-op). Okuma-
        karar-yazma ``BEGIN IMMEDIATE`` içinde yapılır. Hatada ``sqlite3.Error``
        YÜKSELİR (çağıran fail-closed davranır).
        """
        if decision not in RESOLUTION_DECISIONS:
            raise ValueError(f"Tanınmayan karar: {decision}")
        gerekce = (reason or "").strip()
        if not gerekce:
            raise ValueError("Çözüm kaydı için gerekçe zorunludur.")
        izinli = set(allowed_from)
        rid = resolution_id or uuid.uuid4().hex
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            try:
                onceki = (self._effective_states(conn, period, company_code)
                          .get(company_code) or EffectiveState())
                if onceki.state not in izinli:
                    conn.execute("ROLLBACK")
                    return AppendOutcome(False, onceki)
                yeni = {DECISION_VERIFIED_SENT: STATE_VERIFIED_SENT,
                        DECISION_REOPENED: STATE_REOPENED,
                        DECISION_UNDER_REVIEW: onceki.state}[decision]
                an = _now()
                kanit = json.dumps(evidence or {}, ensure_ascii=False,
                                   default=str)[:8000]
                cur = conn.execute(
                    "INSERT INTO send_resolutions (resolution_id, period, "
                    "company_code, decision, basis_row_id, prior_state, "
                    "new_state, reason, user, role, at, evidence) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                    (rid, period, company_code, decision,
                     onceki.basis_row_id, onceki.state, yeni, gerekce[:1000],
                     user, role, an, kanit))
                satir_id = int(cur.lastrowid or 0)
                conn.execute("COMMIT")
            except BaseException:
                try:
                    conn.execute("ROLLBACK")
                except sqlite3.Error:
                    pass
                raise
        finally:
            conn.close()
        return AppendOutcome(True, onceki, SendResolution(
            id=satir_id, resolution_id=rid, period=period,
            company_code=company_code, decision=decision,
            basis_row_id=onceki.basis_row_id, prior_state=onceki.state,
            new_state=yeni, reason=gerekce[:1000], user=user, role=role,
            at=an, evidence=evidence or {}))

    def unknown_sends(self, period: Optional[str] = None) -> list[MailLogEntry]:
        """Sonucu belirsiz kalan gönderimler (insan incelemesi gerekir)."""
        return self.entries(period=period, status=STATUS_SEND_UNKNOWN)

    def entries(self, period: Optional[str] = None,
                status: Optional[str] = None,
                send_id: Optional[str] = None) -> list[MailLogEntry]:
        sql = ("SELECT company_code, period, status, company_name, locale, "
               "directions, recipients, subject, attachments, reason, "
               "run_id, sent_at, message_id, conversation_id, mail_status, "
               "send_id, snapshot_id, responsible, entry_id, "
               "identity_verified "
               "FROM mail_sends")
        where, params = [], []
        if period:
            where.append("period = ?")
            params.append(period)
        if status:
            where.append("status = ?")
            params.append(status)
        if send_id:
            where.append("send_id = ?")
            params.append(send_id)
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY id"
        try:
            with self._session() as conn:
                rows = conn.execute(sql, params).fetchall()
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"Mail günlüğü okunamadı: {exc}")
            return []
        return [self._entry_from_row(r) for r in rows]

    @staticmethod
    def _entry_from_row(r) -> MailLogEntry:
        """``_ENTRY_COLUMNS`` sırasındaki satırı ``MailLogEntry``ye çevir."""
        try:
            ekler = tuple(json.loads(r[8] or "[]"))
        except (TypeError, ValueError):
            ekler = ()
        return MailLogEntry(
            company_code=r[0], period=r[1], status=r[2],
            company_name=r[3] or "", locale=r[4] or "",
            directions=r[5] or "", recipients=r[6] or "",
            subject=r[7] or "", attachments=ekler,
            reason=r[9] or "", run_id=r[10], sent_at=r[11],
            message_id=r[12] or "", conversation_id=r[13] or "",
            mail_status=r[14] or "",
            send_id=r[15] or "", snapshot_id=r[16] or "",
            responsible=r[17] or "",
            entry_id=r[18] or "",
            identity_verified=_flag(r[19]),
        )

    # -- gelen cevabı gönderilen maile bağlama ------------------------------

    def tracked_mails(self, period: Optional[str] = None) -> list[MailLogEntry]:
        """MutabakatPro'nun GÖNDERDİĞİ (dolayısıyla takip ettiği) mailler.

        Gelen kutusu taraması yalnızca bu kayıtların zincirine bakar; genel
        Inbox trafiği (reklam, şirket içi yazışma, kişisel mail) mutabakat
        sistemine hiç girmez.

        ``SEND_UNKNOWN`` kayıtları DA takip edilir: o mail gitmiş olabilir ve
        firma cevap verebilir. Takip dışında bırakılsaydı gelen gerçek cevap
        "ilgisiz" sayılıp sessizce atılırdı.
        """
        return [e for e in self.entries(period=period)
                if e.status in NO_RESEND_STATUSES]

    def update_tracking(self, company_code: str, period: str, *,
                        message_id: str = "", conversation_id: str = "",
                        mail_status: str = "", send_id: str = "",
                        entry_id: str = "",
                        identity_verified: bool = False) -> bool:
        """Gönderim sonrası öğrenilen kimlikleri/durumu kaydet.

        Yalnızca DOLU verilen alanlar güncellenir; boş değerle var olan bir
        kimlik ezilmez (Outlook bazen ConversationID'yi geç verir).

        HEDEF SEÇİMİ
            ``send_id`` verilirse YALNIZCA o gönderim güncellenir. Bu tercih
            edilen yoldur: aynı firmaya aynı dönemde ikinci bir mail
            gittiyse, ``company_code + period`` ile yapılan güncelleme İKİ
            KAYDI BİRDEN ezer ve gelen cevap yanlış mutabakata bağlanır.

            ``send_id`` yoksa (eski kayıtlar, ilk kez tamamlanan kimlikler)
            firma + dönem kullanılır ama yalnızca kimliği HENÜZ BOŞ OLAN
            satırlar güncellenir — böylece daha önce doğru kimliği almış bir
            gönderim asla ezilmez.
        """
        fields, params = [], []
        for name, value in (("message_id", message_id),
                            ("conversation_id", conversation_id),
                            ("mail_status", mail_status),
                            ("entry_id", entry_id)):
            if value:
                fields.append(f"{name} = ?")
                params.append(value)
        # Doğrulama bayrağı yalnızca TRUE yönünde yazılır: bir kez gönderilmiş
        # öğeden okunmuş kimlik, sonraki kısmi güncellemeyle "doğrulanmamış"a
        # düşmemelidir.
        if identity_verified:
            fields.append("identity_verified = 1")
        if not fields:
            return False
        if send_id:
            where = "send_id = ?"
            params.append(send_id)
        else:
            # Kimlik yazılacak kolonlar HÂLÂ BOŞ olan en son gönderim seçilir
            # ve TEK SATIR güncellenir. Böylece daha önce doğru kimliğini almış
            # bir gönderim hiçbir koşulda ezilmez.
            conditions = ["company_code = ?", "period = ?"]
            # DOĞRULANMIŞ kimlik yazarken "kolon boş olsun" koşulu ARANMAZ:
            # gönderim anında yazılan (taslak) EntryID kasten ÜZERİNE yazılır,
            # çünkü öğe Gönderilmiş Öğeler'e taşınınca o kimlik geçersizdir.
            if not identity_verified:
                for name, value in (("message_id", message_id),
                                    ("conversation_id", conversation_id),
                                    ("entry_id", entry_id)):
                    if value:
                        conditions.append(f"COALESCE({name}, '') = ''")
            where = ("id = (SELECT id FROM mail_sends WHERE "
                     + " AND ".join(conditions)
                     + " ORDER BY id DESC LIMIT 1)")
            params.extend([company_code, period])
        try:
            with self._session() as conn:
                conn.execute(
                    f"UPDATE mail_sends SET {', '.join(fields)} WHERE {where}",
                    params)
            return True
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"Mail günlüğü güncellenemedi ({company_code}): {exc}")
            return False

    def entry_by_send_id(self, send_id: str) -> Optional[MailLogEntry]:
        """Tek bir gönderimi kimliğiyle getir."""
        if not send_id:
            return None
        # Filtre VERİTABANINDA uygulanır. Eskiden tüm günlük belleğe alınıp
        # Python'da taranıyordu; binlerce gönderimde her çağrı tabloyu
        # baştan sona okuyordu.
        rows = self.entries(send_id=send_id)
        return rows[0] if rows else None

    def summary(self, period: str) -> dict[str, int]:
        """Dönem özeti: durum -> adet."""
        try:
            with self._session() as conn:
                rows = conn.execute(
                    "SELECT status, COUNT(*) FROM mail_sends "
                    "WHERE period = ? GROUP BY status", (period,),
                ).fetchall()
            return {r[0]: r[1] for r in rows}
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"Mail günlüğü okunamadı: {exc}")
            return {}


def period_key(year: int, month: int) -> str:
    """Günlükte kullanılan dönem anahtarı."""
    return f"{year}-{month:02d}"
