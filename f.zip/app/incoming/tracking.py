"""Gelen maili GÖNDERDİĞİMİZ mutabakat mailine bağlama (kapsam kontrolü).

KESİN KURAL (görev şartı)
    Bu sistem genel bir Outlook asistanı DEĞİLDİR. Yalnızca MutabakatPro
    tarafından gönderilmiş mutabakat maillerinin zinciri işlenir. Reklam,
    şirket içi yazışma, kişisel mail ve ilgisiz müşteri maili mutabakat
    hattına HİÇ girmez.

    Bir gelen mail ancak güvenilir biçimde bir mutabakat kaydına
    bağlanabiliyorsa işleme alınır. Bağlanamıyorsa ``UNRELATED`` olarak
    dışarıda bırakılır (teslim hatası ise ``UNKNOWN_DELIVERY_FAILURE`` ile
    insan incelemesine düşer — sessizce atılmaz).

EŞLEŞTİRME SIRASI (güçlüden zayıfa)
    1. In-Reply-To / References  →  gönderdiğimiz Message-ID   (kesin)
    2. ConversationID            →  gönderim zinciri            (kesin)
    3. Teslim hatası içindeki orijinal Message-ID               (kesin)
    4. Teslim hatasındaki başarısız adres + dönem               (güçlü)
    5. Gönderen adresi alıcılarımızda + konu benzerliği         (orta)
    Konu TEK BAŞINA asla yeterli değildir.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Iterable, Optional

from app.incoming.delivery_failure import (
    DeliveryFailureInfo,
    detect_delivery_failure,
    is_automatic_reply,
)


class MailKind(str, Enum):
    """Gelen mailin mutabakat açısından türü."""

    CUSTOMER_REPLY = "CUSTOMER_REPLY"
    DELIVERY_FAILURE = "DELIVERY_FAILURE"
    AUTOMATIC_REPLY = "AUTOMATIC_REPLY"
    UNRELATED = "UNRELATED"                 # mutabakatla ilgisi yok → atlanır


class MatchMethod(str, Enum):
    """Eşleştirmenin hangi kanıta dayandığı (denetim için)."""

    IN_REPLY_TO = "IN_REPLY_TO"
    REFERENCES = "REFERENCES"
    CONVERSATION_ID = "CONVERSATION_ID"
    NDR_ORIGINAL_MESSAGE_ID = "NDR_ORIGINAL_MESSAGE_ID"
    NDR_RECIPIENT = "NDR_RECIPIENT"
    SENDER_AND_SUBJECT = "SENDER_AND_SUBJECT"
    # Mail BİZE ait bir mutabakatın cevabı ama HANGİ gönderime cevap verdiği
    # ayırt edilemiyor (aynı firmaya aynı dönemde birden çok mail gitmiş
    # olabilir). Tahmin YAPILMAZ; kayıt insan incelemesine düşer.
    AMBIGUOUS = "AMBIGUOUS"
    NONE = "NONE"


# Kesin kabul edilen yöntemler (konu benzerliği aranmaz).
_STRONG = frozenset({
    MatchMethod.IN_REPLY_TO, MatchMethod.REFERENCES,
    MatchMethod.CONVERSATION_ID, MatchMethod.NDR_ORIGINAL_MESSAGE_ID,
})

_MSGID_RE = re.compile(r"<[^>\s]+>")
_WORD_RE = re.compile(r"[0-9a-zçğıöşü]+")
# Konu başındaki cevap/iletme ekleri.
_PREFIX_RE = re.compile(r"^\s*((re|rv|ret|yan|ynt|ilt|fw|fwd|aw|sv)\s*:\s*)+",
                        re.I)
_TR_MAP = str.maketrans("ÇĞİIÖŞÜ", "çğiıöşü")


@dataclass(frozen=True)
class TrackedMail:
    """Gönderdiğimiz tek bir mutabakat maili (mail günlüğünden gelir)."""

    company_code: str
    period: str
    message_id: str = ""
    conversation_id: str = ""
    subject: str = ""
    recipients: tuple[str, ...] = ()
    company_name: str = ""

    # -- gönderim kimliği (FAZ 1/2) ----------------------------------------
    # Cevabın karşılaştırılacağı GERÇEK veri buradan bulunur:
    #     gelen mail -> send_id -> snapshot_id -> gönderilen FBL1H/FBL5H
    # ``company_code + period`` bir gönderimi TEKİL OLARAK belirtmez.
    send_id: str = ""
    snapshot_id: str = ""
    responsible: str = ""
    sent_at: str = ""
    # Gönderimin borç/alacak yönleri ("M", "S" ya da ikisi). Finansal ön
    # koşul kontrolü (bkz. financial_guard) bu yönü cevaptaki yönle
    # karşılaştırır; TEK yön varsa uyuşmazlık otomatik kararı durdurur.
    directions: tuple[str, ...] = ()

    @property
    def key(self) -> tuple[str, str]:
        return (self.company_code, self.period)

    @property
    def identity(self) -> str:
        """Bu gönderimin tekil kimliği (yoksa firma+döneme düşer)."""
        return self.send_id or f"{self.company_code}|{self.period}"

    @classmethod
    def from_log_entry(cls, entry) -> "TrackedMail":
        """``MailLogEntry`` → ``TrackedMail`` (günlükten okunanı kullanır)."""
        raw = getattr(entry, "recipients", "") or ""
        addresses = tuple(
            a.strip().lower()
            for a in raw.replace(",", ";").split(";") if a.strip())
        return cls(
            company_code=getattr(entry, "company_code", "") or "",
            period=getattr(entry, "period", "") or "",
            message_id=getattr(entry, "message_id", "") or "",
            conversation_id=getattr(entry, "conversation_id", "") or "",
            subject=getattr(entry, "subject", "") or "",
            recipients=addresses,
            company_name=getattr(entry, "company_name", "") or "",
            directions=tuple(
                d.strip().upper()
                for d in str(getattr(entry, "directions", "") or "")
                .replace(";", ",").split(",") if d.strip()),
            send_id=getattr(entry, "send_id", "") or "",
            snapshot_id=getattr(entry, "snapshot_id", "") or "",
            responsible=getattr(entry, "responsible", "") or "",
            sent_at=getattr(entry, "sent_at", "") or "",
        )


@dataclass
class MatchResult:
    """Bir gelen mailin sınıflandırma + eşleştirme sonucu."""

    kind: MailKind = MailKind.UNRELATED
    tracked: Optional[TrackedMail] = None
    method: MatchMethod = MatchMethod.NONE
    confidence: float = 0.0
    reason: str = ""
    failure: Optional[DeliveryFailureInfo] = None
    evidence: list[str] = field(default_factory=list)
    # Ayırt edilemeyen gönderim adayları. Doluysa mail BİZE aittir ama hangi
    # pakete cevap verildiği bilinmiyordur — tahmin edilmez, insana sorulur.
    candidates: list[TrackedMail] = field(default_factory=list)

    @property
    def matched(self) -> bool:
        return self.tracked is not None

    @property
    def ambiguous(self) -> bool:
        """Bize ait ama hangi gönderime cevap verildiği belirsiz mi?"""
        # Tek aday da bulunabilir fakat gönderen o gönderimin alıcılarından
        # biri değilse otomatik bağlanmaz; mail kaybolmadan incelemeye gider.
        return self.tracked is None and bool(self.candidates)

    @property
    def send_id(self) -> str:
        return self.tracked.send_id if self.tracked else ""

    @property
    def snapshot_id(self) -> str:
        return self.tracked.snapshot_id if self.tracked else ""

    @property
    def should_process(self) -> bool:
        """Hattın (parser + motor) çalıştırılması gerekir mi?

        İlgisiz mail işlenmez. Teslim hatası ve otomatik yanıt işlenir ama
        müşteri cevabı olarak DEĞİL — kendi türleriyle kaydedilir.
        Belirsiz eşleşme de işlenir: kaybolmasındansa insana sunulur.
        """
        return self.kind is not MailKind.UNRELATED


def _norm_subject(text: str) -> str:
    """Konuyu karşılaştırılabilir hâle getir (Re:/Fwd: ekleri ve büyük harf)."""
    cleaned = _PREFIX_RE.sub("", (text or "").translate(_TR_MAP).lower())
    return " ".join(_WORD_RE.findall(cleaned))


def _subject_similarity(reply: str, sent: str) -> float:
    """GÖNDERDİĞİMİZ konunun ne kadarı cevapta korunmuş (kapsama oranı).

    NEDEN JACCARD DEĞİL
        Jaccard (kesişim / birleşim) cevaba EKLENEN kelimeleri cezalandırır.
        Oysa firmalar konuya rutin olarak kendi adını, firma kodunu ya da
        "(imzalı)" gibi notlar ekler:

            "RE: Mutabakat Mektubu - Temmuz 2026 [ÖRNEK FİRMA / 4009668]"

        Bu gerçek bir cevaptır ama Jaccard'da 0.44 alıyordu ve EŞİĞİN ALTINDA
        kalarak cevabın kaybolmasına yol açıyordu. Kapsama oranı ise
        "bizim konumuz cevapta duruyor mu?" sorusunu sorar; ekleme onu bozmaz.

    Ölçüt: |gönderilen ∩ cevap| / |gönderilen|
    """
    sent_words = set(_norm_subject(sent).split())
    reply_words = set(_norm_subject(reply).split())
    if not sent_words or not reply_words:
        return 0.0
    return len(sent_words & reply_words) / len(sent_words)


# Dönem ayırt edici belirteçler: ay adları (TR/EN) ve yıl.
_MONTHS = {
    "ocak", "subat", "şubat", "mart", "nisan", "mayis", "mayıs", "haziran",
    "temmuz", "agustos", "ağustos", "eylul", "eylül", "ekim", "kasim",
    "kasım", "aralik", "aralık",
    "january", "february", "march", "april", "may", "june", "july",
    "august", "september", "october", "november", "december",
}
_YEAR_RE = re.compile(r"^(19|20)\d{2}$")


def _period_tokens(text: str) -> tuple[set[str], set[str]]:
    """Konudaki (ay, yıl) belirteçlerini çıkar."""
    words = set(_norm_subject(text).split())
    months = {w for w in words if w in _MONTHS}
    years = {w for w in words if _YEAR_RE.match(w)}
    return months, years


def _period_conflict(reply: str, sent: str) -> bool:
    """İki konu FARKLI dönemlere mi ait?

    KRİTİK KORUMA: "Mutabakat Mektubu - Haziran 2026" ile "… Temmuz 2026"
    kelimelerin çoğunu paylaşır. Yalnızca benzerliğe bakılırsa HAZİRAN cevabı
    TEMMUZ mutabakatına yazılırdı — finansal olarak yanlış bir kayıt. Her iki
    konuda da dönem belirteci varsa ve KESİŞMİYORSA eşleşme reddedilir.
    """
    reply_months, reply_years = _period_tokens(reply)
    sent_months, sent_years = _period_tokens(sent)
    if reply_months and sent_months and not (reply_months & sent_months):
        return True
    if reply_years and sent_years and not (reply_years & sent_years):
        return True
    return False


def _ids(text: str) -> set[str]:
    """Metindeki tüm <message-id> değerlerini çıkar."""
    return {m.strip() for m in _MSGID_RE.findall(text or "")}


class MailTracker:
    """Takip edilen gönderimler üzerinde hızlı eşleştirme yapar."""

    # Konu KAPSAMA eşiği: gönderdiğimiz konunun en az bu kadarı cevapta
    # korunmuş olmalı. Gerçekçi cevap konularıyla kalibre edilmiştir
    # (bkz. tests/test_subject_matching.py): 0.75'te tüm gerçek cevap
    # biçimleri yakalanır, ilgisiz mailler dışarıda kalır.
    subject_threshold: float = 0.75

    def __init__(self, tracked: Iterable[TrackedMail]) -> None:
        self._tracked = list(tracked)
        self._by_message_id: dict[str, TrackedMail] = {}
        # Zincir kimliği TEKİL DEĞİLDİR: aynı konuşmaya ikinci bir mutabakat
        # maili gönderilirse iki gönderim aynı ConversationID'yi paylaşır.
        # Bu yüzden liste tutulur; tek aday varsa kesin eşleşme, birden çok
        # aday varsa BELİRSİZLİK (tahmin yapılmaz).
        self._by_conversation: dict[str, list[TrackedMail]] = {}
        self._by_recipient: dict[str, list[TrackedMail]] = {}
        for item in self._tracked:
            if item.message_id:
                self._by_message_id.setdefault(item.message_id.strip(), item)
            if item.conversation_id:
                self._by_conversation.setdefault(
                    item.conversation_id.strip(), []).append(item)
            for address in item.recipients:
                self._by_recipient.setdefault(address, []).append(item)

    @classmethod
    def from_mail_log(cls, log, period: Optional[str] = None) -> "MailTracker":
        """Mail günlüğündeki GÖNDERİLMİŞ kayıtlardan izleyici kur."""
        return cls(TrackedMail.from_log_entry(e)
                   for e in log.tracked_mails(period=period))

    @property
    def tracked_count(self) -> int:
        return len(self._tracked)

    # -- ana giriş ---------------------------------------------------------

    def match(self, mail) -> MatchResult:
        """Gelen maili sınıflandır ve mümkünse bir gönderime bağla."""
        failure = detect_delivery_failure(
            subject=getattr(mail, "subject", "") or "",
            body=getattr(mail, "body", "") or "",
            sender=getattr(mail, "sender", "") or "",
            sender_name=getattr(mail, "sender_name", "") or "",
            message_class=getattr(mail, "message_class", "") or "",
        )

        result = self._link(mail, failure)

        if failure.is_failure:
            result.kind = MailKind.DELIVERY_FAILURE
            result.failure = failure
            if result.tracked is None:
                result.reason = ("Teslim hatası, ilgili mutabakat maili "
                                 "bulunamadı (insan incelemesi).")
            return result

        if result.tracked is None:
            if result.ambiguous:
                # Mail BİZE ait: birden çok gönderim adayı var ama hangisine
                # cevap verildiği ayırt edilemiyor. Tahmin YAPILMAZ; kayıt
                # işlenir ve insan incelemesine düşer (FAZ 5 zorunlu kılar).
                result.kind = MailKind.CUSTOMER_REPLY
                adaylar = ", ".join(
                    sorted({c.identity for c in result.candidates})[:5])
                result.reason = (
                    f"{len(result.candidates)} gönderim adayı var; hangi "
                    f"mutabakat paketine cevap verildiği belirsiz ({adaylar}). "
                    "İnsan incelemesi gerekli.")
                return result
            result.kind = MailKind.UNRELATED
            result.reason = ("Takip edilen bir mutabakat mailine "
                             "bağlanamadı; atlandı.")
            return result

        if is_automatic_reply(getattr(mail, "subject", ""),
                              getattr(mail, "body", "")):
            result.kind = MailKind.AUTOMATIC_REPLY
            result.reason = "Otomatik yanıt / ofis dışı mesajı."
            return result

        result.kind = MailKind.CUSTOMER_REPLY
        return result

    # -- eşleştirme adımları -----------------------------------------------

    def _link(self, mail, failure: DeliveryFailureInfo) -> MatchResult:
        sender = (getattr(mail, "sender", "") or "").strip().lower()

        def strong(hit: TrackedMail, method: MatchMethod, confidence: float,
                   evidence: list[str]) -> MatchResult:
            # Güçlü başlık kimliği tek başına göndereni yetkilendirmez.
            # NDR gibi sistem cevapları aşağıdaki ayrı teslim-hatası yolunda
            # işlenir. Alias/forward ihtimali nedeniyle şüpheli cevap atılmaz.
            recipients = {a.strip().lower() for a in hit.recipients if a}
            if sender and recipients and sender not in recipients:
                return MatchResult(
                    candidates=[hit], method=MatchMethod.AMBIGUOUS,
                    confidence=0.0,
                    reason="Zincir eşleşti ancak gönderen yetkili alıcılarla eşleşmedi.",
                    evidence=evidence + [f"unauthorized_sender={sender}"])
            return MatchResult(tracked=hit, method=method,
                               confidence=confidence, evidence=evidence)

        # 1) In-Reply-To → gönderdiğimiz Message-ID (en kesin).
        for candidate in _ids(getattr(mail, "in_reply_to", "")):
            hit = self._by_message_id.get(candidate)
            if hit is not None:
                return strong(hit, MatchMethod.IN_REPLY_TO, 1.0,
                              [f"in_reply_to={candidate}"])

        # 2) References zinciri.
        for candidate in _ids(getattr(mail, "references", "")):
            hit = self._by_message_id.get(candidate)
            if hit is not None:
                return strong(hit, MatchMethod.REFERENCES, 0.98,
                              [f"references={candidate}"])

        # 3) ConversationID.
        conversation = (getattr(mail, "conversation_id", "") or "").strip()
        if conversation:
            hits = self._by_conversation.get(conversation) or []
            if len(hits) == 1:
                return strong(hits[0], MatchMethod.CONVERSATION_ID, 0.97,
                              [f"conversation_id={conversation}"])
            if len(hits) > 1:
                # Aynı zincirde birden çok gönderim var. YANLIŞ SNAPSHOT
                # seçmektense hangi pakete cevap verildiğini insana sorarız.
                return MatchResult(
                    candidates=list(hits), method=MatchMethod.AMBIGUOUS,
                    confidence=0.0,
                    evidence=[f"conversation_id={conversation}",
                              f"aday_gonderim={len(hits)}"])

        # 4) Teslim hatası: bildirimin içindeki orijinal Message-ID.
        if failure.is_failure and failure.original_message_id:
            hit = self._by_message_id.get(failure.original_message_id.strip())
            if hit is not None:
                return MatchResult(
                    tracked=hit, method=MatchMethod.NDR_ORIGINAL_MESSAGE_ID,
                    confidence=0.96,
                    evidence=[f"ndr_original={failure.original_message_id}"])

        # 5) Teslim hatası: ulaşılamayan adres → alıcı listemiz.
        if failure.is_failure and failure.failed_recipient:
            hit = self._unique_by_recipient(failure.failed_recipient,
                                            failure.original_subject)
            if hit is not None:
                return MatchResult(
                    tracked=hit, method=MatchMethod.NDR_RECIPIENT,
                    confidence=0.85,
                    evidence=[f"failed_recipient={failure.failed_recipient}"])

        # 6) Gönderen adresi + konu benzerliği (en zayıf; konu TEK BAŞINA yetmez).
        subject = getattr(mail, "subject", "") or ""
        if sender:
            hit, tied = self._resolve_by_recipient(sender, subject)
            if hit is not None:
                score = _subject_similarity(subject, hit.subject)
                return MatchResult(
                    tracked=hit, method=MatchMethod.SENDER_AND_SUBJECT,
                    confidence=round(0.6 + 0.3 * score, 3),
                    evidence=[f"sender={sender}",
                              f"subject_similarity={score:.2f}"])
            if len(tied) > 1:
                # Mail bize ait bir mutabakatın cevabı ama HANGİSİ belli değil.
                # Eskiden bu kayıt sessizce "ilgisiz" sayılıp kayboluyordu.
                return MatchResult(
                    candidates=list(tied), method=MatchMethod.AMBIGUOUS,
                    confidence=0.0,
                    evidence=[f"sender={sender}",
                              f"aday_gonderim={len(tied)}"])
        return MatchResult()

    def _unique_by_recipient(self, address: str,
                             subject: str) -> Optional[TrackedMail]:
        """Adrese göre TEK aday bul (geriye dönük uyumlu yardımcı)."""
        return self._resolve_by_recipient(address, subject)[0]

    def _resolve_by_recipient(self, address: str, subject: str
                              ) -> tuple[Optional[TrackedMail],
                                         list[TrackedMail]]:
        """Adrese göre aday bul; birden çok aday varsa konuyla ayır.

        Döner: ``(kesin_aday, ayirt_edilemeyen_adaylar)``. Ayırt edilemiyorsa
        ilk değer ``None``dır — yanlış mutabakata bağlamaktansa insana sormak
        doğrudur; ikinci değer o kararı verecek adayları taşır.
        """
        candidates = self._by_recipient.get((address or "").strip().lower())
        if not candidates:
            return None, []
        # Farklı döneme ait konular baştan elenir: Haziran cevabı Temmuz
        # mutabakatına ASLA yazılmamalıdır.
        if subject:
            candidates = [c for c in candidates
                          if not (c.subject and _period_conflict(subject, c.subject))]
        if not candidates:
            return None, []
        if len(candidates) == 1:
            # Tek aday: konu benzerliği aranmaz ama tamamen alakasız bir konu
            # da kabul edilmez (aynı firmadan gelen ilgisiz mail olabilir).
            only = candidates[0]
            if not subject or not only.subject:
                return only, []
            if _subject_similarity(subject, only.subject) >= self.subject_threshold:
                return only, []
            return None, []
        scored = sorted(
            ((_subject_similarity(subject, c.subject), c) for c in candidates),
            key=lambda pair: (-pair[0], pair[1].period, pair[1].company_code))
        best_score, best = scored[0]
        if best_score < self.subject_threshold:
            return None, []
        # İlk iki aday eşit skorluysa ayırt edilemiyor demektir. Konu aynı
        # olduğu için hangi GÖNDERİME cevap verildiği bilinemez; en yüksek
        # skoru paylaşan adayların hepsi insana sunulur.
        tied = [c for score, c in scored if abs(score - best_score) < 1e-9]
        if len(tied) > 1:
            return None, tied
        return best, []


def filter_relevant(mails: Iterable, tracker: MailTracker
                    ) -> list[tuple[object, MatchResult]]:
    """Gelen kutusunu mutabakatla İLGİLİ maillere indir.

    Dönen listede yalnızca işlenecek mailler vardır; ilgisiz mailler hiç
    ayrıştırılmaz, AI'ya gönderilmez ve ek indirilmez.
    """
    out: list[tuple[object, MatchResult]] = []
    for mail in mails:
        match = tracker.match(mail)
        if match.should_process:
            out.append((mail, match))
    return out
