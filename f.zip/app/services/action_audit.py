"""Kullanıcı işlemlerinin SALT EKLENİR denetim günlüğü (madde 7).

NE KAYDEDİLİR
    Gönderim, adres değiştirme, fark kapatma, manuel mutabakat, rol
    değişikliği ve politika değişikliği — kullanıcı adı, zaman, hedef kayıt,
    eski/yeni değer ve (finansal kararlarda) ZORUNLU gerekçe ile.

SİLİNEMEZ
    Bu modülde silme/temizleme/güncelleme API'si YOKTUR. Kayıt yalnızca
    eklenir; veritabanı ayrıca ``AFTER DELETE`` ve ``AFTER UPDATE``
    tetikleyicileriyle korunur, böylece uygulama içinden yapılacak bir SQL
    çağrısı da geçmişi değiştiremez.

ASLA ÇÖKERTMEZ
    Günlük yazılamazsa hata loglanır ve iş devam eder: denetim kaydı
    tutulamadı diye kullanıcının mutabakatı durmaz.
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional, Sequence

from loguru import logger

from app.utils.paths import app_data_dir
from app.utils.sqlite import open_sqlite_connection

# Denetlenen işlem türleri (serbest metin de kabul edilir).
ACTION_MAIL_SENT = "MAIL_SENT"
ACTION_ADDRESS_CHANGED = "ADDRESS_CHANGED"
ACTION_DIFFERENCE_CLOSED = "DIFFERENCE_CLOSED"
ACTION_MANUAL_RECONCILE = "MANUAL_RECONCILE"
ACTION_DECISION_CHANGED = "FINANCIAL_DECISION_CHANGED"
ACTION_ROLE_CHANGED = "ROLE_CHANGED"
ACTION_POLICY_CHANGED = "POLICY_CHANGED"
# SEND_UNKNOWN çözümü: karar iki satırla izlenir (detail: phase=ATTEMPT ->
# phase=APPLIED). Yalnız ATTEMPT varsa durum DEĞİŞMEMİŞTİR (çökme/iptal).
ACTION_SEND_UNKNOWN_RESOLUTION = "SEND_UNKNOWN_RESOLUTION"
ACTION_SEND_UNKNOWN_DENIED = "SEND_UNKNOWN_RESOLUTION_DENIED"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass(frozen=True)
class AuditEntry:
    """Denetim günlüğündeki tek bir satır."""

    action: str
    user: str = ""
    target: str = ""
    company_code: str = ""
    period: str = ""
    old_value: str = ""
    new_value: str = ""
    reason: str = ""
    detail: str = ""
    at: str = ""


class ActionAuditLog:
    """Kullanıcı işlemlerinin kalıcı, salt eklenir denetim günlüğü."""

    _COLUMNS = ("action, user, target, company_code, period, old_value, "
                "new_value, reason, detail, at")

    def __init__(self, path: str | Path | None = None) -> None:
        if path is None:
            base = app_data_dir()
            base.mkdir(parents=True, exist_ok=True)
            path = base / "action_audit.db"
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    @property
    def path(self) -> Path:
        return self._path

    @contextmanager
    def _session(self):
        conn = open_sqlite_connection(self._path)
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _ensure_schema(self) -> None:
        try:
            with self._session() as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS action_audit (
                        id           INTEGER PRIMARY KEY AUTOINCREMENT,
                        action       TEXT NOT NULL,
                        user         TEXT NOT NULL DEFAULT '',
                        target       TEXT NOT NULL DEFAULT '',
                        company_code TEXT NOT NULL DEFAULT '',
                        period       TEXT NOT NULL DEFAULT '',
                        old_value    TEXT NOT NULL DEFAULT '',
                        new_value    TEXT NOT NULL DEFAULT '',
                        reason       TEXT NOT NULL DEFAULT '',
                        detail       TEXT NOT NULL DEFAULT '',
                        at           TEXT NOT NULL
                    )
                """)
                conn.execute("CREATE INDEX IF NOT EXISTS ix_audit_action "
                             "ON action_audit (action, at)")
                # GEÇMİŞ DEĞİŞTİRİLEMEZ: silme ve güncelleme veritabanı
                # seviyesinde reddedilir. Uygulama içinden yazılacak bir SQL
                # de bu tetikleyiciyi aşamaz.
                conn.execute("""
                    CREATE TRIGGER IF NOT EXISTS trg_audit_no_delete
                    BEFORE DELETE ON action_audit
                    BEGIN
                        SELECT RAISE(ABORT,
                            'Denetim kaydı silinemez.');
                    END
                """)
                conn.execute("""
                    CREATE TRIGGER IF NOT EXISTS trg_audit_no_update
                    BEFORE UPDATE ON action_audit
                    BEGIN
                        SELECT RAISE(ABORT,
                            'Denetim kaydı değiştirilemez.');
                    END
                """)
        except sqlite3.Error as exc:  # pragma: no cover - ortam bağımlı
            logger.error(f"[denetim] şema kurulamadı: {exc}")

    # -- yazma (yalnızca EKLEME) -------------------------------------------

    def record(self, action: str, *, user: str = "", target: str = "",
               company_code: str = "", period: str = "", old_value: str = "",
               new_value: str = "", reason: str = "", detail: str = "") -> bool:
        """İşlemi günlüğe ekle. Yazılamazsa loglar, ``False`` döner."""
        if not user:
            from app.services.authz import current_user

            user = current_user()
        try:
            with self._session() as conn:
                conn.execute(f"""
                    INSERT INTO action_audit ({self._COLUMNS})
                    VALUES (?,?,?,?,?,?,?,?,?,?)
                """, (action, user, target, company_code, period,
                      str(old_value or "")[:500], str(new_value or "")[:500],
                      str(reason or "")[:1000], str(detail or "")[:1000],
                      _now()))
            return True
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[denetim] kayıt yazılamadı ({action}): {exc}")
            return False

    # -- okuma -------------------------------------------------------------

    @staticmethod
    def _row(row: Sequence[Any]) -> AuditEntry:
        return AuditEntry(action=row[0], user=row[1], target=row[2],
                          company_code=row[3], period=row[4],
                          old_value=row[5], new_value=row[6], reason=row[7],
                          detail=row[8], at=row[9])

    def entries(self, *, action: Optional[str] = None,
                user: Optional[str] = None,
                company_code: Optional[str] = None) -> list[AuditEntry]:
        sql = f"SELECT {self._COLUMNS} FROM action_audit"
        where, params = [], []
        for alan, deger in (("action", action), ("user", user),
                            ("company_code", company_code)):
            if deger:
                where.append(f"{alan} = ?")
                params.append(deger)
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY id"
        try:
            with self._session() as conn:
                rows = conn.execute(sql, params).fetchall()
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[denetim] okunamadı: {exc}")
            return []
        return [self._row(r) for r in rows]

    def count(self) -> int:
        try:
            with self._session() as conn:
                return int(conn.execute(
                    "SELECT COUNT(*) FROM action_audit").fetchone()[0])
        except sqlite3.Error:  # pragma: no cover
            return 0
