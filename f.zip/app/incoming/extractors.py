"""Ek dosyalardan DETERMİNİSTİK içerik çıkarımı (PDF / Excel / CSV / metin).

Bu katman AI'ya HİÇ dokunmaz. Amacı tek: "Python bu dosyadan ne okuyabiliyor?"
sorusunu net biçimde cevaplamak. Okuyamadığında sessiz kalmaz, ``read_error``
alanına gerekçe yazar; hattın üst katmanı bunu insan incelemesi ya da AI
fallback tetikleyicisi olarak kullanır.

Yalnızca projede zaten kurulu kütüphaneler kullanılır (pdfplumber, pypdf,
openpyxl, xlrd, pandas gerekmez). Harici program (Ghostscript / Poppler /
ImageMagick) ÇAĞRILMAZ.
"""

from __future__ import annotations

import csv
import io
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from html.parser import HTMLParser
from typing import Optional

from app.incoming.models import MAX_ATTACHMENT_BYTES, IncomingAttachment
from app.incoming.textutil import fold, html_to_text
from app.utils.file_safety import UnsafeInputError, validate_input_bytes

# Güvenlik sınırları: bozuk/aşırı büyük bir ek uygulamayı kilitlemesin.
MAX_PDF_PAGES = 40
MAX_EXCEL_ROWS = 2000
MAX_EXCEL_COLS = 40
MAX_TEXT_CHARS = 400_000

_PDF_EXT = {".pdf"}
_EXCEL_EXT = {".xlsx", ".xlsm", ".xltx", ".xls"}
_CSV_EXT = {".csv", ".tsv"}
_TEXT_EXT = {".txt", ".log"}
_HTML_EXT = {".htm", ".html"}
_IMAGE_EXT = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".emf",
              ".wmf", ".svg", ".ico"}

# Outlook'un mail gövdesine gömdüğü imza/logo görselleri. Bunlar "okunamayan
# ek" sayılıp insan incelemesi tetiklememeli.
_INLINE_IMAGE_RE = re.compile(r"^(image\d+|oledata|logo|imza|signature|banner)",
                              re.IGNORECASE)
INLINE_IMAGE_MAX_SIZE = 200_000


@dataclass
class TableData:
    """Tek bir tablo/sayfa: başlık + satırlar (hepsi string'e indirgenmiş)."""

    name: str = ""
    rows: list[list[str]] = field(default_factory=list)
    truncated: bool = False

    @property
    def header(self) -> list[str]:
        return self.rows[0] if self.rows else []

    @property
    def data_rows(self) -> list[list[str]]:
        return self.rows[1:] if len(self.rows) > 1 else []


def is_inline_image(attachment: IncomingAttachment) -> bool:
    """Mail gövdesine gömülü küçük görsel mi? (logo / imza resmi / banner)"""
    if attachment.extension not in _IMAGE_EXT:
        return False
    name = (attachment.filename or "").rsplit(".", 1)[0]
    if _INLINE_IMAGE_RE.match(name.strip()):
        return True
    return 0 < attachment.size <= INLINE_IMAGE_MAX_SIZE and not name.strip()


def _content_of(attachment: IncomingAttachment) -> bytes:
    """Ekin baytları; yoksa diskten okumayı dener."""
    if attachment.content:
        return attachment.content
    if attachment.path:
        from pathlib import Path

        target = Path(attachment.path)
        # BOYUT ÖNCE KONTROL EDİLİR: 500 MB'lık bir PDF'i doğrudan belleğe
        # almak süreci düşürür. Outlook tarafındaki okuyucu aynı sınırı
        # zaten uyguluyor; disk yolundan okuma da uygulamalı.
        try:
            size = target.stat().st_size
        except OSError as exc:
            raise ValueError(f"ek dosyası okunamadı: {exc}") from exc
        if size > MAX_ATTACHMENT_BYTES:
            raise ValueError(
                f"ek çok büyük ({size} bayt); belleğe alınmadı.")
        try:
            return target.read_bytes()
        except OSError as exc:
            raise ValueError(f"ek dosyası okunamadı: {exc}") from exc
    raise ValueError("ek içeriği boş")


# --- PDF ---------------------------------------------------------------------

@dataclass
class PdfExtract:
    text: str = ""
    page_count: int = 0
    extracted_page_count: int = 0
    truncated: bool = False
    image_count: int = 0
    has_text_layer: bool = False
    has_digital_signature: Optional[bool] = None
    tables: list[list[list[str]]] = field(default_factory=list)
    error: str = ""


def extract_pdf(data: bytes) -> PdfExtract:
    """PDF'ten metin, tablo, görsel sayısı ve dijital imza bilgisi çıkar.

    Metin katmanı yoksa (taranmış belge) hata DEĞİL, bilgi üretilir:
    ``has_text_layer=False``. Bu, üst katmanın "AI'ya sor / insana sor"
    kararını verebilmesi için gereken sinyaldir.
    """
    result = PdfExtract()
    if not data:
        result.error = "PDF içeriği boş."
        return result

    try:
        import pdfplumber
    except ImportError as exc:  # pragma: no cover - kurulum sorunu
        result.error = f"pdfplumber yok: {exc}"
        return result

    chunks: list[str] = []
    try:
        with pdfplumber.open(io.BytesIO(data)) as pdf:
            result.page_count = len(pdf.pages)
            pages = pdf.pages[:MAX_PDF_PAGES]
            result.extracted_page_count = len(pages)
            result.truncated = result.page_count > result.extracted_page_count
            for page in pages:
                try:
                    text = page.extract_text() or ""
                except Exception:  # noqa: BLE001 - tek sayfa bozuksa diğerleri okunsun
                    text = ""
                if text:
                    chunks.append(text)
                try:
                    result.image_count += len(page.images or [])
                except Exception:  # noqa: BLE001
                    pass
                try:
                    for table in (page.extract_tables() or []):
                        rows = [[("" if c is None else str(c).strip()) for c in row]
                                for row in table if row]
                        if rows:
                            result.tables.append(rows)
                except Exception:  # noqa: BLE001 - tablo çıkarımı opsiyoneldir
                    pass
    except Exception as exc:  # noqa: BLE001 - bozuk/şifreli PDF çökertmesin
        result.error = f"PDF okunamadı: {type(exc).__name__}: {exc}"
        return result

    result.text = "\n".join(chunks)[:MAX_TEXT_CHARS]
    result.has_text_layer = bool(result.text.strip())
    result.has_digital_signature = _detect_digital_signature(data)
    return result


def _detect_digital_signature(data: bytes) -> Optional[bool]:
    """PDF'te DOLDURULMUŞ bir imza alanı (AcroForm ``/Sig``) var mı?

    Bu, imzanın deterministik olarak KANITLANABİLDİĞİ tek durumdur. Görsel
    (ıslak) imza buradan görülmez; o yüzden None dönebilir → belirsizlik
    yukarı taşınır, uydurma yapılmaz.
    """
    try:
        import pypdf

        reader = pypdf.PdfReader(io.BytesIO(data))
        root = reader.trailer.get("/Root")
        if root is None:
            return None
        root = root.get_object()
        acro = root.get("/AcroForm")
        if acro is None:
            return False
        acro = acro.get_object()
        fields = acro.get("/Fields") or []
        for ref in fields:
            try:
                obj = ref.get_object()
            except Exception:  # noqa: BLE001
                continue
            if str(obj.get("/FT")) == "/Sig" and obj.get("/V") is not None:
                return True
        return False
    except Exception:  # noqa: BLE001 - imza tespiti asla çökertmez
        return None


# --- Excel / CSV -------------------------------------------------------------

@dataclass
class TableExtract:
    tables: list[TableData] = field(default_factory=list)
    error: str = ""

    @property
    def row_count(self) -> int:
        return sum(len(t.rows) for t in self.tables)


def _cell_to_text(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def extract_excel(data: bytes, filename: str = "") -> TableExtract:
    """Excel'i normalize satırlara indir (.xlsx/.xlsm ve eski .xls)."""
    result = TableExtract()
    if not data:
        result.error = "Excel içeriği boş."
        return result
    try:
        validate_input_bytes(data, filename or "ek.xlsx")
    except UnsafeInputError as exc:
        result.error = str(exc)
        return result

    ext = ("." + filename.rsplit(".", 1)[-1].lower()) if "." in filename else ""
    errors: list[str] = []

    # İçerik imzası uzantıdan daha güvenilirdir. Sahadaki bazı SAP/ERP
    # çıktıları OOXML olmasına rağmen yanlışlıkla `.xls` adıyla gelir.
    # Bu dosyayı doğrudan xlrd'ye vermek "Excel xlsx file; not supported"
    # hatası üretir ve okunabilir ek insan/AI incelemesine düşer.
    if ext != ".xls" or data[:2] == b"PK":
        try:
            return _extract_xlsx(data)
        except Exception as exc:  # noqa: BLE001 - eski .xls olabilir, denemeye devam
            errors.append(f"openpyxl: {type(exc).__name__}: {exc}")

    try:
        return _extract_xls(data)
    except Exception as exc:  # noqa: BLE001
        errors.append(f"xlrd: {type(exc).__name__}: {exc}")

    # Eski Excel dışa aktarımlarında `.xls` uzantılı HTML, SpreadsheetML XML
    # veya UTF-16 sekmeli metin sık görülür. Bunlar çalıştırılabilir içerik
    # değildir; yalnız hücre metinleri stdlib ile deterministik çıkarılır.
    try:
        fallback = _extract_textual_excel(data)
        if fallback.tables:
            return fallback
        if fallback.error:
            errors.append(fallback.error)
    except Exception as exc:  # noqa: BLE001 - bozuk metinsel dışa aktarım çökertmez
        errors.append(f"metinsel Excel: {type(exc).__name__}: {exc}")

    result.error = "Excel okunamadı — " + " | ".join(errors)
    return result


class _HtmlTableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tables: list[list[list[str]]] = []
        self._table: list[list[str]] | None = None
        self._row: list[str] | None = None
        self._cell: list[str] | None = None

    def handle_starttag(self, tag: str, attrs) -> None:
        tag = tag.lower()
        if tag == "table":
            self._table = []
        elif tag == "tr" and self._table is not None:
            self._row = []
        elif tag in {"td", "th"} and self._row is not None:
            self._cell = []

    def handle_data(self, data: str) -> None:
        if self._cell is not None:
            self._cell.append(data)

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in {"td", "th"} and self._cell is not None and self._row is not None:
            self._row.append(" ".join("".join(self._cell).split()))
            self._cell = None
        elif tag == "tr" and self._row is not None and self._table is not None:
            if any(self._row):
                self._table.append(self._row[:MAX_EXCEL_COLS])
            self._row = None
        elif tag == "table" and self._table is not None:
            if self._table:
                self.tables.append(self._table[:MAX_EXCEL_ROWS])
            self._table = None


def _extract_textual_excel(data: bytes) -> TableExtract:
    """`.xls` adı altında gelen HTML/XML/sekme metnini güvenle oku."""
    result = TableExtract()
    text = _decode(data)
    stripped = text.lstrip("\ufeff\x00\r\n\t ")
    lowered = stripped[:200].lower()

    if lowered.startswith(("<html", "<!doctype")):
        parser = _HtmlTableParser()
        try:
            parser.feed(stripped)
        except Exception as exc:  # noqa: BLE001
            result.error = f"HTML tablo okunamadı: {type(exc).__name__}: {exc}"
            return result
        result.tables = [TableData(name=f"html-{i + 1}", rows=rows,
                                   truncated=len(rows) >= MAX_EXCEL_ROWS)
                         for i, rows in enumerate(parser.tables)]
        return result

    if lowered.startswith("<?xml") or "<workbook" in lowered:
        try:
            root = ET.fromstring(stripped)
            rows: list[list[str]] = []
            for row in (node for node in root.iter()
                        if node.tag.rsplit("}", 1)[-1].lower() == "row"):
                cells = []
                for cell in (node for node in row.iter()
                             if node.tag.rsplit("}", 1)[-1].lower() == "cell"):
                    cells.append(" ".join("".join(cell.itertext()).split()))
                if any(cells):
                    rows.append(cells[:MAX_EXCEL_COLS])
                if len(rows) >= MAX_EXCEL_ROWS:
                    break
            if rows:
                result.tables.append(TableData(name="xml", rows=rows,
                                               truncated=len(rows) >= MAX_EXCEL_ROWS))
                return result
        except ET.ParseError as exc:
            result.error = f"XML tablo okunamadı: {exc}"
            return result

    # UTF-16/ANSI sekmeli ya da ayraçlı metin dışa aktarımı.
    sample = text[:4096]
    if "\t" in sample or ";" in sample or "," in sample:
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters="\t;,")
        except csv.Error:
            dialect = csv.excel_tab if "\t" in sample else csv.excel
        rows = []
        try:
            source = io.StringIO(text, newline="")
            for row in csv.reader(source, dialect):
                cells = [str(cell).strip() for cell in row[:MAX_EXCEL_COLS]]
                if any(cells):
                    rows.append(cells)
                if len(rows) >= MAX_EXCEL_ROWS:
                    break
        except csv.Error as exc:
            result.error = f"Ayraçlı tablo okunamadı: {exc}"
            return result
        if rows:
            result.tables.append(TableData(name="delimited", rows=rows,
                                           truncated=len(rows) >= MAX_EXCEL_ROWS))
    return result


def _extract_xlsx(data: bytes) -> TableExtract:
    from openpyxl import load_workbook

    result = TableExtract()
    wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    try:
        for ws in wb.worksheets:
            table = TableData(name=ws.title)
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i >= MAX_EXCEL_ROWS:
                    table.truncated = True
                    break
                cells = [_cell_to_text(c) for c in row[:MAX_EXCEL_COLS]]
                if any(cells):
                    table.rows.append(cells)
            if table.rows:
                result.tables.append(table)
    finally:
        wb.close()
    if not result.tables:
        result.error = "Excel içinde veri satırı yok."
    return result


def _extract_xls(data: bytes) -> TableExtract:
    import xlrd

    result = TableExtract()
    book = xlrd.open_workbook(file_contents=data)
    for sheet in book.sheets():
        table = TableData(name=sheet.name)
        for r in range(min(sheet.nrows, MAX_EXCEL_ROWS)):
            cells = [_cell_to_text(sheet.cell_value(r, c))
                     for c in range(min(sheet.ncols, MAX_EXCEL_COLS))]
            if any(cells):
                table.rows.append(cells)
        if sheet.nrows > MAX_EXCEL_ROWS:
            table.truncated = True
        if table.rows:
            result.tables.append(table)
    if not result.tables:
        result.error = "Excel içinde veri satırı yok."
    return result


def extract_csv(data: bytes) -> TableExtract:
    """CSV/TSV'yi ayraç tahminiyle satırlara indir."""
    result = TableExtract()
    text = _decode(data)
    if not text.strip():
        result.error = "CSV içeriği boş."
        return result
    sample = text[:4096]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=";,\t|")
    except csv.Error:
        dialect = csv.excel
        dialect.delimiter = ";" if sample.count(";") > sample.count(",") else ","
    table = TableData(name="csv")
    for i, row in enumerate(csv.reader(io.StringIO(text), dialect)):
        if i >= MAX_EXCEL_ROWS:
            table.truncated = True
            break
        cells = [str(c).strip() for c in row[:MAX_EXCEL_COLS]]
        if any(cells):
            table.rows.append(cells)
    if not table.rows:
        result.error = "CSV içinde veri satırı yok."
        return result
    result.tables.append(table)
    return result


def _decode(data: bytes) -> str:
    """Baytları metne çevir — Türkçe için UTF-8 → cp1254 → latin-1 sırası."""
    for encoding in ("utf-8-sig", "utf-8", "cp1254", "iso-8859-9", "latin-1"):
        try:
            return data.decode(encoding)
        except (UnicodeDecodeError, LookupError):
            continue
    return data.decode("utf-8", errors="replace")


def table_to_text(tables: list[TableData], max_rows: int = 60) -> str:
    """Tabloyu AI'ya/eşleştirmeye uygun düz metne çevir (satır başına tab)."""
    lines: list[str] = []
    for table in tables:
        if table.name:
            lines.append(f"# {table.name}")
        for row in table.rows[:max_rows]:
            lines.append("\t".join(row))
        if len(table.rows) > max_rows:
            lines.append(f"… ({len(table.rows) - max_rows} satır daha)")
    return "\n".join(lines)


# --- Tek giriş noktası -------------------------------------------------------

def extract_attachment(attachment: IncomingAttachment) -> IncomingAttachment:
    """Eki türüne göre çözümle ve alanlarını doldur (yerinde günceller).

    ASLA istisna fırlatmaz: okunamayan ek ``read_error`` ile işaretlenir,
    böylece 12 ekli bir mailde tek bozuk dosya diğerlerini engellemez.
    """
    try:
        data = _content_of(attachment)
    except ValueError as exc:
        if is_inline_image(attachment):
            attachment.read_error = ""
            attachment.has_text_layer = False
            return attachment
        attachment.read_error = str(exc)
        return attachment

    ext = attachment.extension

    if ext in _PDF_EXT or (not ext and data[:5] == b"%PDF-"):
        pdf = extract_pdf(data)
        attachment.text = pdf.text
        attachment.page_count = pdf.page_count
        attachment.extracted_page_count = pdf.extracted_page_count
        attachment.extraction_truncated = pdf.truncated
        attachment.image_count = pdf.image_count
        attachment.has_text_layer = pdf.has_text_layer
        attachment.has_digital_signature = pdf.has_digital_signature
        attachment.tables = pdf.tables
        attachment.read_error = pdf.error
        return attachment

    if ext in _EXCEL_EXT:
        table = extract_excel(data, attachment.filename)
        _apply_tables(attachment, table)
        return attachment

    if ext in _CSV_EXT:
        _apply_tables(attachment, extract_csv(data))
        return attachment

    if ext in _HTML_EXT:
        attachment.text = html_to_text(_decode(data))[:MAX_TEXT_CHARS]
        attachment.has_text_layer = bool(attachment.text.strip())
        if not attachment.text.strip():
            attachment.read_error = "HTML ekten metin çıkarılamadı."
        return attachment

    if ext in _TEXT_EXT:
        attachment.text = _decode(data)[:MAX_TEXT_CHARS]
        attachment.has_text_layer = bool(attachment.text.strip())
        if not attachment.text.strip():
            attachment.read_error = "Metin ek boş."
        return attachment

    if ext in _IMAGE_EXT:
        # Görselden Python metin çıkaramaz. Gömülü logo/imza görselleri
        # gürültüdür (hata değil); gerçek bir belge taraması ise belirsizdir
        # ve üst katman AI/insan incelemesine taşır.
        attachment.has_text_layer = False
        attachment.read_error = ("" if is_inline_image(attachment)
                                 else "Görsel ek: metin katmanı yok (taranmış belge olabilir).")
        return attachment

    # Bilinmeyen uzantı: içerik imzasına bak, olmazsa metin olarak dene.
    if data[:5] == b"%PDF-":
        pdf = extract_pdf(data)
        attachment.text = pdf.text
        attachment.page_count = pdf.page_count
        attachment.extracted_page_count = pdf.extracted_page_count
        attachment.extraction_truncated = pdf.truncated
        attachment.image_count = pdf.image_count
        attachment.has_text_layer = pdf.has_text_layer
        attachment.has_digital_signature = pdf.has_digital_signature
        attachment.read_error = pdf.error
        return attachment
    if data[:2] == b"PK":  # zip tabanlı → xlsx/docx olabilir
        table = extract_excel(data, attachment.filename or "x.xlsx")
        if not table.error:
            _apply_tables(attachment, table)
            return attachment

    text = _decode(data[:MAX_TEXT_CHARS])
    printable = sum(1 for ch in text[:2000] if ch.isprintable() or ch in "\r\n\t")
    if text.strip() and printable >= 0.8 * max(1, len(text[:2000])):
        attachment.text = text
        attachment.has_text_layer = True
    else:
        attachment.read_error = (
            f"Desteklenmeyen ek türü: {attachment.extension or 'uzantısız'}")
    return attachment


def _apply_tables(attachment: IncomingAttachment, extract: TableExtract) -> None:
    attachment.tables = [t.rows for t in extract.tables]
    attachment.page_count = len(extract.tables)
    attachment.text = table_to_text(extract.tables)
    attachment.has_text_layer = bool(attachment.text.strip())
    attachment.read_error = extract.error


def extract_all(attachments: list[IncomingAttachment]) -> list[IncomingAttachment]:
    """Tüm ekleri çözümle. Aynı ek iki kez çözümlenmez (idempotent)."""
    for attachment in attachments:
        already = (attachment.text or attachment.tables or attachment.read_error
                   or attachment.has_text_layer is not None)
        if not already:
            extract_attachment(attachment)
    return attachments


def folded_text(attachment: IncomingAttachment) -> str:
    """Ekin metni + dosya adı, karşılaştırma biçiminde."""
    return fold(f"{attachment.filename}\n{attachment.text}")
