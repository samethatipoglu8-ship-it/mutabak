"""Run ID / audit trail — SQLite tabanlı denetim kaydı.

Her mutabakat çalıştırmasına benzersiz bir kimlik (RUN-YYYY-MM-DD-######)
verilir ve kalıcı olarak saklanır: hangi şirket, hangi kaynak sistem, hangi
dosyalar (SHA-256 hash'leriyle), ne zaman başladı/bitti, hangi kullanıcı,
kural versiyonu ve sonuç. Böylece aylar sonra "11 Ağustos'ta bu fatura neden
eşleşmiş?" sorusu yanıtlanabilir.

Tasarım ilkesi: audit ASLA mutabakatı çökertmez. Veritabanı yazılamazsa
hata loglanır ve iş devam eder (best-effort).
"""

from __future__ import annotations

import hashlib
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from loguru import logger

from app.utils.paths import app_data_dir
from app.utils.sqlite import open_sqlite_connection

# Eşleştirme kurallarının sürümü. Kural mantığı değiştiğinde artırın; audit
# kaydı hangi kural setiyle çalışıldığını saklar.
RULE_VERSION = "v4.2"


def file_sha256(path: str | Path) -> Optional[str]:
    """Dosyanın SHA-256 hash'ini döndür (okunamazsa None)."""
    try:
        h = hashlib.sha256()
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return None


class AuditStore:
    """SQLite tabanlı, kurulum gerektirmeyen yerel denetim kaydı."""

    # RUN-ID çakışmasında kaç kez yeniden denenecek.
    _MAX_RUN_ID_ATTEMPTS = 10

    # Sonucun tekrar üretilebilmesi için saklanan çalıştırma parametreleri.
    # (Eski audit.db dosyalarına _ensure_schema tarafından ALTER ile eklenir.)
    # Not: burada yalnızca PARAMETRE ve SAYIM tutulur; tutar/referans gibi
    # hassas satır verisi audit'e YAZILMAZ.
    _EXTRA_COLUMNS = (
        ("program_version", "TEXT"),
        ("amount_tolerance", "TEXT"),
        ("date_tolerance_days", "INTEGER"),
        ("cross_match_enabled", "INTEGER"),
        ("cross_max_pool", "INTEGER"),
        ("cross_max_subset", "INTEGER"),
        ("cross_max_candidates", "INTEGER"),
        ("search_node_budget", "INTEGER"),
        ("subset_scan_budget", "INTEGER"),
        ("balance_delta", "INTEGER"),
        ("account_prefixes", "TEXT"),
        ("prefix_filter_active", "INTEGER"),
        ("off_prefix_referenced_rows", "INTEGER"),
        ("company_config_hash", "TEXT"),
        ("engine_hash", "TEXT"),
        ("loader_hash", "TEXT"),
        ("sap_declared_total", "TEXT"),
        ("firma_declared_total", "TEXT"),
        ("tofas_opening_balance", "TEXT"),
        ("firma_opening_balance", "TEXT"),
        ("excluded_belge_turu", "TEXT"),
        ("tofas_rows", "INTEGER"),
        ("firma_rows", "INTEGER"),
        ("output_file", "TEXT"),
        ("output_status", "TEXT"),
        ("cross_matched", "INTEGER"),
    )

    def __init__(self, path: str | Path | None = None) -> None:
        if path is None:
            base = app_data_dir()
            base.mkdir(parents=True, exist_ok=True)
            path = base / "audit.db"
        self._path = Path(path)
        self._ensure_schema()

    def _connect(self) -> sqlite3.Connection:
        return open_sqlite_connection(self._path, isolation_level=None)

    @contextmanager
    def _session(self):
        """Bağlantı aç, işlemi tamamla ve BAĞLANTIYI KAPAT.

        ``with sqlite3.connect(...) as conn`` yalnızca commit/rollback yapar;
        bağlantıyı KAPATMAZ. Kapanış çöp toplayıcıya kalınca yük altında
        dosya tanıtıcıları birikiyordu.
        """
        conn = self._connect()
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _ensure_schema(self) -> None:
        try:
            with self._session() as conn:
                conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS runs (
                        run_id          TEXT PRIMARY KEY,
                        company         TEXT,
                        mode            TEXT,
                        source_system   TEXT,
                        tofas_file      TEXT,
                        firma_file      TEXT,
                        tofas_hash      TEXT,
                        firma_hash      TEXT,
                        started_at      TEXT,
                        completed_at    TEXT,
                        app_user        TEXT,
                        rule_version    TEXT,
                        status          TEXT,
                        matched         INTEGER,
                        amount_diff     INTEGER,
                        only_firma      INTEGER,
                        only_tofas      INTEGER,
                        error           TEXT
                    )
                    """
                )
                # -- şema göçü: eski veritabanlarına eksik kolonları ekle ------
                existing = {row[1] for row in conn.execute("PRAGMA table_info(runs)")}
                for col, decl in self._EXTRA_COLUMNS:
                    if col not in existing:
                        conn.execute(f"ALTER TABLE runs ADD COLUMN {col} {decl}")
        except sqlite3.Error as exc:  # pragma: no cover - ortam bağımlı
            logger.warning("Audit şeması oluşturulamadı: {}", exc)

    def _next_run_id(self, conn: sqlite3.Connection, day: str) -> str:
        prefix = f"RUN-{day}-"
        cur = conn.execute(
            "SELECT run_id FROM runs WHERE run_id LIKE ? ORDER BY run_id DESC LIMIT 1",
            (prefix + "%",),
        )
        row = cur.fetchone()
        seq = 1
        if row and row[0]:
            try:
                seq = int(row[0].rsplit("-", 1)[1]) + 1
            except (ValueError, IndexError):
                seq = 1
        return f"{prefix}{seq:06d}"

    def start_run(
        self,
        *,
        tofas_file: str,
        firma_file: str,
        mode: str,
        company: Optional[str],
        app_user: str,
        source_system: Optional[str] = None,
    ) -> Optional[str]:
        """Yeni bir çalıştırma kaydı aç ve run_id döndür (hata olursa None).

        RUN-ID üretimi ("son sıra + 1") tek başına yarış koşuluna açıktır: iki
        süreç aynı anda okursa aynı sırayı üretir. İki katmanlı korunur:
          1) Okuma+yazma tek bir ``BEGIN IMMEDIATE`` işlemi içindedir (yazar
             kilidi hemen alınır, ikinci süreç bekler).
          2) run_id PRIMARY KEY olduğu için yine de çakışırsa (ör. WAL üzerinden
             farklı makineler) IntegrityError yakalanır ve yeniden denenir.
        """
        now = datetime.now(timezone.utc)
        day = now.strftime("%Y-%m-%d")
        payload = (
            company, mode, source_system,
            str(tofas_file), str(firma_file),
            file_sha256(tofas_file), file_sha256(firma_file),
            now.isoformat(), app_user, RULE_VERSION, "RUNNING",
        )
        for attempt in range(self._MAX_RUN_ID_ATTEMPTS):
            conn = None
            try:
                conn = self._connect()
                conn.execute("BEGIN IMMEDIATE")
                run_id = self._next_run_id(conn, day)
                conn.execute(
                    """
                    INSERT INTO runs (
                        run_id, company, mode, source_system,
                        tofas_file, firma_file, tofas_hash, firma_hash,
                        started_at, app_user, rule_version, status
                    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (run_id,) + payload,
                )
                conn.execute("COMMIT")
                return run_id
            except sqlite3.IntegrityError:
                # Aynı run_id başka bir süreççe alınmış — bir sonraki sırayı dene.
                logger.debug("RUN-ID çakışması, yeniden deneniyor ({}).", attempt + 1)
                continue
            except sqlite3.Error as exc:  # pragma: no cover - ortam bağımlı
                logger.warning("Audit start_run başarısız: {}", exc)
                return None
            finally:
                if conn is not None:
                    conn.close()
        logger.warning("Audit start_run: benzersiz RUN-ID üretilemedi.")
        return None

    def record_parameters(self, run_id: Optional[str], **params) -> None:
        """Çalıştırma parametrelerini kaydet (tekrar üretilebilirlik için).

        Yalnızca ``_EXTRA_COLUMNS`` içinde tanımlı anahtarlar yazılır; bilinmeyen
        anahtarlar sessizce yok sayılır (audit asla mutabakatı çökertmez).
        """
        if not run_id or not params:
            return
        allowed = {c for c, _ in self._EXTRA_COLUMNS}
        fields = {k: v for k, v in params.items() if k in allowed and v is not None}
        if not fields:
            return
        sets = ", ".join(f"{k}=?" for k in fields)
        try:
            with self._session() as conn:
                conn.execute(
                    f"UPDATE runs SET {sets} WHERE run_id=?",
                    tuple(fields.values()) + (run_id,),
                )
        except sqlite3.Error as exc:  # pragma: no cover
            logger.warning("Audit record_parameters başarısız: {}", exc)

    def complete_run(
        self,
        run_id: Optional[str],
        *,
        status: str,
        matched: int = 0,
        amount_diff: int = 0,
        only_firma: int = 0,
        only_tofas: int = 0,
        error: Optional[str] = None,
        cross_matched: int = 0,
        output_file: Optional[str] = None,
        output_status: Optional[str] = None,
    ) -> None:
        """Çalıştırma kaydını sonuçla kapat."""
        if not run_id:
            return
        try:
            with self._session() as conn:
                conn.execute(
                    """
                    UPDATE runs SET completed_at=?, status=?, matched=?,
                        amount_diff=?, only_firma=?, only_tofas=?, error=?,
                        cross_matched=?, output_file=?, output_status=?
                    WHERE run_id=?
                    """,
                    (
                        datetime.now(timezone.utc).isoformat(), status, matched,
                        amount_diff, only_firma, only_tofas, error,
                        cross_matched, output_file, output_status, run_id,
                    ),
                )
        except sqlite3.Error as exc:  # pragma: no cover
            logger.warning("Audit complete_run başarısız: {}", exc)

    def get_run(self, run_id: str) -> Optional[dict]:
        """Bir çalıştırma kaydını sözlük olarak döndür (yoksa None)."""
        try:
            with self._session() as conn:
                conn.row_factory = sqlite3.Row
                cur = conn.execute("SELECT * FROM runs WHERE run_id=?", (run_id,))
                row = cur.fetchone()
                return dict(row) if row else None
        except sqlite3.Error:  # pragma: no cover
            return None
