"""Gönderim anının DEĞİŞMEZ hafızası — FBL1H/FBL5H snapshot deposu.

NEDEN GEREKLİ
    Bir firma mutabakat mailine cevap verdiğinde sorulması gereken soru
    şudur: «Bu firmaya, bu dönemde, GERÇEKTE hangi ekstre gönderilmişti?»

    Mevcut sistem bu soruya cevap veremiyordu. ``MailLog`` yalnızca "kime,
    ne zaman, hangi konuyla mail gitti"yi saklıyor; gönderimde kullanılan
    FBL1H/FBL5H dosyaları ise ekran üzerinde bir STRING YOL olarak yaşayıp
    paket üretildikten sonra çöpe gidiyordu. Kaynak dosya bir ay sonra
    güncellendiğinde ya da silindiğinde geçmiş gönderimin verisi
    KAYBOLUYORDU — ve gelen cevap, gönderilen rakamla değil, bugünkü
    rakamla karşılaştırılıyordu. Bu sessiz bir finansal hatadır.

    Bu modül o boşluğu kapatır: gönderim anındaki dosyaların fiziksel,
    değişmez kopyası uygulamanın kendi veri klasörüne alınır, SHA-256'sı
    kaydedilir ve gönderime benzersiz bir ``send_id`` / ``snapshot_id``
    ile bağlanır.

DOSYA YERLEŞİMİ
    ~/.mutabakat_pro/snapshots/
        _blobs/<sha256[:2]>/<sha256>.xlsx        ← ham kaynak (içerik-adresli)
        <period>/<company_code>/<snapshot_id>/
            snapshot.json                        ← tüm meta veri
            sent_mail_body.txt                   ← gönderilen mail gövdesi
            records.json                         ← firma bazlı normalize satırlar (FAZ 2)

    HAM DOSYA NEDEN HER SNAPSHOT KLASÖRÜNE KOPYALANMAZ
        Tek bir FBL1H dosyası 600 firmayı birden besler ve 100 MB olabilir.
        Firma başına kopyalamak 60 GB demektir — kabul edilemez. Bunun
        yerine dosya İÇERİK HASH'İYLE adlandırılıp bir kez saklanır
        (``_blobs``). Aynı içerik ikinci kez yazılmaz; farklı içerik farklı
        hash aldığı için ESKİ SNAPSHOT'IN GÖRDÜĞÜ BAYTLAR ASLA DEĞİŞMEZ.
        Kaynak dosya sonradan silinse ya da değiştirilse bile snapshot
        kendi blob'unu okumaya devam eder — istenen garanti budur.

TASARIM İLKELERİ (audit.py / mail_log.py ile aynı)
    * Snapshot ASLA gönderimi çökertmez. Yazılamazsa loglanır, iş devam eder.
    * Kayıt DEĞİŞMEZDİR: ``sent_at`` / takip kimlikleri dışında hiçbir alan
      sonradan güncellenmez. Geçmiş yeniden yazılamaz.
    * Takip ``company_code + period`` ile DEĞİL, benzersiz ``send_id`` ile
      yapılır: aynı firmaya aynı dönemde ikinci bir gönderim yapılırsa iki
      kayıt birbirine karışmaz.
    * Sıradan "UI Sıfırla" bu deponun kaydını SİLMEZ (bkz. FAZ 8).
"""

from __future__ import annotations

import hashlib
import json
import shutil
import sqlite3
import uuid
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional, Sequence

from loguru import logger

from app.utils.paths import app_data_dir
from app.utils.sqlite import open_sqlite_connection

# Gönderim durumları — MailLog'un STATUS_* değerleriyle aynı sözlük.
SNAPSHOT_PENDING = "PENDING"     # paket üretildi, henüz gönderilmedi
SNAPSHOT_SENT = "SENT"
SNAPSHOT_FAILED = "FAILED"
SNAPSHOT_SKIPPED = "SKIPPED"
# ``Send()`` hata verdi ama mail gitmiş OLABİLİR. Snapshot KORUNUR: cevap
# gelirse karşılaştırılacak referans hazır olmalıdır.
SNAPSHOT_UNKNOWN = "SEND_UNKNOWN"

# Bilinen SAP kaynak türleri.
SOURCE_FBL1H = "fbl1h"
SOURCE_FBL5H = "fbl5h"


def _now() -> str:
    # Milisaniye çözünürlük: aynı saniyede oluşan iki gönderim (düzeltme
    # maili hemen ardından gidebilir) zaman damgasıyla da ayırt edilebilsin.
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def new_send_id() -> str:
    """Benzersiz gönderim kimliği.

    ``company_code + period`` ANAHTAR DEĞİLDİR: bir firmaya aynı dönemde
    (düzeltme, tekrar gönderim, ek yön) birden çok mail gidebilir. Cevabın
    doğru pakete bağlanabilmesi için her gönderimin kendi kimliği olmalıdır.
    """
    return "SND-" + uuid.uuid4().hex[:16]


def new_snapshot_id() -> str:
    return "SNP-" + uuid.uuid4().hex[:16]


def file_sha256(path: str | Path) -> str:
    """Dosyanın SHA-256'sı (okunamazsa boş string — çökertmez)."""
    try:
        digest = hashlib.sha256()
        with open(path, "rb") as handle:
            for chunk in iter(lambda: handle.read(1 << 20), b""):
                digest.update(chunk)
        return digest.hexdigest()
    except OSError as exc:
        logger.warning(f"[snapshot] hash alınamadı ({path}): {exc}")
        return ""


@dataclass(frozen=True)
class AttachmentMeta:
    """Gönderilen tek bir ekin kimliği.

    Ekin KENDİSİ snapshot'a kopyalanmaz (Excel/PDF zaten çıktı klasöründe
    ve içeriği FBL1H/FBL5H snapshot'ından yeniden üretilebilir); ancak adı,
    boyutu ve hash'i saklanır ki «firma hangi dosyayı aldı?» sorusu
    cevaplanabilsin.
    """

    filename: str = ""
    path: str = ""
    size: int = 0
    sha256: str = ""

    @classmethod
    def of(cls, path: str | Path) -> "AttachmentMeta":
        p = Path(path)
        try:
            size = p.stat().st_size
        except OSError:
            size = 0
        return cls(filename=p.name, path=str(p), size=size,
                   sha256=file_sha256(p) if size else "")


@dataclass
class SentReconciliationSnapshot:
    """Bir firmaya, bir dönemde, TEK bir gönderimde giden paketin kaydı."""

    # -- kimlik ------------------------------------------------------------
    snapshot_id: str = field(default_factory=new_snapshot_id)
    send_id: str = field(default_factory=new_send_id)
    company_code: str = ""
    company_name: str = ""
    period: str = ""                       # "2026-08"
    run_id: Optional[str] = None
    responsible: str = ""

    # -- mail --------------------------------------------------------------
    recipients: tuple[str, ...] = ()
    cc: tuple[str, ...] = ()
    subject: str = ""
    body: str = ""
    locale: str = ""
    directions: tuple[str, ...] = ()       # ("M", "S")

    # -- zaman / takip -----------------------------------------------------
    created_at: str = field(default_factory=_now)
    sent_at: str = ""
    message_id: str = ""
    conversation_id: str = ""
    status: str = SNAPSHOT_PENDING

    # -- kaynak dosyalar ---------------------------------------------------
    fbl1h_source_path: str = ""
    fbl5h_source_path: str = ""
    fbl1h_sha256: str = ""
    fbl5h_sha256: str = ""
    fbl1h_snapshot_path: str = ""          # değişmez blob kopyası
    fbl5h_snapshot_path: str = ""

    # -- ekler -------------------------------------------------------------
    attachments: tuple[AttachmentMeta, ...] = ()

    # -- normalize kayıtlar (FAZ 2 doldurur) -------------------------------
    record_count: int = 0
    snapshot_dir: str = ""

    # -- yardımcılar -------------------------------------------------------

    @property
    def key(self) -> tuple[str, str]:
        return (self.company_code, self.period)

    @property
    def has_sources(self) -> bool:
        return bool(self.fbl1h_snapshot_path or self.fbl5h_snapshot_path)

    def source_path(self, which: str) -> str:
        """``"fbl1h"`` / ``"fbl5h"`` için değişmez kopyanın yolu."""
        return (self.fbl1h_snapshot_path if which == SOURCE_FBL1H
                else self.fbl5h_snapshot_path)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["recipients"] = list(self.recipients)
        data["cc"] = list(self.cc)
        data["directions"] = list(self.directions)
        data["attachments"] = [asdict(a) for a in self.attachments]
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SentReconciliationSnapshot":
        payload = dict(data or {})
        payload["recipients"] = tuple(payload.get("recipients") or ())
        payload["cc"] = tuple(payload.get("cc") or ())
        payload["directions"] = tuple(payload.get("directions") or ())
        payload["attachments"] = tuple(
            AttachmentMeta(**a) if isinstance(a, dict) else a
            for a in (payload.get("attachments") or ()))
        allowed = {f for f in cls.__dataclass_fields__}      # bilinmeyen alanı at
        return cls(**{k: v for k, v in payload.items() if k in allowed})


class SnapshotStore:
    """Gönderim snapshot'larının kalıcı deposu (SQLite + değişmez dosyalar)."""

    def __init__(self, base_dir: str | Path | None = None,
                 db_path: str | Path | None = None) -> None:
        if base_dir is None:
            base_dir = app_data_dir() / "snapshots"
        self._base = Path(base_dir)
        self._blobs = self._base / "_blobs"
        try:
            self._blobs.mkdir(parents=True, exist_ok=True)
        except OSError as exc:  # pragma: no cover - ortam bağımlı
            logger.error(f"[snapshot] klasör oluşturulamadı: {exc}")
        self._path = Path(db_path) if db_path else self._base / "snapshots.db"
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
        except OSError:  # pragma: no cover
            pass
        self._ensure_schema()

    # -- altyapı -----------------------------------------------------------

    @property
    def base_dir(self) -> Path:
        return self._base

    @property
    def path(self) -> Path:
        return self._path

    def _connect(self) -> sqlite3.Connection:
        return open_sqlite_connection(self._path, isolation_level=None)

    @contextmanager
    def _session(self):
        """Bağlantı aç, işlemi tamamla ve BAĞLANTIYI KAPAT.

        ``with sqlite3.connect(...) as conn`` yalnızca commit/rollback yapar;
        bağlantıyı KAPATMAZ. Kapanış çöp toplayıcıya kalınca yük altında
        dosya tanıtıcıları birikiyordu. (Aynı düzeltme idempotency ve audit
        depolarında da uygulandı.)
        """
        conn = self._connect()
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _ensure_schema(self) -> None:
        try:
            with self._session() as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS sent_snapshots (
                        snapshot_id          TEXT PRIMARY KEY,
                        send_id              TEXT NOT NULL UNIQUE,
                        company_code         TEXT NOT NULL,
                        company_name         TEXT,
                        period               TEXT NOT NULL,
                        run_id               TEXT,
                        responsible          TEXT,
                        recipients           TEXT,
                        cc                   TEXT,
                        subject              TEXT,
                        body                 TEXT,
                        locale               TEXT,
                        directions           TEXT,
                        created_at           TEXT NOT NULL,
                        sent_at              TEXT,
                        message_id           TEXT,
                        conversation_id      TEXT,
                        status               TEXT,
                        fbl1h_source_path    TEXT,
                        fbl5h_source_path    TEXT,
                        fbl1h_sha256         TEXT,
                        fbl5h_sha256         TEXT,
                        fbl1h_snapshot_path  TEXT,
                        fbl5h_snapshot_path  TEXT,
                        attachments          TEXT,
                        record_count         INTEGER DEFAULT 0,
                        snapshot_dir         TEXT
                    )
                """)
                for name, columns in (
                    ("ix_snapshots_code_period",
                     "(company_code, period, created_at)"),
                    ("ix_snapshots_message", "(message_id)"),
                    ("ix_snapshots_conversation", "(conversation_id)"),
                    ("ix_snapshots_period", "(period)"),
                ):
                    conn.execute(
                        f"CREATE INDEX IF NOT EXISTS {name} "
                        f"ON sent_snapshots {columns}")
        except sqlite3.Error as exc:  # pragma: no cover - ortam bağımlı
            logger.error(f"[snapshot] şema kurulamadı: {exc}")

    # -- ham kaynak dosyanın değişmez kopyası ------------------------------

    def store_source(self, path: str | Path | None) -> tuple[str, str]:
        """Kaynak dosyayı içerik-adresli blob deposuna al.

        Döner: ``(blob_path, sha256)``. Dosya yoksa/okunamıyorsa ``("", "")``.

        Aynı içerik ikinci kez KOPYALANMAZ (600 firmalık bir partide tek bir
        FBL1H dosyası bir kez yazılır). Farklı içerik farklı hash aldığı için
        var olan bir blob asla ÜZERİNE YAZILMAZ — eski snapshot'ların gördüğü
        baytlar değişmez.
        """
        if not path:
            return "", ""
        source = Path(path)
        if not source.is_file():
            logger.warning(f"[snapshot] kaynak dosya bulunamadı: {source}")
            return "", ""
        digest = file_sha256(source)
        if not digest:
            return "", ""
        target_dir = self._blobs / digest[:2]
        target = target_dir / f"{digest}{source.suffix.lower()}"
        if target.exists():
            return str(target), digest          # zaten saklanmış
        staging: Optional[Path] = None
        try:
            target_dir.mkdir(parents=True, exist_ok=True)
            # Önce geçici ada yazılır, sonra atomik olarak taşınır: yarım
            # kopyalanmış bir blob asla geçerli sayılmaz.
            staging = target_dir / f".{digest}.{uuid.uuid4().hex[:8]}.part"
            shutil.copyfile(source, staging)
            staging.replace(target)
            return str(target), digest
        except OSError as exc:
            # YARIŞ DURUMU (özellikle Windows): başka bir iş parçacığı ya da
            # ikinci bir uygulama örneği aynı blob'u aynı anda yazmış olabilir.
            # Windows'ta bu ``replace`` çağrısını [WinError 5] ile düşürür.
            #
            # Blob İÇERİK-ADRESLİDİR: hedef zaten varsa içeriği bizimkiyle
            # BİREBİR AYNIDIR ve iş başarıyla tamamlanmış demektir. Bunu hata
            # sayıp boş yol döndürmek, snapshot'ı DEĞİŞMEZ KOPYASIZ bırakırdı
            # — yani asıl garantiyi sessizce kaybederdik.
            if target.is_file():
                return str(target), digest
            logger.error(f"[snapshot] kaynak kopyalanamadı ({source}): {exc}")
            return "", digest
        finally:
            if staging is not None:
                try:
                    staging.unlink(missing_ok=True)
                except OSError:  # pragma: no cover - temizlik hatası yutulur
                    pass

    # -- yazma -------------------------------------------------------------

    def create(
        self,
        *,
        company_code: str,
        period: str,
        company_name: str = "",
        run_id: Optional[str] = None,
        responsible: str = "",
        recipients: Sequence[str] = (),
        cc: Sequence[str] = (),
        subject: str = "",
        body: str = "",
        locale: str = "",
        directions: Sequence[str] = (),
        fbl1h_path: str | Path | None = None,
        fbl5h_path: str | Path | None = None,
        attachments: Sequence[str | Path] = (),
        send_id: Optional[str] = None,
        snapshot_id: Optional[str] = None,
        records: Optional[Sequence[dict]] = None,
    ) -> Optional[SentReconciliationSnapshot]:
        """Gönderim öncesi snapshot'ı oluştur ve kalıcı hâle getir.

        Hiçbir koşulda istisna fırlatmaz; başarısız olursa ``None`` döner ve
        çağıran taraf gönderimi snapshot'sız sürdürebilir (kayıt eksikliği
        loglanır — sessizce "her şey yolunda" denmez).
        """
        try:
            snapshot = SentReconciliationSnapshot(
                snapshot_id=snapshot_id or new_snapshot_id(),
                send_id=send_id or new_send_id(),
                company_code=str(company_code or ""),
                company_name=str(company_name or ""),
                period=str(period or ""),
                run_id=run_id,
                responsible=str(responsible or ""),
                recipients=tuple(str(r) for r in recipients if str(r).strip()),
                cc=tuple(str(c) for c in cc if str(c).strip()),
                subject=str(subject or ""),
                body=str(body or ""),
                locale=str(locale or ""),
                directions=tuple(str(d) for d in directions),
            )

            blob1, hash1 = self.store_source(fbl1h_path)
            blob5, hash5 = self.store_source(fbl5h_path)
            snapshot.fbl1h_source_path = str(fbl1h_path or "")
            snapshot.fbl5h_source_path = str(fbl5h_path or "")
            snapshot.fbl1h_snapshot_path = blob1
            snapshot.fbl5h_snapshot_path = blob5
            snapshot.fbl1h_sha256 = hash1
            snapshot.fbl5h_sha256 = hash5
            snapshot.attachments = tuple(
                AttachmentMeta.of(a) for a in attachments)

            # Kimlik çakışması DOSYALAR YAZILMADAN önce yakalanır.
            # _snapshot_dir yolu snapshot_id'den türetilir: aynı kimlik
            # aynı klasörü verir ve _write_files eski snapshot.json'u
            # DB hatası oluşmadan ÖNCE ezerdi. Veritabanı kısıtı diski
            # koruyamaz; bu yüzden ön kontrol gerekir.
            self._reject_duplicate_ids(snapshot)

            directory = self._snapshot_dir(snapshot)
            snapshot.snapshot_dir = str(directory)
            if records is not None:
                snapshot.record_count = len(records)

            self._write_files(snapshot, directory, records)
            self._insert(snapshot)
            return snapshot
        except Exception as exc:  # noqa: BLE001 - snapshot gönderimi çökertmez
            logger.exception(f"[snapshot] oluşturulamadı ({company_code}): {exc}")
            return None

    def _reject_duplicate_ids(self,
                              snapshot: SentReconciliationSnapshot) -> None:
        """Kimlik zaten kullanılmışsa yazmadan ÖNCE durdur.

        Yarış durumunda (iki süreç aynı anda) bu kontrol yetmez; son söz
        veritabanı kısıtındadır (bkz. ``_insert``). Buradaki amaç, asıl
        gerçekçi senaryoda — çağıranın bilerek aynı kimliği vermesi —
        diskteki snapshot'ın ezilmesini engellemektir.
        """
        if self.get(snapshot.snapshot_id) is not None:
            raise ValueError(
                f"snapshot_id zaten kullanılmış: {snapshot.snapshot_id} "
                "(kayıt değiştirilemez; var olan snapshot korundu)")
        if self.by_send_id(snapshot.send_id) is not None:
            raise ValueError(
                f"send_id zaten kullanılmış: {snapshot.send_id} "
                "(kayıt değiştirilemez; var olan snapshot korundu)")

    def _snapshot_dir(self, snapshot: SentReconciliationSnapshot) -> Path:
        return (self._base / (snapshot.period or "donemsiz")
                / (snapshot.company_code or "kodsuz") / snapshot.snapshot_id)

    def _write_files(self, snapshot: SentReconciliationSnapshot,
                     directory: Path,
                     records: Optional[Sequence[dict]]) -> None:
        """``snapshot.json`` + mail gövdesi + normalize kayıtları yaz."""
        directory.mkdir(parents=True, exist_ok=True)
        (directory / "snapshot.json").write_text(
            json.dumps(snapshot.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8")
        if snapshot.body:
            (directory / "sent_mail_body.txt").write_text(
                snapshot.body, encoding="utf-8")
        if records is not None:
            (directory / "records.json").write_text(
                json.dumps(list(records), ensure_ascii=False, default=str),
                encoding="utf-8")

    def _insert(self, snapshot: SentReconciliationSnapshot) -> None:
        """Snapshot satırını yaz. Var olan bir kaydı ASLA EZMEZ.

        Eskiden ``INSERT OR REPLACE`` kullanılıyordu: ``snapshot_id`` ya da
        ``send_id`` çakışırsa SQLite eski satırı SİLİP yenisini yazardı.
        Bu, modülün "kayıt değiştirilemez; geçmiş yeniden yazılamaz"
        ilkesiyle çelişir — üstelik sessizce, hiçbir iz bırakmadan.

        Kimlikler uuid4'ten üretildiği için kazara çakışma pratikte
        imkânsızdır; gerçek risk, ``create()``e DIŞARIDAN aynı kimliğin
        verilmesidir. Artık böyle bir durumda IntegrityError yükselir,
        loglanır ve ``create()`` snapshot'sız (None) döner: çakışma
        GÖRÜNÜR olur.
        """
        try:
            self._insert_row(snapshot)
        except sqlite3.IntegrityError as exc:
            logger.error(
                "[snapshot] çakışan kimlik — snapshot YAZILMADI, var olan "
                f"kayıt korundu (snapshot_id={snapshot.snapshot_id}, "
                f"send_id={snapshot.send_id}): {exc}")
            raise

    def _insert_row(self, snapshot: SentReconciliationSnapshot) -> None:
        with self._session() as conn:
            conn.execute("""
                INSERT INTO sent_snapshots (
                    snapshot_id, send_id, company_code, company_name, period,
                    run_id, responsible, recipients, cc, subject, body, locale,
                    directions, created_at, sent_at, message_id,
                    conversation_id, status, fbl1h_source_path,
                    fbl5h_source_path, fbl1h_sha256, fbl5h_sha256,
                    fbl1h_snapshot_path, fbl5h_snapshot_path, attachments,
                    record_count, snapshot_dir
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                snapshot.snapshot_id, snapshot.send_id, snapshot.company_code,
                snapshot.company_name, snapshot.period, snapshot.run_id,
                snapshot.responsible,
                json.dumps(list(snapshot.recipients), ensure_ascii=False),
                json.dumps(list(snapshot.cc), ensure_ascii=False),
                snapshot.subject, snapshot.body, snapshot.locale,
                json.dumps(list(snapshot.directions), ensure_ascii=False),
                snapshot.created_at, snapshot.sent_at, snapshot.message_id,
                snapshot.conversation_id, snapshot.status,
                snapshot.fbl1h_source_path, snapshot.fbl5h_source_path,
                snapshot.fbl1h_sha256, snapshot.fbl5h_sha256,
                snapshot.fbl1h_snapshot_path, snapshot.fbl5h_snapshot_path,
                json.dumps([asdict(a) for a in snapshot.attachments],
                           ensure_ascii=False),
                snapshot.record_count, snapshot.snapshot_dir,
            ))

    # -- gönderim sonucu ---------------------------------------------------

    def mark_sent(self, send_id: str, *, status: str = SNAPSHOT_SENT,
                  sent_at: str = "", message_id: str = "",
                  conversation_id: str = "") -> bool:
        """Gönderim sonrası öğrenilenleri YALNIZCA ``send_id`` ile yaz.

        ``company_code + period`` ile güncelleme YAPILMAZ: aynı firmanın aynı
        dönemdeki ikinci gönderimi birincisinin kimliklerini ezerdi ve cevap
        yanlış snapshot'a bağlanırdı.

        Boş değer var olan bir kimliği EZMEZ (Outlook ConversationID'yi bazen
        geç verir); finansal içerik zaten hiç güncellenmez.
        """
        if not send_id:
            return False
        fields = ["status = ?", "sent_at = COALESCE(NULLIF(?, ''), sent_at)"]
        params: list[Any] = [status or SNAPSHOT_SENT, sent_at or _now()]
        for name, value in (("message_id", message_id),
                            ("conversation_id", conversation_id)):
            if value:
                fields.append(f"{name} = ?")
                params.append(value)
        params.append(send_id)
        try:
            with self._session() as conn:
                cursor = conn.execute(
                    f"UPDATE sent_snapshots SET {', '.join(fields)} "
                    "WHERE send_id = ?", params)
                changed = cursor.rowcount > 0
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[snapshot] güncellenemedi ({send_id}): {exc}")
            return False
        if changed:
            self._refresh_json(send_id)
        return changed

    def _refresh_json(self, send_id: str) -> None:
        """``snapshot.json``ı DB ile eşitle (yalnızca takip alanları değişir)."""
        snapshot = self.by_send_id(send_id)
        if snapshot is None or not snapshot.snapshot_dir:
            return
        try:
            target = Path(snapshot.snapshot_dir) / "snapshot.json"
            if target.parent.is_dir():
                target.write_text(
                    json.dumps(snapshot.to_dict(), ensure_ascii=False, indent=2),
                    encoding="utf-8")
        except OSError as exc:  # pragma: no cover
            logger.warning(f"[snapshot] snapshot.json yazılamadı: {exc}")

    # -- okuma -------------------------------------------------------------

    _SELECT = """
        SELECT snapshot_id, send_id, company_code, company_name, period,
               run_id, responsible, recipients, cc, subject, body, locale,
               directions, created_at, sent_at, message_id, conversation_id,
               status, fbl1h_source_path, fbl5h_source_path, fbl1h_sha256,
               fbl5h_sha256, fbl1h_snapshot_path, fbl5h_snapshot_path,
               attachments, record_count, snapshot_dir
        FROM sent_snapshots
    """

    @staticmethod
    def _row(row: Sequence[Any]) -> SentReconciliationSnapshot:
        def _load(value: Any, default):
            try:
                return json.loads(value) if value else default
            except (TypeError, ValueError):
                return default

        return SentReconciliationSnapshot(
            snapshot_id=row[0], send_id=row[1], company_code=row[2],
            company_name=row[3] or "", period=row[4], run_id=row[5],
            responsible=row[6] or "",
            recipients=tuple(_load(row[7], [])),
            cc=tuple(_load(row[8], [])),
            subject=row[9] or "", body=row[10] or "", locale=row[11] or "",
            directions=tuple(_load(row[12], [])),
            created_at=row[13] or "", sent_at=row[14] or "",
            message_id=row[15] or "", conversation_id=row[16] or "",
            status=row[17] or SNAPSHOT_PENDING,
            fbl1h_source_path=row[18] or "", fbl5h_source_path=row[19] or "",
            fbl1h_sha256=row[20] or "", fbl5h_sha256=row[21] or "",
            fbl1h_snapshot_path=row[22] or "",
            fbl5h_snapshot_path=row[23] or "",
            attachments=tuple(AttachmentMeta(**a)
                              for a in _load(row[24], []) if isinstance(a, dict)),
            record_count=int(row[25] or 0), snapshot_dir=row[26] or "",
        )

    def _query(self, where: str = "", params: Sequence[Any] = (),
               # Sıralama EKLEME SIRASINA göredir (rowid). Zaman damgası tek
               # başına yetmez: aynı milisaniyede iki gönderim oluşabilir ve
               # o durumda "en son gönderim" rastgele seçilirdi.
               order: str = " ORDER BY created_at, rowid"
               ) -> list[SentReconciliationSnapshot]:
        sql = self._SELECT + (f" WHERE {where}" if where else "") + order
        try:
            with self._session() as conn:
                rows = conn.execute(sql, list(params)).fetchall()
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[snapshot] okunamadı: {exc}")
            return []
        return [self._row(r) for r in rows]

    def get(self, snapshot_id: str) -> Optional[SentReconciliationSnapshot]:
        found = self._query("snapshot_id = ?", (snapshot_id,))
        return found[0] if found else None

    def by_send_id(self, send_id: str) -> Optional[SentReconciliationSnapshot]:
        found = self._query("send_id = ?", (send_id,))
        return found[0] if found else None

    def by_message_id(self, message_id: str
                      ) -> Optional[SentReconciliationSnapshot]:
        if not message_id:
            return None
        found = self._query("message_id = ?", (message_id.strip(),))
        return found[0] if found else None

    def find(self, company_code: Optional[str] = None,
             period: Optional[str] = None,
             status: Optional[str] = None
             ) -> list[SentReconciliationSnapshot]:
        """Filtreli listeleme (en eskiden yeniye)."""
        where, params = [], []
        if company_code:
            where.append("company_code = ?")
            params.append(company_code)
        if period:
            where.append("period = ?")
            params.append(period)
        if status:
            where.append("status = ?")
            params.append(status)
        return self._query(" AND ".join(where), params)

    def latest(self, company_code: str, period: str
               ) -> Optional[SentReconciliationSnapshot]:
        """Bu firma+dönemin EN SON gönderimi.

        DİKKAT: bu yalnızca bir kolaylıktır. Gelen cevabı bağlarken tek
        başına KULLANILMAZ — birden çok gönderim varsa hangisine cevap
        verildiği zincir kimliğinden çözülmelidir (bkz. FAZ 3).
        """
        found = self.find(company_code=company_code, period=period)
        return found[-1] if found else None

    def all(self) -> list[SentReconciliationSnapshot]:
        return self._query()

    # -- normalize satırlar (FAZ 2) ----------------------------------------

    @staticmethod
    def records(snapshot: Optional[SentReconciliationSnapshot]
                ) -> Optional[list[dict]]:
        """Gönderilen ekstrenin normalize satırları.

        ``None`` = bu snapshot için satır YAZILMADI (yalnızca ham blob var).
        Bu, boş listeyle KARIŞTIRILMAMALIDIR: boş liste "firmanın hiç kaydı
        yoktu" demektir ve karşılaştırmada geçerli bir referanstır; ``None``
        ise "bilmiyoruz" demektir ve insan incelemesi gerektirir.
        """
        if snapshot is None or not snapshot.snapshot_dir:
            return None
        target = Path(snapshot.snapshot_dir) / "records.json"
        if not target.is_file():
            return None
        try:
            data = json.loads(target.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            logger.error(f"[snapshot] records.json okunamadı ({target}): {exc}")
            return None
        return data if isinstance(data, list) else None

    def records_for_send(self, send_id: str) -> Optional[list[dict]]:
        return self.records(self.by_send_id(send_id))

    # -- bütünlük ----------------------------------------------------------

    def verify(self, snapshot_id: str) -> list[str]:
        """Snapshot'ın dosyaları hâlâ sağlam mı? Sorun listesi döner (boş = sağlam).

        Hash yeniden hesaplanır: blob bozulmuş ya da silinmişse bu sessizce
        geçilmez, çünkü bozuk bir referansla yapılan karşılaştırma yanlış
        finansal sonuç üretir.
        """
        snapshot = self.get(snapshot_id)
        if snapshot is None:
            return [f"Snapshot bulunamadı: {snapshot_id}"]
        problems: list[str] = []
        for label, blob, expected in (
            ("FBL1H", snapshot.fbl1h_snapshot_path, snapshot.fbl1h_sha256),
            ("FBL5H", snapshot.fbl5h_snapshot_path, snapshot.fbl5h_sha256),
        ):
            if not blob:
                continue
            path = Path(blob)
            if not path.is_file():
                problems.append(f"{label} snapshot dosyası kayıp: {blob}")
                continue
            actual = file_sha256(path)
            if expected and actual != expected:
                problems.append(
                    f"{label} snapshot bozulmuş (beklenen {expected[:12]}…, "
                    f"bulunan {actual[:12]}…)")
        if snapshot.snapshot_dir and not Path(snapshot.snapshot_dir).is_dir():
            problems.append(f"Snapshot klasörü kayıp: {snapshot.snapshot_dir}")
        return problems

    def source_changed(self, snapshot_id: str) -> Optional[bool]:
        """Kaynak dosya gönderimden BU YANA değişti mi?

        ``None`` = karşılaştırılamadı (kaynak silinmiş ya da hash yok).
        Snapshot'ın kendisi bundan etkilenmez; bu yalnızca kullanıcıya
        "elinizdeki dosya artık gönderdiğinizle aynı değil" demek içindir.
        """
        snapshot = self.get(snapshot_id)
        if snapshot is None:
            return None
        verdicts: list[bool] = []
        for source, expected in (
            (snapshot.fbl1h_source_path, snapshot.fbl1h_sha256),
            (snapshot.fbl5h_source_path, snapshot.fbl5h_sha256),
        ):
            if not source or not expected or not Path(source).is_file():
                continue
            verdicts.append(file_sha256(source) != expected)
        if not verdicts:
            return None
        return any(verdicts)

    # -- bakım -------------------------------------------------------------

    def orphan_blobs(self) -> list[Path]:
        """Hiçbir snapshot tarafından kullanılmayan blob dosyaları.

        SİLMEZ — yalnızca listeler. Snapshot verisinin otomatik temizlenmesi
        tasarım gereği YASAKTIR; geçmiş gönderimin kanıtı bir bakım işiyle
        sessizce yok edilemez.
        """
        used = set()
        for snapshot in self.all():
            used.update(p for p in (snapshot.fbl1h_snapshot_path,
                                    snapshot.fbl5h_snapshot_path) if p)
        if not self._blobs.is_dir():
            return []
        return [p for p in self._blobs.rglob("*")
                if p.is_file() and str(p) not in used]


def snapshots_for_period(store: SnapshotStore, period: str
                         ) -> dict[str, list[SentReconciliationSnapshot]]:
    """Dönemdeki snapshot'ları firma koduna göre grupla (UI/oran için)."""
    grouped: dict[str, list[SentReconciliationSnapshot]] = {}
    for snapshot in store.find(period=period):
        grouped.setdefault(snapshot.company_code, []).append(snapshot)
    return grouped
