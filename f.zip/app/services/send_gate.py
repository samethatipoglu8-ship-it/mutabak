"""Paket-bağımsız gönderim kapısı: SendQueue + MailLog idempotency.

OTL-08 öncesi tek bir gönderim yolu ("9) Ekli Mailleri Gönder" ->
``PackageSendWorker``) bu korumalara sahipti; "1) Mutabakat Gönder",
"5) Seçili Firmalara Gönder", "6) Sorumlu CC ile Gönder" (eski
``MailSendWorker``) hiçbirinden geçmiyordu (bkz.
``docs/claude-audit/14_AUTONOMOUS_P1_FIXES.md`` FAZ A/B).

Bu modül, o korumaların ``CompanyMailPackage``'a (ek dosya üretimine)
BAĞIMLI OLMAYAN halidir: yalnızca ``MailDraft`` (``code``, ``to``, ``cc``,
``subject``, ``attachments``) ve dönem/kuyruk/günlük nesnelerine ihtiyaç
duyar. Her iki gönderim yolu (paketli ve paketsiz) artık AYNI fonksiyonları
çağırır — hiçbiri kendi idempotency mantığını yeniden yazmaz.

Fonksiyonlar ``PackageSendWorker``'ın (``app/mailing/package_worker.py``)
eski özel metodlarından AYNI mantıkla, davranış değiştirmeden çıkarılmıştır;
o sınıf artık bunları çağırır (bkz. ``PackageSendWorker._kuyruk_hazirla`` vb.).
"""

from __future__ import annotations

from typing import Callable, Iterable, Optional, Sequence

from loguru import logger

from app.services.mail_log import MailLogEntry


def _mail_status_of(result) -> str:
    """Gönderim sonucunu takip durumuna çevir.

    ``SEND_UNKNOWN`` ayrı tutulur: "gitmedi" değil, "bilmiyoruz" demektir ve
    insan incelemesi gerektirir.
    """
    from app.services.mail_log import STATUS_FAILED, STATUS_SEND_UNKNOWN

    if result.sent:
        return "SENT"
    if result.status == STATUS_SEND_UNKNOWN:
        return STATUS_SEND_UNKNOWN
    if result.status == STATUS_FAILED:
        return "SEND_FAILED"
    return "WAITING"


# -- kalıcı kuyruk ------------------------------------------------------------

def prepare_queue(queue, log, period: str, *,
                  meta_by_code: Optional[dict] = None) -> None:
    """Kuyruğu resume et (yarım işleri UNKNOWN'a çek) ve kuyruk gerçeğini
    MailLog kapısına yansıt.

    FAIL-CLOSED: kurtarma durumu okunamazsa ``QueueUnavailableError`` yükselir
    ve çağıran taraf HİÇBİR mail göndermemelidir.

    ``meta_by_code``: ``{firma_kodu: {"company_name": str}}`` (isteğe bağlı,
    yalnızca günlük okunabilirliği için — kurtarma mantığını etkilemez).
    """
    from app.services.send_queue import QueueUnavailableError

    geri_alinan = queue.resume()
    if geri_alinan:
        logger.warning(
            f"[kuyruk] {geri_alinan} yarım kalmış gönderim BELİRSİZ "
            "olarak işaretlendi; otomatik tekrar YAPILMAYACAK.")
    if log is not None and period:
        try:
            _recover_queue_into_log(queue, log, period,
                                    meta_by_code=meta_by_code or {})
        except QueueUnavailableError as exc:
            raise QueueUnavailableError(
                f"{exc} HİÇBİR mail gönderilmedi.") from exc


def _recover_queue_into_log(queue, log, period: str, *, meta_by_code: dict) -> int:
    """Kuyrukta SENT/UNKNOWN/SENDING olup MailLog kapısında OLMAYAN firmaları
    kapıya yansıt. İDEMPOTENT: kapıda zaten olan firma atlanır.

    * kuyruk ``SENT``                -> MailLog ``SENT``
    * kuyruk ``UNKNOWN``/``SENDING`` -> MailLog ``SEND_UNKNOWN`` (mail
      gitmiş OLABİLİR; otomatik tekrar yok, insan incelemesi)
    ``SENDING`` ayrıca kuyrukta ``UNKNOWN``a çekilir (15 dk beklenmez:
    yeniden başlatan süreç, öncekinin ölü olduğunu bilir).
    """
    from app.services.mail_log import STATUS_SEND_UNKNOWN, STATUS_SENT
    from app.services.send_queue import STATUS_SENDING, QueueUnavailableError
    from app.services.send_queue import STATUS_SENT as Q_SENT

    kayitli = set(log.no_resend_codes(period))
    yazilan = 0
    for item in queue.recoverable(period):
        kod = item.company_code
        if kod in kayitli:
            if item.status == STATUS_SENDING:
                queue.mark_unknown(item.queue_id, "Kapıda zaten kayıtlı.")
            continue
        gitti = item.status == Q_SENT
        payload = item.payload or {}
        meta = meta_by_code.get(kod, {})
        entry = MailLogEntry(
            company_code=kod, period=period,
            status=STATUS_SENT if gitti else STATUS_SEND_UNKNOWN,
            company_name=meta.get("company_name", ""),
            recipients="; ".join(payload.get("to") or []),
            subject=str(payload.get("subject") or ""),
            attachments=tuple(str(a) for a in
                              (payload.get("attachments") or [])),
            reason=("Gönderim kuyruğundan kurtarıldı: mail gitmişti, "
                    "günlük yazılamadan süreç kesilmişti."
                    if gitti else
                    "Gönderim sırasında süreç kesildi; mail gitmiş "
                    "OLABİLİR. Otomatik tekrar gönderilmez; Gönderilmiş "
                    "Öğeler doğrulanmalı."),
            run_id=item.batch_id or None, sent_at=item.updated_at,
            message_id=item.message_id,
            conversation_id=item.conversation_id,
            entry_id=item.entry_id,
            mail_status="SENT" if gitti else STATUS_SEND_UNKNOWN)
        if not log.record(entry):
            raise QueueUnavailableError(
                f"{kod}: kuyruktaki gönderim durumu MailLog'a "
                "yansıtılamadı.")
        kayitli.add(kod)
        yazilan += 1
        if item.status == STATUS_SENDING:
            queue.mark_unknown(
                item.queue_id, "Süreç gönderim sırasında kesildi; "
                "sonuç bilinmiyor. Gönderilmiş Öğeler doğrulanmalı.")
    if yazilan:
        logger.warning(
            f"[kuyruk] {yazilan} firma kuyruktan MailLog kapısına "
            "yansıtıldı (önceki çalıştırma yarıda kesilmiş); bu firmalara "
            "otomatik tekrar gönderim YAPILMAYACAK.")
    return yazilan


def enqueue_drafts(queue, drafts: Sequence, period: str, *,
                   run_id: str = "") -> dict[str, str]:
    """Gönderilecek taslakları kalıcı kuyruğa yaz.

    Döner: ``{firma_kodu: queue_id}``. Kuyruk kaydı alınamayan firma
    sözlükte YER ALMAZ ve gönderim öncesi kapıda GÖNDERİLMEZ (fail-closed).

    Ek dosyalar ``draft.attachments``'tan okunur — paketli akışta bu zaten
    ``CompanyMailPackage.attachments`` ile AYNI listedir (bkz.
    ``CompanyPackageService._build_mail``); paketsiz akışta (FAZ1) boştur.
    """
    from app.services.send_queue import QueueItem

    kimlikler: dict[str, str] = {}
    for draft in drafts:
        item = QueueItem(
            company_code=draft.code, period=period,
            batch_id=run_id or "",
            payload={"subject": draft.subject,
                     "to": list(draft.to),
                     "cc": list(draft.cc),
                     "attachments": [str(a) for a in draft.attachments]})
        # INSERT OR IGNORE: aynı (batch, dönem, firma) varsa yeni satır
        # eklenmez; GERÇEK satırı anahtarla okuyup onun kimliğini kullanırız.
        queue.enqueue(item)
        try:
            kayit = queue.get_by_key(period, item.batch_id, draft.code)
        except Exception as exc:  # noqa: BLE001 - okunamadı: GÖNDERME
            logger.error(f"[kuyruk] {draft.code} kaydı okunamadı: {exc}")
            continue
        if kayit is not None:
            kimlikler[draft.code] = kayit.queue_id
    return kimlikler


def make_before_send(queue, queue_ids: dict, engellenen: set, *,
                     force: bool = False) -> Callable[[str], bool]:
    """``send_with_results(on_before_send=...)`` için kapı üretir.

    Send() ÖNCESİ kalıcı SENDING kaydı. Yazılamazsa GÖNDERME.
    """
    def gonderim_oncesi(code: str) -> bool:
        queue_id = queue_ids.get(code, "")
        if queue_id and queue.mark_sending(queue_id, force=force):
            return True
        engellenen.add(code)
        logger.error(
            f"[kuyruk] {code}: gönderim öncesi kayıt alınamadı; "
            "mükerrer mektup riskine karşı GÖNDERİLMEDİ.")
        return False
    return gonderim_oncesi


def make_result_sink(queue, queue_ids: dict,
                     engellenen: set) -> Callable[[object], None]:
    """``send_with_results(on_result=...)`` için her sonucu ANINDA kuyruğa
    yazan kanca üretir."""
    def sonuc_geldi(result) -> None:
        if result.code in engellenen:
            # Kapı tarafından engellenen firmanın kuyruktaki GERÇEK
            # durumu (SENT/UNKNOWN/SENDING) FAILED ile ezilmez.
            return
        queue_id = queue_ids.get(result.code, "")
        if queue_id:
            queue.apply_result(queue_id, result)
    return sonuc_geldi


# -- günlük --------------------------------------------------------------

def record_results(log, period: str, results: Iterable, drafts_by_code: dict,
                   *, meta_by_code: Optional[dict] = None,
                   run_id: Optional[str] = None,
                   snapshots: Optional[dict] = None) -> None:
    """Her sonucu ANINDA değil ama parti sonunda ``MailLog``'a yazar
    (``on_result`` kuyruğu zaten anlık yazdığı için bu adım tekrar
    kesintiye karşı DEĞİL, kalıcı günlük/takip kaydı içindir).

    ``meta_by_code``: ``{firma_kodu: {"company_name": str, "directions": [...]}}``
    (isteğe bağlı, paketli akışta kullanılır; FAZ1'de boş/``None``).
    """
    if log is None or not period:
        return
    meta_by_code = meta_by_code or {}
    snapshots = snapshots or {}
    for r in results:
        draft = drafts_by_code.get(r.code)
        meta = meta_by_code.get(r.code, {})
        snapshot = snapshots.get(r.code)
        log.record(MailLogEntry(
            company_code=r.code,
            period=period,
            status=r.status,
            company_name=meta.get("company_name", ""),
            locale=draft.locale if draft else "",
            directions=",".join(meta.get("directions") or []),
            recipients="; ".join(draft.to) if draft else "",
            subject=draft.subject if draft else "",
            attachments=tuple(draft.attachments) if draft else (),
            reason=r.reason,
            run_id=run_id,
            # Takip kimlikleri: firmanın cevabı geldiğinde bu mutabakata
            # KESİN olarak bağlanmasını sağlar.
            message_id=getattr(r, "message_id", ""),
            conversation_id=getattr(r, "conversation_id", ""),
            entry_id=getattr(r, "entry_id", ""),
            mail_status=_mail_status_of(r),
            send_id=snapshot.send_id if snapshot else "",
            snapshot_id=snapshot.snapshot_id if snapshot else "",
            responsible=(draft.responsible if draft else ""),
        ))


def verify_identities(log, period: str, results, snapshots: Optional[dict] = None,
                      store=None, folder=None) -> None:
    """Gönderilmiş öğeden EntryID/Message-ID/ConversationID'yi doğrula.

    BEST-EFFORT: başarısız olursa gönderim etkilenmez; yalnızca kimlik
    doğrulanmamış kalır ve kayıt ``identity_verified=0`` olur.

    Güncelleme ``send_id`` ile yapılır: aynı firmaya aynı dönemde ikinci
    bir mail gitmişse firma+dönem ile yazmak iki kaydı birden ezerdi.
    """
    adaylar = [r for r in results
               if getattr(r, "sent", False) or getattr(r, "unknown", False)]
    if not adaylar:
        return
    try:
        from app.mailing.outlook_client import identity_key, resolve_sent_identity

        kimlikler = resolve_sent_identity(adaylar, folder)
    except Exception as exc:  # noqa: BLE001 - takip bilgisi maili bozmaz
        logger.warning(f"Gönderim kimlikleri doğrulanamadı: {exc}")
        return
    snapshots = snapshots or {}
    for r in adaylar:
        kimlik = kimlikler.get(identity_key(r))
        if kimlik is None:
            continue
        # Sonuç nesnesi de güncellenir: çağıran taraf (case tohumlama,
        # özet ekranı) doğrulanmış kimliği görmelidir.
        for alan in ("entry_id", "message_id", "conversation_id"):
            deger = getattr(kimlik, alan, "")
            if deger:
                try:
                    setattr(r, alan, deger)
                except Exception:  # noqa: BLE001 - donmuş nesne olabilir
                    pass
        snapshot = snapshots.get(r.code)
        send_id = snapshot.send_id if snapshot else ""
        log.update_tracking(r.code, period,
                            message_id=kimlik.message_id,
                            conversation_id=kimlik.conversation_id,
                            entry_id=kimlik.entry_id,
                            identity_verified=True,
                            send_id=send_id)
        if snapshot is not None and store is not None:
            try:
                store.mark_sent(send_id,
                                message_id=kimlik.message_id,
                                conversation_id=kimlik.conversation_id)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    f"[snapshot] kimlik işlenemedi ({r.code}): {exc}")


def complete_missing_ids(log, period: str, results, snapshots: Optional[dict] = None,
                         store=None) -> None:
    """Kimliksiz kalan gönderimler için Message-ID'yi sonradan tamamla.

    BEST-EFFORT: başarısız olursa gönderim etkilenmez. Zincir kimliği
    (ConversationID) zaten varsa hiç denenmez — eşleşme onunla da kesindir
    ve gereksiz COM çağrısı partiyi yavaşlatır.

    Güncelleme ``send_id`` ile yapılır: aynı firmaya aynı dönemde ikinci
    bir mail gitmişse firma+dönem ile yazmak iki kaydı birden ezerdi.
    """
    eksik = [r for r in results
             if r.sent and not r.message_id and not r.conversation_id
             and getattr(r, "entry_id", "")]
    if not eksik:
        return
    try:
        from app.mailing.outlook_client import resolve_sent_message_ids

        resolved = resolve_sent_message_ids(eksik)
    except Exception as exc:  # noqa: BLE001 - takip bilgisi maili bozmaz
        logger.warning(f"Message-ID tamamlanamadı: {exc}")
        return
    snapshots = snapshots or {}
    for r in eksik:
        message_id = resolved.get(r.entry_id, "")
        if not message_id:
            continue
        snapshot = snapshots.get(r.code)
        send_id = snapshot.send_id if snapshot else ""
        log.update_tracking(r.code, period, message_id=message_id,
                            send_id=send_id)
        if snapshot is not None and store is not None:
            try:
                store.mark_sent(send_id, message_id=message_id)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    f"[snapshot] Message-ID işlenemedi ({r.code}): {exc}")
