"""Kullanıcı girdileri için kaynak tüketimi güvenlik sınırları."""

from __future__ import annotations

import io
import zipfile
from pathlib import Path

MAX_INPUT_FILE_BYTES = 100 * 1024 * 1024
MAX_ZIP_ENTRIES = 20_000
MAX_ZIP_UNCOMPRESSED_BYTES = 512 * 1024 * 1024
MAX_ZIP_MEMBER_BYTES = 256 * 1024 * 1024
ZIP_SUFFIXES = frozenset({".xlsx", ".xlsm", ".xltx", ".xltm"})


class UnsafeInputError(ValueError):
    """Dosya güvenlik/kaynak sınırlarını aşıyor veya kabı geçersiz."""


def _validate_zip(source, label: str) -> None:
    try:
        with zipfile.ZipFile(source) as archive:
            entries = archive.infolist()
            if len(entries) > MAX_ZIP_ENTRIES:
                raise UnsafeInputError(
                    f"{label}: Excel kabı çok fazla parça içeriyor "
                    f"({len(entries)} > {MAX_ZIP_ENTRIES}).")
            expanded = 0
            for info in entries:
                # Şifreli ZIP üyeleri openpyxl tarafından güvenilir biçimde
                # işlenemez; beklenmedik parola istemi/okuma hatası yerine reddet.
                if info.flag_bits & 0x1:
                    raise UnsafeInputError(f"{label}: şifreli Excel kabı desteklenmiyor.")
                if info.file_size > MAX_ZIP_MEMBER_BYTES:
                    raise UnsafeInputError(
                        f"{label}: Excel içindeki '{info.filename}' parçası "
                        "güvenli boyut sınırını aşıyor.")
                expanded += info.file_size
                if expanded > MAX_ZIP_UNCOMPRESSED_BYTES:
                    raise UnsafeInputError(
                        f"{label}: Excel'in açılmış boyutu güvenli sınırı aşıyor ")
    except zipfile.BadZipFile as exc:
        raise UnsafeInputError(f"{label}: geçersiz/bozuk Excel ZIP kabı.") from exc


def validate_input_file(path: str | Path) -> None:
    p = Path(path)
    try:
        size = p.stat().st_size
    except OSError as exc:
        raise UnsafeInputError(f"Dosya bilgisi okunamadı: {p}") from exc
    if size > MAX_INPUT_FILE_BYTES:
        raise UnsafeInputError(
            f"{p.name}: dosya boyutu güvenli sınırı aşıyor "
            f"({size} > {MAX_INPUT_FILE_BYTES} bayt).")
    if p.suffix.lower() in ZIP_SUFFIXES:
        _validate_zip(p, p.name)


def validate_input_bytes(data: bytes, filename: str = "ek") -> None:
    if len(data) > MAX_INPUT_FILE_BYTES:
        raise UnsafeInputError(
            f"{filename}: içerik güvenli boyut sınırını aşıyor.")
    if Path(filename).suffix.lower() in ZIP_SUFFIXES:
        _validate_zip(io.BytesIO(data), filename)
