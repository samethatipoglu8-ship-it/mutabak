"""FAZ 6 — top-level orchestration: profiling → scoring → conflict-free
assignment → override → explainable result.

ADVISORY/DORMANT: bu modülün ``infer_schema`` fonksiyonu hiçbir üretim
yükleyicisi (``TofasLoader``/``FirmaLoader``) tarafından ÇAĞRILMAZ.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Optional, Sequence

from pydantic import BaseModel, Field

from .evidence import FieldEvidence
from .profiling import ColumnProfile, NumericLocale, build_column_profile, normalize_header_text
from .roles import SemanticRole
from .scoring import RoleCandidate, ScoreReason, score_column

#: İki aday skoru bu kadardan az farklıysa AMBIGUOUS sayılır (üst üste
#: binen, eşit-geçerli adaylar — kullanıcı talimatı Aşama 6: "preserve
#: alternatives rather than arbitrarily hiding one").
AMBIGUITY_SCORE_GAP = 0.08

#: Bir role en fazla bu kadar alternatif taşınır (açıklanabilirlik +
#: performans — sınırsız liste büyümez).
MAX_ALTERNATIVES = 3

#: Aynı anda TEK bir kolona atanması gereken roller (ör. bir kolon hem DEBIT
#: hem CREDIT OLAMAZ — kullanıcı talimatı Aşama 6, madde 1). Bu roller
#: öncelik sırasıyla işlenir; bir kolon bir role atandıktan sonra o kolon
#: SONRAKİ exclusive rollerin havuzundan ÇIKARILIR (bkz. ``assign_roles``).
_EXCLUSIVE_PRIORITY: tuple[SemanticRole, ...] = (
    SemanticRole.TRANSACTION_DATE,
    SemanticRole.DUE_DATE,
    SemanticRole.POSTING_DATE,
    SemanticRole.DEBIT,
    SemanticRole.CREDIT,
    SemanticRole.BALANCE,
    SemanticRole.SIGNED_AMOUNT,
    SemanticRole.DOCUMENT_AMOUNT,
    SemanticRole.DOCUMENT_CURRENCY,
    SemanticRole.COUNTERPARTY_CODE,
    SemanticRole.COUNTERPARTY_NAME,
    SemanticRole.DOCUMENT_TYPE,
)

#: Birden fazla kolon aynı role eşit geçerlilikte aday olabilir; TEKİNİ
#: zorla seçmek yerine hepsi ``alternatives``'ta tutulur (kullanıcı talimatı
#: Aşama 6, madde 3).
MULTI_ROLES: frozenset[SemanticRole] = frozenset({
    SemanticRole.DOCUMENT_NUMBER,
    SemanticRole.EXTERNAL_DOCUMENT_NUMBER,
    SemanticRole.REFERENCE,
    SemanticRole.DESCRIPTION,
})


class SourceProfile(BaseModel):
    """Aşama 9 — jenerik, isimli bir kaynak profili (ör. GENERIC_TR_CARI).

    BİLEREK İÇERMEZ: sign convention, tax-identity semantiği, FX politikası,
    gross/net politikası, clearing semantiği (kullanıcı talimatı, birebir).
    Bunlardan biri eklenmek istenirse GERÇEK export örneği + finans onayı +
    test + açık review GEREKİR (bkz. doc 20 §22).
    """

    name: str
    description: str
    header_aliases: dict[SemanticRole, frozenset[str]] = Field(default_factory=dict)
    known_file_types: tuple[str, ...] = ()
    locale_hint: Optional[NumericLocale] = None
    evidence: list[FieldEvidence] = Field(default_factory=list)


#: Doc 16 §8.2'nin ZATEN KOD-KANITLI, üretimde doğrulanmış GENERIC_TR_CARI
#: alias kümesinden türetilmiş KÜÇÜK bir ipucu alt-kümesi. Bu, ``column_
#: mapper.py``'nin BÜYÜK sözlüğünü TEKRARLAMAZ/DEĞİŞTİRMEZ — salt scoring'e
#: ek bir "bu zaten bilinen bir profil" sinyali verir. Harici bir ERP
#: vendor'ının araştırma iddiası DEĞİLDİR (bu yüzden ``evidence=[]`` — proje
#: kendi karakterizasyon testlerinden gelir, dış kaynak ATIFI gerekmez).
GENERIC_TR_CARI = SourceProfile(
    name="GENERIC_TR_CARI",
    description=(
        "Türkiye genel cari ekstre başlık seti: tarih/belge no/referans/"
        "vade/açıklama/borç/alacak/bakiye (doc 16 §8.2, test-kanıtlı)."
    ),
    header_aliases={
        SemanticRole.TRANSACTION_DATE: frozenset({"tarih"}),
        SemanticRole.DUE_DATE: frozenset({"vade", "vadetarihi"}),
        SemanticRole.DOCUMENT_NUMBER: frozenset({"belgeno", "faturano"}),
        SemanticRole.DESCRIPTION: frozenset({"aciklama"}),
        SemanticRole.DEBIT: frozenset({"borc"}),
        SemanticRole.CREDIT: frozenset({"alacak"}),
        SemanticRole.BALANCE: frozenset({"bakiye"}),
    },
    known_file_types=(".xlsx", ".csv"),
    locale_hint=NumericLocale.TR_STYLE,
    evidence=[],
)


class RoleAssignment(BaseModel):
    """Aşama 11 — açıklanabilir, salt-okunur rol önerisi (production kararı
    DEĞİL)."""

    role: SemanticRole
    column_index: Optional[int] = None
    header_raw: Optional[str] = None
    confidence: float = 0.0
    reasons: list[ScoreReason] = Field(default_factory=list)
    alternatives: list[RoleCandidate] = Field(default_factory=list)
    ambiguous: bool = False
    override_applied: bool = False
    source_profile_hint: Optional[str] = None


class SchemaOverride(BaseModel):
    """Aşama 10 — deterministik, denetlenebilir manuel/config override.

    Çıkarımdan ÖNCELİKLİDİR, ham kaynağı DEĞİŞTİRMEZ, profil/kaynağa
    kapsanabilir (``profile_scope``), test edilebilir.
    """

    profile_scope: Optional[str] = None
    source_column_header: str
    role: SemanticRole
    reason: Optional[str] = None


class SchemaInferenceResult(BaseModel):
    """Aşama 2/11 — tüm pipeline'ın açıklanabilir çıktısı."""

    source_name: str
    column_profiles: list[ColumnProfile] = Field(default_factory=list)
    assignments: dict[SemanticRole, RoleAssignment] = Field(default_factory=dict)
    overrides_applied: list[SchemaOverride] = Field(default_factory=list)


def assign_roles(
    column_profiles: list[ColumnProfile],
    candidates_by_column: dict[int, list[RoleCandidate]],
) -> dict[SemanticRole, RoleAssignment]:
    """Aşama 6 — Hungarian YOK. Basit, deterministik, çakışmasız atama +
    alternatifler. Hedef: "best proposal + confidence + alternatives",
    "force one role no matter what" DEĞİL.
    """
    by_role: dict[SemanticRole, list[RoleCandidate]] = defaultdict(list)
    for candidates in candidates_by_column.values():
        for c in candidates:
            by_role[c.role].append(c)
    for lst in by_role.values():
        lst.sort(key=lambda c: (-c.score, c.column_index))

    assignments: dict[SemanticRole, RoleAssignment] = {}
    consumed: set[int] = set()

    for role in _EXCLUSIVE_PRIORITY:
        candidates = [c for c in by_role.get(role, []) if c.column_index not in consumed]
        if not candidates:
            assignments[role] = RoleAssignment(role=role)
            continue
        top, rest = candidates[0], candidates[1:]
        ambiguous = bool(rest) and (top.score - rest[0].score) < AMBIGUITY_SCORE_GAP
        assignments[role] = RoleAssignment(
            role=role, column_index=top.column_index, header_raw=top.header_raw,
            confidence=top.score, reasons=top.reasons,
            alternatives=rest[:MAX_ALTERNATIVES], ambiguous=ambiguous,
        )
        consumed.add(top.column_index)

    for role in MULTI_ROLES:
        candidates = by_role.get(role, [])
        if not candidates:
            assignments[role] = RoleAssignment(role=role)
            continue
        top, rest = candidates[0], candidates[1:]
        ambiguous = bool(rest) and (top.score - rest[0].score) < AMBIGUITY_SCORE_GAP
        assignments[role] = RoleAssignment(
            role=role, column_index=top.column_index, header_raw=top.header_raw,
            confidence=top.score, reasons=top.reasons,
            alternatives=rest[:MAX_ALTERNATIVES], ambiguous=ambiguous,
        )
    return assignments


def apply_overrides(
    result: SchemaInferenceResult, overrides: Sequence[SchemaOverride],
) -> SchemaInferenceResult:
    """Aşama 10 — override, çıkarımın ÜZERİNE yazar (daha yüksek öncelik),
    ham kolon DEĞERLERİNİ değiştirmez, denetlenebilir (``overrides_applied``
    listesine eklenir).
    """
    updated = result.model_copy(deep=True)
    for override in overrides:
        if override.profile_scope is not None and override.profile_scope != result.source_name:
            continue
        target = normalize_header_text(override.source_column_header)
        match = next(
            (p for p in updated.column_profiles if p.header_normalized == target), None,
        )
        if match is None:
            continue
        updated.assignments[override.role] = RoleAssignment(
            role=override.role, column_index=match.index, header_raw=match.header_raw,
            confidence=1.0,
            reasons=[ScoreReason(
                code="manual_override", weight=1.0,
                detail=override.reason or "açık manuel override",
            )],
            alternatives=[], ambiguous=False, override_applied=True,
        )
        updated.overrides_applied.append(override)
    return updated


def infer_schema(
    headers: list[object],
    rows: list[list[object]],
    *,
    source_name: str = "unknown",
    profile_hint: Optional[SourceProfile] = None,
    overrides: Sequence[SchemaOverride] = (),
) -> SchemaInferenceResult:
    """Aşama 2 hedef zinciri — TEK giriş noktası (dormant, advisory).

    ``Raw file -> source/file profiling -> column profiling -> candidate
    semantic roles -> deterministic scoring -> conflict-free assignment ->
    confidence -> alternatives -> explicit override -> canonical mapping
    proposal``. Hiçbir aşama üretim kayıtları/``Reconciler`` üretmez.
    """
    n_cols = len(headers)
    header_strings = ["" if h is None else str(h) for h in headers]
    column_profiles: list[ColumnProfile] = []
    candidates_by_column: dict[int, list[RoleCandidate]] = {}

    for idx, header in enumerate(headers):
        values = [row[idx] if idx < len(row) else None for row in rows]
        neighbors = [header_strings[j] for j in (idx - 1, idx + 1) if 0 <= j < n_cols and j != idx]
        profile = build_column_profile(idx, header, values, neighboring_headers=neighbors)
        column_profiles.append(profile)
        candidates_by_column[idx] = score_column(profile, profile_hint=profile_hint)

    assignments = assign_roles(column_profiles, candidates_by_column)
    if profile_hint is not None:
        for role, assignment in assignments.items():
            if assignment.column_index is not None:
                assignment.source_profile_hint = profile_hint.name

    result = SchemaInferenceResult(
        source_name=source_name, column_profiles=column_profiles, assignments=assignments,
    )
    if overrides:
        result = apply_overrides(result, overrides)
    return result
