"""Şirket-bazlı hesap prefiks yapılandırması.

120 / 320 / 323 hesap mantığı önceden kod içinde sabitti. Şirket sayısı
arttıkça (Company A: 320/323, Company B: 320/321, Company C: 120/121 ...) bu
bilginin yapılandırmaya taşınması gerekir. Bu modül ``config/companies.yaml``
dosyasını okur ve mod + (opsiyonel) şirket için hesap prefikslerini çözer.

Yapılandırma bulunamazsa ya da PyYAML kurulu değilse, kod içindeki güvenli
varsayılanlara (DEFAULTS) düşer — böylece uygulama her koşulda çalışır.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from app.utils.paths import resolved_config_path

# Kod içi güvenli varsayılanlar (YAML yoksa kullanılır). reconciliation_service
# içindeki _ACCOUNT_PREFIXES_BY_MODE ile aynı davranış.
DEFAULTS: dict[str, Optional[tuple[str, ...]]] = {
    "yerli": ("120", "121"),
    "yabanci": ("320", "323"),
    "birlikte": None,
}

# Varsayılan yapılandırma dosyası: paketlenmiş .exe yanındaki config/
# klasöründe bir kopya varsa ONU, yoksa gömülü (_internal) varsayılanı kullanır
# (bkz. mimari inceleme bulgusu: _internal\\config kullanıcının bulabileceği
# bir yer değildir).
_DEFAULT_CONFIG_PATH = resolved_config_path("companies.yaml")


class CompanyConfig:
    """YAML tabanlı hesap prefiks çözücü. Dosya yoksa varsayılanlara düşer."""

    def __init__(self, path: str | Path | None = None) -> None:
        self._path = Path(path) if path else _DEFAULT_CONFIG_PATH
        self._data: dict = self._load()

    @property
    def path(self) -> Path:
        """Etkin yapılandırma dosyasının yolu (manifest hash'i için)."""
        return self._path

    def _load(self) -> dict:
        if not self._path.exists():
            return {}
        try:
            import yaml  # PyYAML
        except ImportError:
            return {}
        try:
            with self._path.open("r", encoding="utf-8") as fh:
                data = yaml.safe_load(fh) or {}
            return data if isinstance(data, dict) else {}
        except Exception:  # noqa: BLE001 - yapılandırma hatası asla çökertmesin
            return {}

    # -- çözümleme ----------------------------------------------------------

    def _default_for_mode(self, mode: str) -> Optional[tuple[str, ...]]:
        defaults = self._data.get("defaults") or {}
        if mode in defaults:
            val = defaults[mode]
            return tuple(str(x) for x in val) if val else None
        return DEFAULTS.get(mode, DEFAULTS["birlikte"])

    def account_prefixes(
        self, mode: str, company: Optional[str] = None
    ) -> Optional[tuple[str, ...]]:
        """Mod (+ opsiyonel şirket) için hesap prefikslerini döndür.

        - 'birlikte' modunda daima filtre kapalıdır (None).
        - Şirket verildi ve YAML'de tanımlıysa şirkete özel prefiksler kullanılır.
        - Aksi halde mod-bazlı defaults (YAML ya da kod içi) kullanılır.
        """
        if mode == "birlikte":
            return None

        if company:
            companies = self._data.get("companies") or {}
            entry = companies.get(company) or companies.get(company.upper())
            if isinstance(entry, dict):
                key = "customer_accounts" if mode == "yerli" else "supplier_accounts"
                val = entry.get(key)
                if val:
                    return tuple(str(x) for x in val)

        return self._default_for_mode(mode)
