"""Firma bazlı mutabakat mail üreteci (FAZ1).

Kurallar (kullanıcı doğruladı):
  - Firma kodu: A kolonundaki değerin EN SAĞDAN 8 hanesi. (Örnek dosyada tüm
    kodlar 7 hane; 8'den kısa ise olduğu gibi alınır, 8'den uzunsa son 8.)
  - Yerli/Yabancı: firma kodunun SOLDAN İLK rakamı. 4 -> yabancı (İngilizce),
    2 -> yerli (Türkçe). Diğer -> yabancı varsayımı YOK; net işaretlenir.
  - E kolonu: M / S / X. X == S (kullanıcı kararı). B/A yön bilgisi YOK SAYILIR.
    Tutar mutlak değeriyle yazılır.
  - Bakiye: J(TL)/L(EUR)/N(USD) kolonlarında 0,00 / 0.00 dışı değer varsa maile
    girer. Aynı anda birden çok döviz olabilir -> "and" ile birleştirilir.
  - Bir firma kodu birden çok satırda olabilir (biri M biri S); TEK mail üretilir,
    her yön/segment ayrı blok olarak metne girer.
  - Sayı biçimi: TR binlik/ondalık (1.234.567,89).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Dict, List, Optional

from app.mailing.excel_loader import MailRow
from app.utils.email import is_valid_email

# --- Ay adları ---------------------------------------------------------------
MONTHS_EN = ["January", "February", "March", "April", "May", "June",
             "July", "August", "September", "October", "November", "December"]
MONTHS_TR = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran",
             "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]

# Ayın son günü (basit, kütüphanesiz).
def _last_day_of_month(year: int, month: int) -> int:
    import calendar
    return calendar.monthrange(year, month)[1]


def normalize_code(code_raw: str) -> str:
    """A kolonu değerinden firma kodunu türetir: en sağdan 8 hane.

    - Yalnızca rakamlar dikkate alınır (float '.0' gibi ekler zaten loader'da
      temizlenir ama garanti için burada da rakam süzülür).
    - 8'den uzunsa son 8 hane; kısa/eşitse tümü.
    """
    s = str(code_raw).strip()
    # Float eki (ör. '4449668.0') -> ondalık kısmı at; aksi hâlde sondaki
    # sıfır rakama karışır. Sadece '<rakam>.0' / '<rakam>.00' kalıbında.
    if "." in s:
        head, _, tail = s.partition(".")
        if head.isdigit() and set(tail) <= {"0"}:
            s = head
    digits = "".join(ch for ch in s if ch.isdigit())
    if len(digits) > 8:
        return digits[-8:]
    return digits


def classify_locale(code: str) -> str:
    """Firma koduna göre 'tr' (yerli) / 'en' (yabancı) döndürür.

    Soldan ilk rakam: 2 -> yerli, 4 -> yabancı. Diğerlerinde 'unknown'.
    """
    if not code:
        return "unknown"
    first = code[0]
    if first == "2":
        return "tr"
    if first == "4":
        return "en"
    return "unknown"


def effective_ms(ms: str) -> str:
    """E kolonu değerini etkin yöne indirger: X -> S; M -> M; boş -> S varsayımı YOK."""
    u = (ms or "").strip().upper()
    if u == "M":
        return "M"
    if u in ("S", "X"):
        return "S"
    return ""  # tanınmayan -> çağıran taraf karar verir


def fmt_amount_tr(value: Decimal) -> str:
    """Decimal'i TR binlik/ondalık biçimine çevirir: 1234567.89 -> '1.234.567,89'.

    B/A yön bilgisi yok sayıldığından mutlak değer yazılır.
    """
    q = abs(value).quantize(Decimal("0.01"))
    sign, digits, exp = q.as_tuple()
    s = f"{q:.2f}"           # '1234567.89'
    int_part, dec_part = s.split(".")
    # Binlik ayraç ekle.
    grouped = ""
    for i, ch in enumerate(reversed(int_part)):
        if i and i % 3 == 0:
            grouped = "." + grouped
        grouped = ch + grouped
    return f"{grouped},{dec_part}"


# Mail metnindeki döviz sırası. Listede olmayanlar alfabetik olarak SONA
# eklenir — SESSİZCE DÜŞÜRÜLMEZ.
BALANCE_ORDER = ("TL", "EUR", "USD")


def format_balances(balances: Dict[str, Decimal]) -> str:
    """Sıfır-olmayan bakiyeleri 'X.XXX,XX EUR and Y USD' biçiminde birleştirir.

    Sıra: TL, EUR, USD; ardından diğer para birimleri alfabetik.

    ÖNEMLİ: Eskiden yalnızca TL/EUR/USD yazılır, SAP'tan gelen CNY/GBP/JPY
    gibi para birimleri sessizce düşerdi — mutabakat mektubunda eksik bir
    döviz, yanlış bilgi demektir.
    """
    def order(code: str) -> tuple[int, str]:
        return ((BALANCE_ORDER.index(code), "") if code in BALANCE_ORDER
                else (len(BALANCE_ORDER), code))

    parts = [f"{fmt_amount_tr(balances[c])} {c}"
             for c in sorted(balances, key=order) if balances[c] != 0]
    if not parts:
        return ""
    if len(parts) == 1:
        return parts[0]
    return " and ".join([", ".join(parts[:-1]), parts[-1]])


# --- Mail modeli -------------------------------------------------------------
@dataclass
class MailDraft:
    code: str                    # normalize edilmiş 8 haneli kod
    locale: str                  # 'tr' / 'en' / 'unknown'
    to: List[str]                # P kolonu mailleri (birleşik, tekilleştirilmiş)
    cc: List[str] = field(default_factory=list)
    subject: str = ""
    body: str = ""
    responsible: str = ""
    row_indices: List[int] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    # Maile eklenecek dosyaların TAM yolları (Excel ekstre + PDF mektup).
    # Boş bırakılırsa mail eksiz gider; mevcut FAZ1 davranışı değişmez.
    attachments: List[str] = field(default_factory=list)
    # Gönderimi ENGELLEYEN gerekçe (boşsa engel yok). Taslak yine üretilir ki
    # firma ekranda görünsün ve NEDEN gönderilmediği yazılabilsin; eskiden bu
    # firmalar sessizce listeden düşüyordu.
    blocked_reason: str = ""

    @property
    def invalid_recipients(self) -> List[str]:
        return [x for x in [*self.to, *self.cc] if not is_valid_email(x)]

    @property
    def has_recipient(self) -> bool:
        return (bool(self.to) and not self.invalid_recipients
                and bool(self.body.strip()))

    @property
    def needs_confirmation(self) -> bool:
        """Dil belirlenemedi — otomatik toplu gönderime GİRMEZ.

        Firma kodu 2/4 ile başlamıyorsa yerli mi yabancı mı bilinmiyordur.
        Eskiden bu durumda sessizce İNGİLİZCE mail gönderiliyordu: yerli bir
        firmaya yanlış dilde mutabakat mektubu gitmesi riski vardı. Artık böyle
        taslaklar toplu gönderimde atlanır ve kullanıcı bunları ayrıca (ör.
        'Seçili Firmalara Gönder' ile) bilerek göndermek zorundadır.
        """
        return self.locale == "unknown"

    @property
    def sendable(self) -> bool:
        return (self.has_recipient and not self.needs_confirmation
                and not self.blocked_reason)

    @property
    def skip_reason(self) -> str:
        """Gönderilemiyorsa NEDEN gönderilemediği (gönderilebiliyorsa boş).

        Ekranda ve gönderim özetinde bu metin gösterilir: bir firmanın
        listede görünüp mail almaması artık açıklamasız kalmaz.
        """
        if not self.to:
            return "firma mail adresi tanımlı değil"
        if self.invalid_recipients:
            return "geçersiz e-posta adresi: " + ", ".join(self.invalid_recipients)
        if not self.body.strip():
            return "mail gövdesi üretilemedi"
        if self.needs_confirmation:
            return ("firma kodu 2/4 ile başlamıyor, DİL belirlenemedi; "
                    "yanlış dilde mail gitmesin diye atlandı")
        if self.blocked_reason:
            return self.blocked_reason
        return ""


@dataclass
class BuildConfig:
    year: int
    month: int                   # 1-12
    include_responsible_cc: bool = False
    # İsim -> mail adresi eşlemesi (6. madde: sorumlu maili CC).
    responsible_emails: Dict[str, str] = field(default_factory=dict)
    extra_cc: List[str] = field(default_factory=list)


# --- Metin şablonları --------------------------------------------------------
def _body_en(blocks: List[str], as_of: str) -> str:
    inner = "\n\n".join(blocks)
    return f"Dear,\n\n{inner}\n\nKind regards.\nTOFAŞ"


def _body_tr(blocks: List[str], as_of: str) -> str:
    inner = "\n\n".join(blocks)
    return f"Sayın Yetkili,\n\n{inner}\n\nSaygılarımızla,\nTOFAŞ"


def _block_en(ms: str, amounts: str, as_of: str) -> str:
    if ms == "M":
        return (f"The amount must be paid by you is {amounts} as of {as_of}.")
    # S (X dahil)
    return (f"The amount must be paid by TOFAS is {amounts} as of {as_of}. "
            f"Please confirm this.")


def _block_tr(ms: str, amounts: str, as_of: str) -> str:
    if ms == "M":
        return (f"Şirketiniz tarafından ödenmesi gereken tutar {amounts} "
                f"({as_of} itibarıyla)'dir.")
    return (f"TOFAŞ tarafından ödenmesi gereken tutar {amounts} "
            f"({as_of} itibarıyla)'dir. Lütfen teyit ediniz.")


# Rapordaki tüm bakiyeler 0 olduğunda para birimi bilgisi kalmaz; İngilizce
# metinde bir kod yazmak gerektiği için şirketin ulusal para birimi kullanılır.
# (Ekli akışta bu değer FBL1H'daki gerçek para biriminden seçilir.)
ZERO_BALANCE_CURRENCY = "TRY"


def zero_balance_block(locale: str, currency: str = "TRY") -> str:
    """Tüm dövizlerde bakiyesi 0 olan firma için mesaj (kullanıcı kararı).

    Sıfır bakiye gönderimi ENGELLEMEZ; yalnızca metin değişir. Türkçe metinde
    para birimi geçmez, İngilizce metinde geçer.
    """
    if locale == "tr":
        return "Ödemeyi bekleyen faturanız bulunmamaktadır. Onaylıyor musunuz?"
    return f"Your balance is 0.00 {currency}. May you please confirm?"


def period_end_date(year: int, month: int) -> str:
    """Dönemin son günü — gg.aa.yyyy (ör. Temmuz 2026 → ``31.07.2026``).

    Mail gövdesindeki "… itibarıyla" tarihi ile AYNI değerdir; tek bir yerden
    üretilir ki konu ile gövde asla farklı tarih göstermesin.
    """
    return f"{_last_day_of_month(year, month):02d}.{month:02d}.{year}"


def _subject(code: str, locale: str, year: int, month: int) -> str:
    """Mail konusu — mevcut düzen korunur, SONUNA dönem sonu tarihi eklenir.

    Tarih hem yerli (TR) hem yabancı (EN) mailde aynı biçimdedir (gg.aa.yyyy)
    ve her ayın SON günüdür. Konu satırındaki bu tarih, gelen cevapların doğru
    döneme bağlanmasını da kolaylaştırır: aynı firmanın Haziran ve Temmuz
    mutabakatı artık konu satırından ayırt edilebilir.
    """
    as_of = period_end_date(year, month)
    if locale == "tr":
        return f"{code} {MONTHS_TR[month - 1]} Mutabakatı - TOFAŞ - {as_of}"
    return f"{code} {MONTHS_EN[month - 1]} Reconciliation with TOFAS - {as_of}"


# --- Ana kurucu --------------------------------------------------------------
def build_drafts(rows: List[MailRow], config: BuildConfig,
                 only_codes: Optional[set[str]] = None,
                 address_registry=None) -> List[MailDraft]:
    """Satırları firma koduna göre gruplar, her grup için tek MailDraft üretir.

    only_codes verilirse yalnızca o kodlar için üretir (5. buton: seçili firmalar).
    """
    as_of = period_end_date(config.year, config.month)

    # Grupla: normalize kod -> satırlar.
    groups: Dict[str, List[MailRow]] = {}
    for r in rows:
        code = normalize_code(r.code_raw)
        if not code:
            continue
        if only_codes is not None and code not in only_codes:
            continue
        groups.setdefault(code, []).append(r)

    #: adres -> engel gerekçesi (çağrı boyunca geçerli; bkz. aşağıdaki not)
    blocked_cache: Dict[str, str] = {}

    drafts: List[MailDraft] = []
    for code in sorted(groups):
        grp = groups[code]
        locale = classify_locale(code)
        warnings: List[str] = []

        # to / responsible: satırlar arasında farklı olabilir -> birleştir/tekille.
        to: List[str] = []
        for r in grp:
            for m in r.mails:
                if is_valid_email(m) and m not in to:
                    to.append(m)
        invalid_addresses = list(dict.fromkeys(
            m for r in grp for m in [*r.invalid_mails, *r.mails]
            if not is_valid_email(m)))
        if invalid_addresses:
            warnings.append(
                "Geçersiz e-posta adresi: " + ", ".join(invalid_addresses))
        responsibles = [r.responsible for r in grp if r.responsible]
        responsible = responsibles[0] if responsibles else ""
        if len(set(responsibles)) > 1:
            warnings.append("Aynı firma kodunda farklı mutabakat sorumluları var.")

        # Her satır için bakiye bloğu üret (yalnızca sıfır-olmayan bakiyesi olan).
        # Aynı yön (M/S) + aynı bakiye kümesi tekrarı tekilleştirilir (kullanıcı
        # kararı A): mükerrer S/X kayıtları tek cümle olarak yazılır, toplanmaz.
        blocks: List[str] = []
        seen_keys: set = set()
        has_balance = False
        for r in grp:
            nz = r.nonzero_balances
            if not nz:
                continue
            has_balance = True
            ms = effective_ms(r.ms)
            if not ms:
                warnings.append(f"Tanınmayan E kolonu değeri: '{r.ms}' (satır {r.row_index}).")
                # X==S kararı gereği tanınmayanı da S kabul etmiyoruz; atlıyoruz.
                continue
            # Tekilleştirme anahtarı: yön + (para birimi -> tutar) kümesi.
            key = (ms, tuple(sorted((c, str(v)) for c, v in nz.items())))
            if key in seen_keys:
                continue
            seen_keys.add(key)
            amounts = format_balances(nz)
            if locale == "tr":
                blocks.append(_block_tr(ms, amounts, as_of))
            else:
                blocks.append(_block_en(ms, amounts, as_of))

        # Bakiyesi TAMAMEN sıfır olan firma da mail alır (kullanıcı kararı):
        # metin "ödemeyi bekleyen faturanız yok, onaylıyor musunuz?" olur.
        # Ekli akış (7/9) zaten böyle davranıyordu; iki akış artık aynı.
        blocked_reason = ""
        if not blocks:
            if has_balance:
                # Bakiye VAR ama yön (M/S) hiçbir satırda okunamadı: hangi
                # tarafın ödeyeceği bilinmeden mail gönderilemez. Taslak yine
                # üretilir ki firma ekranda gerekçesiyle görünsün.
                blocked_reason = (
                    "M/S kolonu tanınmadı; ödeme yönü belirlenemediği için "
                    "gönderilmedi")
                warnings.append(blocked_reason + ".")
            else:
                blocks = [zero_balance_block(locale, ZERO_BALANCE_CURRENCY)]

        if locale == "unknown":
            warnings.append("Firma kodu 2/4 ile başlamıyor; dil belirlenemedi (İngilizce kullanıldı).")

        body = (_body_tr(blocks, as_of) if locale == "tr"
                else _body_en(blocks, as_of))
        subject = _subject(code, locale, config.year, config.month)

        # CC: sorumlu maili (6. madde).
        cc = list(config.extra_cc)
        if config.include_responsible_cc and responsible:
            addr = config.responsible_emails.get(responsible.strip())
            if addr:
                for a in addr.replace(",", ";").split(";"):
                    a = a.strip()
                    if is_valid_email(a) and a not in cc:
                        cc.append(a)
                    elif a:
                        invalid_addresses.append(a)
            else:
                warnings.append(f"Sorumlu '{responsible}' için mail adresi tanımlı değil.")

        if not to:
            warnings.append("Firma mail adresi (P kolonu) boş.")
        if address_registry is not None:
            # ADRES BAŞINA TEK SORGU.
            #
            # ``blocked_reason`` her çağrıda YENİ bir SQLite bağlantısı açıp
            # kapatıyor. Aynı mail adresi birçok firmada geçtiği için
            # 600 firmalı bir dönemde bu, binden fazla bağlantı demekti
            # (ağ sürücüsündeki .db dosyasında saniyeler). Sonuç çağrı
            # boyunca önbelleğe alınır; doğruluk değişmez, çünkü tek bir
            # taslak üretimi sırasında adres durumu sabittir.
            blocked = []
            for address in to:
                if address not in blocked_cache:
                    blocked_cache[address] = address_registry.blocked_reason(address)
                reason = blocked_cache[address]
                if reason:
                    blocked.append(reason)
            if blocked and not blocked_reason:
                blocked_reason = "teslimatı engellenmiş adres: " + "; ".join(blocked)
                warnings.append(blocked_reason)
        if invalid_addresses and not blocked_reason:
            blocked_reason = (
                "geçersiz e-posta adresi: "
                + ", ".join(dict.fromkeys(invalid_addresses)))

        drafts.append(MailDraft(
            code=code, locale=locale, to=to, cc=cc, subject=subject, body=body,
            responsible=responsible,
            row_indices=[r.row_index for r in grp],
            warnings=warnings,
            blocked_reason=blocked_reason,
        ))

    return drafts
