"""Canonical layer: source-agnostic model + adapters + engine facade.

Additive to the V4 system. The V4 domain models remain the source of truth for
reconciliation behaviour; this layer generalises them so the same engine can be
fed from Excel/PDF/PNG/UBL/ERP once those extractors/connectors land.
"""

from .adapters import (
    canonical_to_firma,
    canonical_to_tofas,
    firma_to_canonical,
    map_match_status,
    to_canonical,
    tofas_to_canonical,
)
from .evidence import ExtractionMethod, FieldEvidence
from .facade import CanonicalReconciler
from .model import (
    CanonicalMatchStatus,
    DocumentType,
    ReconciliationRecord,
    RecordSide,
)

__all__ = [
    "ReconciliationRecord",
    "RecordSide",
    "DocumentType",
    "CanonicalMatchStatus",
    "FieldEvidence",
    "ExtractionMethod",
    "CanonicalReconciler",
    "to_canonical",
    "tofas_to_canonical",
    "firma_to_canonical",
    "canonical_to_tofas",
    "canonical_to_firma",
    "map_match_status",
]
