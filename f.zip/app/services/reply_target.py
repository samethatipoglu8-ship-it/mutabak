"""Hatırlatma/aksiyon maili HANGİ maile cevap olarak gitmeli?

SORUN
    Hatırlatma her seferinde İLK mutabakat mailinden cevaplanıyordu:
    ``build_reminder`` yalnızca ``case.conversation_id`` /
    ``case.message_id`` alanlarını kullanıyor, bunlar da gönderim
    anındaki (ilk) kimliklerdi. Üçüncü hatırlatma da birinci mailin
    altına düşüyor, firma "aynı maili tekrar gönderiyorlar" görüyordu.

ÇÖZÜM
    Her başarılı gönderimde yakalanan yeni kimlikler vakaya yazılır
    (``last_outbound_*``). Bir sonraki mail EN SON gönderdiğimiz maili
    hedefler. İLK gönderimin kimlikleri EZİLMEZ; son kimlik geçersizse
    ona düşülür.

HEDEF SIRASI (güçlüden zayıfa)
    1. last_outbound_entry_id          — yerel Outlook kimliği, en güçlü
    2. last_outbound_message_id        — RFC 5322 Message-ID
    3. doğrulanmış conversation zinciri
    4. initial_outbound_entry_id
    5. initial_outbound_message_id
    6. doğrulanmış ilk mutabakat mesajı (case.message_id)

CONVERSATION TEK BAŞINA YETMEZ
    ``ConversationID`` TEKİL DEĞİLDİR: aynı konuşmaya ikinci bir
    mutabakat gönderilmiş olabilir. Bu yüzden yalnızca conversation
    varsa, firma kodu / dönem / alıcı doğrulaması aranır. Doğrulanamazsa
    HEDEF YOK denir — yeni mail AÇILMAZ.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

#: Hedefin hangi kanıta dayandığı (izlenebilirlik için timeline'a yazılır).
SOURCE_LAST_ENTRY = "last_outbound_entry_id"
SOURCE_LAST_MESSAGE = "last_outbound_message_id"
SOURCE_LAST_CONVERSATION = "last_outbound_conversation_id"
SOURCE_INITIAL_ENTRY = "initial_outbound_entry_id"
SOURCE_INITIAL_MESSAGE = "initial_outbound_message_id"
SOURCE_CASE_MESSAGE = "case.message_id"
SOURCE_CASE_CONVERSATION = "case.conversation_id"


@dataclass
class ReplyTarget:
    """Cevaplanacak mailin kimlikleri ve bu kararın gerekçesi."""

    entry_id: str = ""
    message_id: str = ""
    conversation_id: str = ""
    source: str = ""
    blocked_reason: str = ""

    @property
    def ready(self) -> bool:
        return not self.blocked_reason and bool(
            self.entry_id or self.message_id or self.conversation_id)


def _s(case: Any, name: str) -> str:
    return str(getattr(case, name, "") or "").strip()


def conversation_verified(case: Any) -> bool:
    """Conversation fallback'i DENEMEYE değer mi?

    DİKKAT — BU SON SÖZ DEĞİLDİR.
        Burada yalnızca "Outlook'ta arama yapıp doğrulayabilecek kadar
        kanıtımız var mı?" sorusu yanıtlanır. Gerçek doğrulama, bulunan
        ÖĞENİN kendisi üzerinde yapılır (outlook_client.verify_item):
        alıcı adresleri kesişiyor mu, konu firma kodunu/dönemi taşıyor mu.

        Vaka alanlarının dolu olması TEK BAŞINA kanıt sayılmaz; bu yüzden
        yalnızca ``company_code`` yeterli DEĞİLDİR — doğrulamayı
        yapabilmek için alıcı listesi ya da gönderim kimliği gerekir.
    """
    if _s(case, "send_id"):
        return True
    # Alıcı adresi olmadan bulunan öğeyi doğrulayamayız.
    alicilar = _s(case, "recipients")
    return bool(_s(case, "company_code") and "@" in alicilar)


def resolve_target(case: Any) -> ReplyTarget:
    """Bu vaka için cevaplanacak maili seç.

    Hiçbir güvenilir hedef yoksa ``blocked_reason`` doldurulur ve
    ÇAĞIRAN YENİ MAİL AÇMAZ — sessizce yanlış zincire yazmaktansa
    kullanıcıya "zincir bulunamadı" demek doğrudur.
    """
    # 1-2) En son GÖNDERDİĞİMİZ mail.
    if _s(case, "last_outbound_entry_id"):
        return ReplyTarget(
            entry_id=_s(case, "last_outbound_entry_id"),
            message_id=_s(case, "last_outbound_message_id"),
            conversation_id=_s(case, "last_outbound_conversation_id"),
            source=SOURCE_LAST_ENTRY)
    if _s(case, "last_outbound_message_id"):
        return ReplyTarget(
            message_id=_s(case, "last_outbound_message_id"),
            conversation_id=_s(case, "last_outbound_conversation_id"),
            source=SOURCE_LAST_MESSAGE)

    # 3) Son gönderimin conversation'ı — yalnızca DOĞRULANMIŞSA.
    if _s(case, "last_outbound_conversation_id") and conversation_verified(case):
        return ReplyTarget(
            conversation_id=_s(case, "last_outbound_conversation_id"),
            source=SOURCE_LAST_CONVERSATION)

    # 4-5) İlk mutabakat gönderiminin kimlikleri.
    if _s(case, "initial_outbound_entry_id"):
        return ReplyTarget(entry_id=_s(case, "initial_outbound_entry_id"),
                           message_id=_s(case, "initial_outbound_message_id"),
                           conversation_id=_s(case, "conversation_id"),
                           source=SOURCE_INITIAL_ENTRY)
    if _s(case, "initial_outbound_message_id"):
        return ReplyTarget(message_id=_s(case, "initial_outbound_message_id"),
                           conversation_id=_s(case, "conversation_id"),
                           source=SOURCE_INITIAL_MESSAGE)

    # 6) Vakanın kendi kayıtlı kimlikleri (gönderim anından).
    if _s(case, "message_id"):
        return ReplyTarget(message_id=_s(case, "message_id"),
                           conversation_id=_s(case, "conversation_id"),
                           source=SOURCE_CASE_MESSAGE)
    if _s(case, "conversation_id"):
        if not conversation_verified(case):
            return ReplyTarget(blocked_reason=(
                "Yalnızca ConversationID var ve bu vakaya ait olduğu "
                "DOĞRULANAMADI (firma kodu/dönem/gönderim kimliği eksik). "
                "Yanlış firmaya cevap yazma riskine karşı mail "
                "hazırlanmadı."))
        return ReplyTarget(conversation_id=_s(case, "conversation_id"),
                           source=SOURCE_CASE_CONVERSATION)

    return ReplyTarget(blocked_reason=(
        "Mail zinciri kimliği yok; Reply-All yapılamaz "
        "(gönderim kaydında entry/message/conversation id bulunamadı)."))


def record_outbound(case: Any, result: Any, kind: str, *,
                    now: Optional[str] = None) -> None:
    """Başarılı gönderimin kimliklerini vakaya işle.

    * İLK gönderimin kimlikleri BOŞSA doldurulur, doluysa DOKUNULMAZ.
    * Son gönderim kimlikleri her seferinde güncellenir.
    * Boş dönen bir kimlik, dolu olan eskisini EZMEZ (Outlook bazen
      kimlik veremez; elde olanı kaybetmemek gerekir).
    """
    from app.services.incoming_cases import _now  # yerel: döngüsel import yok

    zaman = now or _now()
    entry = str(getattr(result, "entry_id", "") or "")
    message = str(getattr(result, "message_id", "") or "")
    conversation = str(getattr(result, "conversation_id", "") or "")

    if not _s(case, "initial_outbound_entry_id") and entry:
        case.initial_outbound_entry_id = entry
    if not _s(case, "initial_outbound_message_id") and message:
        case.initial_outbound_message_id = message

    if entry:
        case.last_outbound_entry_id = entry
    if message:
        case.last_outbound_message_id = message
    if conversation:
        case.last_outbound_conversation_id = conversation
    case.last_outbound_at = zaman
    case.last_outbound_kind = kind
