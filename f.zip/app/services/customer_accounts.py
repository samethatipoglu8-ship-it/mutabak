"""Müşteri (120*) alt hesabı → firma kodu eşlemesi.

Neden gerekli: SAP FBL1H çıktısında ``Firma Kodu`` ve ``Satıcı hesabı: Ad 1``
alanları YALNIZCA satıcı (320/323) kalemlerinde dolar. Müşteri (120) kalemlerinde
bu alanlar boştur; satırın hangi müşteriye ait olduğu ana hesabın alt kırılımında
(ör. ``1200102003``) saklıdır. Bu modül o kırılımı firma koduna bağlayan,
dışarıdan düzenlenebilir eşleme tablosunu okur.

Tasarım ilkesi: eşleme YOKSA satır bir firmaya ATANMAZ. Tahmin edilmez, en
büyük firmaya yazılmaz — yanlış atama, yanlış firmaya milyonluk bakiye
göndermek demektir. Eşlenemeyen hesaplar ``Fbl1hLoadResult`` içinde sayaçla
raporlanır ki eksik eşleme sessizce kaybolmasın.

Yapılandırma bulunamazsa ya da PyYAML kurulu değilse boş eşleme ile çalışır;
davranış eşleme eklenmeden önceki hâliyle aynıdır (120 satırları dışlanır).
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from app.services.errors import DataValidationError
from app.utils.paths import resolved_config_path

# Paketlenmiş .exe yanındaki config/ klasöründe bir kopya varsa ONU, yoksa
# gömülü (_internal) varsayılanı kullanır.
_DEFAULT_CONFIG_PATH = resolved_config_path("customer_accounts.yaml")


def normalize_account(value: object) -> Optional[str]:
    """Ana hesap değerini kanonik metne indir.

    Excel sayısal hücreleri pandas üzerinden ``3230101000.0`` gibi float
    artığıyla gelir; sondaki ``.0`` atılır. Boş/anlamsız değer için None.
    """
    if value is None:
        return None
    text = str(value).strip()
    if not text or text.lower() in {"nan", "none", "null"}:
        return None
    if text.endswith(".0") and text[:-2].isdigit():
        text = text[:-2]
    return text or None


class CustomerAccountMap:
    """``120*`` alt hesabı → (firma kodu, firma adı) eşlemesi."""

    def __init__(
        self,
        path: str | Path | None = None,
        mapping: Optional[dict[str, tuple[str, str]]] = None,
    ) -> None:
        if mapping is not None:
            self._map = dict(mapping)
            self._path = None
            return
        self._path = Path(path) if path else _DEFAULT_CONFIG_PATH
        self._map = self._load()

    def _load(self) -> dict[str, tuple[str, str]]:
        if self._path is None or not self._path.exists():
            return {}
        try:
            import yaml  # PyYAML
        except ImportError:
            return {}
        try:
            with self._path.open("r", encoding="utf-8") as fh:
                data = yaml.safe_load(fh) or {}
        except Exception:  # noqa: BLE001 - yapılandırma hatası asla çökertmesin
            return {}
        if not isinstance(data, dict):
            return {}

        entries = data.get("accounts") or {}
        if not isinstance(entries, dict):
            return {}

        out: dict[str, tuple[str, str]] = {}
        for raw_account, value in entries.items():
            account = normalize_account(raw_account)
            if not account:
                continue
            # Değer ya doğrudan firma kodu ya da {company_code, name} sözlüğü.
            if isinstance(value, dict):
                code = value.get("company_code")
                name = value.get("name") or ""
            else:
                code, name = value, ""
            if code is None:
                continue
            code = normalize_account(code) or str(code).strip()
            if code:
                out[account] = (code, str(name).strip())
        return out

    # -- sorgulama ---------------------------------------------------------

    @property
    def is_empty(self) -> bool:
        return not self._map

    def resolve(self, main_account: object) -> Optional[tuple[str, str]]:
        """Ana hesap için (firma kodu, firma adı) döndür; eşleme yoksa None."""
        account = normalize_account(main_account)
        if account is None:
            return None
        return self._map.get(account)

    def accounts(self) -> list[str]:
        return sorted(self._map)


# -- mod uyarısı -----------------------------------------------------------

#: 120* müşteri hesaplarına dokunan modlar. Bu modlarda eşleme tablosu boşsa
#: FBL5H/FBL1H müşteri satırları hiçbir firmaya atanamaz ve mutabakat
#: sessizce EKSİK çalışır — kullanıcı uyarılmalıdır.
MODES_NEEDING_CUSTOMER_MAP = frozenset({"yerli", "birlikte"})


def customer_mapping_warning(mode: str,
                             account_map: "CustomerAccountMap | None" = None
                             ) -> str:
    """DEPRECATED — boş eşleme tablosu TEK BAŞINA sorun değildir.

    Bu uyarı, yalnızca ``customer_accounts.yaml`` boş diye müşteri modunda
    kalıcı bir uyarı gösteriyordu. Gerçek FBL5H çıktısıyla test edilince
    yanlış olduğu görüldü: FBL5H firma kodunu ``Müşteri`` kolonunda
    verir; eşleme tablosu BOŞKEN bile 126 müşteri sorunsuz çözülüyor
    (0 eşlenmemiş hesap, 0 atlanan satır).

    Eşleme tablosu yalnızca 120* satırlarının firma kodu OLMADAN geldiği
    dışa-aktarımlarda gerekir. Bunu dosya yüklenmeden bilmek mümkün
    değildir; bu yüzden uyarı artık VERİYE bakan
    :func:`unmapped_customer_warning`'a taşındı.

    Geriye dönük uyum için korunur ve HER ZAMAN boş döner.
    """
    return ""


def unmapped_customer_warning(unmapped: "dict[str, int] | None") -> str:
    """Veriden gelen GERÇEK uyarı: hangi 120* hesabı firmaya bağlanamadı?

    ``CompanyStatementService`` bu sayımı zaten üretiyordu ama hiçbir yerde
    gösterilmiyordu: sahte uyarı bağırırken gerçek sinyal sessizce
    atılıyordu.

    Eşlenemeyen satır bir firmaya ATANMAZ — tahmin edilmez. Dolayısıyla o
    satırların bakiyesi hiçbir mutabakat mektubuna girmez; kullanıcı bunu
    bilmelidir.
    """
    if not unmapped:
        return ""
    toplam = sum(unmapped.values())
    hesaplar = ", ".join(
        f"{hesap} ({adet} satır)"
        for hesap, adet in sorted(unmapped.items(), key=lambda x: -x[1])[:5])
    ek = " …" if len(unmapped) > 5 else ""
    return (
        f"{len(unmapped)} müşteri hesabı ({toplam} satır) hiçbir firmaya "
        f"bağlanamadı: {hesaplar}{ek}\n\n"
        "Bu satırlar TAHMİN EDİLMEZ; hiçbir mutabakat mektubuna girmezler. "
        "Bağlamak için config/customer_accounts.yaml dosyasına ilgili "
        "hesap → firma kodu eşlemesini ekleyin."
    )


def require_complete_customer_mapping(unmapped: "dict[str, int] | None") -> None:
    """Block package generation when customer balances have no owner.

    Showing a warning after files are generated is not a sufficient financial
    control: the omitted balance can otherwise be followed by a partial bulk
    send.  The caller must resolve the account mapping or use an explicitly
    approved source that identifies every customer before any package exists.
    """
    message = unmapped_customer_warning(unmapped)
    if message:
        raise DataValidationError(
            "Toplu paket üretimi engellendi: müşteri hesap eşlemesi eksik.\n\n"
            + message
        )
