"""FAZ 11 — "Karşılaştır" akışının orkestrasyonu (§6, §7, §11, §15).

TEK BİR SATIR İÇİN NE OLUR
    1. Case okunur; yön (M/S) hangi FBL dosyasının kullanılacağını söyler.
    2. Gelen ekler kalıcı depodan geri okunur (tarama sırasında saklanmıştı).
    3. MEVCUT mutabakat motoru çalıştırılır — yeni bir motor yazılmaz.
    4. Fark, ekstre kararı, güven puanı ve açıklaması güncellenir.
    5. Nihai durum yeniden hesaplanır (ekstre kararı body kararını EZER).
    6. İşlem geçmişine kayıt düşülür.

KULLANICI MÜDAHALESİ KORUNUR
    Kullanıcı bir satırı elle yeşil/kırmızı yaptıysa, otomatik karşılaştırma
    o kararı EZMEZ. Rakamlar güncellenir, karar kullanıcıda kalır; aradaki
    fark işlem geçmişinde görünür.

HİÇBİR ŞEY TAHMİN EDİLMEZ
    Ek yoksa "ekstre yok", dosya okunamadıysa "kontrol edilemedi" denir.
    Boş veri, mutabakat sayılmaz.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Optional, Sequence

from loguru import logger

from app.services.case_tracking import (
    STATUS_INCELEME,
    STATUS_MUTABIK,
    STATUS_RED,
    STATUS_WAITING,
    color_for,
)
from app.services.confidence import score_case
from app.services.current_fbl_reconciliation import (
    CurrentFblComparison,
    CurrentFblReconciliationService,
)
from app.services.incoming_attachments import IncomingAttachmentStore
from app.services.incoming_cases import IncomingCase, IncomingCaseStore

# Ekstre kararı sabitleri (§8).
STATEMENT_MATCHED = "STATEMENT_MATCHED"
STATEMENT_DIFFERENCE = "STATEMENT_DIFFERENCE_FOUND"
STATEMENT_NOT_AVAILABLE = "STATEMENT_NOT_AVAILABLE"
STATEMENT_UNREADABLE = "STATEMENT_UNREADABLE"
STATEMENT_MANUAL = "STATEMENT_MANUAL_REVIEW"

# Body kararı sabitleri (§8).
BODY_MUTABIK = "BODY_MUTABIK"
BODY_RED = "BODY_RED"
BODY_SARTLI = "BODY_SARTLI"
BODY_BELIRSIZ = "BODY_BELIRSIZ"
BODY_FATURA = "BODY_FATURA_GONDERILDI"
BODY_CEVAP_YOK = "BODY_CEVAP_YOK"

_BODY_BY_REPLY = {
    "ACCEPTED": BODY_MUTABIK,
    "REJECTED": BODY_RED,
    "PARTIALLY_ACCEPTED": BODY_SARTLI,
    "REQUESTED_CORRECTION": BODY_SARTLI,
    "INFORMATION_ONLY": BODY_BELIRSIZ,
    "UNKNOWN": BODY_BELIRSIZ,
}


def body_decision_of(case: IncomingCase) -> str:
    """Mail gövdesinin kararı — ekstreden BAĞIMSIZ."""
    if not case.has_reply:
        return BODY_CEVAP_YOK
    if case.invoice_received:
        return BODY_FATURA
    return _BODY_BY_REPLY.get((case.reply_type or "").upper(), BODY_BELIRSIZ)


def statement_decision_of(comparison: Optional[CurrentFblComparison]) -> str:
    """Ekstre karşılaştırmasının kararı."""
    if comparison is None:
        return STATEMENT_NOT_AVAILABLE
    if comparison.error:
        return STATEMENT_MANUAL
    if comparison.statement is None:
        return (STATEMENT_NOT_AVAILABLE if "NO_ATTACHMENT" in comparison.reasons
                else STATEMENT_UNREADABLE)
    if comparison.difference_found is True:
        return STATEMENT_DIFFERENCE
    if comparison.difference_found is False:
        return STATEMENT_MATCHED
    return STATEMENT_UNREADABLE


@dataclass
class ComparisonOutcome:
    """Bir satırın karşılaştırma sonucu (toplu işlemde raporlanır)."""

    case_id: str = ""
    company_code: str = ""
    ok: bool = False
    statement_decision: str = ""
    difference: str = ""
    error: str = ""

    @property
    def label(self) -> str:
        if self.error:
            return f"HATA: {self.error[:60]}"
        return self.statement_decision or "—"


class CaseComparisonService:
    """Case bazlı karşılaştırma; UI bilmez, thread bilmez."""

    def __init__(
        self,
        fbl_service: Optional[CurrentFblReconciliationService] = None,
        case_store: Optional[IncomingCaseStore] = None,
        attachment_store: Optional[IncomingAttachmentStore] = None,
    ) -> None:
        self._fbl = fbl_service or CurrentFblReconciliationService()
        self._cases = case_store
        self._attachments = attachment_store

    @property
    def fbl(self) -> CurrentFblReconciliationService:
        return self._fbl

    # -- tek satır ---------------------------------------------------------

    def compare_case(self, case: IncomingCase, *,
                     attachments: Optional[Sequence[Any]] = None,
                     user: str = "") -> ComparisonOutcome:
        """Tek bir case'i güncel FBL ile karşılaştır ve kaydı güncelle."""
        outcome = ComparisonOutcome(case_id=case.case_id,
                                    company_code=case.company_code)
        try:
            ekler = list(attachments) if attachments is not None else \
                self._load_attachments(case)
            comparison = self._fbl.reconcile(case, ekler)
            self._apply(case, comparison, user=user)

            outcome.statement_decision = case.statement_decision
            outcome.difference = case.financial_difference
            outcome.error = comparison.error
            outcome.ok = not comparison.error
        except Exception as exc:  # noqa: BLE001 - tek satır partiyi durdurmaz
            logger.exception(f"[karşılaştır] {case.company_code} başarısız")
            outcome.error = f"{type(exc).__name__}: {exc}"
            case.statement_decision = STATEMENT_MANUAL
            case.add_event("COMPARE_ERROR", "Karşılaştırma hata verdi",
                           user=user, detail=outcome.error)
            case.needs_human_review = True
        finally:
            if self._cases is not None:
                self._cases.upsert(case)
        return outcome

    def _load_attachments(self, case: IncomingCase) -> list[Any]:
        if self._attachments is None:
            return []
        stored = self._attachments.load_attachments(case.incoming_attachments)
        if not stored:
            stored = [a for a in
                      (self._attachments.for_case(case.case_id) or [])]
            from app.incoming.models import IncomingAttachment

            stored = [IncomingAttachment(filename=s.filename,
                                         content=s.read_bytes(),
                                         path=s.path)
                      for s in stored if s.exists]
        return stored

    # -- kaydı güncelle ----------------------------------------------------

    def _apply(self, case: IncomingCase, comparison: CurrentFblComparison,
               *, user: str = "") -> None:
        onceki_karar = case.statement_decision
        onceki_durum = case.final_status

        case.statement_decision = statement_decision_of(comparison)
        case.body_decision = body_decision_of(case)
        case.statement_result = comparison.summary()

        fark = comparison.difference_total
        case.financial_difference = str(fark) if comparison.compared else ""
        analysis = (comparison.statement.analysis
                    if comparison.statement else None)
        case.difference_currency = getattr(analysis, "currency", "") or ""

        celiski = (case.body_decision == BODY_MUTABIK
                   and case.statement_decision == STATEMENT_DIFFERENCE)
        puan = score_case(
            has_reply=case.has_reply,
            reply_type=case.reply_type,
            attachment_present=bool(case.incoming_attachments),
            attachment_readable=comparison.statement is not None
            and bool(comparison.statement.rows_loaded),
            comparison_done=comparison.compared,
            difference_found=comparison.difference_found,
            contradiction=celiski,
        )
        case.confidence_100 = puan.value
        case.confidence = round(puan.value / 100, 3)
        case.confidence_explanation = puan.explanation

        # Nihai durum: kullanıcı elle karar verdiyse DOKUNULMAZ.
        if not case.manual_override:
            case.final_status = self._final_status(case, comparison, celiski)
            case.status_color = color_for(case.final_status)
        case.needs_human_review = case.final_status in (
            STATUS_INCELEME, STATUS_WAITING) or celiski

        case.add_event(
            "STATEMENT_COMPARED",
            f"Ekstre güncel {comparison.source_type} ile karşılaştırıldı",
            old_value=f"{onceki_karar or '—'} / {onceki_durum or '—'}",
            new_value=f"{case.statement_decision} / {case.final_status}",
            user=user,
            detail=(f"referans satır={comparison.reference_rows} "
                    f"fark={case.financial_difference or '0'} "
                    f"{case.difference_currency}").strip())

    @staticmethod
    def _final_status(case: IncomingCase, comparison: CurrentFblComparison,
                      contradiction: bool) -> str:
        """Karar hiyerarşisi (§8): EKSTRE KARARI BODY'DEN ÜSTÜNDÜR."""
        if case.invoice_received:
            return case.final_status or STATUS_INCELEME
        if case.statement_decision == STATEMENT_DIFFERENCE:
            # "Mutabıkız" dese bile fark varsa yeşil OLMAZ.
            return STATUS_RED
        if case.statement_decision == STATEMENT_MATCHED:
            if case.body_decision in (BODY_RED, BODY_SARTLI):
                return STATUS_INCELEME       # rakam tutuyor ama firma itiraz etti
            if case.body_decision == BODY_MUTABIK:
                return STATUS_MUTABIK
            return STATUS_INCELEME
        if not case.has_reply:
            return STATUS_WAITING
        return STATUS_INCELEME

    # -- toplu -------------------------------------------------------------

    def compare_many(
        self,
        cases: Sequence[IncomingCase],
        *,
        on_progress: Optional[Callable[[int, int, IncomingCase], None]] = None,
        should_cancel: Optional[Callable[[], bool]] = None,
        user: str = "",
    ) -> list[ComparisonOutcome]:
        """Satır satır karşılaştır. Bir satırın hatası diğerlerini DURDURMAZ."""
        results: list[ComparisonOutcome] = []
        total = len(cases)
        for index, case in enumerate(cases, start=1):
            if should_cancel is not None and should_cancel():
                break
            results.append(self.compare_case(case, user=user))
            if on_progress is not None:
                try:
                    on_progress(index, total, case)
                except Exception:  # noqa: BLE001 - ilerleme bildirimi kritik değil
                    pass
        return results


def summarize(outcomes: Sequence[ComparisonOutcome]) -> dict[str, int]:
    """Toplu karşılaştırma özeti (§7 raporlaması)."""
    summary = {"toplam": len(outcomes), "basarili": 0, "fark": 0,
               "ekstre_yok": 0, "okunamadi": 0, "hata": 0}
    for outcome in outcomes:
        if outcome.error:
            summary["hata"] += 1
            continue
        summary["basarili"] += 1
        if outcome.statement_decision == STATEMENT_DIFFERENCE:
            summary["fark"] += 1
        elif outcome.statement_decision == STATEMENT_NOT_AVAILABLE:
            summary["ekstre_yok"] += 1
        elif outcome.statement_decision in (STATEMENT_UNREADABLE,
                                            STATEMENT_MANUAL):
            summary["okunamadi"] += 1
    return summary
