"""Yükleme / eşleştirme hataları.

Sessiz başarısızlık (silent mapping failure) tehlikelidir: sistem bir dosyayı
okuyamadığında ya da zorunlu kolonları bulamadığında "0 kayıt" veya yanlış
tutar üretip mutabakatı bozmak yerine, kullanıcıya NE bulamadığını açıkça
söylemelidir. Bu modül o amaçla kullanılan zengin istisnaları tanımlar.
"""

from __future__ import annotations

from typing import Optional


class MutabakatError(Exception):
    """Tüm uygulama-seviyesi hataların ortak atası."""


class DataValidationError(MutabakatError):
    """Dosya okundu ama içeriği mutabakata uygun değil.

    ``MappingError`` "kolonu bulamadım" der; bu hata ise "kolonu buldum ama
    veri anlamsız" der (ör. sıfır satır). Sessizce boş bir mutabakat üretmek
    yerine kullanıcıya nedenini söylemek için kullanılır.
    """


class MappingError(MutabakatError):
    """Bir ekstrede zorunlu kolonlar (referans / tutar) bulunamadı.

    Kullanıcıya gösterilebilecek şekilde; hangi dosya, hangi başlık satırı ve
    hangi kolonların bulunduğu bilgisini taşır.
    """

    def __init__(
        self,
        message: str,
        *,
        file: Optional[str] = None,
        header_row: Optional[int] = None,
        found_columns: Optional[list[str]] = None,
        missing: Optional[list[str]] = None,
    ) -> None:
        self.file = file
        self.header_row = header_row
        self.found_columns = list(found_columns or [])
        self.missing = list(missing or [])
        super().__init__(self._render(message))

    def _render(self, message: str) -> str:
        parts = [message]
        if self.missing:
            parts.append("Bulunamayan zorunlu kolon(lar): " + ", ".join(self.missing))
        if self.file:
            parts.append(f"Dosya: {self.file}")
        if self.header_row is not None:
            parts.append(f"Başlık satırı: {self.header_row}")
        if self.found_columns:
            cols = ", ".join(str(c) for c in self.found_columns if str(c).strip())
            parts.append(f"Bulunan kolonlar: {cols}")
        return "\n".join(parts)
