"""Shared safety helpers for Excel output."""

from __future__ import annotations

from typing import Any

_FORMULA_PREFIXES = ("=", "+", "-", "@")


def safe_excel_value(value: Any) -> Any:
    """Keep untrusted text as text when a workbook is opened in Excel.

    A leading apostrophe is Excel's explicit text marker and is not displayed
    to the user. Non-string values (dates, Decimal amounts, counters) retain
    their native type and formatting.
    """
    if not isinstance(value, str):
        return value
    if value.lstrip().startswith(_FORMULA_PREFIXES):
        return "'" + value
    return value
