"""«Oran» sayfası — sorumlu (R) bazlı mutabakat karnesi (FAZ 9).

Ekranın tek işi göstermektir: hesap ``app/services/ratio.py`` içindedir ve
Qt bilmez. Veri iki kalıcı depodan gelir — gönderim günlüğü (payda) ve
gelen cevap iş kayıtları (pay). Sorumlu MAİLDEN TAHMİN EDİLMEZ; gönderim
anında «Mutabakat Mailleri» Excel'inin ``(R)`` alanından yazılmıştır.
"""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.services.ratio import RatioReport, format_percent

_COLUMNS = ("Sorumlu", "Toplam", "Mutabık", "Red", "İnceleme", "Cevap Yok",
            "Oran", "Mutabık/Cevaplanan")

TUM_DONEMLER = "Tüm dönemler"


def _row_values(stats) -> tuple:
    return (
        stats.responsible,
        str(stats.total),
        str(stats.mutabik),
        str(stats.red),
        str(stats.inceleme),
        str(stats.bekleyen),
        format_percent(stats.ratio),
        format_percent(stats.answered_ratio),
    )


class RatioPage(QWidget):
    """Sorumlu bazlı mutabakat oranını gösterir."""

    def __init__(self, mail_log=None, case_store=None) -> None:
        super().__init__()
        self._mail_log = mail_log
        self._cases = case_store
        self._report: RatioReport | None = None
        self._build_ui()
        self.refresh()

    # -- arayüz ------------------------------------------------------------

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)

        title = QLabel("Oran")
        title.setObjectName("Title")
        root.addWidget(title)

        aciklama = QLabel(
            "Sorumlu bilgisi «Mutabakat Mailleri» sayfasındaki (R) alanından "
            "gelir ve gönderim anında kaydedilir; mailden tahmin edilmez.\n"
            "Sayım birimi firma + dönemdir: aynı firmaya iki kez mail "
            "gitmesi ya da firmanın iki kez cevap vermesi sayıyı artırmaz.\n"
            "ANA KPI: Mutabık / Toplam Firma."
        )
        aciklama.setWordWrap(True)
        aciklama.setObjectName("Hint")
        root.addWidget(aciklama)

        top = QHBoxLayout()
        top.addWidget(QLabel("Dönem:"))
        self.period_combo = QComboBox()
        self.period_combo.currentIndexChanged.connect(
            lambda _index: self.refresh())
        top.addWidget(self.period_combo)
        self.btn_refresh = QPushButton("Yenile")
        self.btn_refresh.clicked.connect(self.refresh)
        top.addWidget(self.btn_refresh)
        top.addStretch(1)
        root.addLayout(top)

        self.table = QTableWidget(0, len(_COLUMNS))
        self.table.setHorizontalHeaderLabels(list(_COLUMNS))
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setStretchLastSection(True)
        root.addWidget(self.table, 1)

        self.lbl_total = QLabel("")
        self.lbl_total.setWordWrap(True)
        root.addWidget(self.lbl_total)

    # -- veri --------------------------------------------------------------

    def _stores(self):
        """Depoları tembel kur; kurulamazsa sayfa boş ama AÇIK kalır."""
        if self._mail_log is None:
            try:
                from app.services.mail_log import MailLog

                self._mail_log = MailLog()
            except Exception:  # noqa: BLE001
                self._mail_log = None
        if self._cases is None:
            try:
                from app.services.incoming_cases import IncomingCaseStore

                self._cases = IncomingCaseStore()
            except Exception:  # noqa: BLE001
                self._cases = None
        return self._mail_log, self._cases

    def _refresh_periods(self, entries) -> None:
        """Dönem listesini gönderim günlüğünden türet (seçimi koruyarak)."""
        donemler = sorted({(e.period or "").strip() for e in entries
                           if (e.period or "").strip()}, reverse=True)
        secili = self.period_combo.currentData()
        self.period_combo.blockSignals(True)
        try:
            self.period_combo.clear()
            self.period_combo.addItem(TUM_DONEMLER, None)
            for donem in donemler:
                self.period_combo.addItem(donem, donem)
            index = self.period_combo.findData(secili)
            self.period_combo.setCurrentIndex(max(index, 0))
        finally:
            self.period_combo.blockSignals(False)

    def refresh(self) -> None:
        """Oranı yeniden hesapla ve tabloyu doldur. ASLA çökertmez."""
        from app.services.ratio import compute_ratios

        mail_log, cases = self._stores()
        if mail_log is None:
            self.lbl_total.setText("Gönderim günlüğü okunamadı.")
            return
        try:
            entries = mail_log.tracked_mails()
            kayitlar = cases.all() if cases is not None else []
        except Exception as exc:  # noqa: BLE001 - sayfa açık kalsın
            self.lbl_total.setText(f"Veri okunamadı: {exc}")
            return

        self._refresh_periods(entries)
        period = self.period_combo.currentData()
        self._report = compute_ratios(entries, kayitlar, period=period)
        self._fill_table()

    def _fill_table(self) -> None:
        report = self._report
        rows = report.rows if report else []
        self.table.setUpdatesEnabled(False)
        try:
            self.table.clearContents()
            self.table.setRowCount(len(rows))
            for row, stats in enumerate(rows):
                for column, value in enumerate(_row_values(stats)):
                    item = QTableWidgetItem(str(value))
                    if column:
                        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    self.table.setItem(row, column, item)
        finally:
            self.table.setUpdatesEnabled(True)
        self.table.resizeColumnsToContents()

        if report is None or report.total.total == 0:
            self.lbl_total.setText(
                "Bu dönemde gönderilmiş mutabakat maili yok; oran "
                "hesaplanamaz.")
            return
        toplam = report.total
        self.lbl_total.setText(
            f"TOPLAM — Firma: {toplam.total} · Mutabık: {toplam.mutabik} · "
            f"Red: {toplam.red} · İnceleme: {toplam.inceleme} · "
            f"Cevap yok: {toplam.bekleyen} · "
            f"Mutabakat oranı: {format_percent(toplam.ratio)} "
            f"(cevaplananlara göre {format_percent(toplam.answered_ratio)})")
