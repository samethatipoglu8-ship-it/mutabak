"""Açılış (splash) ekranı + arka planda Outlook bağlantısı.

Amaç (kullanıcı kararı):
  - Profesyonel bir açılış ekranı gösterilir.
  - Outlook bağlantısı ARKA PLANDA (QThread) kurulur -> UI asla donmaz
    ("not responding" yok). Bu, kullanıcının gümrük uygulamasındaki
    "Outlook işini ayrı thread'de çalıştır" desenine uygundur.
  - Bağlantı bitene kadar açılış ekranı kalır; başarılı olunca ana pencere
    açılır ve hesap bilgisi gösterilir.
  - Bağlantı BAŞARISIZ olursa ana pencere kısıtlı modda açılır: Excel
    mutabakatı çalışır, Outlook'a bağlı mail özellikleri uyarı gösterir.
"""

from __future__ import annotations

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QFrame,
    QLabel,
    QVBoxLayout,
    QWidget,
)

from app.mailing.outlook_client import get_default_account


class OutlookConnectWorker(QThread):
    """Outlook bağlantısını arka planda kurar; sonucu sinyalle bildirir."""

    ok = Signal(object)      # OutlookAccount
    failed = Signal(str)     # hata mesajı

    def run(self) -> None:
        try:
            account = get_default_account()
        except Exception as exc:  # RuntimeError dahil her şey
            self.failed.emit(str(exc))
            return
        self.ok.emit(account)


class SplashScreen(QWidget):
    """Sade, profesyonel açılış ekranı (frameless)."""

    def __init__(self) -> None:
        super().__init__()
        self.setWindowFlag(Qt.FramelessWindowHint, True)
        self.setWindowFlag(Qt.WindowStaysOnTopHint, True)
        self.setFixedSize(460, 220)

        outer = QVBoxLayout(self)
        card = QFrame()
        card.setObjectName("SplashCard")
        # AÇILIŞ EKRANI KULLANICININ TEMASINI İZLER.
        #
        # Renkler eskiden koyu tema için sabitlenmişti: açık tema seçen
        # kullanıcı, uygulama açılırken bir kare koyu ekran görüyordu.
        # Ayar okunamazsa koyu temaya düşülür (önceki davranış).
        try:
            from app.services.settings import Settings

            acik_tema = Settings().theme == "light"
        except Exception:  # noqa: BLE001 - ayar hatası açılışı engellemez
            acik_tema = False
        if acik_tema:
            zemin, yazi = "#ffffff", "#1e293b"
        else:
            zemin, yazi = "#0f172a", "#e2e8f0"
        card.setStyleSheet(
            f"#SplashCard{{background:{zemin};border-radius:14px;}}"
            f"QLabel{{color:{yazi};}}"
        )
        outer.addWidget(card)
        lay = QVBoxLayout(card)
        lay.setContentsMargins(28, 28, 28, 28)
        lay.setSpacing(10)

        title = QLabel("MutabakatPro")
        tf = QFont()
        tf.setPointSize(20)
        tf.setBold(True)
        title.setFont(tf)
        title.setAlignment(Qt.AlignCenter)
        lay.addWidget(title)

        sub = QLabel("Uygulama açılıyor")
        sf = QFont()
        sf.setPointSize(11)
        sub.setFont(sf)
        sub.setAlignment(Qt.AlignCenter)
        sub.setStyleSheet("color:#94a3b8;")
        lay.addWidget(sub)

        lay.addStretch(1)
        self.status = QLabel("Outlook'a bağlanılıyor, lütfen bekleyiniz…")
        self.status.setAlignment(Qt.AlignCenter)
        self.status.setStyleSheet("color:#38bdf8;")
        lay.addWidget(self.status)

    def set_status(self, text: str) -> None:
        self.status.setText(text)

    def center_on_screen(self) -> None:
        from PySide6.QtGui import QGuiApplication
        screen = QGuiApplication.primaryScreen()
        if screen:
            geo = screen.availableGeometry()
            self.move(geo.center() - self.rect().center())
