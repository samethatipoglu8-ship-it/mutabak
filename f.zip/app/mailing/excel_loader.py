"""Mutabakat raporu Excel yükleyici.

Sabit şablon (kullanıcı doğruladı):
  A Hesap No | E Musteri/Satici (M/S/X) | J TL Bakiye | L EUR Bakiye |
  N USD Bakiye | P Firma Mail | R Mutabakat Sorumlusu | D Firma Adi

Kolonlar HARFE göre değil, başlık adına göre eşlenir (kolon kayması olursa
bozulmamak için). Başlık bulunamazsa net hata verir — sessiz sıfır yok.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Dict, List

from app.utils.email import is_valid_email
from app.utils.file_safety import UnsafeInputError, validate_input_file

# --- Başlık eşleme sözlüğü (rol -> olası başlık adları, normalize edilmiş) ----
# Not: başlıklar aksan/boşluk/case normalize edilerek karşılaştırılır.
_HEADER_ALIASES: Dict[str, List[str]] = {
    "code": ["hesap no", "hesapno", "hesap kodu", "firma kodu", "cari kod"],
    "name": ["firma adi", "firma adı", "unvan", " unvan", "musteri adi"],
    "ms": ["musteri/satici", "musteri satici", "müşteri/satıcı", "m/s",
           "musteri/satıcı"],
    "tl": ["tl bakiye", "try bakiye", "tl bakiyesi"],
    "eur": ["eur bakiye", "eur bakiyesi", "euro bakiye"],
    "usd": ["usd bakiye", "usd bakiyesi", "dolar bakiye"],
    "mail": ["firma mail", "firma e-mail", "firma eposta", "mail", "e-posta"],
    "responsible": ["mutabakat sorumlusu", "sorumlu", "uzman"],
}

# Bakiye rolü -> (para birimi kodu) sırası: J, L, N.
BALANCE_ROLES = [("tl", "TL"), ("eur", "EUR"), ("usd", "USD")]

_ZERO_TOKENS = {"", "0", "0,00", "0.00", "0,0", "0.0", "-", "0,00 ", " 0,00"}


def _norm_header(text: Any) -> str:
    s = str(text).strip().lower()
    for a, b in (("ı", "i"), ("İ", "i"), ("ş", "s"), ("ç", "c"),
                 ("ğ", "g"), ("ö", "o"), ("ü", "u")):
        s = s.replace(a, b)
    return " ".join(s.split())


def _to_decimal(value: Any) -> Decimal:
    """Bakiye hücresini Decimal'e çevirir; boş/tanınmaz -> 0."""
    if value is None:
        return Decimal("0")
    if isinstance(value, (int, float)):
        # Excel sayısal hücresi.
        try:
            return Decimal(str(value))
        except (InvalidOperation, ValueError):
            return Decimal("0")
    s = str(value).strip()
    if s in _ZERO_TOKENS:
        return Decimal("0")
    # Metinsel sayı: TR (1.234,56) veya EN (1,234.56) olabilir.
    cleaned = s.replace(" ", "").replace("\u00a0", "")
    if "," in cleaned and "." in cleaned:
        # Son ayraç ondalık kabul edilir.
        if cleaned.rfind(",") > cleaned.rfind("."):
            cleaned = cleaned.replace(".", "").replace(",", ".")
        else:
            cleaned = cleaned.replace(",", "")
    elif "," in cleaned:
        # TR yazımında virgül ONDALIK ayracıdır ("1,50" → 1.50).
        cleaned = cleaned.replace(",", ".")
    elif "." in cleaned:
        # YALNIZCA NOKTA VAR — belirsiz durum. TR yazımında nokta BİNLİK
        # ayracıdır: "1.234" 1234 demektir, 1.234 değil. Yanlış okunursa
        # 1234 EUR'luk bakiye 1,23 EUR olarak mektuba yazılır.
        #
        # Binlik sayılan haller:
        #   * birden çok nokta ("1.234.567") — ondalık olamaz, daha önce
        #     Decimal'i patlatıp SESSİZCE 0 üretiyordu;
        #   * tek nokta ve sonrasında TAM 3 hane ("1.234").
        # Tam sayı kısmı "0" ise ondalık kabul edilir ("0.500" → 0.5):
        # kimse binlik ayracıyla sıfırla başlayan sayı yazmaz.
        parts = cleaned.split(".")
        govde = parts[0].lstrip("+-")
        binlik = len(parts) > 2 or (len(parts) == 2 and len(parts[1]) == 3
                                    and govde not in ("", "0"))
        if binlik:
            cleaned = cleaned.replace(".", "")
    try:
        return Decimal(cleaned)
    except (InvalidOperation, ValueError):
        return Decimal("0")


@dataclass
class MailRow:
    """Excel'deki tek bir satır (bir hesap/segment)."""

    row_index: int
    code_raw: str
    name: str
    ms: str                      # M / S / X (ham)
    balances: Dict[str, Decimal]  # {"TL": .., "EUR": .., "USD": ..}
    mails: List[str] = field(default_factory=list)
    invalid_mails: List[str] = field(default_factory=list)
    responsible: str = ""

    @property
    def nonzero_balances(self) -> Dict[str, Decimal]:
        return {c: v for c, v in self.balances.items() if v != 0}


@dataclass
class LoadResult:
    rows: List[MailRow]
    sheet_name: str
    header_row: int
    column_map: Dict[str, int]


class ExcelLoadError(Exception):
    """Yükleme başarısız — net kullanıcı mesajı taşır."""


def _split_mails(cell: Any) -> List[str]:
    """P kolonu: birden fazla mail ';' ile ayrılır (kullanıcı doğruladı).

    Ayrıca ',' ve boşlukla ayrılmış hâlleri de tolere edilir; boş/geçersiz
    parçalar atılır. Sıra korunur, tekrarlar tekilleştirilir.
    """
    if cell is None:
        return []
    raw = str(cell).strip()
    if not raw or raw in {";", ",", "-"}:
        return []
    parts: List[str] = []
    for chunk in raw.replace(",", ";").split(";"):
        c = chunk.strip()
        if is_valid_email(c) and c not in parts:
            parts.append(c)
    return parts


def _invalid_mails(cell: Any) -> List[str]:
    if cell is None:
        return []
    invalid: List[str] = []
    for chunk in str(cell).replace(",", ";").split(";"):
        value = chunk.strip()
        if value and value not in {"-"} and not is_valid_email(value):
            if value not in invalid:
                invalid.append(value)
    return invalid


def _read_xls_rows(path: Path) -> tuple[List[List[Any]], str]:
    import xlrd  # yerel import: yalnızca .xls için gerekli
    wb = xlrd.open_workbook(str(path))
    sh = wb.sheet_by_index(0)
    data = [[sh.cell_value(r, c) for c in range(sh.ncols)]
            for r in range(sh.nrows)]
    return data, sh.name


def _read_xlsx_rows(path: Path) -> tuple[List[List[Any]], str]:
    from openpyxl import load_workbook
    wb = load_workbook(str(path), read_only=True, data_only=True)
    # try/finally: okuma ortasında hata olursa (bozuk/kısmi dosya) kitap
    # kapanmadan kalıyordu. read_only kitap kaynak dosyanın tanıtıcısını
    # AÇIK tutar; Windows'ta bu, kullanıcının o Excel dosyasını kaydetmesini
    # ya da silmesini engelleyebilir.
    try:
        ws = wb.active
        data = [list(row) for row in ws.iter_rows(values_only=True)]
        name = ws.title
    finally:
        wb.close()
    return data, name


def _find_header(data: List[List[Any]], scan: int = 10) -> tuple[int, Dict[str, int]]:
    """İlk `scan` satırda başlıkları arar; rol->kolon indeksi döndürür."""
    best_row, best_map, best_hits = -1, {}, -1
    for r in range(min(scan, len(data))):
        norm = {i: _norm_header(v) for i, v in enumerate(data[r]) if v not in (None, "")}
        role_map: Dict[str, int] = {}
        for role, aliases in _HEADER_ALIASES.items():
            for i, h in norm.items():
                if h in aliases:
                    role_map[role] = i
                    break
        hits = len(role_map)
        if hits > best_hits:
            best_row, best_map, best_hits = r, role_map, hits
    return best_row, best_map


def load_report(path: str | Path) -> LoadResult:
    """Mutabakat raporunu okuyup MailRow listesi döndürür."""
    p = Path(path)
    if not p.exists():
        raise ExcelLoadError(f"Dosya bulunamadı: {p}")
    try:
        validate_input_file(p)
    except UnsafeInputError as exc:
        raise ExcelLoadError(str(exc)) from exc
    suffix = p.suffix.lower()
    if suffix == ".xls":
        data, sheet = _read_xls_rows(p)
    elif suffix in (".xlsx", ".xlsm"):
        data, sheet = _read_xlsx_rows(p)
    else:
        raise ExcelLoadError(f"Desteklenmeyen biçim: {suffix} (.xls/.xlsx bekleniyor)")

    if not data:
        raise ExcelLoadError("Excel boş.")

    header_row, cmap = _find_header(data)
    required = ["code", "ms", "mail"]
    missing = [r for r in required if r not in cmap]
    if missing:
        pretty = {"code": "Hesap No", "ms": "Musteri/Satici", "mail": "Firma Mail"}
        raise ExcelLoadError(
            "Zorunlu kolon(lar) bulunamadı: "
            + ", ".join(pretty[m] for m in missing)
            + ". Başlık satırı beklenen şablona uymuyor."
        )

    rows: List[MailRow] = []
    for r in range(header_row + 1, len(data)):
        raw = data[r]
        code_cell = raw[cmap["code"]] if cmap["code"] < len(raw) else None
        if code_cell in (None, ""):
            continue
        # A kolonu float (4449668.0) gelebilir -> tam sayı stringe çevir.
        try:
            code_str = str(int(float(code_cell)))
        except (TypeError, ValueError):
            code_str = str(code_cell).strip()
        if not code_str or not any(ch.isdigit() for ch in code_str):
            continue

        def cell(role: str) -> Any:
            idx = cmap.get(role)
            if idx is None or idx >= len(raw):
                return None
            return raw[idx]

        balances = {code: _to_decimal(cell(role)) for role, code in BALANCE_ROLES}
        rows.append(MailRow(
            row_index=r,
            code_raw=code_str,
            name=str(cell("name") or "").strip(),
            ms=str(cell("ms") or "").strip().upper(),
            balances=balances,
            mails=_split_mails(cell("mail")),
            invalid_mails=_invalid_mails(cell("mail")),
            responsible=str(cell("responsible") or "").strip(),
        ))

    if not rows:
        raise ExcelLoadError("Veri satırı bulunamadı (başlık altında satır yok).")

    return LoadResult(rows=rows, sheet_name=sheet, header_row=header_row, column_map=cmap)
