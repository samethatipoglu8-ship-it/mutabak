"""FAZ 6 (Aşama 4/15) — ERP araştırma kanıt kataloğu.

Bu dosya kullanıcının sağladığı araştırma bulgularını ``FieldEvidence``
(bkz. ``evidence.py``) biçiminde KAYDEDER ve her birine bir
``ResearchClaimStatus`` (VERIFIED/SUPPORTED/RESEARCH_ONLY/CONTRADICTORY/
INSUFFICIENT_EVIDENCE) atar.

PROVENANCE DÜZELTME NOTU (FAZ 6 kabul-sonrası düzeltme turu):
    İlk sürümde 4 girdi (Mikro×2, Business Central, SAP) ``VERIFIED``
    olarak işaretlenmişti. Bu HATALIYDI — bu repo/oturum için GERÇEK bir
    birincil kanıt (gerçek export örneği, gerçek kullanıcı dosyası, ya da
    somut bir URL/dosya adı/versiyon taşıyan arşivlenmiş bir kaynak) hiçbir
    girdi için MEVCUT DEĞİL. Tüm 9 girdinin TEK kaynağı: kullanıcının FAZ 6
    isteminde özetlenen "birden çok LLM'den araştırma" (SAP AUGBL/AUGDT
    girdisi için ayrıca bu oturumun kendi genel/eğitim bilgisi — bu da AYNI
    kategoriye girer: somut, oturumda doğrulanabilir bir kaynak DEĞİLDİR).
    "VERIFIED" yalnızca şu üçünden biri GERÇEKTEN mevcutsa kullanılabilir:
    (a) gerçek bir export örneği, (b) gerçek bir kullanıcı dosyası, (c) somut
    bir kaynak referansı/URL'si olan resmi bir doküman/arşivlenmiş kaynak.
    Hiçbiri yok — bu yüzden TÜM girdilerin ``evidence_type``'ı
    ``LLM_RESEARCH_ONLY``'ye düzeltildi (önceden bazıları ``OFFICIAL_API_
    SCHEMA``/``OFFICIAL_DB_SCHEMA``/``OFFICIAL_PRODUCT_DOC``/``OFFICIAL_
    IMPORT_TEMPLATE`` idi — bu etiketler, elimizde GERÇEKTEN o türde bir
    kaynak VARMIŞ gibi bir izlenim veriyordu; YOKTU, sadece ÖYLE
    TANIMLANMIŞTI). ``claim_status`` da buna göre düzeltildi (bkz. her
    girdinin ``rationale``'ı). İki girdi (Logo, Zirve) ``SUPPORTED`` kaldı
    ama gerekçesi DEĞİŞTİ: artık "Logo/Zirve dokümantasyonuna dayanıyor"
    DENMİYOR (bu iddia edilemez) — bunun yerine, iddia edilen GENERİK
    desenin (Türkçe tarih/borç/alacak/bakiye/cari-hesap kelime dağarcığı;
    B/A gösterge kolonu) bu REPO'DAKİ BAĞIMSIZ, somut kanıtla (doc 16 §8.2
    test-kanıtlı GENERIC_TR_CARI başlık kümesi; ``column_mapper.py``'nin
    zaten üretimde olan ``ba_indicator`` rolü) zaten ÖRTÜŞTÜĞÜ belirtiliyor.
    ÜRÜNE ÖZEL atıf (bunun "Logo'nun" ya da "Zirve'nin" kendi dokümanından
    geldiği) HÂLÂ doğrulanamaz ve asla VERIFIED sayılmaz.

KRİTİK: Bu katalog hiçbir ürün-özel production profili ÜRETMEZ. Hiçbir
girdi ``safe_for_auto_mapping=True`` DEĞİLDİR — HİÇBİRİ gerçek bir export
dosyasında gözlenmedi (``observed_in_real_file=False``). Bu, modülün KENDİ
``FieldEvidence._enforce_export_schema_rule`` invariant'ı ile ZORLANIR
(deneme: ``safe_for_auto_mapping=True`` ile bir girdi eklemeye çalışmak
``ValueError`` fırlatır — test ile kanıtlanmıştır).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .evidence import EvidenceType, FieldEvidence


class ResearchClaimStatus(str, Enum):
    """Aşama 15 — araştırma iddiasının sınıflandırması.

    VERIFIED: bu repo/oturum İÇİN somut birincil kanıt MEVCUTTUR (gerçek
        export örneği / gerçek kullanıcı dosyası / somut kaynak referanslı
        resmi doküman). Yalnızca kullanıcının FAZ 6 isteminde/önceki
        konuşma özetinde/bir LLM araştırma raporunda GEÇMİŞ olması asla
        yeterli DEĞİLDİR.
    SUPPORTED: ürüne özel birincil kaynak YOK, ama iddia edilen GENERİK
        desen bu repodaki BAŞKA, bağımsız, somut bir kanıtla (test-kanıtlı
        karakterizasyon, zaten üretimde olan kod) örtüşüyor.
    RESEARCH_ONLY: tek kaynak, araştırma özeti/LLM çıktısıdır; bağımsız
        hiçbir doğrulama YOK.
    CONTRADICTORY: iki kaynak birbirini YALANLIYOR (bu katalogda bugün
        boş).
    INSUFFICIENT_EVIDENCE: iddia o kadar belirsiz ki (somut bir alan/kolon
        adı önermiyor) hiçbir sınıfa oturtulamaz.
    """

    VERIFIED = "verified"
    SUPPORTED = "supported"
    RESEARCH_ONLY = "research_only"
    CONTRADICTORY = "contradictory"
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"


@dataclass(frozen=True)
class ResearchClaimEntry:
    evidence: FieldEvidence
    claim_status: ResearchClaimStatus
    rationale: str


RESEARCH_EVIDENCE_CATALOG: tuple[ResearchClaimEntry, ...] = (
    # --- Mikro: "resmi API alanları" olarak TANIMLANAN, DOĞRULANAMAYAN iddia -
    ResearchClaimEntry(
        evidence=FieldEvidence(
            source_system="Mikro", product=None, field_name="cho_CariKodu",
            proposed_role="counterparty_code", evidence_type=EvidenceType.LLM_RESEARCH_ONLY,
            source_reference="Bu oturumda somut bir kaynak (URL/dosya/arşiv) YOK — iddia "
                              "FAZ 6 isteminin araştırma özetinden relay edildi, bağımsız "
                              "doğrulanmadı.",
            confidence=0.20, observed_in_real_file=False, safe_for_auto_mapping=False,
            notes="'Mikro resmi API alanı' olarak TANIMLANMIŞ bir iddia — bu oturum bunu "
                  "ne API seviyesinde ne export seviyesinde DOĞRULAYABİLİR. Gerçek bir "
                  "Mikro API yanıtı/dokümanı görülmeden ne ÜRÜN-özel kabul ne de "
                  "API-şeması-VERIFIED sayılamaz.",
        ),
        claim_status=ResearchClaimStatus.RESEARCH_ONLY,
        rationale="Somut birincil kaynak (API dokümanı/yanıt örneği) bu oturumda MEVCUT "
                  "DEĞİL; tek kaynak araştırma özetidir. VERIFIED/SUPPORTED için yetersiz — "
                  "RESEARCH_ONLY'ye düşürüldü (düzeltme turu).",
    ),
    ResearchClaimEntry(
        evidence=FieldEvidence(
            source_system="Mikro", product=None, field_name="cho_Ana_Borc / cho_Ana_Alacak",
            proposed_role="debit / credit", evidence_type=EvidenceType.LLM_RESEARCH_ONLY,
            source_reference="Bu oturumda somut bir kaynak (URL/dosya/arşiv) YOK — aynı "
                              "gerekçe.",
            confidence=0.20, observed_in_real_file=False, safe_for_auto_mapping=False,
            notes="cho_Alt_*/cho_Orj_* değişkenlerinin de VAR olduğu iddia edildi (alt "
                  "hesap/orijinal döviz); bunların GERÇEKTEN var olup olmadığı, varsa "
                  "Excel export'ta aynı adla çıkıp çıkmadığı bu oturumda DOĞRULANAMADI.",
        ),
        claim_status=ResearchClaimStatus.RESEARCH_ONLY,
        rationale="Aynı gerekçe: somut kaynak YOK, tek kaynak araştırma özeti — "
                  "RESEARCH_ONLY'ye düşürüldü (düzeltme turu).",
    ),
    # --- Logo: jenerik TR muhasebe kelime dağarcığı, repo-içi korobore -------
    ResearchClaimEntry(
        evidence=FieldEvidence(
            source_system="Logo", product=None, field_name="Tarih / Fiş Türü / Fiş Numarası / Borç / Alacak / Bakiye / Cari Hesap",
            proposed_role=None, evidence_type=EvidenceType.LLM_RESEARCH_ONLY,
            source_reference="Logo'ya ÖZEL somut bir doküman/URL bu oturumda YOK. Ancak "
                              "GENERİK desen (bu Türkçe terimler) doc 16 §8.2'nin "
                              "test-kanıtlı GENERIC_TR_CARI başlık kümesiyle (bu repoda, "
                              "bağımsız olarak) ÖRTÜŞÜYOR.",
            confidence=0.35, observed_in_real_file=False, safe_for_auto_mapping=False,
            notes="DİKKAT — ayrım: desteklenen şey 'bu kelimeler Türkçe cari ekstrelerde "
                  "GENEL OLARAK geçer' (repo-içi kanıtlı); desteklenmeyen şey 'bunlar "
                  "LOGO'nun KENDİ export dosyasının kolon adlarıdır' (hiçbir kaynakla "
                  "doğrulanmadı — Logo'ya özel atıf RESEARCH_ONLY seviyesinde kalır).",
        ),
        claim_status=ResearchClaimStatus.SUPPORTED,
        rationale="Ürüne özel (Logo) atıf için birincil kaynak YOK — SUPPORTED statüsü "
                  "yalnızca GENERİK deseni, bu repodaki BAŞKA somut kanıta "
                  "(test_generic_tr_cari_research_confirmed_header_set_is_fully_"
                  "recognized, doc 16 §8.2) dayanarak verilir; 'Logo'nun export şeması "
                  "budur' iddiası AYRI ve hâlâ doğrulanmamıştır.",
    ),
    # --- DİA: rapor konsepti, kolon adı YOK ---------------------------------
    ResearchClaimEntry(
        evidence=FieldEvidence(
            source_system="DİA", product=None, field_name="cari-ekstre (rapor konsepti, kolon adı yok)",
            proposed_role=None, evidence_type=EvidenceType.LLM_RESEARCH_ONLY,
            source_reference="Somut kaynak YOK; iddia tek başına 'böyle bir rapor var' "
                              "seviyesinde, hiçbir kolon adı içermiyor.",
            confidence=0.15, observed_in_real_file=False, safe_for_auto_mapping=False,
            notes="Rapor VARLIĞI iddia edildi ama hiçbir GERÇEK kolon adı önerilmedi — "
                  "kullanıcı talimatı: 'do NOT promote guessed export column names "
                  "without actual evidence'.",
        ),
        claim_status=ResearchClaimStatus.INSUFFICIENT_EVIDENCE,
        rationale="Hiçbir somut alan/kolon iddiası YOK — değerlendirilecek bir şema "
                  "iddiası bile mevcut değil; bu yüzden INSUFFICIENT_EVIDENCE (düzeltme "
                  "turunda değişmedi).",
    ),
    # --- Zirve: B/A göstergesi, jenerik desen repo-içi korobore --------------
    ResearchClaimEntry(
        evidence=FieldEvidence(
            source_system="Zirve", product=None, field_name="B/A göstergesi (debit/credit indicator)",
            proposed_role="ba_indicator", evidence_type=EvidenceType.LLM_RESEARCH_ONLY,
            source_reference="Zirve'ye ÖZEL somut bir doküman/URL bu oturumda YOK. Ancak "
                              "GENERİK B/A gösterge deseni, ``app/services/column_mapper."
                              "py``'nin zaten üretimde olan ``ba_indicator`` rolü ve "
                              "``app/services/loader.py``'nin ``_BA_CREDIT_TOKENS``/"
                              "``_BA_DEBIT_TOKENS`` sözlükleriyle (bu repoda, bağımsız "
                              "olarak) ÖRTÜŞÜYOR.",
            confidence=0.35, observed_in_real_file=False, safe_for_auto_mapping=False,
            notes="DİKKAT — ayrım: desteklenen şey 'B/A gösterge kolonu GENEL OLARAK "
                  "Türkçe muhasebe ekstrelerinde geçen bir desendir' (repo-içi kanıtlı, "
                  "zaten üretim kodu VAR); desteklenmeyen şey 'bu ZİRVE'NİN KENDİ import "
                  "şablonunun/export'unun davranışıdır' (doğrulanmadı). Ayrıca import-"
                  "template ile export şeması AYRI akışlardır (kullanıcı CRITICAL RULE).",
        ),
        claim_status=ResearchClaimStatus.SUPPORTED,
        rationale="Ürüne özel (Zirve) atıf için birincil kaynak YOK — SUPPORTED statüsü "
                  "yalnızca GENERİK deseni, bu repoda ZATEN ÜRETİMDE olan "
                  "`ba_indicator`/`_BA_CREDIT_TOKENS` koduna dayanarak verilir; "
                  "'Zirve'nin import/export davranışı budur' iddiası AYRI ve hâlâ "
                  "doğrulanmamıştır.",
    ),
    # --- Business Central / SAP / IFS / NetSuite: jenerik kavramlar ----------
    ResearchClaimEntry(
        evidence=FieldEvidence(
            source_system="Business Central", product=None,
            field_name="Remaining Amount / Open / Due Date / Document Currency Code / External Document No.",
            proposed_role="open_amount / is_open / due_date / document_currency / external_document_number",
            evidence_type=EvidenceType.LLM_RESEARCH_ONLY,
            source_reference="Bu oturumda somut bir kaynak (URL/doküman adı/versiyon) YOK "
                              "— iddia FAZ 6 isteminin araştırma özetinden relay edildi.",
            confidence=0.20, observed_in_real_file=False, safe_for_auto_mapping=False,
            notes="Bu alan adları kavramsal olarak MAKUL (genel muhasebe terimleri) ama "
                  "Business Central'ın GERÇEKTEN bu adlarla bir API/export alanı "
                  "sunduğu bu oturumda DOĞRULANAMADI. Katalogdaki kullanım alanı SADECE "
                  "rol-taksonomisi TASARIMINA girdi (roles.py OPEN_AMOUNT/IS_OPEN/"
                  "CLEARING_REFERENCE) — ürün-özel bir profil ÜRETMEZ.",
        ),
        claim_status=ResearchClaimStatus.RESEARCH_ONLY,
        rationale="Önceki sürümde 'API şeması VERIFIED' denmişti — bu HATALIYDI, somut "
                  "kaynak YOK. RESEARCH_ONLY'ye düşürüldü; yalnızca JENERİK rol "
                  "taksonomisi tasarımına girdi olarak kullanılması KORUNDU (düzeltme "
                  "turu).",
    ),
    ResearchClaimEntry(
        evidence=FieldEvidence(
            source_system="SAP", product=None, field_name="AUGBL / AUGDT (clearing document / date)",
            proposed_role="clearing_reference / clearing_date", evidence_type=EvidenceType.LLM_RESEARCH_ONLY,
            source_reference="Bu oturumda somut bir kaynak (URL/doküman adı/versiyon) YOK "
                              "— bu girdi kullanıcının FAZ 6 isteminde BİLE verilmemişti; "
                              "bu asistanın kendi genel/eğitim bilgisinden EKLENDİ. Bu, "
                              "'LLM-generated research'ten farklı bir kategori DEĞİLDİR "
                              "— aynı kurala tabidir.",
            confidence=0.20, observed_in_real_file=False, safe_for_auto_mapping=False,
            notes="SAP BSEG tablosunun AUGBL/AUGDT alanları genel bilgi olarak bilinir "
                  "ama bu oturum bunu doğrulayacak somut, erişilebilir bir referans "
                  "(sürüm/doküman/URL) TUTMUYOR. FBL1H Excel export'unda AYNI adla "
                  "çıkmadığı doc 16'da zaten not edilmişti (o kısım AYRI ve geçerli).",
        ),
        claim_status=ResearchClaimStatus.RESEARCH_ONLY,
        rationale="Önceki sürümde 'DB şeması VERIFIED' denmişti — bu HATALIYDI: bu "
                  "iddianın kaynağı bu asistanın KENDİ eğitim bilgisidir, bu oturumda "
                  "doğrulanabilir somut bir referans YOKTUR. Kullanıcı talimatı birebir: "
                  "'Do NOT classify something as VERIFIED merely because it was stated "
                  "in ... an LLM-generated research report' — bu, kendi ürettiğim bir "
                  "iddia için de GEÇERLİDİR. RESEARCH_ONLY'ye düşürüldü (düzeltme turu).",
    ),
    # --- CANIAS: doğrulanamayan XML etiketleri -------------------------------
    ResearchClaimEntry(
        evidence=FieldEvidence(
            source_system="CANIAS", product=None, field_name="(belirtilmemiş XML etiketleri)",
            proposed_role=None, evidence_type=EvidenceType.LLM_RESEARCH_ONLY,
            source_reference="Somut kaynak YOK; birincil kaynak doğrulanamadı.",
            confidence=0.15, observed_in_real_file=False, safe_for_auto_mapping=False,
            notes="Birincil kaynak (resmi doküman/örnek dosya) YOK; salt araştırma "
                  "özeti.",
        ),
        claim_status=ResearchClaimStatus.RESEARCH_ONLY,
        rationale="Hiçbir birincil kanıt yok; LLM_RESEARCH_ONLY türü kendi başına "
                  "hiçbir zaman VERIFIED/SUPPORTED olamaz (düzeltme turunda değişmedi).",
    ),
    # --- Nebim: REST alanları -------------------------------------------------
    ResearchClaimEntry(
        evidence=FieldEvidence(
            source_system="Nebim", product="Nebim V3 REST", field_name="(belirtilmemiş REST alanları)",
            proposed_role=None, evidence_type=EvidenceType.LLM_RESEARCH_ONLY,
            source_reference="Bu oturumda somut bir kaynak (URL/doküman adı/versiyon) YOK "
                              "— hiçbir alan adı dahi belirtilmedi.",
            confidence=0.15, observed_in_real_file=False, safe_for_auto_mapping=False,
            notes="Ne somut bir alan adı ne doğrulanabilir bir doküman referansı var; "
                  "iddia 'REST API'si var ve bazı jenerik alanlar sunuyor' seviyesinde "
                  "kaldı.",
        ),
        claim_status=ResearchClaimStatus.RESEARCH_ONLY,
        rationale="Önceki sürümde 'API dokümantasyonu SUPPORTED' denmişti — somut bir "
                  "doküman adı/URL/alan listesi OLMADIĞI için bu da fazla iyimserdi. "
                  "RESEARCH_ONLY'ye düşürüldü (düzeltme turu).",
    ),
)


def export_schema_claims() -> tuple[ResearchClaimEntry, ...]:
    """Katalogdaki, GERÇEKTEN bir export şemasını kanıtlayan girdiler.

    Bugün BOŞ döner — katalogdaki HİÇBİR girdi ``OFFICIAL_EXPORT_SAMPLE``
    ya da ``REAL_USER_SAMPLE`` değildir (kullanıcı talimatı: "do not create
    product-specific production profiles from LLM claims alone" — bu
    fonksiyonun boş dönmesi, o kuralın KOD SEVİYESİNDE doğrulanmasıdır).
    """
    return tuple(e for e in RESEARCH_EVIDENCE_CATALOG if e.evidence.is_export_schema_evidence())


def verified_claims() -> tuple[ResearchClaimEntry, ...]:
    """Düzeltme-turu sonrası: bugün BOŞ döner.

    Hiçbir girdi için bu repo/oturumda somut birincil kanıt (gerçek export
    örneği / gerçek kullanıcı dosyası / somut kaynak referanslı resmi
    doküman) MEVCUT DEĞİL. Bu fonksiyonun boş dönmesi, düzeltme turunun
    talep ettiği disiplinin KOD SEVİYESİNDE doğrulanmasıdır.
    """
    return tuple(e for e in RESEARCH_EVIDENCE_CATALOG if e.claim_status is ResearchClaimStatus.VERIFIED)
