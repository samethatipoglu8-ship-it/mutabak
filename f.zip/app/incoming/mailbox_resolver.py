"""Outlook mağaza/klasör çözümleyici — DİNAMİK, hiçbir COM ID'si GÖMÜLMEZ.

Bkz. ``docs/claude-audit/21_MAILBOX_CONTRACT_AND_APPLICATION_MAIL_MARKER_DESIGN.md``.

KESİN KURAL (onaylanmış karar)
    Yapılandırılmış bir mağaza/klasör çözülemezse SESSİZCE Gelen Kutusu'na
    DÜŞÜLMEZ. Bunun yerine yapılandırılmış ``MailboxResolutionError`` döner
    (``STORE_NOT_FOUND`` / ``AMBIGUOUS_STORE`` / ``FOLDER_NOT_FOUND`` /
    ``AMBIGUOUS_FOLDER``). Mağaza/klasör kimliği (StoreID/FolderEntryID) HİÇ
    SAKLANMAZ; her çağrıda isme göre YENİDEN aranır — bu yüzden "dinamik"tir.

KAPSAM
    Bu modül YALNIZCA çözümleme mantığıdır: bir ``namespace`` (ya da test
    sahtesi) ve isteğe bağlı bir mağaza/klasör adı alır, bir klasör COM
    nesnesi ya da yapılandırılmış hata döndürür. Outlook'a hiçbir YAZMA
    (Send/Move/Delete/MarkRead/Category/Flag) işlemi YAPMAZ ve hiçbir
    kalıcı durum TUTMAZ.

    Hiçbir çağıran bugün bir mağaza/klasör kimliği YAPILANDIRMIYOR (bkz. rapor
    §IMPLEMENTATION STATUS): ``store_identifier``/``folder_path`` boşsa bu
    modül bugünkü davranışla BİREBİR aynı sonucu verir (varsayılan mağazanın
    Gelen Kutusu). Bu, kalıcı bir yapılandırma kimliği eklemenin kullanıcı
    kararı gerektirdiği (STOP_FOR_DECISION) ilkesini bozmadan, mekanizmanın
    test edilebilir ve hazır olmasını sağlar.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

#: ``Namespace.GetDefaultFolder`` / ``Store.GetDefaultFolder`` için
#: ``olFolderInbox`` sabiti — ``outlook_reader.py``'deki ``OL_FOLDER_INBOX``
#: ile aynı değer; modüller birbirine import ETMEZ (gümrük kalıbındaki
#: küçük-sabit-tekrarı geleneği, bkz. ``outlook_client.py``/``outlook_reader.py``).
OL_FOLDER_INBOX = 6


def _safe(getter, default: Any = "") -> Any:
    """COM özelliği okunamazsa varsayılana düş (okuyucu tarafıyla aynı kalıp)."""
    try:
        value = getter()
    except Exception:  # noqa: BLE001 - COM her özellikte patlayabilir
        return default
    return default if value is None else value


@dataclass(frozen=True)
class MailboxResolutionError:
    """Yapılandırılmış çözümleme hatası — bir log satırı DEĞİL, bir DEĞER.

    ``code``: ``STORE_NOT_FOUND`` | ``AMBIGUOUS_STORE`` | ``FOLDER_NOT_FOUND``
        | ``AMBIGUOUS_FOLDER`` | ``CONFIG_MISSING`` (yalnızca
        ``resolve_store_by_smtp``: SMTP kimliği hiç verilmemiş).
    ``candidates``: operatöre gösterilecek aday mağaza/klasör adları
        (STOP_FOR_DECISION ekranı için).
    """

    code: str
    detail: str
    candidates: tuple[str, ...] = ()


class MailboxResolutionFailed(RuntimeError):
    """``MailboxResolutionError``'ı taşıyan istisna; çağıran taraf
    ``exc.error.code``/``exc.error.candidates`` okuyabilir."""

    def __init__(self, error: MailboxResolutionError) -> None:
        super().__init__(error.detail)
        self.error = error


@dataclass
class MailboxResolution:
    """Başarıda ``folder`` dolu, başarısızlıkta ``error`` dolu — ikisi birden
    DEĞİL."""

    folder: Any = None
    error: Optional[MailboxResolutionError] = None

    @property
    def ok(self) -> bool:
        return self.error is None


def _store_label(store: Any) -> str:
    return str(_safe(lambda: store.DisplayName, "") or "")


def _folder_label(folder: Any) -> str:
    return str(_safe(lambda: folder.Name, "") or "")


def _child_folders(folder: Any) -> list:
    """Alt klasörleri listele.

    Hem gerçek Outlook COM koleksiyonu hem de testteki düz Python listesi
    ``for x in folder.Folders`` ile gezilebilir (ikisi de yineleme
    destekler); bu yüzden ``.Count``/``.Item(i)`` YERİNE basit yineleme
    kullanılır — ``outlook_reader.py``'nin ESKİ ``_resolve_folder``'ıyla
    aynı, kanıtlanmış kalıp.
    """
    try:
        return list(folder.Folders)
    except Exception:  # noqa: BLE001 - alt klasörler okunamayabilir
        return []


def _all_stores(namespace: Any) -> list:
    """Açık Outlook mağazalarını (hesap/PST/paylaşılan posta kutusu) listele."""
    try:
        return list(namespace.Stores)
    except Exception:  # noqa: BLE001 - sağlayıcı desteklemeyebilir
        return []


def _account_smtp(account: Any) -> str:
    return str(_safe(lambda: account.SmtpAddress, "") or "")


def _all_accounts(namespace: Any) -> list:
    """Açık Outlook hesaplarını (``namespace.Accounts``) listele."""
    try:
        return list(namespace.Accounts)
    except Exception:  # noqa: BLE001 - sağlayıcı desteklemeyebilir
        return []


def resolve_store_base(namespace: Any, store_identifier: str = "") -> MailboxResolution:
    """Klasör aramasının başlayacağı TEMEL klasörü (bir mağazanın Gelen
    Kutusu'nu) çöz.

    ``store_identifier`` BOŞSA: varsayılan mağazanın Gelen Kutusu — BUGÜNKÜ
    ``namespace.GetDefaultFolder(OL_FOLDER_INBOX)`` çağrısıyla BİREBİR AYNI;
    hiçbir mağaza listesi gezilmez, hiçbir "tahmin" yoktur çünkü zaten tek
    seçenek budur.

    ``store_identifier`` VERİLMİŞSE: açık mağazalar arasında ``DisplayName``
    ile (büyük/küçük harf duyarsız) aranır. Sıfır eşleşme ya da birden fazla
    eşleşme ASLA tahmin edilmez — yapılandırılmış hata döner.
    """
    identifier = (store_identifier or "").strip()
    if not identifier:
        folder = _safe(lambda: namespace.GetDefaultFolder(OL_FOLDER_INBOX), None)
        if folder is None:
            return MailboxResolution(error=MailboxResolutionError(
                "STORE_NOT_FOUND",
                "Varsayılan Outlook mağazasının Gelen Kutusu çözülemedi."))
        return MailboxResolution(folder=folder)

    stores = _all_stores(namespace)
    target = identifier.lower()
    matches = [s for s in stores if _store_label(s).strip().lower() == target]
    if not matches:
        return MailboxResolution(error=MailboxResolutionError(
            "STORE_NOT_FOUND",
            f"Yapılandırılmış mağaza '{identifier}' açık Outlook "
            "mağazaları arasında bulunamadı.",
            candidates=tuple(_store_label(s) for s in stores)))
    if len(matches) > 1:
        return MailboxResolution(error=MailboxResolutionError(
            "AMBIGUOUS_STORE",
            f"'{identifier}' adına birden fazla açık Outlook mağazası "
            "uyuyor; hangisinin kullanılacağı belirsiz.",
            candidates=tuple(_store_label(s) for s in matches)))
    store = matches[0]
    root = _safe(lambda: store.GetDefaultFolder(OL_FOLDER_INBOX), None)
    if root is None:
        root = _safe(lambda: store.GetRootFolder(), None)
    if root is None:
        return MailboxResolution(error=MailboxResolutionError(
            "STORE_NOT_FOUND",
            f"'{identifier}' mağazasının Gelen Kutusu/kök klasörü açılamadı."))
    return MailboxResolution(folder=root)


def resolve_store_by_smtp(namespace: Any, smtp_address: str) -> MailboxResolution:
    """Hesabı SMTP adresiyle eşleştirip O HESABIN gerçek Gelen Kutusu'nu çöz.

    Yapılandırılmış kimlik burada bir mağaza ``DisplayName``'i DEĞİL, bir
    hesabın SMTP adresidir (örn. ``Settings.incoming_mailbox_smtp``).
    Eşleştirme ``namespace.Accounts`` üzerinde ``SmtpAddress`` alanına TAM
    (büyük/küçük harf duyarsız) eşleşmeyle yapılır; sıfır ya da birden
    fazla eşleşme ASLA tahmin edilmez — yapılandırılmış hata döner.

    Eşleşen hesabın ``DeliveryStore``'u alınır ve o STORE'un
    ``GetDefaultFolder(olFolderInbox)``'ı döner. StoreID/FolderEntryID HİÇ
    saklanmaz; bu değerler her çağrıda YENİDEN, runtime'da kurulur.

    ``smtp_address`` BOŞSA: bu fonksiyonun TEK işi SMTP tabanlı çözümleme
    olduğu için ``CONFIG_MISSING`` yapılandırılmış hatası döner — VARSAYILAN
    mağazaya SESSİZCE DÜŞÜLMEZ (onaylanmış karar: "Missing configured SMTP →
    structured configuration error"). Geriye dönük uyumluluk (mevcut
    kurulumlarda ``incoming_mailbox_smtp`` hiç ayarlanmamışsa eski
    davranışın BOZULMAMASI) bu fonksiyonun İÇİNDE değil, ÇAĞIRANDA
    (``resolve_mailbox_folder``) sağlanır: o fonksiyon ``account_smtp`` BOŞ
    İKEN bu fonksiyonu HİÇ ÇAĞIRMAZ, doğrudan eski ``resolve_store_base``
    yoluna gider.
    """
    identifier = (smtp_address or "").strip()
    if not identifier:
        return MailboxResolution(error=MailboxResolutionError(
            "CONFIG_MISSING",
            "Kontrollü gelen kutusu SMTP eşleştirmesi için "
            "'incoming_mailbox_smtp' yapılandırması gereklidir; boş "
            "bırakılamaz."))

    accounts = _all_accounts(namespace)
    target = identifier.lower()
    matches = [a for a in accounts if _account_smtp(a).strip().lower() == target]
    if not matches:
        return MailboxResolution(error=MailboxResolutionError(
            "STORE_NOT_FOUND",
            f"Yapılandırılmış SMTP adresi '{identifier}' açık Outlook "
            "hesapları arasında bulunamadı.",
            candidates=tuple(_account_smtp(a) for a in accounts)))
    if len(matches) > 1:
        return MailboxResolution(error=MailboxResolutionError(
            "AMBIGUOUS_STORE",
            f"'{identifier}' SMTP adresine birden fazla açık Outlook "
            "hesabı uyuyor; hangisinin kullanılacağı belirsiz.",
            candidates=tuple(_account_smtp(a) for a in matches)))
    account = matches[0]
    store = _safe(lambda: account.DeliveryStore, None)
    if store is None:
        return MailboxResolution(error=MailboxResolutionError(
            "STORE_NOT_FOUND",
            f"'{identifier}' hesabının teslimat mağazası (DeliveryStore) "
            "okunamadı."))
    root = _safe(lambda: store.GetDefaultFolder(OL_FOLDER_INBOX), None)
    if root is None:
        return MailboxResolution(error=MailboxResolutionError(
            "STORE_NOT_FOUND",
            f"'{identifier}' hesabının Gelen Kutusu açılamadı."))
    return MailboxResolution(folder=root)


def resolve_subfolder_path(base_folder: Any, folder_path: str) -> MailboxResolution:
    """``base_folder`` altında ``/`` ile ayrılmış iç içe klasör yolunu gez.

    ``folder_path`` BOŞSA: ``base_folder``'ın KENDİSİ döner (BİR HATA
    DEĞİLDİR — hiçbir alt klasör istenmemiştir; bu, bugünkü varsayılan
    davranışla birebir aynıdır).

    Her bölümde: eşleşme YOKSA ``FOLDER_NOT_FOUND``; BİRDEN FAZLA eşleşme
    VARSA ``AMBIGUOUS_FOLDER`` — ikisinde de ``base_folder``'a (ya da
    Gelen Kutusu'na) SESSİZCE DÜŞÜLMEZ.
    """
    segments = [s.strip() for s in str(folder_path or "").split("/") if s.strip()]
    if not segments:
        return MailboxResolution(folder=base_folder)

    current = base_folder
    for segment in segments:
        children = _child_folders(current)
        target = segment.lower()
        matches = [f for f in children
                   if _folder_label(f).strip().lower() == target]
        parent_label = _folder_label(current) or "mağaza kökü"
        if not matches:
            return MailboxResolution(error=MailboxResolutionError(
                "FOLDER_NOT_FOUND",
                f"Yapılandırılmış klasör '{segment}' '{parent_label}' "
                "altında bulunamadı.",
                candidates=tuple(_folder_label(f) for f in children)))
        if len(matches) > 1:
            return MailboxResolution(error=MailboxResolutionError(
                "AMBIGUOUS_FOLDER",
                f"'{parent_label}' altında '{segment}' adında birden "
                "fazla klasör var; hangisinin kullanılacağı belirsiz.",
                candidates=tuple(_folder_label(f) for f in matches)))
        current = matches[0]
    return MailboxResolution(folder=current)


def resolve_mailbox_folder(namespace: Any, *, store_identifier: str = "",
                          folder_path: str = "",
                          account_smtp: str = "",
                          require_account_smtp: bool = False) -> MailboxResolution:
    """Mağaza + klasör çözümlemesini birleştir (çağıranın kullanacağı tek giriş).

    ``account_smtp`` DOLUYSA ``store_identifier`` (mağaza ``DisplayName``'i)
    YERİNE SMTP tabanlı hesap eşleştirmesi kullanılır (bkz.
    ``resolve_store_by_smtp``) — ikisi birden verilirse ``account_smtp``
    ÖNCELİKLİDİR, çünkü üretim sözleşmesi tek bir kontrollü hesabı SMTP
    adresiyle sabitler (bkz. doc 21 §MAILBOX DECISION CLARIFICATION).

    ``require_account_smtp=True`` (KONTROLLÜ ÜRETİM ÇAĞRI NOKTALARI İÇİN —
    reply_scan, incoming worker/pipeline, incoming page): ``account_smtp``
    BOŞ olsa BİLE ``store_identifier`` yoluna (ve dolayısıyla
    ``namespace.GetDefaultFolder``'a) ASLA DÜŞÜLMEZ — her zaman
    ``resolve_store_by_smtp`` çağrılır, bu da boşken ``CONFIG_MISSING``
    döner (bkz. doc 21 §FIFTH PASS — fail-closed düzeltmesi). Yalnızca
    ``False`` (varsayılan, geriye dönük uyumlu genel kullanım) iken boş
    ``account_smtp`` eski ``store_identifier``/varsayılan-Gelen-Kutusu
    yoluna düşebilir.

    Mağaza çözülemezse klasör ADIMI HİÇ ÇALIŞMAZ — hata ilk adımdan döner.
    """
    if require_account_smtp or (account_smtp or "").strip():
        base = resolve_store_by_smtp(namespace, account_smtp)
    else:
        base = resolve_store_base(namespace, store_identifier)
    if not base.ok:
        return base
    return resolve_subfolder_path(base.folder, folder_path)
