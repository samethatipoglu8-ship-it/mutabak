"""Mutabakat Mailleri sayfası (PySide6) — FAZ1.

Bağımsız QWidget: MainWindow'un QStackedWidget'ine yeni sayfa olarak eklenir.
Mevcut reconciler/core'a dokunmaz.

Özellikler:
  - Mutabakat ayı seçici (1-12) + yıl.
  - Excel yükle.
  - Outlook'a bağlan (From = açan kişi).
  - Filtrelenebilir + düzenlenebilir tablo (mail ve sorumlu değiştirilebilir;
    "Değişiklikleri kaydet" ile geri yazılır).
  - 6 buton: (1) Mutabakat gönder, (2) Hatırlatma [FAZ2], (3) Dönüş kontrol
    [FAZ2], (4) Değişiklikleri kaydet, (5) Seçili firmalara gönder,
    (6) Sorumlu CC ile gönder.
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from pathlib import Path
from typing import Dict, List, Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QIntValidator
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QFileDialog,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from app.mailing.excel_loader import LoadResult
from app.mailing.mail_builder import (
    MONTHS_TR,
    BuildConfig,
    classify_locale,
    effective_ms,
    normalize_code,
)
from app.mailing.outlook_client import OutlookClient
from app.mailing.package_worker import (
    DraftBuildWorker,
    MailPreviewWorker,
    MailSendWorker,
    OutlookConnectionWorker,
    PackageBuildWorker,
    PackageSendWorker,
    ReportLoadWorker,
    SapBalanceWorker,
)
from app.services.mail_log import MailLog, period_key
from app.services.reconciliation_letter_writer import (
    LetterPeriod,
    missing_templates,
)
from app.ui.worker import WorkerBinding, run_in_thread

# Tablo kolonları. Son iki kolon SAP güncellemesiyle geldi: TL/EUR/USD
# dışındaki para birimleri (SAP'ta CNY/GBP/JPY de var) ve bakiyenin kaynağı.
_COLS = ["Kod", "Firma", "E", "TL", "EUR", "USD", "Mail (P)", "Sorumlu (R)",
         "Diğer PB", "Bakiye Kaynağı"]

# Rapor kolonları ile SAP para birimi kodları arasındaki eşleme.
_REPORT_CURRENCIES = ("TL", "EUR", "USD")
_SAP_TO_REPORT = {"TRY": "TL"}


def _reason_summary(reasons, limit: int = 6) -> str:
    """Gerekçeleri sayarak okunur bir özet üret.

    "Neden bu firmaya mail gitmedi?" sorusu artık cevapsız kalmaz: her
    gerekçe kaç firmayı etkilediğiyle birlikte gösterilir.
    """
    counts: Dict[str, int] = {}
    for reason in reasons:
        text = (reason or "belirtilmemiş").strip()
        counts[text] = counts.get(text, 0) + 1
    if not counts:
        return ""
    ordered = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
    lines = [f"  • {count} firma — {text}" for text, count in ordered[:limit]]
    if len(ordered) > limit:
        lines.append(f"  • … {len(ordered) - limit} gerekçe daha")
    return "\nGerekçeler:\n" + "\n".join(lines) + "\n"


def _reminder_reply_request(reminder, case):
    """Reminder hedefini ve doğrulama kanıtlarını kayıpsız Outlook'a aktar."""
    from app.mailing.outlook_client import ReplyRequest

    recipients = [
        address.strip()
        for address in str(getattr(case, "recipients", "") or "")
        .replace(",", ";").split(";")
        if "@" in address
    ]
    return ReplyRequest(
        body=reminder.body,
        conversation_id=reminder.conversation_id,
        message_id=reminder.message_id,
        entry_id=reminder.entry_id,
        attachments=list(reminder.attachments),
        code=reminder.company_code,
        expected_recipients=recipients,
        period=str(getattr(case, "period", "") or ""),
        expected_subject=str(getattr(case, "subject", "") or ""),
    )


def _record_reminder_result(case, result) -> None:
    """Reminder sonucunu zincir, sayaç ve belirsizlik kilidine işle."""
    durum = str(getattr(result, "status", "") or "")
    if durum not in {"SENT", "SEND_UNKNOWN"}:
        return

    from app.services.case_actions import REMIND_FOR_REPLY
    from app.services.incoming_cases import _now
    from app.services.reply_target import record_outbound

    zaman = _now()
    record_outbound(case, result, REMIND_FOR_REPLY, now=zaman)
    if durum == "SENT":
        try:
            case.reminder_count = int(
                getattr(case, "reminder_count", 0) or 0) + 1
        except (TypeError, ValueError):
            case.reminder_count = 1
        case.last_reminder_at = zaman
        # Başka bir aksiyonun (ör. ekstre talebi) belirsizlik kilidini
        # reminder sonucu temizlememeli.
        if str(getattr(case, "pending_unknown_action", "") or "") in (
                "", REMIND_FOR_REPLY):
            case.pending_unknown_action = ""
            case.pending_unknown_at = ""
    else:
        case.pending_unknown_action = REMIND_FOR_REPLY
        case.pending_unknown_at = zaman
        # Outlook doğrulaması NOT_SENT dönerse kilidin açılabilmesi için
        # resolve_send_unknown aynı türde kalıcı bir aksiyon kaydı arar.
        from app.services.case_actions import (
            STATUS_SEND_UNKNOWN,
            ActionItem,
            actions_of,
            upsert_action,
        )

        action = next((item for item in actions_of(case)
                       if item.action_type == REMIND_FOR_REPLY
                       and item.status == STATUS_SEND_UNKNOWN), None)
        if action is None:
            action = ActionItem(case_id=case.case_id,
                                action_type=REMIND_FOR_REPLY,
                                status=STATUS_SEND_UNKNOWN)
        upsert_action(case, action)


class MailingPage(QWidget):
    # Başka bir sekmeye geçiş isteği (ana pencere bağlar). Sayfa, ana
    # pencereyi TANIMAZ; yalnızca "buraya gitmek istiyorum" der.
    navigate_requested = Signal(str)

    def __init__(self, session=None, outgoing_smtp_provider=None) -> None:
        super().__init__()
        # () -> str; Settings.outgoing_mailbox_smtp'i gönderim anında okur.
        self._outgoing_smtp_provider = outgoing_smtp_provider
        # Kalıcı oturum: seçilen dosyalar, dönem, sorumlu eşlemesi ve filtre
        # uygulama kapanınca KAYBOLMAZ (FAZ 7).
        if session is None:
            try:
                from app.services.session_state import SessionState

                session = SessionState()
            except Exception:  # noqa: BLE001 - oturum hatası sayfayı açmayı engellemez
                session = None
        self._session = session
        self._load: Optional[LoadResult] = None
        self._outlook: Optional[OutlookClient] = None
        self._account_label = ""
        self._responsible_emails: Dict[str, str] = {}
        try:
            from app.services.address_registry import AddressRegistry

            self._address_registry = AddressRegistry()
        except Exception:  # noqa: BLE001 - adres defteri sayfayı engellemez
            self._address_registry = None
        # Ekli gönderim (SAP ekstreleri + PDF mektup) için durum.
        self._fbl1h_path: str = ""
        self._fbl5h_path: str = ""
        self._output_dir: str = ""
        self._report_path: str = ""
        self._packages: List = []
        # Önizleme açıldıktan SONRA çalıştırılacak gönderim (onay penceresi
        # arada olduğu için iş bir sonraki adıma taşınır).
        self._pending_send = None
        self._pending_msg = ""
        # OTL-08: _send_flow -> _on_drafts_built arası taşınan dönem anahtarı
        # (FAZ1 gönderiminin de tekrar-gönderim kapısından geçmesi için).
        self._pending_period = ""
        # Satır -> bakiyenin nereden geldiği ("SAP" / "Rapor"). Kullanıcı
        # hangi rakamın SAP'tan güncellendiğini ekranda görür.
        self._balance_sources: Dict[int, str] = {}
        # SAP hesaplamaları için sıra numarası: FBL1H ve FBL5H peş peşe
        # seçilirse iki hesaplama aynı anda koşar ve ÖNCEKİ sonuç sonra
        # gelip yeniyi ezebilirdi. Yalnızca en güncel token kabul edilir.
        self._sap_token = 0
        self._threads: List = []          # canlı thread referansları
        self._worker = None
        #: işçi kimliği -> WorkerBinding. Eskimiş işçinin sinyalleri bu
        #: kayıttan "retire" edilerek kesilir; bağlantı KOPARILMAZ (silinmiş
        #: nesne üzerinde disconnect süreci çökertiyordu).
        self._bindings: dict = {}
        #: sinyal dağıtımı sırasında kaynağı bildiren alan (bkz. WorkerBinding)
        self._signal_source = None
        # Gönderim günlüğü: mükerrer mail ve yarıda kalan gönderim koruması.
        # Depo kurulamazsa sayfa YİNE AÇILIR (savunmacı): günlüksüz çalışmak,
        # uygulamanın hiç açılmamasından iyidir. Gönderim tarafı zaten
        # ``degraded`` durumunu ayrıca ele alır.
        try:
            self._mail_log = MailLog()
        except Exception as exc:  # noqa: BLE001 - sayfa kurulumu çökmemeli
            from loguru import logger

            logger.error(f"Gönderim günlüğü açılamadı: {exc}")
            self._mail_log = None
        # Gönderim anının değişmez hafızası: hangi firmaya, hangi FBL1H/FBL5H
        # verisiyle mail gittiği kalıcı olarak saklanır. Depo kurulamazsa
        # gönderim yine çalışır (savunmacı) — yalnızca snapshot alınmaz.
        try:
            from app.services.send_snapshot import SnapshotStore

            self._snapshots = SnapshotStore()
        except Exception:  # noqa: BLE001 - depo hatası uygulamayı açmayı engellemez
            self._snapshots = None
        self._build_ui()
        self._restore_session()

    # -- UI ----------------------------------------------------------------
    def _build_ui(self) -> None:
        root = QVBoxLayout(self)

        # Üst şerit: ay/yıl + yükle + outlook.
        top = QHBoxLayout()
        top.addWidget(QLabel("Mutabakat ayı:"))
        self.month_combo = QComboBox()
        for i, m in enumerate(MONTHS_TR, start=1):
            self.month_combo.addItem(f"{i:02d} - {m}", i)
        self.month_combo.setCurrentIndex(date.today().month - 1)
        top.addWidget(self.month_combo)

        top.addWidget(QLabel("Yıl:"))
        self.year_edit = QLineEdit(str(date.today().year))
        self.year_edit.setFixedWidth(70)
        self.year_edit.setMaxLength(4)
        self.year_edit.setValidator(QIntValidator(2000, 2100, self))
        self.year_edit.setToolTip("2000 ile 2100 arasında dört haneli yıl")
        top.addWidget(self.year_edit)

        self.btn_load = QPushButton("Excel Yükle")
        self.btn_load.clicked.connect(self._on_load)
        top.addWidget(self.btn_load)

        self.btn_connect = QPushButton("Outlook'a Bağlan")
        self.btn_connect.clicked.connect(self._on_connect)
        top.addWidget(self.btn_connect)

        self.lbl_account = QLabel("Outlook: bağlı değil")
        top.addWidget(self.lbl_account)
        top.addStretch(1)
        root.addLayout(top)

        # SAP ekstreleri + çıktı klasörü (ekli gönderim için).
        sap = QHBoxLayout()
        self.btn_fbl1h = QPushButton("FBL1H (Satıcı) Seç")
        self.btn_fbl1h.clicked.connect(lambda: self._pick_sap("fbl1h"))
        sap.addWidget(self.btn_fbl1h)
        self.lbl_fbl1h = QLabel("—")
        sap.addWidget(self.lbl_fbl1h, 1)

        self.btn_fbl5h = QPushButton("FBL5H (Müşteri) Seç")
        self.btn_fbl5h.clicked.connect(lambda: self._pick_sap("fbl5h"))
        sap.addWidget(self.btn_fbl5h)
        self.lbl_fbl5h = QLabel("—")
        sap.addWidget(self.lbl_fbl5h, 1)

        self.btn_outdir = QPushButton("Çıktı Klasörü")
        self.btn_outdir.clicked.connect(self._pick_output_dir)
        sap.addWidget(self.btn_outdir)
        self.lbl_outdir = QLabel("—")
        sap.addWidget(self.lbl_outdir, 1)
        root.addLayout(sap)

        # İlerleme çubuğu (üretim/gönderim arka planda çalışır).
        prog = QHBoxLayout()
        self.progress = QProgressBar()
        self.progress.setValue(0)
        prog.addWidget(self.progress, 1)
        self.lbl_status = QLabel("Hazır")
        prog.addWidget(self.lbl_status, 2)
        self.btn_cancel = QPushButton("Durdur")
        self.btn_cancel.setEnabled(False)
        self.btn_cancel.clicked.connect(self._cancel_current)
        prog.addWidget(self.btn_cancel)
        root.addLayout(prog)

        # Filtre.
        fl = QHBoxLayout()
        fl.addWidget(QLabel("Filtre:"))
        self.filter_edit = QLineEdit()
        self.filter_edit.setPlaceholderText("Kod / firma / mail / sorumlu ara…")
        self.filter_edit.textChanged.connect(self._apply_filter)
        fl.addWidget(self.filter_edit)
        root.addLayout(fl)

        # Tablo.
        self.table = QTableWidget(0, len(_COLS))
        self.table.setHorizontalHeaderLabels(_COLS)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(6, QHeaderView.Stretch)
        root.addWidget(self.table, 1)

        # Sorumlu CC adres kutusu (6. madde).
        rc = QHBoxLayout()
        rc.addWidget(QLabel("Sorumlu mail eşleme (Ad=mail; birden çok satır):"))
        root.addLayout(rc)
        self.responsible_box = QTextEdit()
        self.responsible_box.setPlaceholderText(
            "Ad Soyad=ornek.mail@sirket.com\n"
            "Ad Soyad 2=ornek.mail2@sirket.com"
        )
        self.responsible_box.setFixedHeight(70)
        root.addWidget(self.responsible_box)

        # Dokuz ana eylem tek bir 3x3 ızgarada tutulur. Altı düğmeyi tek
        # yatay sıraya koymak %125/%150 Windows ölçeklerinde sağdaki
        # düğmeleri görünür alan dışına itiyordu.
        action_panel = QWidget(self)
        # MailingPage'in tablo/üst şerit boyut ipuçları bazı DPI oranlarında
        # sayfayı görünür alandan daha geniş hesaplatabiliyor. Izgarayı sınırlı
        # bir panelde tutarak üçüncü sütunun ekran dışında kalmasını önle.
        action_panel.setMaximumWidth(1200)
        actions = QGridLayout(action_panel)
        actions.setContentsMargins(0, 0, 0, 0)
        actions.setHorizontalSpacing(6)
        actions.setVerticalSpacing(6)
        self.btn1 = QPushButton("1) Mutabakat Gönder")
        self.btn2 = QPushButton("2) Hatırlatma Gönder")
        self.btn3 = QPushButton("3) Dönüşleri Kontrol Et")
        self.btn4 = QPushButton("4) Değişiklikleri Kaydet")
        self.btn5 = QPushButton("5) Seçili Firmalara Gönder")
        self.btn6 = QPushButton("6) Sorumlu CC ile Gönder")
        for index, button in enumerate(
                (self.btn1, self.btn2, self.btn3, self.btn4, self.btn5, self.btn6)):
            actions.addWidget(button, index // 3, index % 3)

        self.lbl_reminder_policy = QLabel(
            "Hatırlatma kuralı: Açık vakalarda her basış, aynı zincirde en son "
            "başarıyla gönderilen mail üzerinden Reply-All ile ilerler. "
            "Belirsiz veya kapanmış vaka tekrar gönderilmez."
        )
        self.lbl_reminder_policy.setObjectName("Hint")
        self.lbl_reminder_policy.setWordWrap(True)
        self.btn2.setToolTip(
            "Yalnız açık vakalar · Son gönderilen mailden Reply-All · "
            "Belirsiz gönderimde tekrar yok"
        )
        root.addWidget(self.lbl_reminder_policy)

        self.btn1.clicked.connect(lambda: self._send_flow(include_cc=False))
        self.btn5.clicked.connect(lambda: self._send_flow(include_cc=False, selected_only=True))
        self.btn6.clicked.connect(lambda: self._send_flow(include_cc=True))
        self.btn4.clicked.connect(self._save_edits)
        self.btn2.clicked.connect(self._send_reminders)
        self.btn3.clicked.connect(self._open_incoming_page)

        # Ekli gönderim: SAP ekstrelerinden Excel + PDF üretip tek mailde yollar.
        self.btn_build = QPushButton("7) Ekstre + Mektup Üret")
        self.btn_build.clicked.connect(lambda: self._build_packages(False))
        self.btn_build_sel = QPushButton("8) Seçili Firmalar İçin Üret")
        self.btn_build_sel.clicked.connect(lambda: self._build_packages(True))
        self.btn_send_pkg = QPushButton("9) Ekli Mailleri Gönder")
        self.btn_send_pkg.clicked.connect(self._send_packages)
        self.btn_send_pkg.setEnabled(False)
        for column, button in enumerate(
                (self.btn_build, self.btn_build_sel, self.btn_send_pkg)):
            actions.addWidget(button, 2, column)
        root.addWidget(action_panel)

    # -- kalıcı oturum (FAZ 7) ---------------------------------------------

    def _restore_session(self) -> None:
        """Önceki oturumun seçimlerini geri yükle.

        Dosya artık yoksa YOL SİLİNMEZ; etiket "bulunamadı" der ve kullanıcı
        dosyayı geri koyduğunda oturum kaldığı yerden sürer.
        """
        if self._session is None:
            return
        from app.services.session_state import SECTION_MAILING

        try:
            state = self._session.section(SECTION_MAILING)
            self._fbl1h_path = str(state.get("fbl1h_path", "") or "")
            self._fbl5h_path = str(state.get("fbl5h_path", "") or "")
            self._output_dir = str(state.get("output_dir", "") or "")
            self._report_path = str(state.get("report_path", "") or "")
            self.lbl_fbl1h.setText(self._path_label(self._fbl1h_path))
            self.lbl_fbl5h.setText(self._path_label(self._fbl5h_path))
            self.lbl_outdir.setText(self._path_label(self._output_dir))

            year = str(state.get("year", "") or "").strip()
            if year.isdigit() and 2000 <= int(year) <= 2100:
                self.year_edit.setText(year)
            elif year:
                # Eski veya elle bozulmuş oturum verisi arayüzü geçersiz
                # durumda bırakmasın. Gönderim yine dönem doğrulamasından
                # geçer; burada yalnız görünür başlangıç değeri düzeltilir.
                self.year_edit.setText(str(date.today().year))
            month = state.get("month")
            if month:
                index = self.month_combo.findData(int(month))
                if index >= 0:
                    self.month_combo.setCurrentIndex(index)

            mapping = state.get("responsible_emails") or {}
            if mapping:
                self.responsible_box.setPlainText(
                    "\n".join(f"{ad}={adres}"
                              for ad, adres in sorted(mapping.items())))
            self.filter_edit.setText(str(state.get("filter", "") or ""))
        except Exception as exc:  # noqa: BLE001 - oturum asla çökertmez
            from loguru import logger

            logger.warning(f"[oturum] mail sayfası geri yüklenemedi: {exc}")

    @staticmethod
    def _path_label(path: str) -> str:
        """Etiket metni: dosya yoksa bunu AÇIKÇA söyler."""
        if not path:
            return "—"
        p = Path(path)
        return p.name if p.exists() else f"{p.name} (bulunamadı)"

    def _save_session(self) -> None:
        """Mevcut seçimleri kalıcı oturuma yaz (tek disk yazması)."""
        if self._session is None:
            return
        from app.services.session_state import SECTION_MAILING

        try:
            self._session.update(SECTION_MAILING, {
                "report_path": getattr(self, "_report_path", ""),
                "fbl1h_path": self._fbl1h_path,
                "fbl5h_path": self._fbl5h_path,
                "output_dir": self._output_dir,
                "year": self.year_edit.text().strip(),
                "month": self.month_combo.currentData(),
                "responsible_emails": self._parse_responsible_emails(),
                "filter": self.filter_edit.text(),
            })
        except Exception as exc:  # noqa: BLE001
            from loguru import logger

            logger.warning(f"[oturum] mail sayfası kaydedilemedi: {exc}")

    def restore_last_report(self) -> None:
        """Hatırlanan Excel'i ARKA PLANDA yeniden yükle (varsa).

        Dosya okuma UI thread'inde YAPILMAZ: 3000 satırlık bir dosya açılışı
        saniyelerce dondururdu. Dosya yoksa sessizce vazgeçilir — uyarı
        ana pencerede toplu olarak gösterilir.
        """
        path = getattr(self, "_report_path", "")
        if not path or not Path(path).is_file():
            return
        if self._is_busy():
            return          # açılışta başka iş varsa geri yükleme ATLANIR
        self.btn_load.setEnabled(False)
        self._busy("Önceki oturumun Excel'i yükleniyor…", 10)
        self._start_work(ReportLoadWorker(path), self._on_report_restored)

    def _on_report_restored(self, result) -> None:
        """Geri yüklemede bilgi penceresi AÇILMAZ (açılışı kesmesin)."""
        self._work_done()
        self.btn_load.setEnabled(True)
        self._load = result
        self._balance_sources = {}
        self._fill_table()
        self._busy(f"{len(result.rows)} satır önceki oturumdan yüklendi.", 100)

    def reset_ui_state(self) -> None:
        """Sayfanın GEÇİCİ durumunu temizle (FAZ 8).

        Yalnızca ekran/oturum durumu gider: seçili dosyalar, yüklü tablo,
        üretilmiş paket listesi ve filtre. Gönderim günlüğü ve snapshot'lar
        BU METOTTAN ETKİLENMEZ — mükerrer gönderim koruması ve denetim
        kaydı bir arayüz temizliğiyle kaybolamaz.
        """
        self._load = None
        self._packages = []
        self._balance_sources = {}
        self._fbl1h_path = ""
        self._fbl5h_path = ""
        self._output_dir = ""
        self._report_path = ""
        self.lbl_fbl1h.setText("—")
        self.lbl_fbl5h.setText("—")
        self.lbl_outdir.setText("—")
        self.filter_edit.clear()
        self.responsible_box.clear()
        self.table.setRowCount(0)
        self.btn_send_pkg.setEnabled(False)
        self._busy("Oturum sıfırlandı.", 0)

    # -- eylemler ----------------------------------------------------------
    def _on_load(self) -> None:
        """Excel'i ARKA PLANDA yükler; büyük dosyada ekran donmaz."""
        path, _ = QFileDialog.getOpenFileName(
            self, "Mutabakat Excel'i seç", "", "Excel (*.xls *.xlsx *.xlsm)")
        if not path:
            return
        if self._reject_if_busy("Excel yükle"):
            return
        self._report_path = path
        self._save_session()
        self.btn_load.setEnabled(False)
        self._busy("Excel okunuyor…", 10)
        self._start_work(ReportLoadWorker(path), self._on_report_loaded)

    def _on_report_loaded(self, result) -> None:
        self._work_done()
        self.btn_load.setEnabled(True)
        self._load = result
        self._balance_sources = {}
        self._fill_table()
        QMessageBox.information(self, "Yüklendi",
                                f"{len(self._load.rows)} satır yüklendi.")
        # SAP dosyaları önce seçilmiş olabilir: sıra ne olursa olsun bakiye
        # SAP'tan güncellenir.
        self._refresh_sap_balances()

    def _on_connect(self) -> None:
        """Outlook bağlantısını ARKA PLANDA kurar (COM saniyeler sürebilir)."""
        if self._reject_if_busy("Outlook"):
            return
        self.btn_connect.setEnabled(False)
        self.lbl_account.setText("Outlook: bağlanılıyor…")
        self._busy("Outlook'a bağlanılıyor…", 20)
        self._start_work(OutlookConnectionWorker(), self._on_outlook_connected)

    def _on_outlook_connected(self, account) -> None:
        self._work_done()
        self.btn_connect.setEnabled(True)
        self._outlook = OutlookClient()
        self._account_label = (getattr(account, "smtp_address", "")
                               or getattr(account, "display_name", "")
                               or "bağlı")
        self.lbl_account.setText(f"Outlook: {self._account_label} ✓")

    def set_connected_account(self, account) -> None:
        """Açılışta arka planda kurulan bağlantıyı benimser (butona basmadan).

        Bağlantı zaten kurulduğu için yeni bir OutlookClient hazır tutulur;
        gerçek Dispatch her işlemde (gümrük kalıbı) tekrar yapılacağından burada
        yalnızca 'bağlı' durumu ve hesap bilgisi gösterilir.

        ``account is None`` BAĞLANTI KURULAMADI demektir ve "bağlı" durumuna
        GEÇİLMEZ. Eskiden None da kabul ediliyordu: etiket "Outlook: bağlı ✓"
        oluyor, ``_outlook`` kuruluyordu. Kullanıcı bağlı sanıp "Gönder"e
        basıyor, hata ancak gönderim anında ortaya çıkıyordu.
        """
        if account is None:
            from loguru import logger

            logger.warning(
                "Outlook hesabı gelmedi; 'bağlı' durumuna geçilmiyor.")
            return
        self._outlook = OutlookClient()
        self._account_label = (getattr(account, "smtp_address", "")
                               or getattr(account, "display_name", "")
                               or "bağlı")
        self.lbl_account.setText(f"Outlook: {self._account_label} ✓")

    def _fill_table(self) -> None:
        assert self._load is not None
        rows = self._load.rows
        self.table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            other = {c: v for c, v in r.balances.items()
                     if c not in _REPORT_CURRENCIES and v}
            vals = [
                normalize_code(r.code_raw), r.name, r.ms,
                _fmt(r.balances.get("TL")), _fmt(r.balances.get("EUR")),
                _fmt(r.balances.get("USD")),
                "; ".join(r.mails), r.responsible,
                "; ".join(f"{c} {_fmt(v)}" for c, v in sorted(other.items())),
                self._balance_sources.get(r.row_index, "Rapor"),
            ]
            for c, v in enumerate(vals):
                item = QTableWidgetItem(v)
                # Yalnızca mail (6) ve sorumlu (7) düzenlenebilir.
                if c not in (6, 7):
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                self.table.setItem(i, c, item)

    def _apply_filter(self, text: str) -> None:
        t = text.strip().lower()
        for i in range(self.table.rowCount()):
            show = not t or any(
                t in (self.table.item(i, c).text().lower() if self.table.item(i, c) else "")
                for c in range(self.table.columnCount()))
            self.table.setRowHidden(i, not show)

    def _save_edits(self) -> None:
        """Tablodaki mail/sorumlu düzenlemelerini yüklü satırlara geri yazar."""
        if not self._load:
            QMessageBox.warning(self, "Kaydet", "Önce Excel yükleyin.")
            return
        for i, r in enumerate(self._load.rows):
            mail_item = self.table.item(i, 6)
            resp_item = self.table.item(i, 7)
            if mail_item is not None:
                r.mails = [m.strip() for m in mail_item.text().replace(",", ";").split(";")
                           if m.strip() and "@" in m]
            if resp_item is not None:
                r.responsible = resp_item.text().strip()
        # Sorumlu eşlemesi ve dönem kalıcı oturuma da yazılır.
        self._save_session()
        QMessageBox.information(self, "Kaydedildi", "Değişiklikler belleğe alındı.")

    def _parse_responsible_emails(self) -> Dict[str, str]:
        mapping: Dict[str, str] = {}
        for line in self.responsible_box.toPlainText().splitlines():
            if "=" in line:
                name, addr = line.split("=", 1)
                if name.strip():
                    mapping[name.strip()] = addr.strip()
        return mapping

    def _selected_codes(self) -> set:
        codes = set()
        for idx in self.table.selectionModel().selectedRows():
            item = self.table.item(idx.row(), 0)
            if item:
                codes.add(item.text().strip())
        return codes

    def _send_flow(self, include_cc: bool, selected_only: bool = False) -> None:
        if self._reject_if_busy("Gönder"):
            return
        if not self._load:
            QMessageBox.warning(self, "Gönder", "Önce Excel yükleyin.")
            return
        self._save_edits_silent()

        try:
            year = int(self.year_edit.text().strip())
        except ValueError:
            QMessageBox.warning(self, "Gönder", "Yıl geçersiz.")
            return
        month = self.month_combo.currentData()
        # OTL-08: FAZ1 işçisine de aynı dönem anahtarı geçecek (bkz.
        # _on_drafts_built) — "9) Ekli Mailleri Gönder" ile aynı
        # tekrar-gönderim/idempotency kapısından geçsin diye.
        self._pending_period = period_key(year, month)

        only = None
        if selected_only:
            only = self._selected_codes()
            if not only:
                QMessageBox.warning(self, "Gönder", "Önce tablo satırı seçin.")
                return

        cfg = BuildConfig(
            year=year, month=month,
            include_responsible_cc=include_cc,
            responsible_emails=self._parse_responsible_emails(),
        )

        # Outlook kontrolü TASLAK ÜRETİMİNDEN ÖNCE: bağlantı yoksa boşuna
        # 600 firmalık taslak üretmenin anlamı yok.
        if not self._outlook:
            QMessageBox.warning(self, "Outlook",
                                "Önce Outlook'a bağlanın.")
            return

        # TASLAK ÜRETİMİ ARKA PLANDA.
        #
        # ``build_drafts`` burada SENKRON çağrılıyordu; 600 firma + adres
        # başına bir SQLite sorgusu, tıklama anında pencereyi saniyelerce
        # donduruyordu ("not responding"). Akış artık işçi üzerinden
        # ilerliyor: taslaklar hazır olunca _on_drafts_built devralır.
        self._set_send_buttons_enabled(False)
        self._set_buttons_enabled(False)
        self._busy("Mail taslakları hazırlanıyor…", 10)
        self._start_work(
            DraftBuildWorker(self._load.rows, cfg, only_codes=only,
                             address_registry=self._address_registry),
            self._on_drafts_built)

    def _on_drafts_built(self, drafts) -> None:
        """Taslaklar hazır (UI thread'i): özet göster, önizlemeyi başlat."""
        iptal = bool(self._worker
                     and getattr(self._worker, "cancelled", False))
        self._work_done()

        if iptal:
            self._set_send_buttons_enabled(True)
            self._set_buttons_enabled(True)
            self._busy("Taslak üretimi durduruldu.", 0)
            return

        drafts = list(drafts or [])
        if not drafts:
            self._set_send_buttons_enabled(True)
            self._set_buttons_enabled(True)
            self._busy("Gönderilecek mail yok.", 0)
            QMessageBox.information(
                self, "Gönder",
                "Gönderilecek mail yok (0 dışı bakiyeli firma bulunamadı).")
            return

        # Toplu gönderim öncesi açık özet: kullanıcı neyin gideceğini,
        # neyin gitmeyeceğini ve NEDEN gitmeyeceğini görmeden onaylamamalı.
        ready = [d for d in drafts if d.sendable]
        blocked = [d for d in drafts if not d.sendable]

        if not ready:
            self._set_send_buttons_enabled(True)
            self._set_buttons_enabled(True)
            self._busy("Gönderilecek mail yok.", 0)
            QMessageBox.warning(
                self, "Gönderilecek mail yok",
                "Listedeki hiçbir firma gönderilebilir durumda değil.\n\n"
                + _reason_summary(d.skip_reason for d in blocked))
            return

        # OTL-08: "9) Ekli Mailleri Gönder" ile AYNI tekrar-gönderim kapısı
        # — bu dönemde zaten gönderilmiş firmalar burada da çıkarılır.
        # (MailSendWorker bunu KENDİSİ de yapar; bu UI katmanındaki tekrar
        # süzme yalnız özet mesajının doğru sayı göstermesi içindir.)
        donem = self._pending_period
        gonderilmis = (self._mail_log.no_resend_codes(donem)
                      if self._mail_log is not None and donem else set())
        yeni = [d for d in ready if d.code not in gonderilmis]
        tekrar = len(ready) - len(yeni)

        if not yeni:
            self._set_send_buttons_enabled(True)
            self._set_buttons_enabled(True)
            self._busy("Gönderilecek mail yok.", 0)
            QMessageBox.information(
                self, "Gönder",
                f"{donem or 'bu dönemdeki'} {len(ready)} firmanın hepsine "
                "daha önce mail gönderilmiş. Tekrar gönderilmedi.")
            return

        msg = (f"Listedeki firma: {len(drafts)}\n"
               f"Gönderilecek: {len(yeni)}\n"
               f"Gönderilmeyecek: {len(blocked)}\n"
               f"Daha önce gönderilmiş (atlanacak): {tekrar}\n"
               + _reason_summary(d.skip_reason for d in blocked)
               + "\nİlk mail önizleme olarak açılıyor.\n"
               "Gönderilecek mailleri göndermek istiyor musunuz?")

        # Önizleme de ARKA PLANDA: Outlook penceresini açmak COM üzerinden
        # saniyeler sürebiliyor ve UI thread'inde donma yaratıyordu.
        # Düğmeler taslak üretimi başlarken KAPATILDI; burada tekrar
        # kapatılmaz.
        self._pending_msg = msg
        self._pending_send = lambda: self._start_work(
            MailSendWorker(yeni, mail_log=self._mail_log, period=donem,
                           outgoing_smtp=self._outgoing_smtp()),
            self._on_mails_sent)
        self._busy("Önizleme açılıyor…", 10)
        self._start_work(MailPreviewWorker(yeni[0]), self._on_preview_ready)

    def _on_preview_ready(self, _draft) -> None:
        """Önizleme açıldı; onay al ve gönderimi başlat."""
        self._work_done()
        message = self._pending_msg
        start_send = self._pending_send
        self._pending_msg = ""
        self._pending_send = None

        if start_send is None:
            return
        if QMessageBox.question(self, "Gönderim onayı",
                                message) != QMessageBox.Yes:
            self._set_send_buttons_enabled(True)
            self._set_buttons_enabled(True)
            self._busy("Gönderim iptal edildi.", 0)
            return

        self._busy("Gönderiliyor…", 0)
        start_send()

    def _on_mails_sent(self, result) -> None:
        self._work_done()
        sent, skipped = result
        self._set_send_buttons_enabled(True)
        self._set_buttons_enabled(True)
        self._busy(f"Gönderildi: {sent} · Atlanan: {len(skipped)}", 100)
        detail = f"Gönderilen: {sent}\nAtlanan: {len(skipped)}"
        if skipped:
            detail += "\n\n" + "\n".join(skipped[:20])
        QMessageBox.information(self, "Sonuç", detail)

    def _set_send_buttons_enabled(self, enabled: bool) -> None:
        """FAZ1 gönderim butonları: iş sürerken tekrar tıklanmasın."""
        for b in (self.btn1, self.btn5, self.btn6):
            b.setEnabled(enabled)

    def _save_edits_silent(self) -> None:
        if not self._load:
            return
        for i, r in enumerate(self._load.rows):
            mi = self.table.item(i, 6)
            ri = self.table.item(i, 7)
            if mi is not None:
                r.mails = [m.strip() for m in mi.text().replace(",", ";").split(";")
                           if m.strip() and "@" in m]
            if ri is not None:
                r.responsible = ri.text().strip()

    def _open_incoming_page(self) -> None:
        """3) Dönüşleri Kontrol Et — takip ekranına geçer.

        Dönüş taraması "Gelen Cevaplar" sekmesinde yaşar (case'ler orada).
        Aynı işi iki yerde çalıştırmak, iki farklı sonuç üretme riskidir.
        """
        self.navigate_requested.emit("incoming")

    def _reminder_cases(self) -> list:
        """Bu dönemde cevap bekleyen kayıtlar."""
        try:
            from app.services.incoming_cases import IncomingCaseStore
            from app.services.reminder_mail import eligible_cases

            period = self._period()
            if period is None:
                return []
            donem = period_key(period.year, period.month)
            cases = IncomingCaseStore().find(period=donem)
            return eligible_cases(cases)
        except Exception as exc:  # noqa: BLE001 - kayıt hatası ekranı düşürmez
            QMessageBox.warning(self, "Hatırlatma",
                                f"Gönderim kayıtları okunamadı: {exc}")
            return []

    def _send_reminders(self) -> None:
        """2) Hatırlatma Gönder — son giden mailden Reply-All (§3.5, §3.6)."""
        from app.services.reminder_mail import build_many

        if self._reject_if_busy("Hatırlatma"):
            return
        if not self._outlook:
            QMessageBox.warning(self, "Outlook", "Önce Outlook'a bağlanın.")
            return

        cases = self._reminder_cases()
        if not cases:
            QMessageBox.information(
                self, "Hatırlatma",
                "Bu dönemde cevap bekleyen ve mail zinciri bilinen firma yok.\n"
                "Önce mutabakat mailini gönderin; hatırlatma aynı zincire gider.")
            return

        hazir, engelli = build_many(cases)
        if not hazir:
            QMessageBox.warning(
                self, "Hatırlatma",
                "Gönderilebilecek hatırlatma yok.\n"
                + _reason_summary(m.blocked_reason for m in engelli))
            return

        ornek = hazir[0]
        mesaj = (f"Cevap bekleyen firma: {len(cases)}\n"
                 f"Gönderilecek hatırlatma: {len(hazir)}\n"
                 f"Gönderilmeyecek: {len(engelli)}\n"
                 + _reason_summary(m.blocked_reason for m in engelli)
                 + f"\nÖrnek — {ornek.company_code}: {ornek.subject}\n"
                 f"Ek sayısı: {len(ornek.attachments)}\n\n"
                 + ornek.body[:300]
                 + "\n\nHer mail aynı zincirde EN SON gönderdiğimiz mailin "
                 "üzerinden Reply-All olarak gider. "
                 "Gönderilsin mi?")
        if QMessageBox.question(self, "Hatırlatma gönder",
                                mesaj) != QMessageBox.Yes:
            return

        from app.incoming.worker import ThreadReplyWorker
        case_by_id = {str(getattr(c, "case_id", "")): c for c in cases}
        istekler = [
            (m.case_id, _reminder_reply_request(m, case_by_id.get(m.case_id)))
            for m in hazir
        ]

        self._set_send_buttons_enabled(False)
        self._busy(f"{len(istekler)} hatırlatma gönderiliyor…", 5)
        self._start_work(ThreadReplyWorker(
            istekler, send=True, outgoing_smtp=self._outgoing_smtp()),
                         self._on_reminders_sent)

    def _on_reminders_sent(self, results) -> None:
        """Sonuçları işlem geçmişine yaz ve kullanıcıya bildir."""
        self._work_done()
        self._set_send_buttons_enabled(True)
        self._set_buttons_enabled(True)

        gonderilen = 0
        atlanan: list[str] = []
        try:
            from app.services.incoming_cases import IncomingCaseStore

            store = IncomingCaseStore()
        except Exception:  # noqa: BLE001
            store = None

        for case_id, result in results or []:
            durum = str(getattr(result, "status", "") or "")
            basarili = durum == "SENT"
            gonderilen += 1 if basarili else 0
            if not basarili:
                atlanan.append(f"{getattr(result, 'code', '')}: "
                               f"{getattr(result, 'reason', '')[:70]}")
            if store is None:
                continue
            case = store.get(case_id)
            if case is None:
                continue
            # Zinciri ilerlet: bir sonraki basış ilk mutabakat mailini değil,
            # şimdi gönderilen reminder'ı hedeflemelidir. SEND_UNKNOWN'da da
            # eldeki kimlik korunur ve tekrar gönderim kilitlenir.
            _record_reminder_result(case, result)
            case.add_event(
                "REMINDER_SENT" if basarili else "REMINDER_SENT_FAILED",
                "Hatırlatma gönderildi" if basarili
                else "Hatırlatma gönderilemedi",
                detail=getattr(result, "reason", ""))
            case.add_mail_event("OUT", subject=case.subject,
                                snippet="Hatırlatma maili")
            store.upsert(case)

        self._busy(f"Hatırlatma — gönderilen: {gonderilen} · "
                   f"atlanan: {len(atlanan)}", 100)
        detay = f"Gönderilen: {gonderilen}\nAtlanan: {len(atlanan)}"
        if atlanan:
            detay += "\n\n" + "\n".join(atlanan[:15])
        QMessageBox.information(self, "Hatırlatma sonucu", detay)

    def _todo(self, name: str) -> None:
        QMessageBox.information(self, name, f"{name} — FAZ2'de uygulanacak.")

    # -- ekli gönderim (SAP ekstresi + PDF mektup) --------------------------

    def _pick_sap(self, which: str) -> None:
        title = ("FBL1H (satıcı kalemleri) seç" if which == "fbl1h"
                 else "FBL5H (müşteri kalemleri) seç")
        path, _ = QFileDialog.getOpenFileName(
            self, title, "", "Excel (*.xlsx *.xls *.xlsm)")
        if not path:
            return
        name = Path(path).name
        if which == "fbl1h":
            self._fbl1h_path = path
            self.lbl_fbl1h.setText(name)
        else:
            self._fbl5h_path = path
            self.lbl_fbl5h.setText(name)
        self._save_session()
        self._refresh_sap_balances()

    def _templates_ready(self) -> bool:
        """Rapordaki dillerin mektup şablonları yerinde mi?

        Eksikse ÜRETİM BAŞLAMADAN eksik dosyanın tam yolu gösterilir.
        Kullanıcı yine de devam edebilir (Excel ekstreler üretilir), ama
        neyin eksik olduğunu bilerek devam eder.
        """
        if not self._load:
            return True
        locales = {classify_locale(normalize_code(r.code_raw))
                   for r in self._load.rows}
        problems = missing_templates(locales & {"tr", "en"})
        if not problems:
            return True

        detail = "\n".join(f"• {locale.upper()}: {reason}"
                           for locale, reason in problems.items())
        answer = QMessageBox.question(
            self, "Mektup şablonu eksik",
            "Mutabakat mektubu üretilemeyecek çünkü şablon dosyası "
            "bulunamadı:\n\n" + detail +
            "\n\nBu dosyalar uygulamanın 'assets/templates' klasöründe "
            "olmalıdır. Yine de devam edilsin mi?\n"
            "(Devam ederseniz Excel ekstreler üretilir ama mektup üretilmez "
            "ve mailler gönderilemez.)")
        return answer == QMessageBox.Yes

    def _refresh_sap_balances(self) -> None:
        """SAP dosyası seçilince bakiyeleri ARKA PLANDA yeniden hesapla.

        Kullanıcı kararı: SAP verisi her zaman daha güvenilirdir. Tablo ve
        eksiz mail metni bu değerlerle güncellenir; rapordaki eski rakam
        kullanılmaz.
        """
        if not self._load:
            return          # önce mutabakat Excel'i yüklenmeli
        if not self._fbl1h_path and not self._fbl5h_path:
            return

        # Çalışan eski hesaplamayı durdur ve sonucunu geçersiz say.
        # İptal ETMEK YETMEZ: işçi iptalden önce failed yayabilir ve
        # _on_package_error token bilmediği için YENİ hesaplamanın arayüz
        # durumunu sıfırlar (iptal butonu kapanır, modal hata açılır).
        # Bu yüzden eski işçinin sinyalleri ÖNCE koparılır.
        # Yalnızca ESKİ BİR SAP hesaplaması geçersiz kılınır. Başka bir iş
        # (gönderim, paket üretimi) çalışıyorsa bakiye tazeleme ATLANIR:
        # devam eden bir gönderimi sessizce iptal etmek kabul edilemez.
        self._preempt_worker(SapBalanceWorker)
        if self._is_busy():
            return
        self._sap_token += 1
        token = self._sap_token

        self._busy("SAP bakiyeleri hesaplanıyor…", 10)
        # DİKKAT: sinyale lambda BAĞLANMAZ. Lambda'nın alıcı QObject'i
        # olmadığı için Qt bağlantıyı doğrudan sayar ve sonuç WORKER
        # THREAD'İNDE işlenir; arayüzü başka thread'den kurcalamak
        # "QObject::setParent: Cannot set parent" uyarılarına ve çökmeye
        # yol açar. Bağlı metot kullanılır, sıra numarası sonucun İÇİNDE
        # taşınır.
        self._start_work(
            SapBalanceWorker(self._fbl1h_path or None, self._fbl5h_path or None,
                             self._load.rows, token=token),
            self._on_sap_balances)

    def _on_sap_balances(self, result) -> None:
        """SAP bakiyelerini rapor satırlarına ve tabloya yaz (UI thread'i)."""
        token = getattr(result, "token", 0)
        if token and token != self._sap_token:
            return          # eskimiş hesaplama: yeni sonucu EZMESİN
        self._work_done()
        if self._load is None:
            return

        updated = 0
        untouched: list[str] = []
        for row in self._load.rows:
            code = normalize_code(row.code_raw)
            ms = effective_ms(row.ms)
            sap = result.for_direction(code, ms)
            if sap is None:
                # Bu yönün SAP dosyası yok ya da firma dosyada yok:
                # rapordaki değer KORUNUR, kaynak 'Rapor' kalır.
                self._balance_sources[row.row_index] = "Rapor"
                if code and code not in untouched:
                    untouched.append(code)
                continue

            # SAP'ta olmayan para birimi otomatik 0 (kullanıcı kararı).
            balances = {c: Decimal("0") for c in _REPORT_CURRENCIES}
            for currency, amount in sap.items():
                balances[_SAP_TO_REPORT.get(currency, currency)] = amount
            row.balances = balances
            self._balance_sources[row.row_index] = "SAP"
            updated += 1

        self._fill_table()
        self._busy(f"SAP bakiyesi güncellenen satır: {updated}", 100)

        detail = (f"SAP'tan güncellenen satır: {updated}\n"
                  f"Raporda kalan satır: {len(self._load.rows) - updated}\n"
                  f"FBL1H yüklü: {'evet' if result.vendor_loaded else 'hayır'}\n"
                  f"FBL5H yüklü: {'evet' if result.customer_loaded else 'hayır'}")
        if result.missing_directions:
            detail += ("\n\nKaynağı eksik olan yönler (bakiye hesaplanamadı, "
                       "rapordaki değer korundu):\n"
                       + "\n".join(f"• {code}: {', '.join(yonler)}"
                                   for code, yonler in
                                   list(result.missing_directions.items())[:10]))

        # Hiçbir firmaya bağlanamayan 120* hesapları. Bu sayım hep
        # üretiliyordu ama hiçbir yerde gösterilmiyordu: eksik eşleme
        # sessizce kayboluyordu (bkz. unmapped_customer_warning).
        try:
            from app.services.customer_accounts import unmapped_customer_warning

            uyari = unmapped_customer_warning(
                getattr(result, "unmapped_customer_accounts", None))
        except Exception:  # noqa: BLE001 - uyarı üretimi akışı bozmasın
            uyari = ""
        if uyari:
            detail += "\n\n" + uyari

        QMessageBox.information(self, "SAP bakiyeleri", detail)

    def set_default_output_dir(self, path: str) -> None:
        """Ayarlardaki ortak çıktı klasörünü, seçili klasör yoksa kullan."""
        if path and not self._output_dir and Path(path).is_dir():
            self._output_dir = str(path)
            self.lbl_outdir.setText(self._path_label(self._output_dir))

    def _pick_output_dir(self) -> None:
        path = QFileDialog.getExistingDirectory(
            self, "Çıktı klasörü seç", self._output_dir or "")
        if path:
            self._output_dir = path
            self.lbl_outdir.setText(path)
            self._save_session()
            # Ana pencere bu klasörü ORTAK çıktı klasörü olarak hatırlar.
            geri = getattr(self, "on_output_dir_chosen", None)
            if callable(geri):
                try:
                    geri(path)
                except Exception as exc:  # noqa: BLE001 - seçim yine geçerli
                    from loguru import logger

                    logger.warning(f"Çıktı klasörü ayara yazılamadı: {exc}")

    def _period(self) -> Optional[LetterPeriod]:
        try:
            year = int(self.year_edit.text().strip())
        except ValueError:
            QMessageBox.warning(self, "Dönem", "Yıl geçersiz.")
            return None
        return LetterPeriod(year, self.month_combo.currentData())

    def _track(self, thread) -> None:
        """Thread referansını tut ve bitince temizle.

        Temizlik BAĞLI METODA bağlanır: ``QThread.finished`` worker thread'inde
        yayınlanır; lambda bağlanırsa liste başka thread'den değiştirilir.
        Bağlı metot, sayfanın thread'ine kuyruklanır.
        """
        self._threads.append(thread)
        thread.finished.connect(self._forget_finished_threads)

    def _forget_finished_threads(self) -> None:
        alive = []
        for thread in self._threads:
            try:
                if not thread.isFinished():
                    alive.append(thread)
            except RuntimeError:
                continue      # C++ nesnesi silinmiş; listeden düşür
        self._threads = alive

    def _busy(self, message: str, percent: int = 0) -> None:
        self.lbl_status.setText(message)
        self.progress.setValue(percent)

    def _cancel_current(self) -> None:
        """Çalışan işi kooperatif olarak durdurur.

        İş parçacığı zorla öldürülmez: işçi bir sonraki firmada kendisi durur,
        böylece yarım dosya ya da yarım gönderilmiş mail oluşmaz. Gönderim
        iptal edilirse o ana kadar gidenler günlükte kayıtlıdır ve tekrar
        çalıştırıldığında kaldığı yerden devam eder.
        """
        worker = self._worker
        if worker is None or not hasattr(worker, "cancel"):
            return
        worker.cancel()
        self.btn_cancel.setEnabled(False)
        self._busy("Durduruluyor… (mevcut işlem tamamlanınca duracak)",
                   self.progress.value())

    def _is_busy(self) -> bool:
        """TEK İŞÇİ SÖZLEŞMESİ: sayfada çalışan bir iş var mı?"""
        return self._worker is not None

    def _reject_if_busy(self, title: str) -> bool:
        """Çalışan iş varken yeni aksiyonu reddet ve NEDENİNİ söyle.

        Aksiyon işleyicileri düğmeleri kapatmadan ÖNCE bunu çağırır:
        reddedilen iş arayüzü kilitli bırakmaz.
        """
        if not self._is_busy():
            return False
        QMessageBox.information(
            self, title,
            "Şu anda başka bir işlem çalışıyor.\n\n"
            "Aynı anda yalnızca bir işlem yürütülür; aksi hâlde gönderim "
            "veya üretim iki kez başlayabilir. İşlemin bitmesini bekleyin "
            "ya da 'Durdur' ile iptal edin.")
        return True

    def _preempt_worker(self, worker_type: type | None = None) -> None:
        """Çalışan işi sayfanın KENDİ kararıyla geçersiz kıl.

        Yalnızca sayfanın tazelediği hesaplamalar için kullanılır (ör. SAP
        bakiyesi yeni dosya seçilince baştan hesaplanır). İptal ETMEK
        YETMEZ: işçi iptalden önce finished/failed yayabilir ve YENİ işin
        arayüz durumunu sıfırlar. Bu yüzden sinyaller koparılır ve
        SAHİPLİK BIRAKILIR; ancak o zaman yeni iş başlatılabilir.
        """
        worker = self._worker
        if worker is None:
            return
        if worker_type is not None and not isinstance(worker, worker_type):
            return
        if hasattr(worker, "cancel"):
            worker.cancel()
        self._detach_worker(worker)
        self._worker = None

    def _outgoing_smtp(self) -> str:
        """Kurumsal giden posta kutusu SMTP'si; GÖNDERİM ANINDA okunur.

        Sağlayıcı (ana pencerenin ayarları) verilmemişse ya da hata verirse
        boş döner; boş SMTP gerçek gönderimi fail-closed engeller.
        """
        provider = self._outgoing_smtp_provider
        if provider is None:
            return ""
        try:
            return str(provider() or "").strip()
        except Exception:  # noqa: BLE001 - okunamayan ayar = gönderme
            return ""

    def _start_work(self, worker, on_finished) -> bool:
        """Bir işçiyi arka planda başlat ve iptal butonunu aç.

        TEK İŞÇİ SÖZLEŞMESİ: çalışan iş varken yeni işçi BAŞLATILMAZ ve
        ``False`` döner. Eskiden ``self._worker`` koşulsuz eziliyordu; eski
        işçi arka planda çalışmaya devam ediyor, Durdur yalnızca yeni
        işçiye gidiyor ve eski işçinin sinyalleri yeni işin durumunu
        bozuyordu.
        """
        if self._is_busy():
            # SON SAVUNMA HATTI: aksiyon işleyicisi _reject_if_busy ile
            # önceden kontrol etmeyi atlamış olsa da iş sessizce yutulmaz.
            self._reject_if_busy("İşlem")
            return False
        self._worker = worker
        # Sinyaller DOĞRUDAN bağlanmaz: binding, işçi eskidiğinde gelen
        # sinyalleri yutar (bkz. WorkerBinding / _detach_worker).
        self._bindings[id(worker)] = WorkerBinding(
            self, worker, self._busy, on_finished, self._on_package_error)
        self.btn_cancel.setEnabled(True)
        self._track(run_in_thread(worker))
        return True

    def _detach_worker(self, worker) -> None:
        """Eskimiş işçinin sinyallerini sayfadan KES.

        Bağlantılar koparılmaz (bkz. ``WorkerBinding``): işçi bittiğinde
        ``deleteLater`` ile siliniyor ve silinmiş nesne üzerinde
        ``disconnect()`` çağırmak süreci çökertiyordu. Yerine işçinin
        binding'i "eskimiş" işaretlenir; sinyalleri artık yutulur.
        """
        binding = self._bindings.pop(id(worker), None)
        if binding is not None:
            binding.retire()

    def _work_done(self) -> None:
        """İşi SONLANDIR: sahipliği bırak ve işçinin sinyallerini kopar.

        Sinyalleri koparmak şart: ``_work_done`` çağrıldıktan sonra aynı
        işçiden GEÇ GELEN bir finished/failed, o sırada başlatılmış YENİ
        işin durumunu sıfırlıyordu (iptal düğmesi kapanıyor, modal hata
        açılıyordu).
        """
        self.btn_cancel.setEnabled(False)
        worker = self._worker
        self._worker = None
        if worker is not None:
            self._detach_worker(worker)

    def shutdown(self, timeout_ms: int = 5000) -> None:
        """Uygulama kapanırken çalışan işleri düzgünce durdur.

        Çalışan bir QThread'i beklemeden süreç kapanırsa Windows'ta
        0xC0000409 ile çökme olur. Önce işçiye iptal sinyali verilir (yarım
        dosya/mail oluşmasın), sonra thread'lerin bitmesi beklenir.
        Gönderim yarıda kalsa bile o ana kadar gidenler günlükte kayıtlıdır.
        """
        # Kapanışta son durum yazılır: kullanıcı yarın kaldığı yerden devam
        # etsin. Yazma hatası kapanışı ASLA engellemez.
        try:
            self._save_session()
        except Exception:  # noqa: BLE001
            pass
        worker = self._worker
        if worker is not None and hasattr(worker, "cancel"):
            worker.cancel()
        for t in list(self._threads):
            try:
                t.quit()
                t.wait(timeout_ms)
            except RuntimeError:
                pass          # thread zaten silinmiş
        self._threads.clear()
        self._worker = None

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt arayüzü
        self.shutdown()
        super().closeEvent(event)

    def _set_buttons_enabled(self, enabled: bool) -> None:
        for b in (self.btn_build, self.btn_build_sel, self.btn_send_pkg):
            b.setEnabled(enabled)
        if enabled and not self._packages:
            self.btn_send_pkg.setEnabled(False)

    def _build_packages(self, selected_only: bool) -> None:
        """Her firma için Excel ekstre + PDF mektup üretir (arka planda)."""
        if self._reject_if_busy("Üret"):
            return
        if not self._load:
            QMessageBox.warning(self, "Üret", "Önce mutabakat Excel'ini yükleyin.")
            return
        if not self._fbl1h_path and not self._fbl5h_path:
            QMessageBox.warning(
                self, "Üret",
                "En az bir SAP ekstresi seçin.\n\n"
                "FBL1H → S/X yönü (satıcı)\nFBL5H → M yönü (müşteri)")
            return
        if not self._output_dir:
            # Klasör hiç seçilmediyse BİR KEZ sorulur ve hatırlanır.
            self._pick_output_dir()
        if not self._output_dir:
            QMessageBox.warning(self, "Üret", "Önce çıktı klasörünü seçin.")
            return

        period = self._period()
        if period is None:
            return
        self._save_edits_silent()

        # ÜRETİMDEN ÖNCE şablon kontrolü: eksik şablonla 600 firma için Excel
        # üretip sonunda "mektup üretilemedi" demek zaman kaybıdır.
        if not self._templates_ready():
            return

        only = None
        if selected_only:
            only = self._selected_codes()
            if not only:
                QMessageBox.warning(self, "Üret", "Önce tablo satırı seçin.")
                return

        cfg = BuildConfig(
            year=period.year, month=period.month,
            include_responsible_cc=bool(self._parse_responsible_emails()),
            responsible_emails=self._parse_responsible_emails(),
        )

        self._set_buttons_enabled(False)
        self._busy("Üretim başlıyor…", 0)
        self._start_work(
            PackageBuildWorker(
                self._fbl1h_path or None, self._fbl5h_path or None,
                self._load.rows, self._output_dir, period, cfg, only),
            self._on_packages_built)

    def _on_packages_built(self, packages) -> None:
        iptal = bool(self._worker and getattr(self._worker, "cancelled", False))
        self._work_done()
        self._packages = list(packages)
        self._set_buttons_enabled(True)

        if iptal:
            self.btn_send_pkg.setEnabled(
                any(p.sendable for p in self._packages))
            QMessageBox.warning(
                self, "Durduruldu",
                f"Üretim durduruldu.\n\n"
                f"Tamamlanan firma: {len(self._packages)}\n"
                "Üretilen dosyalar geçerlidir; yarım dosya oluşmadı.\n"
                "Tekrar üretirseniz baştan başlar.")
            self._busy(f"Durduruldu — {len(self._packages)} firma üretildi", 0)
            return

        total_files = sum(p.attachment_count for p in self._packages)
        # TEK ölçüt: paketin kendi block_reason'ı. Ekran ve gönderim işçisi
        # artık aynı kaynağa bakar.
        ready = [p for p in self._packages if p.sendable]
        blocked = [p for p in self._packages if not p.sendable]

        self.btn_send_pkg.setEnabled(bool(ready))
        self._busy(
            f"{len(self._packages)} firma · {total_files} dosya · "
            f"{len(ready)} mail gönderime hazır", 100)

        detail = (f"Firma: {len(self._packages)}\n"
                  f"Üretilen dosya: {total_files}\n"
                  f"Gönderime hazır: {len(ready)}\n"
                  f"Gönderilemez: {len(blocked)}\n"
                  + _reason_summary(p.block_reason for p in blocked)
                  + f"\nKlasör: {self._output_dir}")

        if not ready:
            # Buton pasif kalacaksa NEDENİ burada söylenir; eskiden buton
            # sessizce ölü kalıyor, kullanıcı sebebini göremiyordu.
            detail += ("\n\n'9) Ekli Mailleri Gönder' butonu bu yüzden pasif. "
                       "Yukarıdaki gerekçeleri giderip tekrar üretin.")
            QMessageBox.warning(self, "Gönderilebilir paket yok", detail)
            return

        blocking = [p for p in self._packages if p.blocked]
        if blocking:
            detail += ("\n\nMektubu güvenli üretilemeyen firmalar:\n"
                       + "\n".join(f"• {p.company_code}: {r}"
                                   for p in blocking[:10]
                                   for r in p.blocked_reasons[:1]))
        QMessageBox.information(self, "Üretim tamamlandı", detail)

    def _on_package_error(self, message: str) -> None:
        """İşçi hatası: durumu bildir ve arayüzü TEKRAR KULLANILABİLİR yap.

        ``btn_load``/``btn_connect`` buraya SONRADAN eklendi: bir işi
        başlatan kod bu butonları kapatıyor, yalnızca BAŞARI işleyicisi
        geri açıyordu. İşçi hata verdiğinde butonlar kalıcı olarak kapalı
        kalıyordu. Outlook bağlantısının başarısız olması beklenen bir
        durumdur (Outlook kapalı) ve tam o anda "Bağlan" butonu ölüyordu:
        kullanıcı uygulamayı yeniden başlatmadan tekrar deneyemiyordu.
        """
        self._work_done()
        self._set_buttons_enabled(True)
        self._set_send_buttons_enabled(True)
        self.btn_load.setEnabled(True)
        self.btn_connect.setEnabled(True)
        self._busy("Hata oluştu.", 0)
        QMessageBox.critical(self, "Hata", message)

    def _send_packages(self) -> None:
        """Üretilmiş paketleri firma başına TEK mail olarak gönderir."""
        if self._reject_if_busy("Gönder"):
            return
        if not self._packages:
            QMessageBox.warning(self, "Gönder", "Önce paketleri üretin.")
            return
        if not self._outlook:
            QMessageBox.warning(self, "Outlook", "Önce Outlook'a bağlanın.")
            return

        period = self._period()
        if period is None:
            return

        ready = [p for p in self._packages if p.sendable]
        if not ready:
            QMessageBox.warning(
                self, "Gönder",
                "Gönderilebilecek mail yok.\n"
                + _reason_summary(p.block_reason for p in self._packages
                                  if not p.sendable))
            return

        # Bu dönemde zaten gönderilmiş firmalar: mükerrer mutabakat mektubu
        # karşı tarafta karışıklık yaratır ve geri alınamaz.
        donem = period_key(period.year, period.month)
        # SENT ∪ SEND_UNKNOWN: sonucu belirsiz kalan gönderim tekrar
        # denenmez — mail gitmiş olabilir ve mükerrer mektup geri alınamaz.
        gonderilmis = self._mail_log.no_resend_codes(donem)
        yeni = [p for p in ready if p.company_code not in gonderilmis]
        tekrar = len(ready) - len(yeni)

        if not yeni:
            QMessageBox.information(
                self, "Gönder",
                f"{donem} dönemindeki {len(ready)} firmanın hepsine daha önce "
                "mail gönderilmiş. Tekrar gönderilmedi.")
            return

        engellenen = [p for p in self._packages if not p.sendable]
        attach = sum(p.attachment_count for p in yeni)
        # Bilgi satırları (yalnız sıfırdan büyükse): insan kararı bekleyen
        # belirsiz gönderimler GÖNDERİLMEZ; yeniden gönderime açılmış olanlar
        # bu gönderimde GİDER. Okunamazsa mesaj eskisi gibi kalır.
        ek_satir = ""
        try:
            from app.services import send_unknown_resolution as _sur

            bekleyen = len({c.company_code for c in
                            _sur.list_unresolved(self._mail_log, donem)})
            acilan = len({p.company_code for p in yeni}
                         & set(_sur.list_reopened(self._mail_log, donem)))
            if bekleyen:
                ek_satir += ("Belirsiz sonuçlu (insan kararı bekliyor, "
                             f"GÖNDERİLMEYECEK): {bekleyen}\n")
            if acilan:
                ek_satir += ("Yeniden gönderime açılmış (bu gönderimde "
                             f"GİDECEK): {acilan}\n")
        except Exception as exc:  # noqa: BLE001 - yalnız bilgi satırı
            from loguru import logger

            logger.debug(f"[gönderim] belirsiz özeti okunamadı: {exc}")
        msg = (f"Dönem: {donem}\n"
               f"Gönderilecek mail: {len(yeni)}\n"
               f"Toplam ek: {attach}\n"
               f"Daha önce gönderilmiş (atlanacak): {tekrar}\n"
               f"Üretimde engellenen firma: {len(engellenen)}\n"
               + ek_satir
               + _reason_summary(p.block_reason for p in engellenen)
               + "\nİlk mail önizleme olarak açılıyor (ekleriyle birlikte).\n"
               "Göndermek istiyor musunuz?")

        # Önizleme ARKA PLANDA açılır; onay penceresi önizleme geldikten
        # sonra gösterilir. Böylece Outlook yavaşsa bile ekran donmaz.
        self._set_buttons_enabled(False)
        self._pending_msg = msg
        self._pending_send = lambda: self._start_work(
            PackageSendWorker(ready, period=period, mail_log=self._mail_log,
                              snapshot_store=self._snapshots,
                              fbl1h_path=self._fbl1h_path or None,
                              fbl5h_path=self._fbl5h_path or None,
                              outgoing_smtp=self._outgoing_smtp()),
            self._on_packages_sent)
        self._busy("Önizleme açılıyor…", 10)
        self._start_work(MailPreviewWorker(yeni[0].draft),
                         self._on_preview_ready)

    def _on_packages_sent(self, result) -> None:
        self._work_done()
        sent, skipped = result
        self._set_buttons_enabled(True)
        self._busy(f"Gönderildi: {sent} · Atlanan: {len(skipped)}", 100)
        detail = f"Gönderilen: {sent}\nAtlanan: {len(skipped)}"
        if skipped:
            detail += "\n\n" + "\n".join(skipped[:20])
        QMessageBox.information(self, "Sonuç", detail)


def _fmt(v) -> str:
    if v is None:
        return ""
    from decimal import Decimal

    from app.mailing.mail_builder import fmt_amount_tr
    return fmt_amount_tr(v) if v != Decimal("0") else "0,00"
