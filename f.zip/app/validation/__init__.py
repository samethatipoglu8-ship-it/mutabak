"""Bağımsız (independent) doğrulama paketi.

Bu paket, ``app.core.reconciler.Reconciler``'ın ÜRETTİĞİ bir
``ReconciliationResult``'ı SONRADAN, salt-okunur biçimde denetler.

Kesin kural: bu paket Reconciler'ı ASLA import etmez / çağırmaz, eşleşme
üretmez, aday seçmez, sonucu değiştirmez. Yalnızca inceler ve rapor eder.
Bkz. ``independent_validator.py`` modül docstring'i.
"""

from app.validation.independent_validator import (
    Finding,
    ValidationCode,
    ValidationReport,
    ValidationSeverity,
    validate_reconciliation_result,
)

__all__ = [
    "Finding",
    "ValidationCode",
    "ValidationReport",
    "ValidationSeverity",
    "validate_reconciliation_result",
]
