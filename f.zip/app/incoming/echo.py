"""Geri dönen KENDİ eklerimizin tespiti (echo).

SORUN
    Firma cevap verdiğinde Outlook, orijinal maildeki ekleri çoğu zaman
    cevaba geri ekler. Sınıflandırıcı dosyayı içeriğine göre değerlendirdiği
    için bizim kendi mutabakat mektubumuz da ``LETTER`` olarak tanınır — ve
    mektup değerlendirmesi onu "doldurulmuş" bulur, çünkü dört doldurulmuşluk
    sinyalini (firma kodu, bakiye, tarih, şirket eki) ZATEN BİZ yazdık.

    Ölçülen sonuç: kendi ürettiğimiz mektup geri geldiğinde

        kind=LETTER  güven=1.0  filled=True  signed=False  sealed=False

    Yani firma hiç dokunmadığı bir belge için sistem "mektup var ve dolu"
    diyordu; üstelik üç alan da belirlendiği için HİÇBİR belirsizlik uyarısı
    tetiklenmiyor ve kapsama skoru yükseliyordu. Nihai "mutabık" kararı
    güvendeydi (ekstre gelmediyse ``NO_STATEMENT`` kapısı tutuyor), ama
    "kaç firmadan mektup döndü" sayımı ve vakanın güveni YANLIŞTI.

ÇÖZÜM
    Gönderdiğimiz her ekin SHA-256'sı gönderim snapshot'ında (``AttachmentMeta``)
    ZATEN saklanıyor. Gelen ekin hash'i bu listeyle karşılaştırılır; birebir
    aynıysa ek ``ECHO`` olarak işaretlenir ve mektup/ekstre akışına hiç girmez.

    Deterministiktir: AI gerektirmez, sözlük/eşik yoktur, yalnız bayt kimliği.

NE YAPMAZ — BİLEREK
    Firma mektubu YAZDIRIP İMZALAYIP TARADIYSA dosya bayt bayt farklıdır ve
    echo SAYILMAZ. Bu doğru davranıştır: o artık firmanın belgesidir. Benzer
    şekilde firma bizim Excel'i açıp tek hücre değiştirse hash değişir ve ek
    normal akışta işlenir. Yani bu kontrol YANLIŞ POZİTİF üretemez; yalnızca
    "hiç dokunulmamış, aynen geri gelmiş" dosyayı ayıklar.
"""

from __future__ import annotations

from typing import Iterable, Optional

from app.incoming.models import AttachmentKind, IncomingAttachment

#: Ek neden değerlendirilmedi — denetim izinde ve arayüzde görünür.
ECHO_REASON = "bizim gönderdiğimiz dosyanın birebir kopyası (geri dönmüş ek)"


def _digest(attachment: IncomingAttachment) -> str:
    """Ekin içerik SHA-256'sı.

    ``IncomingAttachment.sha256`` bir property'dir ve içerikten hesaplar.
    İÇERİK YOKSA dosya ADINI hash'ler — o değer hiçbir gerçek dosya hash'iyle
    eşleşemeyeceği için yanlış pozitif üretmez; yine de niyeti açık tutmak
    için içeriksiz ek burada elenir.
    """
    if not getattr(attachment, "content", None):
        return ""
    return str(getattr(attachment, "sha256", "") or "").strip().lower()


def normalise_sent_hashes(hashes: Optional[Iterable[str]]) -> frozenset[str]:
    """Gönderilen ek hash'lerini karşılaştırmaya hazır hâle getir."""
    if not hashes:
        return frozenset()
    return frozenset(
        str(h).strip().lower() for h in hashes if str(h or "").strip())


def mark_echo_attachments(
    attachments: Optional[Iterable[IncomingAttachment]],
    sent_hashes: Optional[Iterable[str]],
) -> int:
    """Gönderdiğimizle BİREBİR aynı olan ekleri ``ECHO`` olarak işaretle.

    ``classify`` ÖNCESİNDE ya da SONRASINDA çağrılabilir: türü koşulsuz
    ezer, çünkü bayt kimliği içerik sezgisinden daha güçlü bir kanıttır.

    Döner: işaretlenen ek sayısı. Hash listesi boşsa hiçbir şey yapılmaz —
    snapshot bulunamadığında davranış eskisiyle AYNI kalır (sessiz bir
    kötüleşme yoktur, yalnızca iyileştirme uygulanmaz).
    """
    hedef = normalise_sent_hashes(sent_hashes)
    if not hedef or not attachments:
        return 0

    sayi = 0
    for attachment in attachments:
        if attachment is None:
            continue
        if attachment.kind is AttachmentKind.ECHO:
            continue                       # zaten işaretli (idempotent)
        if _digest(attachment) not in hedef:
            continue
        attachment.kind = AttachmentKind.ECHO
        attachment.kind_confidence = 1.0   # bayt kimliği — tartışma yok
        attachment.kind_reason = ECHO_REASON
        sayi += 1
    return sayi


def sent_hashes_of(snapshot: object) -> frozenset[str]:
    """Bir gönderim snapshot'ındaki ek hash'lerini topla.

    Snapshot ``None`` ya da beklenen yapıda değilse BOŞ küme döner; çağıran
    taraf o durumda eski davranışı sürdürür.
    """
    ekler = getattr(snapshot, "attachments", None) or ()
    return normalise_sent_hashes(
        str(getattr(a, "sha256", "") or "") for a in ekler)
