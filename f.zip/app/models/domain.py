"""Domain models for the TOFAŞ reconciliation engine."""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from enum import Enum
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class Side(str, Enum):
    TOFAS = "TOFAS"
    FIRMA = "FIRMA"


class MatchStatus(str, Enum):
    MATCHED = "MATCHED"                 # Yeşil: referans+tutar tuttu
    AMOUNT_DIFF = "AMOUNT_DIFF"        # Sarı: referans tuttu, tutar (tam kısım) farklı
    ONLY_FIRMA = "ONLY_FIRMA"          # Kırmızı: firmada var, TOFAŞ'ta yok
    ONLY_TOFAS = "ONLY_TOFAS"          # Mavi: TOFAŞ'ta var, firmada yok
    CROSS_MATCHED = "CROSS_MATCHED"    # Mor: bire-çok (bir taraf tek, diğer taraf toplamı)
    CURRENCY_DIFF = "CURRENCY_DIFF"    # Turuncu: aynı fatura no, FARKLI para birimi
    #: FAZ 4 (P0 güvenlik kapısı, docs/claude-audit/17) — her iki tarafta da
    #: VERİFİYE EDİLMİŞ kimlik (bugün: ``tax_id``) var VE bunlar FARKLI.
    #: EŞLEŞME DEĞİLDİR; ``matched``'e asla sessizce girmez.
    IDENTITY_CONFLICT = "IDENTITY_CONFLICT"
    #: FAZ 4 (P0 güvenlik kapısı) — aynı referans için rekabet eden
    #: adaylardan biri GÜVENLE (row_classifier anahtar kelime eşleşmesiyle)
    #: çelişen bir ekonomik olay türü taşıyor (örn. biri fatura, biri
    #: iade/avans). İnsan incelemesi gerekir; otomatik eşleşme YAPILMAZ.
    ECONOMIC_EVENT_REVIEW = "ECONOMIC_EVENT_REVIEW"


class MatchRule(str, Enum):
    REFERENCE_EXACT = "REFERENCE_EXACT"        # birebir referans
    REFERENCE_FUZZY = "REFERENCE_FUZZY"        # baştaki 0 / ayraç farkı
    AMOUNT_DATE = "AMOUNT_DATE"                # referans tutmadı, tutar+tarih tuttu
    CROSS_SUBSET_REF = "CROSS_SUBSET_REF"      # bire-çok, referans-bağlı alt-küme toplamı
    CROSS_SUBSET_DATE = "CROSS_SUBSET_DATE"    # bire-çok, tarih-pencereli alt-küme toplamı
    #: Referans tuttu ama iki taraf FARKLI para birimi bildirdi. Bu bir
    #: EŞLEŞME DEĞİLDİR: tutarlar karşılaştırılmaz, kalem mutabık sayılmaz.
    #: Yalnızca "aynı fatura iki tarafta da var, para birimi çelişiyor"
    #: bilgisini taşır ki muhasebeci bunu "eksik fatura" sanmasın.
    REFERENCE_CURRENCY_CONFLICT = "REFERENCE_CURRENCY_CONFLICT"
    #: FAZ 4 — bkz. MatchStatus.IDENTITY_CONFLICT.
    IDENTITY_CONFLICT = "IDENTITY_CONFLICT"
    #: FAZ 4 — bkz. MatchStatus.ECONOMIC_EVENT_REVIEW.
    ECONOMIC_EVENT_CONFLICT = "ECONOMIC_EVENT_CONFLICT"
    NONE = "NONE"


class TofasRecord(BaseModel):
    """One normalized line from the TOFAŞ SAP export."""

    model_config = ConfigDict(frozen=False)

    row_index: int
    fiscal_year: Optional[str] = None
    main_account: Optional[str] = None          # 320* / 323*
    firma_kodu: Optional[str] = None
    satici_ad: Optional[str] = None
    reference: Optional[str] = None             # normalized primary
    reference_raw: Optional[str] = None
    all_references: list[str] = Field(default_factory=list)
    belge_turu: Optional[str] = None            # document type (VKOA-like filter)
    belge_tarihi: Optional[date] = None         # invoice date
    kayit_tarihi: Optional[date] = None
    giris_tarihi: Optional[date] = None
    net_vade: Optional[date] = None
    amount: Decimal = Decimal("0")              # Blg.PB değeri (signed)
    currency: Optional[str] = None
    metin: Optional[str] = None
    # FAZ 4 (P0 güvenlik kapısı) — VERİFİYE EDİLMİŞ karşı-taraf kimliği
    # (VKN/TCKN veya onaylı bir crosswalk). BİLEREK hiçbir yükleyici bunu
    # DOLDURMAZ (docs/claude-audit/17 §3: firma_kodu/account kör biçimde
    # VKN/TCKN sayılamaz) — bu alan, o gerçek kimlik hattı inşa edilene
    # kadar dormant (etkisiz) kalır; mevcut hiçbir gerçek dosya bunu
    # tetiklemez.
    tax_id: Optional[str] = None

    # FAZ 5 (docs/claude-audit/19) — DORMANT plumbing, Canonical Model v2
    # hazırlığı. Hiçbir yükleyici (``TofasLoader``, ``company_statement_
    # service.py``) bu alanları DOLDURMAZ; ``Reconciler`` hiçbiri OKUMAZ.
    # Üretim matching semantiği bu alanların varlığından BAĞIMSIZDIR —
    # değer her zaman ``None``'dur ve mevcut hiçbir gerçek dosyada hiçbir
    # davranışı değiştirmez. Her birinin "ne zaman doldurulabilir" sorusu
    # doc 19 §11'de (field gap matrisi) ayrı ayrı sınıflandırılmıştır.
    source_profile: Optional[str] = None        # ör. "SAP_FBL1H" (henüz atanmıyor)
    document_currency: Optional[str] = None     # belge/işlem dövizi (WRBTR tabanı)
    local_currency: Optional[str] = None        # yerel/şirket kodu dövizi (DMBTR tabanı)
    local_currency_amount: Optional[Decimal] = None
    gross_amount: Optional[Decimal] = None
    net_amount: Optional[Decimal] = None
    withholding_amount: Optional[Decimal] = None
    is_advance: Optional[bool] = None
    special_gl_indicator: Optional[str] = None  # SAP Özel G/L göstergesi (UMSKZ)
    source_sign_convention: Optional[str] = None  # finans onaylı kaynak-bazlı işaret yönü

    # -- provenance (Bu değer nereden geldi?) --------------------------------
    source_file: Optional[str] = None
    source_row: Optional[int] = None
    extraction_method: Optional[str] = None     # ör. "deterministic_tabular"


class FirmaRecord(BaseModel):
    """One normalized line from the supplier (firma) statement."""

    model_config = ConfigDict(frozen=False)

    row_index: int
    account: Optional[str] = None
    name: Optional[str] = None
    reference: Optional[str] = None             # normalized primary invoice no
    reference_raw: Optional[str] = None
    all_references: list[str] = Field(default_factory=list)
    inv_date: Optional[date] = None
    due_date: Optional[date] = None
    amount: Decimal = Decimal("0")              # signed
    currency: Optional[str] = None              # para birimi (varsa)
    comment: Optional[str] = None
    # FAZ 4 (P0 güvenlik kapısı) — VERİFİYE EDİLMİŞ karşı-taraf kimliği
    # (VKN/TCKN veya onaylı bir crosswalk). BİLEREK hiçbir yükleyici bunu
    # DOLDURMAZ (bkz. TofasRecord.tax_id açıklaması) — dormant alan.
    tax_id: Optional[str] = None

    # FAZ 5 (docs/claude-audit/19) — DORMANT plumbing; bkz. TofasRecord'daki
    # aynı blok açıklaması. Hiçbir yükleyici (``FirmaLoader``) doldurmaz;
    # ``Reconciler`` okumaz; mevcut davranış bu alanların varlığından
    # bağımsızdır.
    source_profile: Optional[str] = None
    document_currency: Optional[str] = None
    local_currency: Optional[str] = None
    local_currency_amount: Optional[Decimal] = None
    gross_amount: Optional[Decimal] = None
    net_amount: Optional[Decimal] = None
    withholding_amount: Optional[Decimal] = None
    is_advance: Optional[bool] = None
    special_gl_indicator: Optional[str] = None
    source_sign_convention: Optional[str] = None

    # -- provenance (Bu değer nereden geldi?) --------------------------------
    source_file: Optional[str] = None
    source_row: Optional[int] = None
    amount_source: Optional[str] = None         # "amount" | "debit-credit" | "balance"
    extraction_method: Optional[str] = None     # ör. "deterministic_tabular"


class MatchedPair(BaseModel):
    firma: FirmaRecord
    tofas: TofasRecord
    rule: MatchRule
    status: MatchStatus
    kurus_farki: Decimal = Decimal("0")         # cents difference note
    isaret_uyari: bool = False                  # signs not opposite -> warning
    # Taraflardan en az birinin para birimi bilinmiyordu; eşleşmeye izin verildi
    # ama sessizce değil — kullanıcı bu bayrağı Excel/UI'da görür.
    para_birimi_uyari: bool = False
    # FAZ 4 (P0 güvenlik kapısı) — bu eşleşme için BİRDEN FAZLA eşit-geçerli
    # aday vardı ve adaylar FARKLI bildirilmiş karşı taraf (firma_kodu/
    # account) taşıyordu. Seçim yine deterministiktir (davranış değişmedi);
    # bu bayrak sadece seçimi GÖRÜNÜR kılar (bkz. docs/claude-audit/17 §4
    # satır 5). Trivial/interchangeable duplicate adaylarda False kalır.
    ambiguous: bool = False
    ambiguous_reason: Optional[str] = None
    # identity_conflict/economic_event_review kovasına taşınan bir çift için
    # orijinal eşleştirme katmanı (izlenebilirlik — doc 17 §F). Normal
    # ``matched``/``amount_mismatch`` çiftlerinde kullanılmaz (None kalır).
    original_rule: Optional[MatchRule] = None

    @property
    def abs_difference(self) -> Decimal:
        return (self.firma.amount.copy_abs() - self.tofas.amount.copy_abs()).copy_abs()


class CrossMatch(BaseModel):
    """Bire-çok (one-to-many) eşleşme: bir taraftaki TEK satır, diğer taraftaki
    BİRDEN ÇOK satırın |tutar| toplamına (kuruş toleransında) eşit.

    ``single_side`` tek-satırın hangi tarafta olduğunu söyler:
      - Side.FIRMA  → one_firma tek; many_tofas = eşleşen TOFAŞ satırları.
      - Side.TOFAS  → one_tofas tek; many_firma = eşleşen firma satırları.
    """

    single_side: Side
    one_firma: Optional[FirmaRecord] = None
    one_tofas: Optional[TofasRecord] = None
    many_firma: list[FirmaRecord] = Field(default_factory=list)
    many_tofas: list[TofasRecord] = Field(default_factory=list)
    rule: MatchRule = MatchRule.CROSS_SUBSET_REF
    status: MatchStatus = MatchStatus.CROSS_MATCHED
    total_one: Decimal = Decimal("0")     # tek tarafın |tutarı|
    total_many: Decimal = Decimal("0")    # çok tarafın |tutar| toplamı
    kurus_farki: Decimal = Decimal("0")
    para_birimi_uyari: bool = False       # en az bir tarafın para birimi bilinmiyor
    score: int = 0                        # global seçimde kullanılan aday skoru


class Summary(BaseModel):
    total_firma: int = 0
    total_tofas: int = 0
    matched: int = 0
    amount_diff: int = 0
    cross_matched: int = 0                            # bire-çok eşleşme grubu sayısı
    only_firma: int = 0
    only_tofas: int = 0
    #: Aynı fatura no iki tarafta da var ama para birimleri çelişiyor.
    #: EŞLEŞME SAYILMAZ; ayrı raporlanır ki "eksik fatura" ile karışmasın.
    currency_diff: int = 0
    #: FAZ 4 (P0 güvenlik kapısı) — doğrulanmış kimlik çelişkisi nedeniyle
    #: BLOCK edilen çift sayısı (bkz. MatchStatus.IDENTITY_CONFLICT).
    identity_conflict: int = 0
    #: FAZ 4 — doğrulanmış ekonomik olay çelişkisi nedeniyle REVIEW'a
    #: taşınan çift sayısı (bkz. MatchStatus.ECONOMIC_EVENT_REVIEW).
    economic_event_review: int = 0
    #: FAZ 4 — ``matched`` içinde kalıp ``ambiguous=True`` işaretli çift
    #: sayısı (bilgi amaçlı; bu çiftler hâlâ matched'dedir, ayrı sayılmaz).
    ambiguous_matches: int = 0

    firma_diptoplam: Decimal = Decimal("0")          # our sum of firma amounts
    tofas_diptoplam_hesap: Decimal = Decimal("0")    # our sum of TOFAŞ amounts
    tofas_diptoplam_sap: Optional[Decimal] = None    # yellow-row total from SAP
    diptoplam_uyari: Optional[str] = None            # set if SAP != our sum
    fark: Decimal = Decimal("0")                      # |firma| - |tofas| totals
    run_id: Optional[str] = None                      # audit trail RUN-ID
    # Sonucun nasıl üretildiğini tek başına anlatan parametreler (Excel özetine
    # ve audit'e yazılır): tolerans değerleri, kural sürümü, girdi hash'leri...
    parameters: dict[str, str] = Field(default_factory=dict)


class ReconciliationResult(BaseModel):
    matched: list[MatchedPair] = Field(default_factory=list)
    amount_mismatch: list[MatchedPair] = Field(default_factory=list)
    cross_matches: list[CrossMatch] = Field(default_factory=list)
    #: Aynı fatura no, FARKLI para birimi. Mutabık DEĞİLDİR — bu liste
    #: ``matched``/``amount_mismatch`` ile aynı anlamı taşımaz; kalem
    #: incelenmek üzere ayrı tutulur.
    currency_diff: list[MatchedPair] = Field(default_factory=list)
    #: FAZ 4 (P0 güvenlik kapısı) — bkz. MatchStatus.IDENTITY_CONFLICT.
    #: Mutabık SAYILMAZ; ``matched``/``only_*``'a asla sessizce düşmez.
    identity_conflict: list[MatchedPair] = Field(default_factory=list)
    #: FAZ 4 — bkz. MatchStatus.ECONOMIC_EVENT_REVIEW. İnsan incelemesi
    #: gerekir; ``matched``/``amount_mismatch``'e asla sessizce düşmez.
    economic_event_review: list[MatchedPair] = Field(default_factory=list)
    only_firma: list[FirmaRecord] = Field(default_factory=list)
    only_tofas: list[TofasRecord] = Field(default_factory=list)
    summary: Summary = Field(default_factory=Summary)
    excluded_belge_turu: list[str] = Field(default_factory=list)
    # Girdi dosyalarının veri kalitesi bulguları (WARNING ve üstü).
    data_quality: list[str] = Field(default_factory=list)
