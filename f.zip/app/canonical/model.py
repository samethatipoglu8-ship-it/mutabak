"""Canonical Financial Model — the source-agnostic integration boundary.

Every input (Excel/CSV via loader.py, native/scanned PDF, PNG, UBL/XML, ERP
API) is converted into ``ReconciliationRecord``. The reconciliation engine can
then be driven from canonical records without knowing the origin.

IMPORTANT — source-of-truth policy: the existing V4 domain models
(``app.models.domain`` : ``TofasRecord`` / ``FirmaRecord`` / ``MatchStatus`` …)
remain authoritative for the *working application and its reconciliation
behaviour*. This canonical model is an **additive** representation that those
records adapt into and back out of losslessly (see ``app.canonical.adapters``).
It never replaces them; it generalises them.

Financial amounts use ``Decimal``. Never use ``float`` for money.
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from enum import Enum
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field

from .evidence import FieldEvidence


class DocumentType(str, Enum):
    ACCOUNT_STATEMENT = "account_statement"   # cari hesap ekstresi
    INVOICE = "invoice"
    PAYMENT = "payment"
    CREDIT_NOTE = "credit_note"
    DEBIT_NOTE = "debit_note"
    OTHER = "other"


class RecordSide(str, Enum):
    """Which party's books a record belongs to.

    Mapped from V4's ``Side``: TOFAS -> OURS, FIRMA -> COUNTERPARTY.
    """

    OURS = "ours"                 # our books (V4: TOFAŞ / SAP side)
    COUNTERPARTY = "counterparty" # the other party (V4: firma / supplier side)


class CanonicalMatchStatus(str, Enum):
    """Generic, engine-facing match status.

    Distinct from V4's richer, colour-coded ``MatchStatus``
    (MATCHED / AMOUNT_DIFF / ONLY_FIRMA / ONLY_TOFAS). The adapter maps V4 ->
    canonical: MATCHED->MATCHED, AMOUNT_DIFF->REVIEW, ONLY_*->UNMATCHED.
    """

    MATCHED = "MATCHED"
    REVIEW = "REVIEW"
    UNMATCHED = "UNMATCHED"


class ReconciliationRecord(BaseModel):
    """A single canonical financial line, source-agnostic."""

    record_id: str = Field(default_factory=lambda: uuid4().hex)
    side: RecordSide | None = None

    company_id: str | None = None
    counterparty_id: str | None = None

    document_number: str | None = None
    # Multiple candidate reference values (V4 supports all_references).
    reference_candidates: list[str] = Field(default_factory=list)

    document_date: date | None = None
    due_date: date | None = None

    amount: Decimal | None = None
    currency: str | None = None

    debit: Decimal | None = None
    credit: Decimal | None = None

    account_code: str | None = None
    document_type: DocumentType | None = None
    description: str | None = None

    # provenance (denormalised) -------------------------------------------
    source_file: str | None = None
    source_page: int | None = None
    source_row: int | None = None

    extraction_method: str | None = None
    extraction_confidence: float | None = Field(default=None, ge=0.0, le=1.0)

    # Full per-field evidence, keyed by field name.
    evidence: dict[str, FieldEvidence] = Field(default_factory=dict)

    # Source-specific fields the adapter preserves for a lossless round trip
    # (e.g. V4 belge_turu, main_account, kayit_tarihi). Keeps the canonical
    # model clean while never dropping origin-specific data.
    source_fields: dict[str, Any] = Field(default_factory=dict)

    def signed_amount(self) -> Decimal | None:
        """Single signed amount; prefer ``amount``, else debit - credit."""
        if self.amount is not None:
            return self.amount
        if self.debit is not None or self.credit is not None:
            return (self.debit or Decimal("0")) - (self.credit or Decimal("0"))
        return None
