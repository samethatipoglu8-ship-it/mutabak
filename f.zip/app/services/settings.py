"""Persistent settings.

Stores the excluded belge türü selection and UI preferences so they survive
across runs until the user changes them (per spec: the selection persists
until explicitly changed). Uses a small JSON file in the user's config dir.
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any

from loguru import logger

from app.utils.file_lock import exclusive_file_lock
from app.utils.paths import app_data_dir


class Settings:
    """Simple JSON-backed settings store."""

    def __init__(self, path: str | Path | None = None) -> None:
        if path is None:
            base = app_data_dir()
            base.mkdir(parents=True, exist_ok=True)
            path = base / "settings.json"
        self._path = Path(path)
        self._data: dict[str, Any] = self._load()
        self._dirty: set[str] = set()
        self._last_error: str = ""

    def _load(self) -> dict[str, Any]:
        if self._path.exists():
            try:
                return json.loads(self._path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError) as exc:
                logger.warning(f"[ayar] ayarlar okunamadı ({exc}); boş başlanıyor.")
                return {}
        return {}

    def _save(self) -> None:
        if not self._dirty:
            return
        temp_name = ""
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            with exclusive_file_lock(self._path.with_suffix(".lock")):
                disk = self._load()
                for key in self._dirty:
                    disk[key] = self._data[key]
                handle, temp_name = tempfile.mkstemp(
                    dir=str(self._path.parent), prefix=".settings-", suffix=".tmp")
                with os.fdopen(handle, "w", encoding="utf-8") as stream:
                    json.dump(disk, stream, ensure_ascii=False, indent=2)
                os.replace(temp_name, self._path)
                self._data = disk
                self._dirty.clear()
                self._last_error = ""
        except (OSError, TimeoutError) as exc:
            logger.warning(f"[ayar] ayarlar yazılamadı: {exc}")
            self._last_error = str(exc)
            if temp_name:
                try:
                    Path(temp_name).unlink(missing_ok=True)
                except OSError:
                    pass

    @property
    def last_error(self) -> str:
        """Son ``_save()`` denemesinde oluşan hata metni (boşsa son yazım başarılı)."""
        return self._last_error

    # -- typed accessors ----------------------------------------------------

    @property
    def excluded_belge_turu(self) -> list[str]:
        return list(self._data.get("excluded_belge_turu", []))

    @excluded_belge_turu.setter
    def excluded_belge_turu(self, values: list[str]) -> None:
        self._data["excluded_belge_turu"] = sorted({str(v).strip() for v in values})
        self._dirty.add("excluded_belge_turu")
        self._save()

    @property
    def theme(self) -> str:
        return self._data.get("theme", "dark")

    @theme.setter
    def theme(self, value: str) -> None:
        self._data["theme"] = value
        self._dirty.add("theme")
        self._save()

    @property
    def company_name(self) -> str:
        return self._data.get("company_name", "")

    @company_name.setter
    def company_name(self, value: str) -> None:
        self._data["company_name"] = value
        self._dirty.add("company_name")
        self._save()

    @property
    def incoming_mailbox_smtp(self) -> str:
        """Kontrollü gelen-kutusu hesabının SMTP adresi.

        Doluysa gelen mail okuma, StoreID/FolderEntryID'yi HİÇ saklamadan,
        bu adrese sahip Outlook hesabının gerçek Gelen Kutusu'nu HER
        ÇAĞRIDA yeniden çözer (bkz. ``app.incoming.mailbox_resolver``).
        Boşsa (varsayılan) bugünkü davranış — varsayılan Outlook mağazası —
        değişmeden kalır.
        """
        return self._data.get("incoming_mailbox_smtp", "")

    @incoming_mailbox_smtp.setter
    def incoming_mailbox_smtp(self, value: str) -> None:
        self._data["incoming_mailbox_smtp"] = (value or "").strip()
        self._dirty.add("incoming_mailbox_smtp")
        self._save()

    @property
    def outgoing_mailbox_smtp(self) -> str:
        """Kurumsal GİDEN posta kutusunun SMTP adresi.

        Gerçek gönderim (toplu mutabakat ve Reply-All) yalnız bu adrese sahip
        Outlook ``Account`` üzerinden çıkar (bkz. ``outlook_client``). Boşsa
        gerçek gönderim ENGELLENİR; varsayılan/kişisel hesaba düşülmez.
        """
        return str(self._data.get("outgoing_mailbox_smtp", "") or "").strip()

    @outgoing_mailbox_smtp.setter
    def outgoing_mailbox_smtp(self, value: str) -> None:
        self._data["outgoing_mailbox_smtp"] = (value or "").strip()
        self._dirty.add("outgoing_mailbox_smtp")
        self._save()

    @property
    def default_folder(self) -> str:
        return self._data.get("default_folder", str(Path.home()))

    @default_folder.setter
    def default_folder(self, value: str) -> None:
        self._data["default_folder"] = value
        self._dirty.add("default_folder")
        self._save()

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        self._data[key] = value
        self._dirty.add(key)
        self._save()
