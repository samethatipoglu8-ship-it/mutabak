"""Yüklenen dosya gerçekten bir EKSTRE mi, yoksa başka bir belge mi?

NEDEN GEREKLİ
    393 gerçek dosyalık örnek sette, okunamayan PDF'lerin önemli bir kısmı
    aslında ekstre DEĞİLDİ: tekil fatura ("Facture", "Invoice"), sipariş
    formu ("ORDER DATA"), irsaliye/CMR. Motorun bunları reddetmesi DOĞRU
    davranıştır — ortada kalem listesi yoktur.

    Sorun mesajdaydı: kullanıcı "gerekli kolonlar bulunamadı (Referans /
    Fatura no)" uyarısını görüp olmayan bir kolon eşleme sorununu arıyordu.
    Oysa yapması gereken tek şey doğru dosyayı yüklemek.

TASARIM İLKESİ — SONUCU ASLA DEĞİŞTİRMEZ
    Bu modül YALNIZCA hata yolunda, dosya zaten reddedilmişken çağrılır ve
    yalnızca AÇIKLAMA metnini zenginleştirir. Hiçbir dosyanın okunmasını
    engellemez, hiçbir dosyanın okunmasını sağlamaz, hiçbir finansal
    değeri etkilemez. Yanlış tahmin ederse en kötü ihtimalle mesaj
    yanıltıcı olur — veri bozulmaz.

    Salt sözlük eşleşmesi; AI yok, tahmin yok, deterministik.
"""

from __future__ import annotations

from typing import Iterable, Optional

#: Belge türü kodları
STATEMENT = "STATEMENT"          # cari ekstre / muavin — beklenen dosya
INVOICE = "INVOICE"              # tekil fatura
ORDER = "ORDER"                  # sipariş formu / sipariş onayı
DELIVERY = "DELIVERY"            # irsaliye / sevk / CMR
UNKNOWN = ""

#: Türe özgü, GÜÇLÜ ipuçları. Bir ekstrede olağan olarak GEÇMEYEN
#: ifadeler seçilmiştir; "fatura" gibi tek başına ekstre satırlarında da
#: geçebilen kelimeler BİLEREK listede yoktur.
_IPUCLARI: dict[str, tuple[str, ...]] = {
    INVOICE: (
        "facture", "fattura", "rechnung", "factura",
        "invoice no", "invoice number", "invoice date", "tax invoice",
        "fatura no", "fatura tarihi", "e-arsiv", "e-arşiv",
        "vat amount", "vat value", "net amount", "total due",
        "ettu", "irsaliye yerine",
    ),
    ORDER: (
        "order data", "order form", "purchase order", "order confirmation",
        "siparis onayi", "sipariş onayı", "siparis formu", "sipariş formu",
        "auftragsbestatigung", "bestellung", "buono d ordine",
    ),
    DELIVERY: (
        "delivery note", "packing list", "irsaliye", "sevk irsaliyesi",
        "lieferschein", "bordereau", "waybill", "consignment note",
    ),
}

#: Ekstre olduğunu gösteren ifadeler. Bunlar varsa belge türü tahmini
#: YAPILMAZ: karma dosyalarda (ekstre + fatura başlığı bir arada) yanlış
#: yönlendirme yapmaktansa susmak doğrudur.
_EKSTRE_IPUCLARI: tuple[str, ...] = (
    "ekstre", "hesap ozeti", "hesap özeti", "cari hareket", "muavin",
    "statement of account", "account statement", "kontoauszug",
    "estratto conto", "extrait de compte", "devreden", "nakli yekun",
    "nakli yekün", "acilis bakiye", "açılış bakiye", "borc", "borç",
    "alacak", "bakiye",
)


def _normalize(value: object) -> str:
    """Metni karşılaştırılabilir hâle getir (Türkçe duyarlı).

    DİKKAT — "İ" TUZAĞI
        Python'da ``"İ".lower()`` iki karakter üretir: ``i`` + birleşik
        nokta (U+0307). Bu yüzden Türkçe harf değişimleri küçük harfe
        çevirmeden ÖNCE yapılır; artakalan birleşik nokta da temizlenir.
        Aksi hâlde "İrsaliye" hiçbir zaman "irsaliye" ile eşleşmez.
    """
    if value is None:
        return ""
    text = str(value)
    for a, b in (("İ", "i"), ("I", "i"), ("Ş", "s"), ("Ç", "c"),
                 ("Ğ", "g"), ("Ö", "o"), ("Ü", "u"), ("Â", "a")):
        text = text.replace(a, b)
    text = text.lower()
    for a, b in (("ı", "i"), ("ş", "s"), ("ç", "c"),
                 ("ğ", "g"), ("ö", "o"), ("ü", "u"), ("â", "a"),
                 ("̇", "")):
        text = text.replace(a, b)
    return " ".join(text.split())


#: Belgenin türünü ilan ettiği "başlık bölgesi" (ilk N karakter).
#:
#: NEDEN GEREKLİ
#:     Bir FATURA, doğası gereği siparişe ve irsaliyeye ATIF yapar
#:     ("Bestellung: …", "Lieferschein: …"). Tüm metne bakınca üç tür de
#:     eşleşiyor, çelişki kuralı devreye giriyor ve hiçbir şey
#:     söylenemiyordu. Oysa belge türü neredeyse her zaman en üstte
#:     yazar ("FAKTURA VAT / RECHNUNG / INVOICE", "ORDER FORM").
_BASLIK_PENCERESI = 300


def _tek_eslesme(metin: str) -> str:
    """Metinde YALNIZCA bir tür eşleşiyorsa onu döndür, yoksa UNKNOWN."""
    bulunan = [tur for tur, ipuclari in _IPUCLARI.items()
               if any(ip in metin for ip in ipuclari)]
    return bulunan[0] if len(bulunan) == 1 else UNKNOWN


def detect_document_type(samples: Iterable[object]) -> str:
    """Örnek metinlerden belge türünü tahmin et; emin değilse ``UNKNOWN``.

    ``samples`` başlık satırı hücreleri, ilk veri satırları ve (PDF'lerde)
    sayfa metni olabilir. Önce belgenin BAŞLIK bölgesine bakılır; orası
    kesin değilse tüm metne bakılır. İki aşamada da birden çok tür
    eşleşirse ``UNKNOWN`` döner — çelişkili sinyalde susulur.
    """
    birlesik = " ".join(_normalize(s) for s in samples if s is not None)
    if not birlesik:
        return UNKNOWN

    # Ekstre sinyali varsa tür tahmini yapma (bkz. _EKSTRE_IPUCLARI).
    if any(ip in birlesik for ip in _EKSTRE_IPUCLARI):
        return UNKNOWN

    # 1) Belgenin kendini ilan ettiği bölge.
    tur = _tek_eslesme(birlesik[:_BASLIK_PENCERESI])
    if tur:
        return tur
    # 2) Tüm metin.
    return _tek_eslesme(birlesik)


#: Kullanıcıya gösterilecek açıklamalar.
_ACIKLAMA: dict[str, str] = {
    INVOICE: (
        "Bu dosya bir EKSTRE değil, tekil FATURA gibi görünüyor. "
        "Mutabakat için firmanın dönem ekstresi (cari hareket listesi) "
        "gerekir."
    ),
    ORDER: (
        "Bu dosya bir EKSTRE değil, SİPARİŞ belgesi gibi görünüyor. "
        "Mutabakat için firmanın dönem ekstresi gerekir."
    ),
    DELIVERY: (
        "Bu dosya bir EKSTRE değil, İRSALİYE / sevk belgesi gibi görünüyor. "
        "Mutabakat için firmanın dönem ekstresi gerekir."
    ),
}


def explain_document_type(doc_type: str) -> Optional[str]:
    """Tür için kullanıcı açıklaması; tür bilinmiyorsa ``None``."""
    return _ACIKLAMA.get(doc_type)
