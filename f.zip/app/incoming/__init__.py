"""Gelen mutabakat maili okuma / analiz hattı (Python-first, AI fallback).

Bu paket MEVCUT sisteme hiç dokunmadan üstüne eklenir:

    OutlookReader  →  IncomingMail  →  MailParser  →  (yetersizse) Copilot Studio
                                                              ↓
                                                   ReconciliationResponse

Ana ilke: Python okuyabiliyorsa AI ÇAĞRILMAZ. AI yalnızca deterministik
parser'ın çözemediği/emin olamadığı alanlar için devreye girer ve sonucu
Python tarafından doğrulanmadan hiçbir zaman doğrudan kabul edilmez.

İçe aktarımlar bilinçli olarak hafiftir: pdfplumber / openpyxl / requests /
PySide6 yalnızca gerçekten kullanıldıkları fonksiyonun içinde import edilir.
"""

from __future__ import annotations

from app.incoming.models import (
    AIAnalysisResult,
    AIReviewStatus,
    AttachmentKind,
    Direction,
    FieldConflict,
    IncomingAttachment,
    IncomingMail,
    ParsedMailResult,
    ReconciliationResponse,
    ReplyType,
)

__all__ = [
    "AIAnalysisResult",
    "AIReviewStatus",
    "AttachmentKind",
    "Direction",
    "FieldConflict",
    "IncomingAttachment",
    "IncomingMail",
    "ParsedMailResult",
    "ReconciliationResponse",
    "ReplyType",
]
