"""Teslim edilemeyen alıcıların kalıcı ve denetlenebilir kayıt defteri."""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from app.utils.paths import app_data_dir
from app.utils.sqlite import open_sqlite_connection


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass(frozen=True)
class AddressState:
    address: str
    status: str
    permanent: bool
    reason: str = ""
    company_code: str = ""
    failure_count: int = 0
    updated_at: str = ""

    @property
    def blocked(self) -> bool:
        return self.permanent or self.status == "UNUSED"


class AddressRegistry:
    """NDR sonrası aynı adrese yeni mail/reminder gitmesini engeller.

    Geçici 4.x hatalar kayıt altına alınır ama adresi kalıcı kapatmaz. Adres
    yalnız açık bir kullanıcı işlemiyle ``ACTIVE`` durumuna döndürülebilir.
    """

    def __init__(self, path: str | Path | None = None) -> None:
        if path is None:
            path = app_data_dir() / "address_registry.db"
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    @contextmanager
    def _session(self):
        conn = open_sqlite_connection(self.path)
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _ensure_schema(self) -> None:
        with self._session() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS address_states (
                    address TEXT PRIMARY KEY,
                    status TEXT NOT NULL,
                    permanent INTEGER NOT NULL DEFAULT 0,
                    reason TEXT NOT NULL DEFAULT '',
                    company_code TEXT NOT NULL DEFAULT '',
                    failure_count INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL
                )
            """)

    @staticmethod
    def normalize(address: str) -> str:
        return (address or "").strip().strip("<>").lower()

    def record_failure(self, address: str, *, permanent: bool,
                       reason: str = "", company_code: str = "") -> AddressState:
        key = self.normalize(address)
        if not key or "@" not in key:
            raise ValueError("Geçerli bir e-posta adresi gerekli.")
        status = "INVALID" if permanent else "TEMPORARY_FAILURE"
        with self._session() as conn:
            conn.execute("""
                INSERT INTO address_states
                    (address,status,permanent,reason,company_code,failure_count,updated_at)
                VALUES (?,?,?,?,?,1,?)
                ON CONFLICT(address) DO UPDATE SET
                    status=excluded.status,
                    permanent=MAX(address_states.permanent, excluded.permanent),
                    reason=excluded.reason,
                    company_code=CASE WHEN excluded.company_code<>''
                                      THEN excluded.company_code
                                      ELSE address_states.company_code END,
                    failure_count=address_states.failure_count+1,
                    updated_at=excluded.updated_at
            """, (key, status, int(permanent), reason[:500],
                    company_code, _now()))
        return self.get(key)  # type: ignore[return-value]

    def mark_unused(self, address: str, *, reason: str,
                    company_code: str = "") -> AddressState:
        state = self.record_failure(address, permanent=True, reason=reason,
                                    company_code=company_code)
        with self._session() as conn:
            conn.execute("UPDATE address_states SET status='UNUSED' WHERE address=?",
                         (state.address,))
        return self.get(state.address)  # type: ignore[return-value]

    def reactivate(self, address: str, *, reason: str) -> AddressState:
        if not (reason or "").strip():
            raise ValueError("Adresi yeniden etkinleştirmek için gerekçe zorunludur.")
        key = self.normalize(address)
        with self._session() as conn:
            cur = conn.execute("""
                UPDATE address_states SET status='ACTIVE', permanent=0,
                    reason=?, updated_at=? WHERE address=?
            """, (reason[:500], _now(), key))
            if cur.rowcount == 0:
                raise KeyError(key)
        return self.get(key)  # type: ignore[return-value]

    def get(self, address: str) -> AddressState | None:
        key = self.normalize(address)
        with self._session() as conn:
            row = conn.execute("SELECT address,status,permanent,reason,company_code,"
                               "failure_count,updated_at FROM address_states "
                               "WHERE address=?", (key,)).fetchone()
        return AddressState(row[0], row[1], bool(row[2]), row[3], row[4],
                            int(row[5]), row[6]) if row else None

    def blocked_reason(self, address: str) -> str:
        state = self.get(address)
        if state is None or not state.blocked:
            return ""
        return f"{state.address}: {state.status} — {state.reason or 'teslim edilemiyor'}"

    def all(self) -> list[AddressState]:
        with self._session() as conn:
            rows = conn.execute("SELECT address,status,permanent,reason,company_code,"
                                "failure_count,updated_at FROM address_states "
                                "ORDER BY updated_at DESC").fetchall()
        return [AddressState(r[0], r[1], bool(r[2]), r[3], r[4], int(r[5]), r[6])
                for r in rows]
