"""DETERMİNİSTİK gelen mail parser'ı — AI'dan ÖNCEKİ tek doğruluk kaynağı.

İlke: **Python okuyabiliyorsa AI kullanılmaz.** Bu modül mail gövdesini,
ekleri ve dosya adlarını yalnızca sözlük + düzenli ifade + yapı analiziyle
çözer. Çözemediği alanı UYDURMAZ: ``None`` bırakır, gerekçesini yazar ve
üst katman (pipeline) o mail için AI fallback'i tetikler.

Mevcut sistemden yeniden kullanılanlar (yeniden yazılmadı):
    app.mailing.mail_builder.normalize_code / classify_locale / MONTHS_*
    app.utils.normalization.normalize_amount / normalize_date

Desteklenen kombinasyonlar (hepsi test edilir):
    gövde+mektup+ekstre | gövde+mektup | gövde+ekstre | yalnız gövde |
    ayrı ayrı ekler | PDF mektup + Excel/PDF ekstre | çok sayıda ek |
    gövdenin İÇİNDE mektup | yalnız gövdede cevap
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from typing import Iterable, Optional

from app.incoming.attachment_classifier import classify_all
from app.incoming.extractors import extract_all
from app.incoming.models import (
    INFO_DUPLICATE_ATTACHMENT,
    REVIEW_ATTACHMENT_UNREADABLE,
    REVIEW_BALANCE_UNCERTAIN,
    REVIEW_CONDITIONAL_REPLY,
    REVIEW_LETTER_UNCERTAIN,
    REVIEW_LOW_CONFIDENCE,
    REVIEW_MULTIPLE_COMPANY_CODES,
    REVIEW_MULTIPLE_LETTERS,
    REVIEW_MULTIPLE_STATEMENTS,
    REVIEW_NO_COMPANY_CODE,
    REVIEW_NO_COMPANY_NAME,
    REVIEW_PAYMENT_INSTRUCTION,
    REVIEW_REPLY_TYPE_UNKNOWN,
    REVIEW_SEAL_UNCERTAIN,
    REVIEW_SIGNATURE_UNCERTAIN,
    AttachmentKind,
    Direction,
    IncomingAttachment,
    IncomingMail,
    ParsedMailResult,
    ReplyType,
)
from app.incoming.textutil import fold, normalize_body
from app.mailing.mail_builder import MONTHS_EN, MONTHS_TR, normalize_code
from app.utils.normalization import normalize_amount, normalize_date

# İnsan incelemesini ZORUNLU kılan gerekçeler. Listede olmayan gerekçeler
# bilgilendirme amaçlıdır (ör. birden fazla ekstre normaldir: M ve S).
REVIEW_TRIGGERS: frozenset[str] = frozenset({
    REVIEW_NO_COMPANY_CODE,
    REVIEW_NO_COMPANY_NAME,
    REVIEW_MULTIPLE_COMPANY_CODES,
    REVIEW_MULTIPLE_LETTERS,
    REVIEW_LETTER_UNCERTAIN,
    REVIEW_SIGNATURE_UNCERTAIN,
    REVIEW_SEAL_UNCERTAIN,
    REVIEW_BALANCE_UNCERTAIN,
    REVIEW_ATTACHMENT_UNREADABLE,
    REVIEW_REPLY_TYPE_UNKNOWN,
    REVIEW_LOW_CONFIDENCE,
    REVIEW_CONDITIONAL_REPLY,
    REVIEW_PAYMENT_INSTRUCTION,
})

LOW_CONFIDENCE = 0.60

# Ekstrede tutar aranırken taranacak en fazla satır (başlık dahil).
_STATEMENT_SCAN_ROWS = 200

# Firma adının gönderenin GÖRÜNEN ADINDAN geldiğini işaretler. Bu ZAYIF bir
# kaynaktır (çoğu zaman bir kişi adıdır) ve birleştirme katmanında belgeden
# okunan bir isim karşısında çelişki sayılmaz.
NAME_SOURCE_SENDER = "gonderen"

# --- cevap türü sözlükleri (katlanmış biçimde yazılır) ----------------------

ACCEPT_PHRASES: tuple[str, ...] = (
    # Türkçe
    "mutabikiz", "mutabik kalinmistir", "mutabik kalinmis", "mutabakat saglanmistir",
    "mutabik oldugumuzu", "mutabakati onayliyoruz", "onayliyoruz", "teyit ederiz",
    "teyit ediyoruz", "teyit edilmistir", "kabul ediyoruz", "kabul edilmistir",
    "kayitlarimizla uyumludur", "kayitlarimizla ayni", "bakiye dogrudur",
    "bakiyeniz dogrudur", "hemfikiriz", "uygundur", "mutabakat saglandi",
    # İngilizce
    "we confirm", "we hereby confirm", "we do confirm", "we agree",
    "we accept", "is confirmed", "balance is correct", "confirm the balance",
    "agree with the balance", "in agreement with", "matches our records",
    "in line with our records", "confirmed as correct", "we approve",
)

REJECT_PHRASES: tuple[str, ...] = (
    # Türkçe
    "mutabik degiliz", "mutabik kalinamamistir", "mutabakat saglanamamistir",
    "kabul etmiyoruz", "katilmiyoruz", "uyusmamaktadir", "uyusmuyor",
    "tutmamaktadir", "tutmuyor", "farklidir", "hatalidir", "yanlistir",
    "itiraz ediyoruz", "onaylamiyoruz", "teyit edemiyoruz", "mutabik degil",
    # İngilizce
    "we do not agree", "we dont agree", "we disagree", "cannot confirm",
    "can not confirm", "do not confirm", "does not match", "do not match",
    "is incorrect", "we object", "differs from our records",
    "not in agreement", "we reject",
)

PARTIAL_PHRASES: tuple[str, ...] = (
    "kismen mutabik", "kismen kabul", "kismen onay", "bir kismina",
    "haricinde mutabik", "disinda mutabik", "partially agree",
    "partially confirm", "partly agree", "with the exception of",
    "except for the invoice", "except for invoice",
)

CORRECTION_PHRASES: tuple[str, ...] = (
    "duzeltilmesini", "duzeltme talep", "duzeltilerek", "revize edilmesi",
    "guncellenmesini", "kontrol edip tekrar", "yeniden gonderiniz",
    "duzeltilmis mutabakat", "lutfen duzeltiniz", "please correct",
    "kindly correct", "please revise", "please amend", "please check and",
    "resend the reconciliation", "correction is needed", "needs correction",
)

INFO_PHRASES: tuple[str, ...] = (
    "bilginize", "bilgilerinize", "otomatik yanit", "ofis disindayim",
    "yillik izin", "ilgili arkadasa ilettim", "yonlendirilmistir",
    "for your information", "out of office", "automatic reply", "auto reply",
    "i am currently out", "will be back on", "kindly note",
)

# Kabul sözcüğü bulunsa bile kararı gelecekteki bir olaya/şarta bağlayan
# ifadeler açık ve koşulsuz kabul değildir. Bu liste yalnızca açık kalıpları
# kapsar; serbest anlam tahmini yapmaz.
CONDITIONAL_PHRASES: tuple[str, ...] = (
    "yonetici onayina bagli", "mudur onayina bagli", "onaylanmasi halinde",
    "kontrol sonrasinda", "kontrolden sonra", "sartiyla", "kosuluyla",
    "subject to approval", "subject to our approval",
    "subject to our managers approval", "subject to our manager s approval",
    "subject to our manager's approval", "pending approval",
    "after manager approval", "once approved", "if approved",
    "sous reserve de", "sous condition de", "vorbehaltlich der genehmigung",
    "nach genehmigung", "sujeto a aprobacion", "pendiente de aprobacion",
)

PAYMENT_INSTRUCTION_PHRASES: tuple[str, ...] = (
    "iban", "banka hesabini degistir", "hesap bilgilerini degistir",
    "odeme talimat", "yeni banka hesabi", "change bank account",
    "change the bank account", "new bank account", "payment instruction",
    "bankverbindung andern", "nouvel iban", "cambiar el iban",
)

# Kabul ifadesinin ÖNÜNDE geçen olumsuzlama: "we do not confirm", "mutabik
# DEĞİLİZ" gibi cümleleri yanlışlıkla ACCEPTED saymamak için.
_NEGATIONS: tuple[str, ...] = (
    "not ", "no ", "never ", "cannot", "can not", "dont", "don t", "doesn t",
    "degil", "yok", "olmadigi", "etmiyoruz", "edemiyoruz", "olmadan",
    "olmamasi", "haric",
)
_NEG_WINDOW = 24

# --- yön sözlükleri ---------------------------------------------------------

_DIRECTION_M_PHRASES = (
    "sirketiniz tarafindan odenmesi gereken",
    "tarafinizdan odenmesi gereken",
    "amount must be paid by you",
    "must be paid by you",
    "payable by you",
    "borcunuz",
)
_DIRECTION_S_PHRASES = (
    "tofas tarafindan odenmesi gereken",
    "amount must be paid by tofas",
    "must be paid by tofas",
    "payable by tofas",
    "alacaginiz",
)
# Kendi ürettiğimiz eklerin adı yönü taşır: 4009668_M_mutabakat.pdf
_DIRECTION_FILE_RE = re.compile(r"(?:^|[_\-\s])([msx])(?:[_\-\s])", re.IGNORECASE)

# --- firma kodu / tutar / tarih desenleri -----------------------------------

# Mevcut kural (mail_builder): kod 2 (yerli) ya da 4 (yabancı) ile başlar,
# 7-8 hane. Bilinmeyen ön ekler için 8 haneli genel desen yedektir.
_CODE_PRIMARY_RE = re.compile(r"(?<!\d)([24]\d{6,7})(?!\d)")
_CODE_FALLBACK_RE = re.compile(r"(?<!\d)(\d{8})(?!\d)")

_CURRENCIES: tuple[str, ...] = (
    "TRY", "TRL", "TL", "EUR", "USD", "GBP", "CHF", "JPY", "SEK", "NOK",
    "DKK", "PLN", "RON", "CZK", "HUF", "RUB", "CNY", "CAD", "AUD", "AED",
)
_CURRENCY_ALIAS = {"TL": "TRY", "TRL": "TRY"}
_AMOUNT_PATTERN = r"[-+]?\d{1,3}(?:[.,\s]\d{3})*(?:[.,]\d{1,2})?|[-+]?\d+(?:[.,]\d{1,2})?"
_CUR_ALTERNATION = "|".join(_CURRENCIES)
_CUR_FIRST_RE = re.compile(
    rf"\b(?P<cur>{_CUR_ALTERNATION})\b[\s:]*(?P<amt>{_AMOUNT_PATTERN})",
    re.IGNORECASE)
_AMT_FIRST_RE = re.compile(
    rf"(?P<amt>{_AMOUNT_PATTERN})\s*(?P<cur>{_CUR_ALTERNATION})\b",
    re.IGNORECASE)

_DATE_RE = re.compile(r"\b(\d{1,2}[./-]\d{1,2}[./-]\d{2,4}|\d{4}-\d{2}-\d{2})\b")

# Firma unvanı ipuçları (deterministik: hukuki şirket ekleri).
#
# İki liste vardır çünkü bazı ekler günlük dilde de geçer: İngilizce bir
# cümledeki "as of 31.07.2026" ifadesi "A.Ş." sanılıp koca bir cümle firma
# adı olarak alınıyordu. Belirsiz ekler yalnızca ORİJİNAL metinde BÜYÜK
# HARFLE yazılmışsa kabul edilir ("STELLANTIS ... S.P.A." evet, "as of" hayır).
_SUFFIX_TOKENS: frozenset[str] = frozenset({
    "a.s.", "a.s", "anonim", "sirketi", "ltd", "ltd.", "limited", "sti",
    "sti.", "sanayi", "ticaret", "holding", "s.p.a.", "s.p.a", "spa",
    "gmbh", "mbh", "s.r.l.", "s.r.l", "srl", "s.a.", "llc", "l.l.c.",
    "inc", "inc.", "incorporated", "corp", "corp.", "corporation", "plc",
    "sarl", "s.a.r.l.", "sas", "kft", "s.l.", "aps", "a/s", "d.o.o.",
    "sp.z.o.o.", "zrt", "oyj",
})
_AMBIGUOUS_SUFFIX_TOKENS: frozenset[str] = frozenset({
    "as", "sa", "ag", "kg", "co", "co.", "san", "san.", "tic", "tic.",
    "bv", "b.v.", "nv", "n.v.", "ab", "oy", "se", "kt",
})

# Firma adı OLAMAYACAK satırlar: cümle işaretleri taşıyan satırlar elenir.
_SENTENCE_MARKERS: tuple[str, ...] = (
    "we ", "the ", " of ", "please", "dear", "regards", "balance",
    "confirm", "agree", "invoice", "kindly", "hereby", "sayin", "lutfen",
    "saygilar", "tutar", "bakiye", "mutabakat", "merhaba", "iyi calismalar",
    "teyit", "odenmesi", "tarafindan", "itibariyla", "itibariyle",
)


@dataclass
class _Balance:
    currency: str
    amount: Decimal
    source: str


def _is_negated(text: str, index: int) -> bool:
    """Eşleşmenin hemen öncesinde olumsuzlama var mı?"""
    start = max(0, index - _NEG_WINDOW)
    window = text[start:index]
    return any(neg in window for neg in _NEGATIONS)


def _find_phrases(folded: str, phrases: Iterable[str],
                  skip_negated: bool = False) -> list[str]:
    """Katlanmış metinde geçen ifadeleri döndür."""
    hits: list[str] = []
    for phrase in phrases:
        index = folded.find(phrase)
        while index >= 0:
            if not (skip_negated and _is_negated(folded, index)):
                hits.append(phrase)
                break
            index = folded.find(phrase, index + 1)
    return hits


def _looks_like_date_number(token: str) -> bool:
    """8 haneli sayı aslında YYYYMMDD bir tarih mi? (20260731 gibi)"""
    if len(token) != 8:
        return False
    try:
        year, month, day = int(token[:4]), int(token[4:6]), int(token[6:])
        date(year, month, day)
    except ValueError:
        return False
    return 1990 <= year <= 2100


def _inside_a_number(text: str, start: int, end: int) -> bool:
    """Eşleşme aslında bir SAYININ parçası mı? (ör. ``4009668,50`` tutarı)

    Firma kodu 7-8 hanedir; bir bakiye de öyle olabilir. Ondalık ayracı
    komşuluğu kontrol edilmezse "Bakiye 4009668,50 TL" cümlesindeki tutar
    firma kodu sanılır — yanlış firmaya mutabakat kapatmak demektir.
    """
    after = text[end:end + 2]
    if len(after) >= 2 and after[0] in ".," and after[1].isdigit():
        return True
    before = text[max(0, start - 2):start]
    if len(before) >= 2 and before[1] in ".," and before[0].isdigit():
        return True
    return False


def extract_company_codes(text: str) -> list[str]:
    """Metindeki firma kodu adaylarını sırayla döndür (tekilleştirilmiş)."""
    if not text:
        return []
    found: list[str] = []
    for regex in (_CODE_PRIMARY_RE, _CODE_FALLBACK_RE):
        for match in regex.finditer(text):
            token = match.group(1)
            if _looks_like_date_number(token):
                continue
            if _inside_a_number(text, match.start(1), match.end(1)):
                continue
            code = normalize_code(token)
            if code and code not in found:
                found.append(code)
        if found:
            # Birincil desen (2/4 ile başlayan kod) tuttuysa genel 8 haneli
            # yedeğe hiç bakılmaz: her 8 haneli sayı firma kodu değildir.
            break
    return found


def extract_balances(text: str, source: str = "") -> list[_Balance]:
    """Metinden (para birimi, tutar) çiftlerini çıkar.

    Hem ``EUR 58.707.401,32`` hem ``58.707.401,32 EUR`` biçimini tanır.
    Sayı ayrıştırma mevcut ``normalize_amount`` ile yapılır — TR/EN biçim
    farkı orada zaten çözülmüştür, ikinci bir uygulama yazılmaz.
    """
    if not text:
        return []
    out: list[_Balance] = []
    seen: set[tuple[str, str]] = set()
    for regex in (_CUR_FIRST_RE, _AMT_FIRST_RE):
        for match in regex.finditer(text):
            raw_cur = match.group("cur").upper()
            currency = _CURRENCY_ALIAS.get(raw_cur, raw_cur)
            raw_amount = match.group("amt").strip()
            if not any(ch.isdigit() for ch in raw_amount):
                continue
            amount = normalize_amount(raw_amount)
            key = (currency, str(amount))
            if key in seen:
                continue
            seen.add(key)
            out.append(_Balance(currency, amount, source))
    return out


def extract_dates(text: str) -> list[date]:
    """Metindeki tarihleri sırayla döndür (tanınmayanlar atlanır)."""
    dates: list[date] = []
    for match in _DATE_RE.finditer(text or ""):
        parsed = normalize_date(match.group(1))
        if parsed and parsed not in dates:
            dates.append(parsed)
    return dates


def extract_period(subject: str, texts: Iterable[str],
                   fallback_year: Optional[int] = None) -> tuple[Optional[str], str]:
    """Dönem (``YYYY-MM``) ve kanıt kaynağını döndür.

    Konu satırı ``4009668 July Reconciliation with TOFAS`` biçimindedir (bizim
    ürettiğimiz mail); firma cevabında ``RE:`` ile aynen döner. Ay adı
    bulunamazsa mektup/gövde içindeki tarihe bakılır.
    """
    folded_subject = fold(subject)
    month_names = [(i + 1, fold(name)) for i, name in enumerate(MONTHS_EN)]
    month_names += [(i + 1, fold(name)) for i, name in enumerate(MONTHS_TR)]

    month = None
    for number, name in month_names:
        if name and name in folded_subject:
            month = number
            break

    year = None
    year_match = re.search(r"\b(20\d{2})\b", subject or "")
    if year_match:
        year = int(year_match.group(1))

    if month and year:
        return f"{year}-{month:02d}", "konu"

    for text in texts:
        for parsed in extract_dates(text):
            if month and parsed.month != month:
                continue
            return f"{parsed.year}-{parsed.month:02d}", "metin"

    if month and (year or fallback_year):
        return f"{year or fallback_year}-{month:02d}", "konu+yil"
    return None, ""


def _company_suffix_in_line(line: str) -> bool:
    """Satır, hukuki bir şirket eki taşıyor mu? (kelime bazlı, cümle değil)"""
    words = [w for w in re.split(r"[\s,;]+", line.strip()) if w]
    if not (1 <= len(words) <= 10):
        return False
    for word in words:
        token = fold(word).strip(".,;:()[]") or fold(word)
        raw = word.strip(".,;:()[]")
        if token in _SUFFIX_TOKENS or fold(word) in _SUFFIX_TOKENS:
            return True
        if (token in _AMBIGUOUS_SUFFIX_TOKENS or
                fold(word) in _AMBIGUOUS_SUFFIX_TOKENS):
            # "as of" değil, "A.Ş." / "S.A." — büyük harf şartı.
            if raw.isupper() and len(words) >= 2:
                return True
    return False


def has_company_suffix(text: str) -> bool:
    """Metnin herhangi bir satırında firma unvanı görünüyor mu?"""
    for line in (text or "").splitlines():
        if _company_suffix_in_line(line):
            return True
    return False


def extract_company_name(texts: Iterable[tuple[str, str]],
                         sender_name: str = "") -> tuple[Optional[str], str]:
    """Metinlerden firma unvanı çıkar (hukuki şirket ekine göre).

    Tahmin YAPILMAZ: yalnızca ``A.Ş. / LTD / S.P.A. / GMBH`` gibi bilinen bir
    şirket eki taşıyan KISA bir satır kabul edilir; cümleler elenir.
    Bulunamazsa gönderenin görünen adı ADAY olarak döner ve kanıt alanına
    'gonderen' yazılır.
    """
    for source, text in texts:
        for line in (text or "").splitlines():
            # Sondaki nokta unvanın parçasıdır ("A.Ş." / "S.P.A."); yalnızca
            # boşluk ve ayraç işaretleri kırpılır.
            candidate = " ".join(line.strip().strip(":-\t ").split())
            if not (4 <= len(candidate) <= 120):
                continue
            folded_line = fold(candidate)
            if any(marker in folded_line for marker in _SENTENCE_MARKERS):
                continue
            if sum(ch.isdigit() for ch in candidate) > len(candidate) / 5:
                continue
            if not _company_suffix_in_line(candidate):
                continue
            return candidate, source
    name = " ".join((sender_name or "").split())
    if name and "@" not in name and len(name) >= 3:
        return name, NAME_SOURCE_SENDER
    return None, ""


def detect_reply_type(folded_text: str) -> tuple[ReplyType, list[str], bool]:
    """Cevap türünü belirle.

    Dönüş: (tür, eşleşen ifadeler, belirsiz mi). Aynı metinde hem kabul hem
    ret ifadesi varsa tür UNKNOWN olur ve belirsizlik bayrağı kalkar — böyle
    bir maili sessizce ACCEPTED saymak, yanlış mutabakat kapatmak demektir.
    """
    if not folded_text.strip():
        return ReplyType.UNKNOWN, [], False

    partial = _find_phrases(folded_text, PARTIAL_PHRASES)
    reject = _find_phrases(folded_text, REJECT_PHRASES)
    accept = _find_phrases(folded_text, ACCEPT_PHRASES, skip_negated=True)
    correction = _find_phrases(folded_text, CORRECTION_PHRASES)
    info = _find_phrases(folded_text, INFO_PHRASES)
    conditional = _find_phrases(folded_text, CONDITIONAL_PHRASES)

    if partial:
        return ReplyType.PARTIALLY_ACCEPTED, partial, False
    if conditional and accept:
        return ReplyType.UNKNOWN, accept + conditional, True
    if accept and reject:
        return ReplyType.UNKNOWN, accept + reject, True
    if reject:
        return ReplyType.REJECTED, reject, False
    if correction and not accept:
        return ReplyType.REQUESTED_CORRECTION, correction, False
    if accept:
        return ReplyType.ACCEPTED, accept, False
    if info:
        return ReplyType.INFORMATION_ONLY, info, False
    return ReplyType.UNKNOWN, [], False


def detect_direction(folded_texts: Iterable[str],
                     filenames: Iterable[str]) -> tuple[Direction, str]:
    """Yönü (M/S/X) belirle: önce dosya adı, sonra metin ifadeleri."""
    for name in filenames:
        match = _DIRECTION_FILE_RE.search(f"_{name}_")
        if match:
            letter = match.group(1).upper()
            if letter in ("M", "S", "X"):
                return Direction(letter), f"dosya adı ({name})"
    for text in folded_texts:
        if not text:
            continue
        for phrase in _DIRECTION_M_PHRASES:
            if phrase in text:
                return Direction.M, f"metin ({phrase})"
        for phrase in _DIRECTION_S_PHRASES:
            if phrase in text:
                return Direction.S, f"metin ({phrase})"
    return Direction.UNKNOWN, ""


@dataclass
class LetterAssessment:
    """Bir mektup ekinin doldurulmuş / imzalı / kaşeli durumu (üç değerli)."""

    filled: Optional[bool] = None
    signed: Optional[bool] = None
    sealed: Optional[bool] = None
    evidence: str = ""


def assess_letter(attachment: IncomingAttachment,
                  company_code: Optional[str]) -> LetterAssessment:
    """Mektubu deterministik sinyallerle değerlendir.

    KURAL: emin olunamayan alan ``None`` kalır. "İmza göremedim" ile "imza
    yok" aynı şey değildir; taranmış bir belgede Python imzayı göremez.

    Kesin olarak söylenebilenler:
      - PDF'te DOLDURULMUŞ dijital imza alanı varsa → imzalı (True).
      - PDF'in metin katmanı VAR, hiç görsel YOK ve dijital imza YOK ise →
        sayfada mürekkep olacak bir yer yoktur: imzasız/kaşesiz (False).
      - Diğer her durumda (taranmış görüntü, gömülü resim, metin katmanı yok)
        → None: AI'ya sorulur, o da emin olamazsa insana gider.
    """
    assessment = LetterAssessment()
    text = attachment.text or ""

    if attachment.read_error or attachment.has_text_layer is False:
        assessment.evidence = ("metin katmanı yok (taranmış/görüntü belge)"
                               if not attachment.read_error
                               else f"okunamadı: {attachment.read_error}")
        return assessment

    # -- doldurulmuş mu? ---------------------------------------------------
    filled_signals = 0
    if company_code and company_code in re.sub(r"\s", "", text):
        filled_signals += 1
    if extract_balances(text):
        filled_signals += 1
    if extract_dates(text):
        filled_signals += 1
    if has_company_suffix(text):
        filled_signals += 1

    if filled_signals >= 3:
        assessment.filled = True
    elif filled_signals == 0:
        assessment.filled = False
    # 1-2 sinyal → belirsiz (None): şablon kısmen dolu olabilir.

    # -- imza / kaşe -------------------------------------------------------
    if attachment.has_digital_signature is True:
        assessment.signed = True
        assessment.evidence = "PDF dijital imza alanı dolu"
    elif (attachment.has_text_layer and attachment.image_count == 0
          and attachment.has_digital_signature is False):
        assessment.signed = False
        assessment.sealed = False
        assessment.evidence = "metin PDF, görsel yok — imza/kaşe taşıyamaz"
    else:
        assessment.evidence = (
            f"görsel sayısı={attachment.image_count}; imza/kaşe görsel "
            "olduğundan Python kesin karar veremez")
    return assessment


class MailParser:
    """Gelen maili deterministik olarak çözümler."""

    def parse(self, mail: IncomingMail) -> ParsedMailResult:
        result = ParsedMailResult()

        extract_all(mail.attachments)
        classify_all(mail.attachments)

        body = normalize_body(mail.body)
        folded_body = fold(body)
        subject = mail.subject or ""
        folded_subject = fold(subject)

        # Outlook aynı dosyayı iki kez ekleyebilir; birebir aynı ek "iki mektup"
        # sayılıp gereksiz yere insan incelemesi tetiklemesin.
        attachments, duplicates = _unique_attachments(mail.attachments)
        if duplicates:
            result.add_reason(INFO_DUPLICATE_ATTACHMENT)

        letters = [a for a in attachments if a.kind is AttachmentKind.LETTER]
        statements = [a for a in attachments
                      if a.kind is AttachmentKind.STATEMENT]
        unreadable = [a for a in attachments
                      if a.read_error or a.kind is AttachmentKind.UNREADABLE]

        letter_text = "\n".join(a.text for a in letters if a.text)
        statement_text = "\n".join(a.text for a in statements if a.text)

        result.letter_count = len(letters)
        result.statement_count = len(statements)
        result.letter_present = bool(letters)
        result.statement_present = bool(statements)
        result.unreadable_attachments = [a.filename for a in unreadable]

        # -- firma kodu ----------------------------------------------------
        candidates: list[str] = []
        code_source = ""
        for source, text in (("konu", subject),
                             ("dosya adı", " ".join(mail.attachment_names)),
                             ("mektup", letter_text),
                             ("gövde", body)):
            found = extract_company_codes(text)
            for code in found:
                if code not in candidates:
                    candidates.append(code)
                    if not code_source:
                        code_source = source
        if not candidates and statement_text:
            found = extract_company_codes(statement_text)
            if found:
                candidates.extend(found)
                code_source = "ekstre"

        result.company_code_candidates = candidates
        if candidates:
            result.company_code = candidates[0]
            result.evidence["company_code"] = code_source
        if len(candidates) > 1:
            result.add_reason(REVIEW_MULTIPLE_COMPANY_CODES)
        if not candidates:
            result.add_reason(REVIEW_NO_COMPANY_CODE)

        # -- gövde içinde mektup (H şıkkı) ---------------------------------
        body_is_letter = self._body_carries_letter(folded_body, body,
                                                   result.company_code)
        if body_is_letter and not letters:
            result.letter_present = True
            result.letter_count = 1
            result.evidence["letter"] = "mail gövdesi"

        # -- firma adı -----------------------------------------------------
        name, name_source = extract_company_name(
            (("mektup", letter_text), ("gövde", body), ("ekstre", statement_text)),
            mail.sender_name)
        if name:
            result.company_name = name
            result.evidence["company_name"] = name_source
        else:
            result.add_reason(REVIEW_NO_COMPANY_NAME)

        # -- dönem ---------------------------------------------------------
        period, period_source = extract_period(
            subject, (letter_text, body, statement_text),
            mail.received_at.year if mail.received_at else None)
        result.period = period
        if period:
            result.evidence["period"] = period_source

        # -- bakiyeler -----------------------------------------------------
        balances: list[_Balance] = []
        balances += extract_balances(letter_text, "mektup")
        if not balances:
            balances += extract_balances(body, "gövde")
        for balance in balances:
            result.currencies.setdefault(balance.currency, balance.amount)
        if balances:
            result.balance_present = True
            result.evidence["balance"] = balances[0].source
        elif statements and self._statement_has_amounts(statements):
            # Ekstrede tutar var ama tek bir "bakiye" cümlesi yok: bakiyenin
            # kendisi belirsizdir, satırlar toplanarak UYDURULMAZ.
            result.balance_present = True
            result.evidence["balance"] = "ekstre satırları"
            result.add_reason(REVIEW_BALANCE_UNCERTAIN)

        # -- cevap türü ----------------------------------------------------
        combined = "\n".join(part for part in (folded_subject, folded_body,
                                               fold(letter_text)) if part)
        reply_type, hits, ambiguous = detect_reply_type(combined)
        result.reply_type = reply_type
        if hits:
            result.evidence["reply_type"] = hits[0]
        if ambiguous:
            result.evidence["reply_type"] = "çelişkili ifadeler: " + ", ".join(hits[:4])
        if reply_type is ReplyType.UNKNOWN:
            result.add_reason(REVIEW_REPLY_TYPE_UNKNOWN)
        if _find_phrases(combined, CONDITIONAL_PHRASES):
            result.add_reason(REVIEW_CONDITIONAL_REPLY)
        if _find_phrases(combined, PAYMENT_INSTRUCTION_PHRASES):
            result.add_reason(REVIEW_PAYMENT_INSTRUCTION)

        if reply_type is ReplyType.ACCEPTED:
            result.balance_accepted = True
        elif reply_type is ReplyType.REJECTED:
            result.balance_accepted = False

        # -- yön -----------------------------------------------------------
        direction, direction_source = detect_direction(
            (fold(letter_text), folded_body, folded_subject),
            mail.attachment_names)
        result.direction = direction
        if direction_source:
            result.evidence["direction"] = direction_source

        # -- mektup durumu -------------------------------------------------
        if letters:
            assessments = [assess_letter(a, result.company_code) for a in letters]
            result.letter_filled = _combine_tristate(a.filled for a in assessments)
            result.letter_signed = _combine_tristate(a.signed for a in assessments)
            result.letter_sealed = _combine_tristate(a.sealed for a in assessments)
            result.evidence["letter_state"] = assessments[0].evidence
        elif body_is_letter:
            # Gövdedeki mektup ıslak imza/kaşe TAŞIYAMAZ; bu ikisi kesin False.
            result.letter_filled = True
            result.letter_signed = False
            result.letter_sealed = False
            result.evidence["letter_state"] = "mektup metni mail gövdesinde"

        if result.letter_present:
            if result.letter_filled is None:
                result.add_reason(REVIEW_LETTER_UNCERTAIN)
            if result.letter_signed is None:
                result.add_reason(REVIEW_SIGNATURE_UNCERTAIN)
            if result.letter_sealed is None:
                result.add_reason(REVIEW_SEAL_UNCERTAIN)
            if not result.balance_present:
                result.add_reason(REVIEW_BALANCE_UNCERTAIN)

        if len(letters) > 1:
            result.add_reason(REVIEW_MULTIPLE_LETTERS)
        if len(statements) > 1:
            result.add_reason(REVIEW_MULTIPLE_STATEMENTS)
        if unreadable:
            result.add_reason(REVIEW_ATTACHMENT_UNREADABLE)

        # -- güven ve insan incelemesi --------------------------------------
        result.confidence = self._confidence(result, ambiguous)
        if result.confidence < LOW_CONFIDENCE:
            result.add_reason(REVIEW_LOW_CONFIDENCE)
        result.needs_human_review = any(r in REVIEW_TRIGGERS for r in result.reasons)
        return result

    # -- yardımcılar -------------------------------------------------------

    @staticmethod
    def _body_carries_letter(folded_body: str, body: str,
                             company_code: Optional[str]) -> bool:
        """Mektup metni mail gövdesinin İÇİNDE mi? (H şıkkı)

        Yalnızca "mutabakat/confirmation" kelimesi yetmez — cevap maillerinin
        çoğunda geçer. Mektup sayılması için gövdede hem mektup ifadesi hem
        bakiye hem de firma kodu bulunmalıdır.
        """
        if not body.strip():
            return False
        markers = ("mutabakat mektubu", "bakiye teyidi", "balance confirmation",
                   "reconciliation letter", "letter of confirmation",
                   "mutabakat formu")
        if not any(marker in folded_body for marker in markers):
            return False
        if not extract_balances(body):
            return False
        return bool(company_code and company_code in re.sub(r"\s", "", body))

    @staticmethod
    def _statement_has_amounts(statements: list[IncomingAttachment]) -> bool:
        """Ekstrede gerçekten tutar var mı? (ilk satırlara bakmak yeterlidir)

        Tüm satırları taramak 2000 satırlık bir ekstrede gereksiz yere pahalı
        olurdu; ilk tutar bulunduğunda zaten çıkılır.
        """
        for attachment in statements:
            for table in attachment.tables:
                for row in table[1:_STATEMENT_SCAN_ROWS]:
                    for cell in row:
                        text = str(cell).strip()
                        if text and any(ch.isdigit() for ch in text) and \
                                normalize_amount(text) != Decimal("0"):
                            return True
            if attachment.text and extract_balances(attachment.text):
                return True
        return False

    @staticmethod
    def _confidence(result: ParsedMailResult, ambiguous_reply: bool) -> float:
        """Deterministik tamlık skoru (0..1).

        Yüksek skor "AI'ya gerek yok" demektir; bu yüzden eksik/belirsiz her
        alan skoru düşürür. Skor bir olasılık değil, kapsama ölçüsüdür.
        """
        score = 0.0
        if result.company_code:
            score += 0.30
        if result.company_name:
            score += 0.10
        if result.reply_type is not ReplyType.UNKNOWN:
            score += 0.25
        if result.currencies:
            score += 0.15
        elif not result.letter_present and not result.statement_present:
            # Ek yoksa bakiye beklenmiyordur; eksikliği cezalandırma.
            score += 0.10
        if not result.unreadable_attachments:
            score += 0.10
        if not result.letter_present or result.letter_filled is not None:
            score += 0.10

        if len(result.company_code_candidates) > 1:
            score = min(score, 0.40)
        if result.unreadable_attachments:
            score = min(score, 0.50)
        if ambiguous_reply:
            score = min(score, 0.50)
        return round(min(1.0, score), 3)


def _unique_attachments(
    attachments: list[IncomingAttachment],
) -> tuple[list[IncomingAttachment], list[IncomingAttachment]]:
    """Birebir aynı ekleri (aynı ad + aynı içerik) tekilleştir.

    Farklı adla gelen aynı içerik AYRILMAZ: dosya adı yön bilgisi taşır
    (``4009668_M_...`` / ``4009668_S_...``) ve bu bilgi kaybolmamalıdır.
    """
    seen: set[tuple[str, str]] = set()
    unique: list[IncomingAttachment] = []
    duplicates: list[IncomingAttachment] = []
    for attachment in attachments:
        key = (attachment.filename.strip().lower(), attachment.sha256)
        if key in seen:
            duplicates.append(attachment)
            continue
        seen.add(key)
        unique.append(attachment)
    return unique, duplicates


def _combine_tristate(values: Iterable[Optional[bool]]) -> Optional[bool]:
    """Birden çok mektubun üç değerli sonucunu birleştir.

    Herhangi biri True ise True (en az bir imzalı/dolu mektup var), hiçbiri
    True değil ama bir tanesi bile belirsizse None, hepsi False ise False.
    """
    seen = list(values)
    if any(v is True for v in seen):
        return True
    if any(v is None for v in seen):
        return None
    return False if seen else None
