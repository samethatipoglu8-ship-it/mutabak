"""FAZ 11 — hatırlatma maili (§3.5, §3.6).

YENİ MAİL DEĞİL
    Hatırlatma, aynı mutabakat zincirinde EN SON gönderdiğimiz mailin
    üzerinden Reply-All olarak gider.
    Firma kendi aldığı maili ve rakamı aynı konu altında görür; yeni bir
    thread açmak karşı tarafta ikinci bir mutabakat sanılır.

DİL FİRMA KODUNDAN
    2 -> Türkçe, 4 -> İngilizce (mevcut ``classify_locale`` kuralı).
    Dil belirlenemiyorsa hatırlatma HAZIRLANMAZ.

EKLER VARSAYILAN OLARAK YENİDEN EKLENİR (kullanıcı kararı)
    Firma ekstreyi kaybetmiş olabilir. Ancak gönderim anındaki dosyalardan
    biri diskte yoksa mail GÖNDERİLMEZ: eksik ekli bir hatırlatma, karşı
    tarafa yanlış/eksik bilgi vermektir.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Sequence

from app.mailing.mail_builder import classify_locale
from app.services.difference_mail import reply_subject

_BODY = {
    "tr": "Merhaba,\n\nKonuya ilişkin dönüşünüzü rica ederiz.\n\n"
          "Teşekkürler,\nİyi çalışmalar.",
    "en": "Dear,\n\nWe kindly ask for your feedback on this matter.\n\n"
          "Kind regards,",
}


@dataclass
class ReminderMail:
    """Hazırlanmış hatırlatma (henüz GÖNDERİLMEDİ)."""

    case_id: str = ""
    company_code: str = ""
    company_name: str = ""
    locale: str = ""
    subject: str = ""
    body: str = ""
    attachments: list[str] = field(default_factory=list)
    missing_attachments: list[str] = field(default_factory=list)
    conversation_id: str = ""
    message_id: str = ""
    # EN GÜÇLÜ HEDEFLEYİCİ: arayüze hiç aktarılmıyordu (§1).
    entry_id: str = ""
    #: Hedefin hangi kanıta dayandığı (izlenebilirlik).
    target_source: str = ""
    blocked_reason: str = ""

    @property
    def ready(self) -> bool:
        return not self.blocked_reason


def attachment_paths(case: Any) -> tuple[list[str], list[str]]:
    """Gönderilen eklerin diskteki yolları. (var olanlar, eksikler)"""
    var: list[str] = []
    eksik: list[str] = []
    for meta in getattr(case, "original_attachments", None) or []:
        path = str((meta or {}).get("path") or "")
        name = str((meta or {}).get("name") or path or "ek")
        if path and Path(path).is_file():
            var.append(path)
        else:
            eksik.append(name)
    return var, eksik


def build_reminder(case: Any, *, include_attachments: bool = True,
                   registry: Any = None) -> ReminderMail:
    """Bir case için hatırlatma maili hazırla.

    ``registry`` verilmezse adres defteri bu çağrı için açılır. Toplu
    üretimde (``build_many``) defter BİR KEZ açılıp devredilir; her firma
    için yeniden açmak binlerce gereksiz SQLite bağlantısı demektir.
    """
    code = getattr(case, "company_code", "") or ""
    locale = classify_locale(code)
    # HEDEF: İLK mutabakat maili DEĞİL, EN SON gönderdiğimiz mail.
    # Eskiden doğrudan case.conversation_id/message_id kullanılıyordu;
    # bunlar gönderim anındaki (ilk) kimliklerdi ve üçüncü hatırlatma da
    # birinci mailin altına düşüyordu (bkz. app/services/reply_target).
    from app.services.reply_target import resolve_target

    hedef = resolve_target(case)
    reminder = ReminderMail(
        case_id=getattr(case, "case_id", ""),
        company_code=code,
        company_name=getattr(case, "company_name", "") or "",
        locale=locale,
        subject=reply_subject(getattr(case, "subject", "")),
        conversation_id=hedef.conversation_id,
        message_id=hedef.message_id,
        entry_id=hedef.entry_id,
        target_source=hedef.source,
    )

    if locale not in ("tr", "en"):
        reminder.blocked_reason = (
            f"Firma kodu '{code}' 2/4 ile başlamıyor; hatırlatma dili "
            "belirlenemedi.")
        return reminder

    reminder.body = _BODY[locale]

    # ADRES TESLİMATA KAPALI MI?
    #
    # Kalıcı NDR almış bir adrese hatırlatma göndermek yalnızca boşunadır:
    # vaka sonsuza kadar "cevap bekleniyor" görünür ve gerçek sorun (yanlış
    # adres) gizlenir. Engel, dil ve ek kontrollerinden ÖNCE gelmez —
    # kullanıcı önce "hangi dil?" değil "neden gitmiyor?" cevabını görsün
    # diye burada, gönderim kilidinden hemen önce uygulanır.
    from app.services.invalid_address import blocked

    adres_engeli = blocked(case, registry if registry is not None
                           else _registry())
    if adres_engeli:
        reminder.blocked_reason = adres_engeli
        return reminder

    # Send() sonucu belirsiz kaldıysa aynı düğmeye tekrar basmak mükerrer
    # reminder üretebilir. Aksiyon merkezindeki gönderim kilidini bu toplu
    # buton yolu da kullanır; yalnız KESİN başarısızlık yeniden denenebilir.
    from app.services.action_send import check_can_send
    from app.services.case_actions import REMIND_FOR_REPLY

    guard = check_can_send(case, REMIND_FOR_REPLY)
    if not guard.allowed:
        reminder.blocked_reason = guard.reason
        return reminder

    if include_attachments:
        var, eksik = attachment_paths(case)
        reminder.attachments = var
        reminder.missing_attachments = eksik
        if eksik:
            reminder.blocked_reason = (
                "Gönderilen ekler diskte bulunamadı: " + ", ".join(eksik[:3])
                + ". Eksik ekli hatırlatma gönderilmez.")
            return reminder

    if not hedef.ready:
        reminder.blocked_reason = hedef.blocked_reason
    return reminder


def _registry():
    """Adres defterini aç; açılamazsa ``None`` (vaka alanı yine korur)."""
    try:
        from app.services.address_registry import AddressRegistry

        return AddressRegistry()
    except Exception:  # noqa: BLE001 - defter yoksa vaka durumu yeterlidir
        return None


def eligible_cases(cases: Iterable[Any]) -> list[Any]:
    """Takip maili gönderilebilecek case'ler.

    ESKİ DAVRANIŞ YETERSİZDİ: yalnızca ``has_reply`` bakılıyordu. Oysa
    firma cevap verip ekstre göndermemiş, okunamayan ekstre yollamış ya
    da yanlış dönem göndermiş olabilir — bunlar da takip gerektirir.
    Kapanmış/mutabık vakalara ise hatırlatma GİTMEZ.

    Ayrıntı: app/services/case_actions.needs_followup
    """
    from app.services.case_actions import eligible_for_followup

    return eligible_for_followup(cases or ())


def build_many(cases: Sequence[Any], *, include_attachments: bool = True
               ) -> tuple[list[ReminderMail], list[ReminderMail]]:
    """(gönderilebilir, engellenen) hatırlatmalar."""
    hazir: list[ReminderMail] = []
    engelli: list[ReminderMail] = []
    registry = _registry()
    for case in cases:
        reminder = build_reminder(case, include_attachments=include_attachments,
                                  registry=registry)
        (hazir if reminder.ready else engelli).append(reminder)
    return hazir, engelli
