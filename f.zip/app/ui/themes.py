"""Qt stylesheets for dark and light themes (professional accounting look)."""

DARK = """
QMainWindow, QWidget { background-color: #2a0d16; color: #ffffff; }
QLabel { color: #ffffff; }
QLabel#Title { font-size: 20px; font-weight: bold; color: #ffffff; }
QLabel#StatCardValue { font-size: 26px; font-weight: bold; color: #ffffff; }
QLabel#StatCardLabel { font-size: 12px; color: #f2dce3; }
QLabel#Hint { font-size: 11px; color: #f2dce3; }
QLabel#CreditsText { font-size: 16px; font-weight: 600; color: #ffffff; padding: 18px; }
QFrame#StatCard { background-color: #5a1428; border-radius: 10px; padding: 8px; }
QFrame#Ribbon { background-color: #3b0d1c; border-bottom: 1px solid #7a2942; }
QPushButton {
    background-color: #8b1e3f; color: #ffffff; border: 1px solid #ad3b5d;
    border-radius: 6px; padding: 8px 16px; font-weight: bold;
}
QPushButton:hover { background-color: #a52a4d; }
QPushButton:pressed { background-color: #6f1732; }
QPushButton:disabled { background-color: #5b3a45; color: #bca7ae; border-color: #6a4a54; }
QPushButton#Ghost { background-color: #4a1224; color: #ffffff; }
QPushButton#Ghost:hover { background-color: #641a31; }
QListWidget, QTableWidget, QLineEdit, QComboBox, QTextEdit,
QSpinBox, QDoubleSpinBox {
    background-color: #451222; color: #ffffff; border: 1px solid #7a2942;
    border-radius: 6px; selection-background-color: #8b1e3f;
}
/* Yetkisiz kullanıcıda salt-okunur alan: "kapalı" olduğu GÖRÜNMELİ,
   yoksa kullanıcı yazamadığını hata sanır. */
QLineEdit:disabled, QComboBox:disabled, QTextEdit:disabled,
QSpinBox:disabled, QDoubleSpinBox:disabled {
    background-color: #3a0f1d; color: #bca7ae; border-color: #6a4a54;
}
QSpinBox::up-button, QSpinBox::down-button,
QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {
    background-color: #5a1428; border: none; width: 16px;
}
QHeaderView::section {
    background-color: #3b0d1c; color: #ffffff; padding: 6px;
    border: none; font-weight: bold;
}
QTableWidget { gridline-color: #7a2942; alternate-background-color: #511629; }
QProgressBar {
    background-color: #451222; border: none; border-radius: 6px;
    text-align: center; color: #ffffff;
}
QProgressBar::chunk { background-color: #d85b7f; border-radius: 6px; }
QStatusBar { background-color: #3b0d1c; color: #f2dce3; }
QCheckBox { color: #ffffff; }
QListWidget#NavList { background-color: #3b0d1c; border: none; font-size: 14px; }
QListWidget#NavList::item { padding: 12px 16px; color: #ffffff; }
QListWidget#NavList::item:selected { background-color: #8b1e3f; color: #ffffff; }
QListWidget#NavList::item:hover { background-color: #5a1428; }
QFrame#ResultCard { background-color: #5a1428; border-radius: 16px; border: 1px solid #7a2942; }
QLabel#DashCompany { font-size: 22px; font-weight: bold; color: #ffffff; }
QLabel#DashSubtitle { font-size: 12px; letter-spacing: 2px; color: #f2dce3; }
QLabel#DashRate { font-size: 60px; font-weight: bold; color: #ffffff; }
QLabel#DashRateLabel { font-size: 12px; letter-spacing: 3px; color: #f2dce3; }
QLabel#DashStatus { font-size: 15px; }
QLabel#DashRunId { font-size: 11px; color: #d5b4bf; }
QProgressBar#DashBar { background-color: #451222; border-radius: 7px; }
QProgressBar#DashBar::chunk { background-color: #d85b7f; border-radius: 7px; }
"""

LIGHT = """
QMainWindow, QWidget { background-color: #eff1f5; color: #4c4f69; }
QLabel { color: #4c4f69; }
QLabel#Title { font-size: 20px; font-weight: bold; color: #1e66f5; }
QLabel#StatCardValue { font-size: 26px; font-weight: bold; color: #1e66f5; }
QLabel#StatCardLabel { font-size: 12px; color: #6c6f85; }
QLabel#Hint { font-size: 11px; color: #6c6f85; }
QFrame#StatCard { background-color: #ffffff; border-radius: 10px; padding: 8px; }
QFrame#Ribbon { background-color: #e6e9ef; border-bottom: 1px solid #ccd0da; }
QPushButton {
    background-color: #1e66f5; color: #ffffff; border: none;
    border-radius: 6px; padding: 8px 16px; font-weight: bold;
}
QPushButton:hover { background-color: #4a83f7; }
QPushButton:disabled { background-color: #ccd0da; color: #9ca0b0; }
QPushButton#Ghost { background-color: #dce0e8; color: #4c4f69; }
QPushButton#Ghost:hover { background-color: #ccd0da; }
QListWidget, QTableWidget, QLineEdit, QComboBox, QTextEdit,
QSpinBox, QDoubleSpinBox {
    background-color: #ffffff; color: #4c4f69; border: 1px solid #ccd0da;
    border-radius: 6px; selection-background-color: #bcc0cc;
}
QLineEdit:disabled, QComboBox:disabled, QTextEdit:disabled,
QSpinBox:disabled, QDoubleSpinBox:disabled {
    background-color: #e6e9ef; color: #9ca0b0; border-color: #ccd0da;
}
QSpinBox::up-button, QSpinBox::down-button,
QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {
    background-color: #dce0e8; border: none; width: 16px;
}
QHeaderView::section {
    background-color: #e6e9ef; color: #1e66f5; padding: 6px;
    border: none; font-weight: bold;
}
QTableWidget { gridline-color: #ccd0da; }
QProgressBar {
    background-color: #dce0e8; border: none; border-radius: 6px;
    text-align: center; color: #4c4f69;
}
QProgressBar::chunk { background-color: #40a02b; border-radius: 6px; }
QStatusBar { background-color: #e6e9ef; color: #6c6f85; }
QCheckBox { color: #4c4f69; }
QListWidget#NavList { background-color: #e6e9ef; border: none; font-size: 14px; }
QListWidget#NavList::item { padding: 12px 16px; color: #4c4f69; }
QListWidget#NavList::item:selected { background-color: #ffffff; color: #1e66f5; }
QFrame#ResultCard { background-color: #ffffff; border-radius: 16px; border: 1px solid #ccd0da; }
QLabel#DashCompany { font-size: 22px; font-weight: bold; color: #4c4f69; }
QLabel#DashSubtitle { font-size: 12px; letter-spacing: 2px; color: #6c6f85; }
QLabel#DashRate { font-size: 60px; font-weight: bold; color: #1e66f5; }
QLabel#DashRateLabel { font-size: 12px; letter-spacing: 3px; color: #6c6f85; }
QLabel#DashStatus { font-size: 15px; }
QLabel#DashRunId { font-size: 11px; color: #9ca0b0; }
QProgressBar#DashBar { background-color: #dce0e8; border-radius: 7px; }
QProgressBar#DashBar::chunk { background-color: #40a02b; border-radius: 7px; }
"""


def get_theme(name: str) -> str:
    return LIGHT if name == "light" else DARK
