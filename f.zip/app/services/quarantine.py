"""Güvenlik kapısından geçemeyen eklerin karantinası (madde 4).

NEDEN
    Reddedilen bir eki SİLMEK bilgi kaybıdır: firma gerçekten ekstre
    göndermiş ama dosya parolalı/bozuk olabilir. Kullanıcı "ne geldi?"
    sorusunu cevaplayabilmeli, gerekirse doğru dosyayı isteyebilmelidir.

    Reddedilen eki NORMAL klasöre koymak da yanlıştır: makrolu ya da bozuk
    bir dosya, yanlışlıkla çift tıklanabilecek bir yerde durmamalıdır.

TASARIM
    * Dosya, karantina klasörüne İÇERİK ADRESLİ (SHA-256) adla yazılır ve
      uzantısı ``.quarantine`` ile NÖTRLENİR: çift tıklamayla Excel/Word
      açılmaz, hiçbir makro çalışmaz.
    * Aynı ek ikinci kez geldiğinde SHA-256 üzerinden tanınır; ikinci kopya
      yazılmaz, yalnızca "kaçıncı kez görüldüğü" sayılır.
    * Kayıt SALT EKLENİR/GÜNCELLENİR; uygulama içinden silme API'si yoktur.
    * Hiçbir koşulda çökertmez: karantina yazılamazsa iş devam eder.
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional, Sequence

from loguru import logger

from app.utils.paths import app_data_dir
from app.utils.sqlite import open_sqlite_connection

#: Karantinaya alınan dosyalara verilen NÖTR uzantı.
QUARANTINE_SUFFIX = ".quarantine"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass(frozen=True)
class QuarantineRecord:
    """Karantinaya alınmış tek bir ek."""

    sha256: str
    filename: str = ""
    code: str = ""
    reason: str = ""
    size: int = 0
    company_code: str = ""
    case_id: str = ""
    message_id: str = ""
    stored_path: str = ""
    seen_count: int = 1
    first_seen: str = ""
    last_seen: str = ""
    needs_human_review: bool = False


class QuarantineStore:
    """Reddedilen eklerin kalıcı karantinası + tekrar tespiti."""

    def __init__(self, base_dir: str | Path | None = None) -> None:
        if base_dir is None:
            base_dir = app_data_dir() / "quarantine"
        self._dir = Path(base_dir)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._path = self._dir / "quarantine.db"
        self._ensure_schema()

    @property
    def path(self) -> Path:
        return self._path

    @property
    def directory(self) -> Path:
        return self._dir

    @contextmanager
    def _session(self):
        conn = open_sqlite_connection(self._path)
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _ensure_schema(self) -> None:
        try:
            with self._session() as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS quarantined (
                        sha256        TEXT PRIMARY KEY,
                        filename      TEXT NOT NULL DEFAULT '',
                        code          TEXT NOT NULL DEFAULT '',
                        reason        TEXT NOT NULL DEFAULT '',
                        size          INTEGER NOT NULL DEFAULT 0,
                        company_code  TEXT NOT NULL DEFAULT '',
                        case_id       TEXT NOT NULL DEFAULT '',
                        message_id    TEXT NOT NULL DEFAULT '',
                        stored_path   TEXT NOT NULL DEFAULT '',
                        seen_count    INTEGER NOT NULL DEFAULT 1,
                        first_seen    TEXT NOT NULL,
                        last_seen     TEXT NOT NULL,
                        needs_review  INTEGER NOT NULL DEFAULT 0,
                        history       TEXT NOT NULL DEFAULT '[]'
                    )
                """)
        except sqlite3.Error as exc:  # pragma: no cover - ortam bağımlı
            logger.error(f"[karantina] şema kurulamadı: {exc}")

    # -- yazma -------------------------------------------------------------

    def quarantine(self, data: bytes, filename: str, security: Any, *,
                   company_code: str = "", case_id: str = "",
                   message_id: str = "") -> Optional[QuarantineRecord]:
        """Reddedilen eki karantinaya al (ya da tekrar geldiğini işaretle).

        Döner: kayıt (yazılamazsa ``None``). Aynı içerik daha önce
        karantinaya alınmışsa DOSYA TEKRAR YAZILMAZ; yalnızca sayaç artar.
        """
        digest = str(getattr(security, "sha256", "") or "")
        if not digest:
            from app.utils.attachment_security import sha256_of

            digest = sha256_of(data)
        mevcut = self.get(digest)
        hedef = self._dir / f"{digest}{QUARANTINE_SUFFIX}"
        try:
            if mevcut is None and not hedef.exists():
                # Uzantı NÖTRDÜR: dosya çift tıklamayla açılamaz, makro
                # çalıştıracak hiçbir uygulamayla ilişkilendirilmez.
                hedef.write_bytes(data or b"")
        except OSError as exc:
            logger.warning(f"[karantina] dosya yazılamadı ({filename}): {exc}")
            hedef = Path("")

        kayit = QuarantineRecord(
            sha256=digest,
            filename=filename or "",
            code=str(getattr(security, "code", "") or ""),
            reason=str(getattr(security, "reason", "") or ""),
            size=len(data or b""),
            company_code=company_code,
            case_id=case_id,
            message_id=message_id,
            stored_path=str(hedef) if str(hedef) else "",
            seen_count=(mevcut.seen_count + 1) if mevcut else 1,
            first_seen=mevcut.first_seen if mevcut else _now(),
            last_seen=_now(),
            needs_human_review=bool(
                getattr(security, "needs_human_review", False)),
        )
        if not self._upsert(kayit, company_code=company_code, case_id=case_id):
            return None
        return kayit

    def _upsert(self, kayit: QuarantineRecord, *, company_code: str,
                case_id: str) -> bool:
        try:
            with self._session() as conn:
                gecmis = conn.execute(
                    "SELECT history FROM quarantined WHERE sha256 = ?",
                    (kayit.sha256,)).fetchone()
                try:
                    olaylar = json.loads(gecmis[0]) if gecmis else []
                except (TypeError, ValueError):
                    olaylar = []
                olaylar.append({"at": kayit.last_seen,
                                "company_code": company_code,
                                "case_id": case_id,
                                "filename": kayit.filename})
                conn.execute("""
                    INSERT INTO quarantined (
                        sha256, filename, code, reason, size, company_code,
                        case_id, message_id, stored_path, seen_count,
                        first_seen, last_seen, needs_review, history
                    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(sha256) DO UPDATE SET
                        seen_count = excluded.seen_count,
                        last_seen  = excluded.last_seen,
                        history    = excluded.history
                """, (
                    kayit.sha256, kayit.filename, kayit.code, kayit.reason,
                    kayit.size, kayit.company_code, kayit.case_id,
                    kayit.message_id, kayit.stored_path, kayit.seen_count,
                    kayit.first_seen, kayit.last_seen,
                    1 if kayit.needs_human_review else 0,
                    json.dumps(olaylar[-50:], ensure_ascii=False),
                ))
            return True
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[karantina] kayıt yazılamadı: {exc}")
            return False

    # -- okuma -------------------------------------------------------------

    _COLUMNS = ("sha256, filename, code, reason, size, company_code, case_id, "
                "message_id, stored_path, seen_count, first_seen, last_seen, "
                "needs_review")

    @staticmethod
    def _row(row: Sequence[Any]) -> QuarantineRecord:
        return QuarantineRecord(
            sha256=row[0], filename=row[1], code=row[2], reason=row[3],
            size=int(row[4]), company_code=row[5], case_id=row[6],
            message_id=row[7], stored_path=row[8], seen_count=int(row[9]),
            first_seen=row[10], last_seen=row[11],
            needs_human_review=bool(row[12]))

    def get(self, sha256: str) -> Optional[QuarantineRecord]:
        if not sha256:
            return None
        try:
            with self._session() as conn:
                row = conn.execute(
                    f"SELECT {self._COLUMNS} FROM quarantined WHERE sha256 = ?",
                    (sha256,)).fetchone()
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[karantina] okunamadı: {exc}")
            return None
        return self._row(row) if row else None

    def seen_before(self, sha256: str) -> bool:
        """Bu ek daha önce işlendi mi? (SHA-256 üzerinden)"""
        return self.get(sha256) is not None

    def all(self) -> list[QuarantineRecord]:
        try:
            with self._session() as conn:
                rows = conn.execute(
                    f"SELECT {self._COLUMNS} FROM quarantined "
                    "ORDER BY last_seen DESC").fetchall()
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[karantina] okunamadı: {exc}")
            return []
        return [self._row(r) for r in rows]

    def needing_review(self) -> list[QuarantineRecord]:
        return [r for r in self.all() if r.needs_human_review]
