"""FAZ 6 (docs/claude-audit/20_...) — deterministic schema-inference foundation.

ADVISORY / DORMANT. Hiçbir üretim modülü (``app.services.loader``,
``app.services.column_mapper``, ``app.core.reconciler``,
``app.services.reconciliation_service``) bu paketi import ETMEZ ve bu paket
hiçbirini import ETMEZ. Bu, "üretim matching semantiği değişmedi" iddiasını
kod seviyesinde KANITLAR: aralarında hiçbir import kenarı yoktur.

Amaç: bilinmeyen ERP/muhasebe export şemalarının kolonlarını, hangi rolü
taşıdıklarını DETERMİNİSTİK biçimde tahmin etmek, kanıt+güven+alternatif
taşıyan bir öneri üretmek — mapping'i OTOMATİK OLARAK production'a
UYGULAMADAN. Hiçbir LLM/ML bileşeni yoktur.
"""

from __future__ import annotations

from .evidence import EvidenceType, FieldEvidence
from .inference import (
    GENERIC_TR_CARI,
    RoleAssignment,
    SchemaInferenceResult,
    SchemaOverride,
    SourceProfile,
    apply_overrides,
    infer_schema,
)
from .profiling import ColumnProfile, DateFormatHypothesis, NumericLocale, build_column_profile
from .roles import ROLE_STATUS, RoleImplementationStatus, SemanticRole
from .scoring import RoleCandidate, ScoreReason

__all__ = [
    "EvidenceType",
    "FieldEvidence",
    "GENERIC_TR_CARI",
    "RoleAssignment",
    "SchemaInferenceResult",
    "SchemaOverride",
    "SourceProfile",
    "apply_overrides",
    "infer_schema",
    "ColumnProfile",
    "DateFormatHypothesis",
    "NumericLocale",
    "build_column_profile",
    "ROLE_STATUS",
    "RoleImplementationStatus",
    "SemanticRole",
    "RoleCandidate",
    "ScoreReason",
]
