"""PHASE C — mutabakat mektubu PDF şablonu: yükleme, alan haritası, temizlik.

Bu modül PDF ÜRETMEZ; yalnızca şablonu tanımlar ve güvenli olup olmadığını
doğrular. Üretim ``reconciliation_letter_writer.py`` içindedir.

TEMİZLİK NEDEN KRİTİK
    Elimizdeki örnek şablon (oRNEK.pdf) görünmeyen ama content stream'de
    duran ~317 vektör glif taşıyor: önceki bir müşterinin firma kodu, adı ve
    bakiyeleri. Bunlar beyaz kutuyla değil KIRPMA (``W* n``) ile gizlenmiş;
    yani render'da görünmüyor ama dosyanın içinde. Herhangi bir PDF
    düzenleyicide kırpma kaldırılınca ortaya çıkar.

    Kural: gizlemek silmek değildir. Bir şablon, alan bölgelerinde mavi yer
    tutucu dışında boya taşıyorsa KİRLİ sayılır ve üretime giremez.

Doğrulama yalnızca mevcut ``pdfplumber`` ile yapılır; harici program,
Ghostscript/Poppler/PyMuPDF ya da web servisi kullanılmaz.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Sequence

from app.utils.paths import external_config_dir

# Şablondaki yer tutucu mavisi. Aynı metin iki farklı yuvarlamayla gömülmüş
# olabildiği için tolerans ile karşılaştırılır.
PLACEHOLDER_BLUE = (0.0, 0.47, 0.83)
_COLOR_TOL = 0.04

# Alan kutusunun kenarına değen kılpayı nesneleri kirlilik saymamak için
# kutuyu bu kadar içeri çekeriz.
_INSET = 1.0

_PROJECT_ROOT = Path(__file__).resolve().parents[2]


class TemplateError(RuntimeError):
    """Şablon kaynaklı hatalar için ortak taban."""

    code = "TEMPLATE_ERROR"


class MissingTemplateError(TemplateError):
    """Şablon dosyası ya da yapılandırması yok."""

    def __init__(self, message: str, code: str) -> None:
        super().__init__(message)
        self.code = code


class DirtyTemplateError(TemplateError):
    """Şablon, alan bölgelerinde eski/gizli içerik taşıyor."""

    code = "DIRTY_TEMPLATE"

    def __init__(self, message: str, report: "CleanlinessReport") -> None:
        super().__init__(message)
        self.report = report


@dataclass(frozen=True)
class FieldBox:
    """Bir doldurma alanı. Kutu SOL-ÜST orijinlidir."""

    name: str
    x0: float
    y0: float
    x1: float
    y1: float
    size: float
    min_size: float
    max_width: float
    align: str = "left"          # "left" | "right" | "center"
    # Şablonun statik metni bazen noktalama beklemez; ör. İngilizce mektupta
    # "...as of the [tarih]. Please let us know" cümlesindeki nokta yer
    # tutucunun içindedir ve bizim yazmamız gerekir.
    prefix: str = ""
    suffix: str = ""

    @property
    def center_x(self) -> float:
        return (self.x0 + self.x1) / 2

    def render(self, text: str) -> str:
        return f"{self.prefix}{text}{self.suffix}" if text else text

    @property
    def baseline_top(self) -> float:
        """Metnin taban çizgisi (sol-üst eksende)."""
        return self.y1

    def cover(self, padding: float) -> tuple[float, float, float, float]:
        return (self.x0 - padding, self.y0 - padding,
                self.x1 + padding, self.y1 + padding)


@dataclass(frozen=True)
class BalanceBlock:
    """Bakiye satırlarının bloğu."""

    x0: float
    y0: float
    x1: float
    y1: float
    line_step: float
    max_lines: int
    size: float
    min_size: float
    max_width: float
    cover_box: tuple[float, float, float, float]

    @property
    def baseline_top(self) -> float:
        return self.y1

    def line_baseline(self, index: int) -> float:
        return self.y1 + index * self.line_step


@dataclass
class PdfTemplate:
    """Bir dile ait şablon tanımı."""

    locale: str
    pdf_path: Path
    page_width: float
    page_height: float
    font_regular: str
    font_bold: str
    font_regular_file: Optional[str]
    font_bold_file: Optional[str]
    cover_padding: float
    date_format: str
    fields: dict[str, FieldBox] = field(default_factory=dict)
    balances: Optional[BalanceBlock] = None
    # Şablonda kapatılması gereken yer tutucu var mı? Boş bir şablonda beyaz
    # dikdörtgen çizmek, konum bir tık kayarsa gerçek içeriği siler.
    cover_placeholders: bool = True

    def to_reportlab_y(self, y_top: float) -> float:
        """Sol-üst eksendeki y'yi ReportLab'in sol-alt eksenine çevir."""
        return self.page_height - y_top

    def all_boxes(self) -> list[tuple[float, float, float, float]]:
        """Temizlik kontrolünde taranacak tüm alan kutuları."""
        boxes = [(f.x0, f.y0, f.x1, f.y1) for f in self.fields.values()]
        if self.balances is not None:
            b = self.balances
            boxes.append((b.x0, b.y0, b.x1,
                          b.y1 + (b.max_lines - 1) * b.line_step))
        return boxes


# --- yapılandırma yükleme ---------------------------------------------------

def config_path(locale: str, config_dir: Optional[Path] = None) -> Path:
    name = f"pdf_template_{locale}.yaml"
    if config_dir:
        return Path(config_dir) / name
    external = external_config_dir() / name
    if external.is_file():
        return external
    return _PROJECT_ROOT / "config" / name


def _missing_code(locale: str) -> str:
    return f"MISSING_{locale.upper()}_LETTER_TEMPLATE"


def load_template(
    locale: str,
    config_dir: Optional[Path] = None,
    project_root: Optional[Path] = None,
) -> PdfTemplate:
    """Dile ait şablon tanımını yükle.

    Yapılandırma ya da PDF yoksa ``MissingTemplateError`` fırlatır; kodu
    ``MISSING_TR_LETTER_TEMPLATE`` biçimindedir, böylece çağıran taraf firmayı
    uyarı listesine koyabilir.
    """
    cfg = config_path(locale, config_dir)
    if not cfg.exists():
        raise MissingTemplateError(
            f"'{locale}' dili için şablon yapılandırması yok: {cfg.name}",
            _missing_code(locale),
        )

    import yaml  # PyYAML — projede zaten var

    data = yaml.safe_load(cfg.read_text(encoding="utf-8")) or {}
    root = Path(project_root) if project_root else _PROJECT_ROOT
    pdf_path = root / str(data.get("template", ""))
    if not pdf_path.exists():
        raise MissingTemplateError(
            f"'{locale}' şablon PDF'i bulunamadı: {pdf_path}",
            _missing_code(locale),
        )

    page = data.get("page") or {}
    font = data.get("font") or {}

    fields: dict[str, FieldBox] = {}
    for name, spec in (data.get("fields") or {}).items():
        box = spec["box"]
        fields[name] = FieldBox(
            name=name,
            x0=float(box[0]), y0=float(box[1]),
            x1=float(box[2]), y1=float(box[3]),
            size=float(spec.get("size", 10)),
            min_size=float(spec.get("min_size", 7)),
            max_width=float(spec.get("max_width", 200)),
            align=str(spec.get("align", "left")).lower(),
            prefix=str(spec.get("prefix", "")),
            suffix=str(spec.get("suffix", "")),
        )

    balances = None
    bspec = data.get("balances")
    if bspec:
        box = bspec["box"]
        cover = bspec.get("cover_box", box)
        balances = BalanceBlock(
            x0=float(box[0]), y0=float(box[1]),
            x1=float(box[2]), y1=float(box[3]),
            line_step=float(bspec.get("line_step", 9.7)),
            max_lines=int(bspec.get("max_lines", 7)),
            size=float(bspec.get("size", 8)),
            min_size=float(bspec.get("min_size", 7)),
            max_width=float(bspec.get("max_width", 400)),
            cover_box=tuple(float(v) for v in cover),  # type: ignore[arg-type]
        )

    return PdfTemplate(
        locale=str(data.get("locale", locale)),
        pdf_path=pdf_path,
        page_width=float(page.get("width", 595.32)),
        page_height=float(page.get("height", 841.92)),
        font_regular=str(font.get("regular", "Vera")),
        font_bold=str(font.get("bold", "VeraBd")),
        font_regular_file=font.get("regular_file"),
        font_bold_file=font.get("bold_file"),
        cover_padding=float(data.get("cover_padding", 1.2)),
        date_format=str(data.get("date_format", "%d/%m/%Y")),
        fields=fields,
        balances=balances,
        cover_placeholders=bool(data.get("cover_placeholders", True)),
    )


# --- temizlik doğrulaması ---------------------------------------------------

@dataclass
class CleanlinessReport:
    """Bir şablonun alan bölgelerinde yabancı içerik taşıyıp taşımadığı."""

    path: Path
    is_clean: bool
    total_objects: int = 0
    hidden_objects: int = 0
    offending_boxes: list[tuple[float, float, float, float]] = field(
        default_factory=list)
    detail: list[str] = field(default_factory=list)
    # Sayfa yalnızca görüntüden mi oluşuyor? Öyleyse nesne taraması hiçbir şey
    # bulamaz; "temiz" sonucu KANIT DEĞİL, yalnızca "vektör artık yok" demektir.
    image_backed: bool = False

    @property
    def verified(self) -> bool:
        """Temizlik gerçekten DOĞRULANABİLDİ mi?

        Taranmış (yalnızca görüntü) şablonlarda eski veri piksellere gömülü
        olabilir; OCR kullanmadan bunu kanıtlamak mümkün değildir.
        """
        return self.is_clean and not self.image_backed

    def message(self) -> str:
        if not self.is_clean:
            return (
                f"{self.path.name}: KİRLİ — alan bölgelerinde mavi yer tutucu "
                f"dışında {self.hidden_objects} nesne var. "
                + " ".join(self.detail[:6])
            )
        if self.image_backed:
            return (
                f"{self.path.name}: vektör/metin artığı yok, ancak sayfa "
                "taranmış görüntüden oluşuyor — içerik piksellere gömülü "
                "olduğu için temizlik OTOMATİK DOĞRULANAMAZ; görsel kontrol "
                "gerekir."
            )
        return f"{self.path.name}: temiz ({self.total_objects} nesne)."


def _as_rgb(value) -> Optional[tuple[float, ...]]:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return (float(value),) * 3
    try:
        vals = tuple(float(v) for v in value)
    except (TypeError, ValueError):
        return None
    if len(vals) == 1:
        return vals * 3
    if len(vals) == 4:  # CMYK -> kabaca RGB
        c, m, y, k = vals
        return (1 - min(1, c + k), 1 - min(1, m + k), 1 - min(1, y + k))
    return vals if len(vals) == 3 else None


def _is_placeholder_blue(color) -> bool:
    rgb = _as_rgb(color)
    if rgb is None or len(rgb) != 3:
        return False
    return all(abs(a - b) < _COLOR_TOL for a, b in zip(rgb, PLACEHOLDER_BLUE))


def _is_white(color) -> bool:
    rgb = _as_rgb(color)
    return rgb is not None and all(v > 0.95 for v in rgb)


def _colors(obj) -> list:
    """Nesnenin GERÇEKTEN boyadığı renkler.

    PDF'te bir nesne yalnızca dolduruluyorsa ``stroking_color`` sayfada iz
    bırakmaz (varsayılan siyahtır ve yanıltıcıdır). Karakterler her zaman
    dolguyla çizilir. Bu ayrım yapılmazsa mavi yer tutucular bile "siyah iz"
    sanılır.
    """
    out = []
    if obj.get("object_type") == "char":
        val = obj.get("non_stroking_color")
        if val is not None:
            out.append(val)
        return out
    if obj.get("fill"):
        val = obj.get("non_stroking_color")
        if val is not None:
            out.append(val)
    if obj.get("stroke"):
        val = obj.get("stroking_color")
        if val is not None:
            out.append(val)
    return out


def _intersects(obj, box: Sequence[float], inset: float = _INSET) -> bool:
    x0, y0, x1, y1 = box
    x0, y0, x1, y1 = x0 + inset, y0 + inset, x1 - inset, y1 - inset
    if x1 <= x0 or y1 <= y0:
        return False
    return not (obj["x1"] <= x0 or obj["x0"] >= x1
                or obj["bottom"] <= y0 or obj["top"] >= y1)


def verify_template_clean(
    pdf_path: str | Path,
    template: Optional[PdfTemplate] = None,
    boxes: Optional[Sequence[Sequence[float]]] = None,
) -> CleanlinessReport:
    """Şablonun alan bölgelerinde yabancı boya olup olmadığını denetle.

    Temiz kabul edilme koşulu: doldurma alanlarının içinde yalnızca yer tutucu
    mavisi (ya da beyaz) bulunabilir. Siyah/başka renkte herhangi bir çizim ya
    da karakter, önceki bir mektuptan kalan veri demektir — kırpmayla gizlenmiş
    olsa bile.
    """
    import pdfplumber

    path = Path(pdf_path)
    target_boxes = list(boxes) if boxes is not None else (
        template.all_boxes() if template is not None else [])

    report = CleanlinessReport(path=path, is_clean=True)

    with pdfplumber.open(path) as pdf:
        for page_no, page in enumerate(pdf.pages, start=1):
            painted = (list(page.chars) + list(page.rects)
                       + list(page.curves) + list(page.lines))
            report.total_objects += len(painted)
            # Hiç vektör/metin yok ama görsel var -> taranmış sayfa.
            if not painted and page.images:
                report.image_backed = True
            if not target_boxes:
                continue
            for box in target_boxes:
                offenders = []
                for obj in painted:
                    if not _intersects(obj, box):
                        continue
                    cols = _colors(obj)
                    if not cols:
                        continue
                    if all(_is_placeholder_blue(c) or _is_white(c)
                           for c in cols):
                        continue
                    offenders.append(obj)
                if offenders:
                    report.is_clean = False
                    report.hidden_objects += len(offenders)
                    report.offending_boxes.append(tuple(box))  # type: ignore
                    report.detail.append(
                        f"s{page_no} kutu({box[0]:.0f},{box[1]:.0f})-"
                        f"({box[2]:.0f},{box[3]:.0f}): {len(offenders)} nesne."
                    )
    return report


def require_clean_template(template: PdfTemplate) -> CleanlinessReport:
    """Şablon kirliyse ``DirtyTemplateError`` fırlat."""
    report = verify_template_clean(template.pdf_path, template)
    if not report.is_clean:
        raise DirtyTemplateError(report.message(), report)
    return report
