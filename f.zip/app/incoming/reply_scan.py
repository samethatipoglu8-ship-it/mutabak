"""«Gelen Maillerin Dönüşlerini Tespit Et» — uçtan uca orkestrasyon.

AKIŞ
    Mail günlüğü (gönderdiklerimiz)
        ↓  MailTracker           — kapsam: yalnızca takip edilen zincirler
    Gelen kutusu
        ↓  filter_relevant       — ilgisiz mail hiç işlenmez (AI'ya gitmez)
        ├── DELIVERY_FAILURE     → kayıt DELIVERY_FAILED (AI ÇAĞRILMAZ)
        ├── AUTOMATIC_REPLY      → cevap sayılmaz (AI ÇAĞRILMAZ)
        └── CUSTOMER_REPLY
                ↓  IncomingMailPipeline   — parser + gerekirse AI (idempotent)
                ↓  StatementReconciliationService — MEVCUT mutabakat motoru
                ↓  evaluate_case          — cevap ile rakamı çelişki için karşılaştır
        ↓
    ScanResult (+ özet)

TASARIM
    * Qt ve Outlook BİLMEZ: arka plan thread'inde güvenle çalışır, testte
      sahte maillerle sürülebilir.
    * Bir mailin hatası partiyi DURDURMAZ (§32): o kayıt insan incelemesine
      düşer, tarama devam eder.
    * İptal KOOPERATİFTİR: yarım iş kaydedilmez.
    * AI yalnızca gerçek müşteri cevapları için ve yalnızca Python yetersizse
      çağrılır; teslim hatası/otomatik yanıt için hiç çağrılmaz.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional, Sequence

from loguru import logger

from app.incoming.echo import mark_echo_attachments, sent_hashes_of
from app.incoming.models import (
    AIReviewStatus,
    IncomingMail,
    ReconciliationResponse,
    ReplyType,
)
from app.incoming.tracking import MailKind, MailTracker, MatchResult
from app.services.case_outcome import CaseEvaluation, CaseOutcome, evaluate_case
from app.services.final_status import FinalStatus
from app.services.financial_guard import (
    TolerancePolicy,
    check_preconditions,
    select_statement,
)
from app.services.mail_status import MailStatus
from app.services.sent_statement_reconciliation import ComparisonReference
from app.services.statement_reconciliation import (
    StatementReconciliationResult,
    StatementReconciliationService,
    StatementStatus,
)


@dataclass
class ScanItem:
    """Tek bir gelen mailin tüm işlenme sonucu (kanıt zinciriyle)."""

    mail: IncomingMail
    match: MatchResult
    response: Optional[ReconciliationResponse] = None
    statements: list[StatementReconciliationResult] = field(default_factory=list)
    evaluation: Optional[CaseEvaluation] = None
    error: str = ""
    # FAZ 4 — gelen ekstrenin, o firmaya GÖNDERİLEN snapshot'a göre sonucu.
    # Finansal kararın ASIL referansı budur; ``statements`` yalnızca
    # snapshot yoksa devreye giren eski (genel TOFAŞ) yoldur.
    snapshot_comparison: Optional[object] = None
    # Teslim hatasının adres kararı (bkz. app/services/invalid_address.py).
    # Vaka kaydına GEÇERSİZ_ADRES olarak işlenir.
    address_decision: Optional[object] = None
    # Finansal ön koşul sonucu (firma/dönem/para birimi/yön eşleşmesi).
    precondition: Optional[object] = None
    # Birden fazla ekstre eki farklı toplam gösterdi mi?
    statement_conflict: bool = False
    # Cevaba geri eklenmiş KENDİ gönderdiğimiz ek sayısı (echo).
    # Bu ekler mektup/ekstre olarak değerlendirilmez.
    echo_attachments: int = 0

    @property
    def company_code(self) -> str:
        if self.match.tracked is not None:
            return self.match.tracked.company_code
        if self.response is not None and self.response.company_code:
            return self.response.company_code
        return ""

    @property
    def period(self) -> str:
        return self.match.tracked.period if self.match.tracked else ""

    @property
    def send_id(self) -> str:
        """Cevabın bağlandığı GÖNDERİMİN kimliği (belirsizse boş)."""
        return self.match.tracked.send_id if self.match.tracked else ""

    @property
    def snapshot_id(self) -> str:
        """Karşılaştırmada kullanılacak snapshot'ın kimliği (belirsizse boş)."""
        return self.match.tracked.snapshot_id if self.match.tracked else ""

    @property
    def responsible(self) -> str:
        """Mutabakat Mailleri Excel'indeki (R) sorumlusu — mailden TAHMİN EDİLMEZ."""
        return self.match.tracked.responsible if self.match.tracked else ""

    @property
    def status(self) -> MailStatus:
        if self.evaluation is not None:
            return self.evaluation.mail_status
        if self.match.kind is MailKind.DELIVERY_FAILURE:
            return MailStatus.DELIVERY_FAILED
        if self.match.kind is MailKind.AUTOMATIC_REPLY:
            return MailStatus.AUTOMATIC_REPLY
        return MailStatus.UNKNOWN

    @property
    def best_statement(self) -> Optional[StatementReconciliationResult]:
        """Ekstre olarak işlenebilmiş ilk ek (varsa)."""
        for statement in self.statements:
            if statement.status in (StatementStatus.MATCHED,
                                    StatementStatus.DIFFERENCE):
                return statement
        return self.statements[0] if self.statements else None

    @property
    def decision(self):
        """Sade nihai karar (MUTABIK / RED / İNCELEME / CEVAP BEKLENİYOR).

        Teknik ``CaseOutcome`` silinmez; bu yalnızca ekran için üretilen
        sadeleştirmedir ve şüpheli her durumu İNCELEME'ye çeker.
        """
        from app.services.final_status import decide

        return decide(self.evaluation,
                      snapshot_comparison=self.snapshot_comparison,
                      ambiguous_send=self.match.ambiguous,
                      response=self.response)

    @property
    def final_status(self):
        return self.decision.status

    def why(self) -> list[str]:
        """«Bu kayıt neden burada?» — kullanıcıya gösterilecek gerekçeler."""
        lines: list[str] = []
        if self.match.method.value != "NONE":
            lines.append(f"Eşleştirme: {self.match.method.value} "
                         f"(güven {self.match.confidence:.0%})")
        if self.match.reason:
            lines.append(self.match.reason)
        if self.match.failure is not None and self.match.failure.is_failure:
            lines.append(self.match.failure.describe())
        if self.evaluation is not None:
            lines.extend(self.evaluation.reasons)
        if self.error:
            lines.append(f"Hata: {self.error}")
        return lines


@dataclass
class ScanSummary:
    """Tarama sonunda kullanıcıya gösterilen profesyonel özet (§28)."""

    taranan_mail: int = 0
    ilgisiz_atlanan: int = 0
    takip_edilen_mutabakat: int = 0

    yeni_cevap: int = 0
    teslim_edilemeyen: int = 0
    otomatik_cevap: int = 0
    ekstre_alinan: int = 0

    mutabik: int = 0
    mutabik_degil: int = 0
    celiski: int = 0
    inceleme_gerekli: int = 0
    ai_basarisiz: int = 0
    onbellekten: int = 0
    hatali: int = 0

    # FAZ 5 — ekranda gösterilen sade durumların dağılımı.
    nihai_mutabik: int = 0
    nihai_red: int = 0
    nihai_inceleme: int = 0
    nihai_cevap_bekleniyor: int = 0
    # Karşılaştırmanın GÖNDERİLEN snapshot ile yapılabildiği kayıt sayısı.
    snapshot_ile_karsilastirilan: int = 0

    def as_lines(self) -> list[str]:
        return [
            f"Taranan mail: {self.taranan_mail}",
            f"İlgisiz (atlandı): {self.ilgisiz_atlanan}",
            f"Takip edilen mutabakat: {self.takip_edilen_mutabakat}",
            f"Yeni cevap: {self.yeni_cevap}",
            f"Teslim edilemeyen: {self.teslim_edilemeyen}",
            f"Otomatik cevap: {self.otomatik_cevap}",
            f"Ekstre/ek alınan: {self.ekstre_alinan}",
            f"Mutabık: {self.mutabik}",
            f"Mutabık değil: {self.mutabik_degil}",
            f"Çelişkili: {self.celiski}",
            f"İnceleme gerekli: {self.inceleme_gerekli}",
            f"AI başarısız: {self.ai_basarisiz}",
            f"Önbellekten (tekrar işlenmedi): {self.onbellekten}",
            f"Hatalı: {self.hatali}",
            f"Snapshot ile karşılaştırılan: "
            f"{self.snapshot_ile_karsilastirilan}",
            f"NİHAİ — Mutabık: {self.nihai_mutabik} · "
            f"Red: {self.nihai_red} · İnceleme: {self.nihai_inceleme} · "
            f"Cevap bekleniyor: {self.nihai_cevap_bekleniyor}",
        ]


@dataclass
class ScanResult:
    items: list[ScanItem] = field(default_factory=list)
    summary: ScanSummary = field(default_factory=ScanSummary)
    cancelled: bool = False

    def attention_items(self) -> list[ScanItem]:
        """Kullanıcının bakması gereken kayıtlar (önce en kritik)."""
        order = {
            CaseOutcome.DELIVERY_FAILED: 0,
            CaseOutcome.CONTRADICTION: 1,
            CaseOutcome.DIFFERENCE: 2,
            CaseOutcome.HUMAN_REVIEW: 3,
        }
        flagged = [i for i in self.items
                   if i.evaluation is not None and i.evaluation.needs_human_review
                   or i.match.kind is MailKind.DELIVERY_FAILURE or i.error]
        return sorted(
            flagged,
            key=lambda i: (order.get(
                i.evaluation.outcome if i.evaluation else CaseOutcome.HUMAN_REVIEW,
                9), i.company_code))


class ReplyScanService:
    """Gelen kutusundaki mutabakat dönüşlerini uçtan uca işler."""

    def __init__(
        self,
        tracker: MailTracker,
        pipeline=None,
        statement_service: Optional[StatementReconciliationService] = None,
        tofas_records: Sequence = (),
        snapshot_store=None,
        case_store=None,
        attachment_store=None,
        address_registry=None,
        policy=None,
        settings=None,
    ) -> None:
        self._tracker = tracker
        self._pipeline = pipeline
        # ŞİRKET POLİTİKASI: yuvarlama toleransı ve eşleşme kuralları
        # ayarlardan gelir; koda gömülü değildir (bkz. financial_guard).
        self._policy = policy or TolerancePolicy.from_settings(settings)
        self._statements = statement_service or StatementReconciliationService(
            amount_tolerance=self._policy.amount_tolerance,
            date_tolerance_days=self._policy.date_tolerance_days,
            strict_currency=self._policy.strict_currency)
        self._tofas_records = list(tofas_records)
        # Beklenen para birimleri (bkz. _expected_currencies) — tembel önbellek.
        self._expected_currency_cache = None
        # Snapshot deposu verilirse finansal karşılaştırmanın referansı
        # "o firmaya gönderilen gerçek paket" olur. Verilmezse sistem eski
        # davranışına (genel TOFAŞ kayıtları) düşer — geriye dönük uyum.
        self._snapshot_store = snapshot_store
        # Gelen cevapların kalıcı iş kaydı. Verilmezse sonuçlar yalnızca
        # bellekte kalır (eski davranış).
        self._case_store = case_store
        self._address_registry = address_registry
        if address_registry is None and case_store is not None:
            try:
                from app.services.address_registry import AddressRegistry

                self._address_registry = AddressRegistry()
            except Exception as exc:  # noqa: BLE001 - tarama durmaz
                logger.warning(f"[dönüş-tarama] adres defteri açılamadı: {exc}")
        # Gelen ekler DİSKE alınır: "Karşılaştır" butonu tarama bittikten
        # saatler sonra da çalışabilmelidir. Depo verilmezse (eski davranış)
        # ekler yalnızca tarama sırasında bellekte yaşar.
        self._attachment_store = attachment_store
        if attachment_store is None and case_store is not None:
            try:
                from app.services.incoming_attachments import (
                    IncomingAttachmentStore,
                )

                self._attachment_store = IncomingAttachmentStore()
            except Exception as exc:  # noqa: BLE001 - tarama durmaz
                logger.warning(f"[dönüş-tarama] ek deposu açılamadı: {exc}")
        self._sent_service = None
        if snapshot_store is not None:
            from app.services.sent_statement_reconciliation import (
                SentStatementReconciliationService,
            )

            self._sent_service = SentStatementReconciliationService(
                snapshot_store, statement_service=self._statements)

    def scan(
        self,
        mails: Sequence[IncomingMail],
        on_progress: Optional[Callable[[int, int, IncomingMail], None]] = None,
        should_cancel: Optional[Callable[[], bool]] = None,
    ) -> ScanResult:
        """Mailleri sırayla işle. İSTİSNA FIRLATMAZ."""
        result = ScanResult()
        result.summary.taranan_mail = len(mails)
        result.summary.takip_edilen_mutabakat = self._tracker.tracked_count

        total = len(mails)
        for index, mail in enumerate(mails, start=1):
            if should_cancel is not None and should_cancel():
                result.cancelled = True
                break
            try:
                item = self._process_one(mail, should_cancel)
            except Exception as exc:  # noqa: BLE001 - tek mail partiyi düşürmesin
                logger.exception("[dönüş-tarama] mail işlenemedi.")
                item = ScanItem(mail=mail, match=self._tracker.match(mail),
                                error=f"{type(exc).__name__}: {exc}")
            if item is not None:
                result.items.append(item)
                self._persist(item)
            if on_progress is not None:
                try:
                    on_progress(index, total, mail)
                except Exception:  # noqa: BLE001 - ilerleme kritik değil
                    pass

        self._summarize(result)
        return result

    # -- tek mail -----------------------------------------------------------

    def _process_one(self, mail: IncomingMail,
                     should_cancel: Optional[Callable[[], bool]]
                     ) -> Optional[ScanItem]:
        match = self._tracker.match(mail)

        # 1) İlgisiz mail: hiç işlenmez (ek indirilmez, AI çağrılmaz).
        if not match.should_process:
            return ScanItem(mail=mail, match=match)

        item = ScanItem(mail=mail, match=match)

        # 2) Teslim hatası: müşteri cevabı DEĞİLDİR; AI'ya gitmez.
        if match.kind is MailKind.DELIVERY_FAILURE:
            item.evaluation = evaluate_case(delivery_failed=True)
            failure = match.failure
            # Adres kararı TEK yerde verilir: defter kaydı, vaka durumu ve
            # hatırlatma engeli aynı kuraldan doğar (invalid_address).
            from app.services.invalid_address import decide, record_in_registry

            item.address_decision = decide(failure)
            if item.address_decision.block:
                record_in_registry(
                    self._address_registry, item.address_decision,
                    company_code=(match.tracked.company_code
                                  if match.tracked else ""))
                item.evaluation.add_reason(
                    "Adres GEÇERSİZ_ADRES durumuna alındı; yeni iletişim "
                    "adresi girilmeden hatırlatma gönderilmez ve vaka "
                    "kapatılamaz.")
            elif (failure is not None and failure.failed_recipient
                    and self._address_registry is not None):
                # Geçici hata adresi KAPATMAZ ama sayılır: aynı adres üst üste
                # patlıyorsa kullanıcı bunu görebilmelidir.
                try:
                    self._address_registry.record_failure(
                        failure.failed_recipient, permanent=False,
                        reason=failure.describe(),
                        company_code=(match.tracked.company_code
                                      if match.tracked else ""))
                except Exception as exc:  # noqa: BLE001 - parti durmaz
                    logger.warning(
                        f"[dönüş-tarama] NDR adresi kaydedilemedi: {exc}")
            return item

        # 3) Otomatik yanıt: cevap sayılmaz; AI'ya gitmez.
        if match.kind is MailKind.AUTOMATIC_REPLY:
            item.evaluation = evaluate_case(automatic_reply=True)
            return item

        # 3b) Hangi gönderime cevap verildiği belirsiz: hiçbir snapshot
        # "muhtemelen budur" diye seçilmez. Yanlış snapshot ile yapılan
        # karşılaştırma, karşılaştırma yapmamaktan DAHA KÖTÜDÜR.
        if match.ambiguous:
            item.evaluation = evaluate_case(replied=True)
            item.evaluation.outcome = CaseOutcome.HUMAN_REVIEW
            item.evaluation.mail_status = MailStatus.HUMAN_REVIEW
            item.evaluation.needs_human_review = True
            item.evaluation.add_reason(match.reason)
            item.evaluation.add_reason(
                "Birden fazla geçerli gönderim adayı olduğu için ekstre "
                "karşılaştırması YAPILMADI.")
            return item

        # 3.5) GERİ DÖNEN KENDİ EKLERİMİZİ AYIKLA — parser'dan ÖNCE.
        #
        # Outlook cevap verirken orijinal ekleri geri yollar. Bizim kendi
        # mutabakat mektubumuz içerikçe "mektup"tur ve doldurulmuşluk
        # sinyallerini (firma kodu, bakiye, tarih, şirket eki) zaten BİZ
        # yazdık; işaretlenmezse parser onu "firma mektup gönderdi ve dolu"
        # diye okur. Bayt kimliği (SHA-256) bu konuda içerik sezgisinden
        # daha güçlü bir kanıttır, bu yüzden sınıflandırmadan ÖNCE uygulanır.
        #
        # Snapshot bulunamazsa hiçbir şey işaretlenmez ve davranış eskisiyle
        # aynı kalır — sessiz bir kötüleşme yoktur.
        item.echo_attachments = self._mark_echo(mail, match)

        # 4) Gerçek müşteri cevabı → mevcut hat (parser + gerekirse AI).
        reply_type = ReplyType.UNKNOWN
        if self._pipeline is not None:
            item.response = self._pipeline.process(mail, should_cancel)
            reply_type = item.response.reply_type

        # 5) Ekler → MEVCUT mutabakat motoru (finansal kararın kaynağı).
        #
        # ÖNCELİK: bu firmaya GÖNDERİLEN snapshot. Firma, bugünkü dosyamıza
        # değil, kendisine yolladığımız ekstreye cevap verdi; karşılaştırma
        # da o veriyle yapılmalıdır.
        snapshot_result = self._compare_with_snapshot(mail, match, item)
        if snapshot_result is not None:
            item.snapshot_comparison = snapshot_result
            statement = snapshot_result.statement
            if statement is not None:
                item.statements = [statement]
                if statement.status is StatementStatus.NO_STATEMENT:
                    statement = None
            item.evaluation = evaluate_case(
                reply_type=reply_type, statement=statement, replied=True)
            for reason in snapshot_result.explain():
                item.evaluation.add_reason(reason)
            if snapshot_result.needs_human_review:
                item.evaluation.needs_human_review = True
            self._carry_ai_review(item)
            return item

        # SNAPSHOT YOK → eski davranış: bugünkü TOFAŞ kayıtları.
        #
        # ÖNEMLİ: TOFAŞ kayıtları yüklenmemişken motoru çalıştırmak, firmanın
        # gönderdiği HER satırı "yalnızca firmada var" gösterir ve mutabık bir
        # firmayı bile "fark var" diye raporlar. Karşılaştıracak veri yoksa
        # karşılaştırma YAPILMAZ; durum açıkça belirtilir.
        if self._tofas_records:
            item.statements = self._statements.reconcile_mail(
                mail, self._tofas_records)
            # BİRDEN FAZLA EKTE FARKLI TOPLAM → OTOMATİK KARAR YOK.
            secim = select_statement(item.statements, self._policy)
            statement = secim.statement
            item.statement_conflict = secim.conflict
            if secim.conflict:
                item.evaluation = evaluate_case(
                    reply_type=reply_type, statement=None, replied=True)
                item.evaluation.outcome = CaseOutcome.HUMAN_REVIEW
                item.evaluation.mail_status = MailStatus.HUMAN_REVIEW
                item.evaluation.needs_human_review = True
                item.evaluation.add_reason(secim.reason)
                for satir in secim.totals:
                    item.evaluation.add_reason(f"Ek toplamı — {satir}")
                self._carry_ai_review(item)
                return item
        else:
            statement = None
            item.evaluation = evaluate_case(
                reply_type=reply_type, statement=None, replied=True)
            item.evaluation.needs_human_review = True
            item.evaluation.add_reason(
                "TOFAŞ kayıtları yüklenmediği için ekteki ekstre "
                "karşılaştırılamadı.")
            return item
        # Hiç işlenebilir ek yoksa "ekstre gelmedi" demektir.
        if statement is not None and statement.status is StatementStatus.NO_STATEMENT:
            statement = None

        item.evaluation = evaluate_case(
            reply_type=reply_type, statement=statement, replied=True)
        self._apply_preconditions(item, match, statement)
        self._carry_ai_review(item)
        return item

    # -- finansal ön koşullar ----------------------------------------------

    def _expected_currencies(self) -> list[str]:
        """Karşılaştırmaya giren TOFAŞ kayıtlarındaki para birimleri.

        Bir kez hesaplanıp saklanır: her mail için binlerce kaydı yeniden
        taramak partiyi yavaşlatırdı.
        """
        if self._expected_currency_cache is None:
            self._expected_currency_cache = sorted({
                str(getattr(r, "currency", "") or "").strip().upper()
                for r in self._tofas_records
                if str(getattr(r, "currency", "") or "").strip()})
        return list(self._expected_currency_cache)

    def _apply_preconditions(self, item: ScanItem, match, statement) -> None:
        """Firma/dönem/para birimi/yön eşleşmeden otomatik mutabakat YAPILMAZ.

        Ön koşul ihlali sonucu SİLMEZ: motorun bulduğu rakamlar kayıtta
        kalır, yalnızca karar "insan incelemesi"ne çevrilir ve gerekçe
        yazılır. Kullanıcı neyin neden durduğunu görebilmelidir.
        """
        if item.evaluation is None:
            return
        tracked = match.tracked
        response = item.response
        yonler = tuple(getattr(tracked, "directions", ()) or ()) if tracked else ()
        # BEKLENEN PARA BİRİMİ, karşılaştırmaya giren KENDİ kayıtlarımızdan
        # gelir: firmaya hangi para biriminde bakiye sorduysak cevabın da o
        # para biriminde olması beklenir. Kayıtlarımızda birden çok döviz
        # varsa kesişim yeterlidir (bkz. check_preconditions).
        beklenen_pb: list[str] = self._expected_currencies()
        gelen_pb: list[str] = []
        if response is not None:
            gelen_pb = [str(c) for c in (response.currencies or {})]
        if statement is not None and getattr(statement, "analysis", None):
            para = getattr(statement.analysis, "currency", "")
            if para:
                gelen_pb.append(str(para))

        sonuc = check_preconditions(
            expected_company=getattr(tracked, "company_code", "") if tracked else "",
            observed_company=getattr(response, "company_code", "") if response else "",
            expected_period=getattr(tracked, "period", "") if tracked else "",
            observed_period=getattr(response, "period", "") if response else "",
            # Gönderim İKİ yönü birden kapsıyorsa (M ve S) cevabın yönü
            # ikisinden biri olabilir; bu bir uyuşmazlık DEĞİLDİR. Bu yüzden
            # yön kontrolü yalnızca TEK yönlü gönderimlerde yapılır.
            expected_direction=(yonler[0] if len(yonler) == 1 else ""),
            observed_direction=(response.direction.value
                                if response is not None
                                and getattr(response, "direction", None)
                                is not None else ""),
            expected_currencies=beklenen_pb,
            observed_currencies=gelen_pb,
            policy=self._policy,
        )
        item.precondition = sonuc
        if sonuc.ok:
            return
        item.evaluation.outcome = CaseOutcome.HUMAN_REVIEW
        item.evaluation.mail_status = MailStatus.HUMAN_REVIEW
        item.evaluation.needs_human_review = True
        for gerekce in sonuc.blockers:
            item.evaluation.add_reason(gerekce)

    # -- kalıcılık ----------------------------------------------------------

    def _persist(self, item: ScanItem) -> None:
        """Sonucu kalıcı iş kaydına yaz. Yazma hatası taramayı DURDURMAZ.

        İlgisiz mailler kaydedilmez: mutabakat hattına hiç girmemişlerdir.
        """
        if self._case_store is None:
            return
        if item.match.kind is MailKind.UNRELATED:
            return
        try:
            from app.services.incoming_cases import (
                case_from_scan_item,
                record_incoming_mail,
            )

            targets = self._existing_case_targets(item)
            cases = ([case_from_scan_item(item, existing=target)
                      for target in targets]
                     if targets else [case_from_scan_item(item)])
            for case in cases:
                # Gelen ekler kalıcı depoya alınır ve case'e KİMLİKLERİYLE
                # yazılır; eski cevap ekleri kaybolmaz.
                new_attachments = self._store_attachments(item, case)
                known = {(str(meta.get("sha256", "")),
                          str(meta.get("name", "")))
                         for meta in case.incoming_attachments}
                case.incoming_attachments.extend(
                    meta for meta in new_attachments
                    if (str(meta.get("sha256", "")),
                        str(meta.get("name", ""))) not in known)
                # §14 — gelen mail, case'in mail timeline'ına yazılır.
                record_incoming_mail(case, item.mail, case.reply_type)
                case.has_reply = True
                case.last_reply_date = case.received_at
                case.latest_reply_sender = case.sender
                case.latest_reply_subject = case.subject
                case.latest_reply_snippet = (
                    getattr(item.mail, "body", "") or "")[:200]
                self._enrich_case(case, item)
                self._case_store.upsert(case)
        except Exception as exc:  # noqa: BLE001 - kayıt hatası partiyi düşürmez
            logger.error(f"[dönüş-tarama] iş kaydı yazılamadı: {exc}")

    def _existing_case_targets(self, item: ScanItem) -> list:
        """Resolve the seeded send-direction case(s) without guessing.

        M/S replies update that direction, X updates both directions. If the
        response direction is unknown, a single seeded direction is safe; with
        multiple directions we keep a separate review case rather than attach
        the reply to an arbitrary balance.
        """
        if self._case_store is None or not item.send_id:
            return []
        existing = self._case_store.by_send_id(item.send_id)
        seeded = [case for case in existing if case.balance_type or any(
            event.get("direction") == "OUT" for event in case.mail_events)]
        candidates = seeded or existing
        direction = (getattr(getattr(item, "response", None), "direction", None)
                     and item.response.direction.value) or "UNKNOWN"
        if direction in {"M", "S"}:
            return [case for case in candidates
                    if case.balance_type == direction]
        if direction == "X":
            return [case for case in candidates
                    if case.balance_type in {"M", "S", "X"}]
        return candidates if len(candidates) == 1 else []

    @staticmethod
    def _enrich_case(case, item) -> None:
        """Fatura tespiti (§13) ve güven puanı (§11) — her satır için.

        Karşılaştırma yapılmamış olsa bile puan ve açıklama üretilir; boş
        bir puan, "değerlendirilmedi" ile "güvenilir değil"i karıştırır.
        """
        from app.services.case_tracking import detects_invoice, mark_invoice_received
        from app.services.confidence import score_from_case
        from app.services.invalid_address import apply_to_case

        # Teslim edilemeyen adres, VAKAYA da işlenir: yalnız adres defterine
        # yazmak yetmez — hatırlatma engeli ve "kapatılamaz" kuralı vakanın
        # kendi durumundan okunur.
        karar = getattr(item, "address_decision", None)
        if karar is not None:
            apply_to_case(case, karar)

        adlar = [str((meta or {}).get("name", ""))
                 for meta in case.incoming_attachments or []]
        if detects_invoice(getattr(item.mail, "body", "") or "", adlar):
            mark_invoice_received(
                case, detail=f"{len(adlar)} ek ile geldi" if adlar else "")

        puan = score_from_case(case)
        case.confidence_100 = puan.value
        case.confidence_explanation = puan.explanation
        if not case.body_decision:
            from app.services.case_comparison import body_decision_of

            case.body_decision = body_decision_of(case)
        if not case.status_color:
            from app.services.case_tracking import color_for

            case.status_color = color_for(case.final_status)

    def _store_attachments(self, item, case) -> list:
        """Gelen ekleri diske al; (ad, hash, yol) listesini döndür.

        İDEMPOTENT: aynı içerik ikinci kez yazılmaz. Depo yoksa ya da yazma
        başarısız olursa tarama DURMAZ; yalnızca o case için ek kaydı boş
        kalır ve "Karşılaştır" ekstre bulunamadığını söyler — sessiz bir
        "mutabık" üretilmez.
        """
        store = self._attachment_store
        ekler = list(getattr(item.mail, "attachments", None) or [])
        if store is None or not ekler:
            return []
        try:
            saklananlar = store.store_many(
                ekler, case_id=case.case_id,
                message_id=getattr(item.mail, "message_id", "") or "")
            return [s.to_meta() for s in saklananlar]
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                f"[dönüş-tarama] ekler saklanamadı ({case.company_code}): {exc}")
            return []

    # -- snapshot referansı -------------------------------------------------

    def _mark_echo(self, mail, match) -> int:
        """Gelen eklerden, o gönderimde BİZİM yolladıklarımızı işaretle.

        Hash listesi gönderim snapshot'ından gelir (``AttachmentMeta.sha256``);
        orada zaten saklanıyordu, yalnızca karşılaştırılmıyordu.

        Snapshot deposu yoksa, gönderim kimliği yoksa ya da snapshot
        okunamazsa 0 döner ve akış DEĞİŞMEZ.
        """
        store = self._snapshot_store
        tracked = getattr(match, "tracked", None)
        if store is None or tracked is None:
            return 0
        snapshot = None
        try:
            if getattr(tracked, "snapshot_id", ""):
                snapshot = store.get(tracked.snapshot_id)
            if snapshot is None and getattr(tracked, "send_id", ""):
                snapshot = store.by_send_id(tracked.send_id)
        except Exception as exc:  # noqa: BLE001 - echo tespiti taramayı düşürmez
            logger.warning(f"[echo] snapshot okunamadı: {exc}")
            return 0
        if snapshot is None:
            return 0

        hashes = sent_hashes_of(snapshot)
        if not hashes:
            return 0
        sayi = mark_echo_attachments(getattr(mail, "attachments", None), hashes)
        if sayi:
            logger.info(
                f"[echo] {sayi} ek bizim gönderdiğimiz dosyanın kopyası; "
                f"mektup/ekstre olarak DEĞERLENDİRİLMEDİ "
                f"(firma={snapshot.company_code or '-'})")
        return sayi

    def _compare_with_snapshot(self, mail, match, item):
        """Gelen ekstreyi gönderilen snapshot'la karşılaştır.

        ``None`` döner ise snapshot yolu kullanılamamıştır ve çağıran taraf
        eski (genel TOFAŞ) yola düşer. Bu, sessiz bir geri düşüş DEĞİLDİR:
        snapshot bulunamadıysa gerekçe kaydın içinde yazılıdır.
        """
        if self._sent_service is None or match.tracked is None:
            return None
        if not (match.tracked.snapshot_id or match.tracked.send_id):
            return None
        result = self._sent_service.reconcile(
            mail, match.tracked,
            current_tofas_records=self._tofas_records,
            response=item.response)
        # Snapshot hiç bulunamadıysa mevcut davranışı bozmamak için eski yola
        # düşülür; ancak gerekçe kaybolmasın diye kayıt yine iliştirilir.
        if result.reference is ComparisonReference.NONE and not result.error:
            item.snapshot_comparison = result
            return None
        return result

    @staticmethod
    def _carry_ai_review(item: ScanItem) -> None:
        """AI katmanı sonuç veremediyse bu da insana taşınır (AI SPOF değildir)."""
        if item.response is None or item.evaluation is None:
            return
        if item.response.review_status in (
                AIReviewStatus.AI_UNAVAILABLE,
                AIReviewStatus.AI_INVALID_JSON,
                AIReviewStatus.AI_AUTH_FAILED,
                AIReviewStatus.AI_ERROR):
            item.evaluation.needs_human_review = True
            item.evaluation.add_reason(
                "AI katmanı sonuç veremedi; deterministik sonuç geçerlidir.")
        # Parser'ın TÜM insan incelemesi bayrağı taşınmaz: "mail gövdesinde
        # firma kodu yok" gibi boşluklar bu hatta zaten çözülmüştür (cevap
        # belirli bir gönderime bağlanmıştır). Yalnızca gerçek belirsizlikler
        # taşınır — bkz. final_status.BLOCKING_REPLY_REASONS.
        from app.services.final_status import blocking_reply_reasons

        for code in blocking_reply_reasons(item.response):
            item.evaluation.needs_human_review = True
            item.evaluation.add_reason(f"Mail çözümlemesi belirsiz: {code}")

    # -- özet ---------------------------------------------------------------

    @staticmethod
    def _summarize(result: ScanResult) -> None:
        s = result.summary
        for item in result.items:
            kind = item.match.kind
            if kind is MailKind.UNRELATED:
                s.ilgisiz_atlanan += 1
                continue
            if kind is MailKind.DELIVERY_FAILURE:
                s.teslim_edilemeyen += 1
                continue
            if kind is MailKind.AUTOMATIC_REPLY:
                s.otomatik_cevap += 1
                continue

            s.yeni_cevap += 1
            if item.error:
                s.hatali += 1
            if any(x.status in (StatementStatus.MATCHED,
                                StatementStatus.DIFFERENCE)
                   for x in item.statements):
                s.ekstre_alinan += 1
            if item.response is not None:
                if item.response.from_cache:
                    s.onbellekten += 1
                if item.response.review_status in (
                        AIReviewStatus.AI_UNAVAILABLE,
                        AIReviewStatus.AI_INVALID_JSON,
                        AIReviewStatus.AI_AUTH_FAILED,
                        AIReviewStatus.AI_ERROR):
                    s.ai_basarisiz += 1

            evaluation = item.evaluation
            if evaluation is None:
                continue
            if evaluation.outcome is CaseOutcome.RECONCILED:
                s.mutabik += 1
            elif evaluation.outcome is CaseOutcome.DIFFERENCE:
                s.mutabik_degil += 1
            elif evaluation.outcome is CaseOutcome.CONTRADICTION:
                s.celiski += 1
            if evaluation.needs_human_review:
                s.inceleme_gerekli += 1

            # Sade nihai durum dağılımı (ekran ve Oran sayfası için).
            if getattr(item.snapshot_comparison, "compared", False):
                s.snapshot_ile_karsilastirilan += 1
            alan = {
                FinalStatus.MUTABIK: "nihai_mutabik",
                FinalStatus.RED: "nihai_red",
                FinalStatus.INCELEME: "nihai_inceleme",
                FinalStatus.CEVAP_BEKLENIYOR: "nihai_cevap_bekleniyor",
            }[item.final_status]
            setattr(s, alan, getattr(s, alan) + 1)
