"""Mutabakat Pro — PySide6 desktop application.

Pages: Dashboard, Reconciliation, Reports, Settings, Logs.
Heavy work runs in a background thread so the UI never freezes. Every action
is wrapped so an exception shows a friendly message instead of crashing.
"""

from __future__ import annotations

import sys
from decimal import Decimal
from pathlib import Path
from typing import Optional

from loguru import logger
from PySide6.QtCore import QSize, Qt, QThread
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QSizePolicy,
    QSpinBox,
    QStackedWidget,
    QStatusBar,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from app.models.domain import ReconciliationResult
from app.services.settings import Settings
from app.ui.themes import get_theme
from app.ui.worker import PeekWorker, ReconcileWorker, run_in_thread

# Status colors for table rows.
_COLOR_MATCHED = QColor("#2d5a2d")
_COLOR_DIFF = QColor("#5a5327")
_COLOR_ONLY_FIRMA = QColor("#5a2d2d")
_COLOR_ONLY_TOFAS = QColor("#2d3f5a")


def _clamp_window_size(width: object, height: object,
                       available_width: int,
                       available_height: int) -> tuple[int, int]:
    """Kalıcı pencere boyutunu mevcut ekranın kullanılabilir alanına sığdır."""
    try:
        saved_width = int(width)
        saved_height = int(height)
    except (TypeError, ValueError):
        saved_width, saved_height = 1150, 720
    min_width = min(900, available_width)
    min_height = min(640, available_height)
    # Çok geniş bir monitörde kaydedilen boyut, daha düşük çözünürlükte veya
    # farklı DPI ölçeğinde geri yüklendiğinde Qt'nin kullanılabilir geometri
    # hesabı Windows yakalama alanından büyük kalabiliyor.  Ana çalışma alanını
    # 1440 px ile sınırlamak hem tüm gezinme öğelerini hem 3x3 eylem ızgarasını
    # tek ekranda tutar; kullanıcı isterse pencereyi sonradan büyütebilir.
    max_width = min(1440, available_width)
    return (
        max(min_width, min(saved_width, max_width)),
        max(min_height, min(saved_height, available_height)),
    )


class DropLineEdit(QLineEdit):
    """Line edit that accepts a dropped file path."""

    def __init__(self, placeholder: str) -> None:
        super().__init__()
        self.setPlaceholderText(placeholder)
        self.setReadOnly(True)
        self.setAcceptDrops(True)

    def dragEnterEvent(self, event) -> None:  # noqa: N802
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event) -> None:  # noqa: N802
        urls = event.mimeData().urls()
        if urls:
            self.setText(urls[0].toLocalFile())


class StatCard(QFrame):
    """A dashboard statistics card."""

    def __init__(self, label: str, value: str = "0") -> None:
        super().__init__()
        self.setObjectName("StatCard")
        lay = QVBoxLayout(self)
        self._value = QLabel(value)
        self._value.setObjectName("StatCardValue")
        lbl = QLabel(label)
        lbl.setObjectName("StatCardLabel")
        lay.addWidget(self._value)
        lay.addWidget(lbl)

    def set_value(self, value: str) -> None:
        self._value.setText(value)


class _ResponsiveStack(QStackedWidget):
    """Farklı Qt stillerinin gizli sayfalardan gelen aşırı minimumunu sınırla.

    ``QStackedWidget`` tüm sayfaların en büyük ``minimumSizeHint`` değerini
    ana pencereye aktarır. Windows/offscreen stillerinde, görünür olmayan bir
    tablo veya dört kartlık ızgara 1400 px'ten büyük bir minimum üretebiliyor;
    böylece pencere 1366 px ekranda dahi küçülemiyordu. Sayfalar zaten kendi
    genişliklerine göre yerleşir; yığın yalnızca bu platforma bağlı alt sınırı
    ana pencereye zorla taşımamalıdır.
    """

    _MINIMUM_WIDTH_CAP = 900
    _MINIMUM_HEIGHT_CAP = 600

    def minimumSizeHint(self) -> QSize:  # noqa: N802 - Qt API adı
        hint = super().minimumSizeHint()
        return QSize(min(hint.width(), self._MINIMUM_WIDTH_CAP),
                     min(hint.height(), self._MINIMUM_HEIGHT_CAP))


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.settings = Settings()
        # Kalıcı oturum (FAZ 7): açılışta HİÇBİR ŞEY temizlenmez.
        try:
            from app.services.session_state import SessionState

            self.session = SessionState()
        except Exception:  # noqa: BLE001 - oturum hatası uygulamayı açmayı engellemez
            self.session = None
        self.setWindowTitle("Mutabakat Pro")
        self.resize(1150, 720)

        self._result: Optional[ReconciliationResult] = None
        self._threads: list[QThread] = []   # canlı thread referansları
        self._thread: Optional[QThread] = None
        self._worker = None
        self._belge_checks: list[QCheckBox] = []

        self._build_ui()
        self.apply_theme(self.settings.theme)
        self._restore_session()
        logger.info("Uygulama başlatıldı.")

    # -- UI construction ----------------------------------------------------

    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Navigation sidebar
        self.nav = QListWidget()
        self.nav.setObjectName("NavList")
        self.nav.setFixedWidth(190)
        # YENİ SAYFALAR SONA EKLENİR: mevcut sayfaların sıra numaraları
        # değişmez (kayıtlı "son açık sekme" başka bir sayfayı açardı).
        for name in ["Panel", "Mutabakat", "Mutabakat Mailleri", "Raporlar",
                     "Ayarlar", "Loglar", "Gelen Cevaplar", "Oran", "Sıfırla",
                     "Emeğine Geçenler", "Operasyon"]:
            self.nav.addItem(QListWidgetItem(name))
        self.nav.currentRowChanged.connect(self._on_nav_changed)
        root.addWidget(self.nav)

        # Pages
        self.stack = _ResponsiveStack()
        self.stack.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        root.addWidget(self.stack, 1)
        self.stack.addWidget(self._page_dashboard())
        self.stack.addWidget(self._page_reconciliation())
        self.stack.addWidget(self._page_mailing())
        self.stack.addWidget(self._page_reports())
        self.stack.addWidget(self._page_settings())
        self.stack.addWidget(self._page_logs())
        # Yeni sayfa SONA eklenir: mevcut sayfaların sıra numaraları değişmez.
        self.stack.addWidget(self._page_incoming())
        self.stack.addWidget(self._page_ratio())
        self.stack.addWidget(self._page_reset())
        self.stack.addWidget(self._page_credits())
        self.stack.addWidget(self._page_operations())
        self.nav.setCurrentRow(0)

        # Status bar with progress
        sb = QStatusBar()
        self.setStatusBar(sb)
        self.progress = QProgressBar()
        self.progress.setFixedWidth(240)
        self.progress.setValue(0)
        self.status_label = QLabel("Hazır")
        sb.addWidget(self.status_label, 1)
        sb.addPermanentWidget(self.progress)

    def _page_dashboard(self) -> QWidget:
        """Firma için SADE mutabakat sonucu ekranı.

        İlk 3 saniyede sonucu anlatır: firma adı, büyük eşleşme oranı, durum
        ışığı (🟢/🟡/🔴), üç temel sayı ve iki eylem butonu. Detaylı eşleştirme
        tablosu / evidence / kural yönetimi burada DEĞİL, 'Mutabakat' sekmesinde
        (iç kullanıcı) durur.
        """
        w = QWidget()
        outer = QVBoxLayout(w)
        outer.setContentsMargins(40, 30, 40, 30)

        card = QFrame()
        card.setObjectName("ResultCard")
        card.setMaximumWidth(720)
        lay = QVBoxLayout(card)
        lay.setSpacing(14)
        lay.setContentsMargins(36, 30, 36, 30)

        self.dash_company = QLabel(self.settings.company_name or "MUTABAKAT SONUCU")
        self.dash_company.setObjectName("DashCompany")
        self.dash_company.setAlignment(Qt.AlignCenter)
        lay.addWidget(self.dash_company)

        subtitle = QLabel("MUTABAKAT SONUCU")
        subtitle.setObjectName("DashSubtitle")
        subtitle.setAlignment(Qt.AlignCenter)
        lay.addWidget(subtitle)

        # Büyük eşleşme oranı
        self.dash_rate = QLabel("—")
        self.dash_rate.setObjectName("DashRate")
        self.dash_rate.setAlignment(Qt.AlignCenter)
        lay.addWidget(self.dash_rate)

        rate_lbl = QLabel("EŞLEŞME ORANI")
        rate_lbl.setObjectName("DashRateLabel")
        rate_lbl.setAlignment(Qt.AlignCenter)
        lay.addWidget(rate_lbl)

        # Oran çubuğu
        self.dash_bar = QProgressBar()
        self.dash_bar.setObjectName("DashBar")
        self.dash_bar.setRange(0, 100)
        self.dash_bar.setValue(0)
        self.dash_bar.setTextVisible(False)
        self.dash_bar.setFixedHeight(14)
        lay.addWidget(self.dash_bar)

        # Üç temel sayı
        grid = QGridLayout()
        grid.setHorizontalSpacing(10)
        self.card_total = StatCard("TOPLAM KAYIT")
        self.card_eslesen = StatCard("EŞLEŞEN")
        self.card_eslesmeyen = StatCard("EŞLEŞMEYEN")
        grid.addWidget(self.card_total, 0, 0)
        grid.addWidget(self.card_eslesen, 0, 1)
        grid.addWidget(self.card_eslesmeyen, 0, 2)
        lay.addLayout(grid)

        # Durum ışığı
        self.dash_status = QLabel("Henüz mutabakat yapılmadı.")
        self.dash_status.setObjectName("DashStatus")
        self.dash_status.setAlignment(Qt.AlignCenter)
        self.dash_status.setWordWrap(True)
        lay.addWidget(self.dash_status)

        # Eylemler
        btn_row = QHBoxLayout()
        self.btn_show_unmatched = QPushButton("Eşleşmeyen Kayıtları Gör")
        self.btn_show_unmatched.clicked.connect(self._show_unmatched)
        self.btn_download_excel = QPushButton("Excel Raporunu İndir")
        self.btn_download_excel.setObjectName("Ghost")
        self.btn_download_excel.clicked.connect(self._write_again)
        btn_row.addWidget(self.btn_show_unmatched)
        btn_row.addWidget(self.btn_download_excel)
        lay.addLayout(btn_row)

        self.dash_runid = QLabel("")
        self.dash_runid.setObjectName("DashRunId")
        self.dash_runid.setAlignment(Qt.AlignCenter)
        lay.addWidget(self.dash_runid)

        wrap = QHBoxLayout()
        wrap.addStretch(1)
        wrap.addWidget(card)
        wrap.addStretch(1)
        outer.addLayout(wrap)
        outer.addStretch(1)
        return w

    def _on_nav_changed(self, index: int) -> None:
        """Sayfayı değiştir ve son açık sekmeyi hatırla."""
        self.stack.setCurrentIndex(index)
        # Operasyon paneli AÇILDIĞINDA kendini tazeler: kullanıcı boş
        # kartlarla karşılaşıp "Yenile"ye basmak zorunda kalmasın.
        if self.nav.item(index) is not None                 and self.nav.item(index).text() == "Operasyon":
            try:
                self._refresh_operations()
            except Exception as exc:  # noqa: BLE001 - panel gezinmeyi bozmaz
                logger.warning(f"[operasyon] otomatik yenileme başarısız: {exc}")
        self._save_session()

    def _show_unmatched(self) -> None:
        """Detaylı tabloya (Mutabakat sekmesi) geç."""
        self.nav.setCurrentRow(1)

    def _page_reconciliation(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        title = QLabel("Mutabakat")
        title.setObjectName("Title")
        lay.addWidget(title)

        # Önceki oturumdan hatırlanan bir dosya artık yoksa bu şerit görünür
        # kalır. Oturum durumu SİLİNMEZ: dosya geri konunca kaldığı yerden
        # devam edilir.
        self.lbl_missing = QLabel("")
        self.lbl_missing.setWordWrap(True)
        self.lbl_missing.setObjectName("Hint")
        self.lbl_missing.setStyleSheet("color: #c62828; font-weight: 600;")
        self.lbl_missing.setVisible(False)
        lay.addWidget(self.lbl_missing)

        # 120* eşleme uyarısı da MODAL DEĞİLDİR (bkz.
        # _warn_missing_customer_map): mod her değiştiğinde açılan bir
        # iletişim kutusu akışı kilitler.
        self.lbl_customer_map = QLabel("")
        self.lbl_customer_map.setWordWrap(True)
        self.lbl_customer_map.setObjectName("Hint")
        self.lbl_customer_map.setStyleSheet("color: #ef6c00; font-weight: 600;")
        self.lbl_customer_map.setVisible(False)
        lay.addWidget(self.lbl_customer_map)

        # Firma türü: Yerli / Yabancı / Birlikte
        mode_row = QHBoxLayout()
        mode_row.addWidget(QLabel("Firma türü:"))
        self.mode_combo = QComboBox()
        self.mode_combo.addItem("Yerli (120* müşteri/cari hesapları)", "yerli")
        self.mode_combo.addItem("Yabancı / İthal (320*/323* satıcı hesapları)", "yabanci")
        self.mode_combo.addItem("Birlikte (hepsi — hesap türüne bakılmaz)", "birlikte")
        # Son seçilen modu hatırla (kalıcı ayar).
        saved_mode = self.settings.get("firma_modu", "birlikte")
        idx = self.mode_combo.findData(saved_mode)
        self.mode_combo.setCurrentIndex(idx if idx >= 0 else 2)
        self.mode_combo.currentIndexChanged.connect(self._on_mode_changed)
        mode_row.addWidget(self.mode_combo, 1)
        lay.addLayout(mode_row)

        self.mode_hint = QLabel(
            "Eşleştirme her üç modda da yalnızca fatura no + tutar üzerinden "
            "yapılır. Mod, sadece hangi hesap satırlarının dikkate alınacağını "
            "belirler."
        )
        self.mode_hint.setWordWrap(True)
        self.mode_hint.setObjectName("Hint")
        lay.addWidget(self.mode_hint)

        # File selectors
        self.tofas_edit = DropLineEdit("TOFAŞ ekstresi (SAP) — dosya seçin veya sürükleyin")
        # Sürükle-bırak ve elle yazma da yakalansın: dosya nasıl verilirse
        # verilsin, gelen cevap ekranı aynı kaynağı kullanır.
        self.tofas_edit.textChanged.connect(
            lambda _text: self._publish_tofas_source())
        btn_tofas = QPushButton("TOFAŞ Ekstresi Seç")
        btn_tofas.clicked.connect(self._pick_tofas)
        row1 = QHBoxLayout()
        row1.addWidget(self.tofas_edit, 1)
        row1.addWidget(btn_tofas)
        lay.addLayout(row1)

        self.firma_edit = DropLineEdit("Firma ekstresi — dosya seçin veya sürükleyin")
        btn_firma = QPushButton("Firma Ekstresi Seç")
        btn_firma.clicked.connect(self._pick_firma)
        row2 = QHBoxLayout()
        row2.addWidget(self.firma_edit, 1)
        row2.addWidget(btn_firma)
        lay.addLayout(row2)

        # Belge türü selection
        lay.addWidget(QLabel("Mutabakata dahil edilmeyecek belge türleri (işaretleyin):"))
        self.belge_container = QListWidget()
        self.belge_container.setMaximumHeight(120)
        lay.addWidget(self.belge_container)
        btn_load_turler = QPushButton("Belge Türlerini Yükle")
        btn_load_turler.setObjectName("Ghost")
        btn_load_turler.clicked.connect(self._load_belge_turleri)
        lay.addWidget(btn_load_turler)

        # Run
        self.btn_run = QPushButton("Karşılaştırmayı Başlat")
        self.btn_run.clicked.connect(self._start_reconcile)
        lay.addWidget(self.btn_run)

        # Result table — genişletilmiş kolonlar
        self._table_headers = [
            "Durum", "Referans (Firma)", "Referans (TOFAŞ)", "Belge Tarihi",
            "Firma Tutar", "TOFAŞ Tutar", "Kuruş Farkı", "İşaret",
            "Eşleşme Kuralı", "Firma Hesap", "TOFAŞ Hesap", "Açıklama",
        ]
        self.table = QTableWidget(0, len(self._table_headers))
        self.table.setHorizontalHeaderLabels(self._table_headers)
        self.table.setAlternatingRowColors(True)
        self.table.setSortingEnabled(False)
        self.table.setToolTip("Bir satıra çift tıklayın: 'Bu tutar nereden geldi?'")
        self.table.cellDoubleClicked.connect(self._show_evidence)
        self._row_meta: list[tuple] = []   # (firma_rec, tofas_rec) her görsel satır
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setStretchLastSection(True)
        # Makul başlangıç genişlikleri (kullanıcı elle değiştirebilir).
        for col, wdt in enumerate(
            [110, 150, 150, 100, 110, 110, 90, 70, 130, 100, 100, 200]
        ):
            self.table.setColumnWidth(col, wdt)
        lay.addWidget(self.table, 1)
        return w

    def _page_reports(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        title = QLabel("Raporlar")
        title.setObjectName("Title")
        lay.addWidget(title)
        lay.addWidget(QLabel(
            "Mutabakat sonucu, seçtiğiniz TOFAŞ dosyasına 'Mutabakat Sonucu' "
            "sayfası olarak otomatik eklenir."))
        self.btn_export_again = QPushButton("Sonucu TOFAŞ Dosyasına Tekrar Yaz")
        self.btn_export_again.setObjectName("Ghost")
        self.btn_export_again.clicked.connect(self._write_again)
        lay.addWidget(self.btn_export_again)
        lay.addStretch(1)
        return w

    def _page_mailing(self) -> QWidget:
        # Bağımsız modül (additive). Import hatası olsa bile ana uygulama açılır.
        try:
            from app.mailing.mailing_page import MailingPage
            # Tek oturum nesnesi paylaşılır: iki ayrı örnek aynı dosyaya
            # yazsaydı biri diğerinin bölümünü ezebilirdi.
            self.mailing_page = MailingPage(
                session=self.session,
                outgoing_smtp_provider=lambda: self.settings.outgoing_mailbox_smtp)
            # "3) Dönüşleri Kontrol Et" takip ekranına geçer; sayfa ana
            # pencereyi TANIMAZ, yalnızca istek yayınlar.
            self.mailing_page.navigate_requested.connect(self._navigate_to)
            from app.services.output_location import saved_output_folder

            self.mailing_page.set_default_output_dir(
                saved_output_folder(self.settings))
            self.mailing_page.on_output_dir_chosen = self._remember_output_folder
            return self.mailing_page
        except Exception as exc:  # pragma: no cover - savunmacı
            self.mailing_page = None
            w = QWidget()
            lay = QVBoxLayout(w)
            title = QLabel("Mutabakat Mailleri")
            title.setObjectName("Title")
            lay.addWidget(title)
            lay.addWidget(QLabel(f"Modül yüklenemedi: {exc}"))
            lay.addStretch(1)
            return w

    def _page_incoming(self) -> QWidget:
        """Gelen mutabakat cevapları (Python-first analiz + AI fallback).

        Mail sayfasıyla aynı savunmacı kalıp: modül yüklenemese bile ana
        uygulama açılır, yalnızca bu sayfa bir açıklama gösterir.
        """
        try:
            from app.incoming.incoming_page import IncomingPage
            self.incoming_page = IncomingPage(
                session=self.session,
                outgoing_smtp_provider=lambda: self.settings.outgoing_mailbox_smtp)
            # Sekme, uygulama açılırken kurulur; o sırada TOFAŞ yolu zaten
            # seçilmiş olabilir (ayarlardan geri yüklenmiş olabilir).
            self._publish_tofas_source()
            return self.incoming_page
        except Exception as exc:  # pragma: no cover - savunmacı
            self.incoming_page = None
            w = QWidget()
            lay = QVBoxLayout(w)
            title = QLabel("Gelen Cevaplar")
            title.setObjectName("Title")
            lay.addWidget(title)
            lay.addWidget(QLabel(f"Modül yüklenemedi: {exc}"))
            lay.addStretch(1)
            return w

    def _page_ratio(self) -> QWidget:
        """Sorumlu (R) bazlı mutabakat oranı — FAZ 9."""
        try:
            from app.ui.ratio_page import RatioPage
            self.ratio_page = RatioPage()
            return self.ratio_page
        except Exception as exc:  # pragma: no cover - savunmacı
            self.ratio_page = None
            w = QWidget()
            lay = QVBoxLayout(w)
            title = QLabel("Oran")
            title.setObjectName("Title")
            lay.addWidget(title)
            lay.addWidget(QLabel(f"Modül yüklenemedi: {exc}"))
            lay.addStretch(1)
            return w

    def _page_reset(self) -> QWidget:
        """Kullanıcının AÇIKÇA tetiklediği oturum sıfırlaması — FAZ 8.

        Normal açılış hiçbir şey temizlemez; temizlik yalnızca burada ve
        yalnızca onay verildikten sonra yapılır.
        """
        from app.services.session_state import (
            SECTION_INCOMING,
            SECTION_MAILING,
            SECTION_RECONCILIATION,
            SECTION_UI,
        )

        w = QWidget()
        lay = QVBoxLayout(w)
        title = QLabel("Sıfırla")
        title.setObjectName("Title")
        lay.addWidget(title)

        aciklama = QLabel(
            "Buradaki işlem yalnızca PANELDEKİ OTURUM VERİLERİNİ temizler: "
            "seçili dosyalar, filtreler, son seçimler ve geçici sonuç ekranı.\n\n"
            "Gönderim geçmişi, gönderim snapshot'ları (hangi firmaya hangi "
            "FBL1H/FBL5H verisiyle mail gittiği) ve gelen cevapların finansal "
            "kayıtları BU İŞLEMDEN ETKİLENMEZ. Bunlar denetim kaydıdır ve bir "
            "arayüz temizliğiyle silinmez."
        )
        aciklama.setWordWrap(True)
        aciklama.setObjectName("Hint")
        lay.addWidget(aciklama)

        self._reset_checks: list[tuple[QCheckBox, str]] = []
        for label, section in (
            ("Mutabakat sayfası (seçili TOFAŞ/firma dosyaları)",
             SECTION_RECONCILIATION),
            ("Mutabakat Mailleri (Excel, FBL1H/FBL5H, çıktı klasörü, dönem, "
             "sorumlu eşlemesi)", SECTION_MAILING),
            ("Gelen Cevaplar (filtreler, son tarama zamanı)", SECTION_INCOMING),
            ("Arayüz (son açık sekme, pencere boyutu)", SECTION_UI),
        ):
            check = QCheckBox(label)
            check.setChecked(True)
            lay.addWidget(check)
            self._reset_checks.append((check, section))

        # Kalıcı kayıtların silinmesi AYRI ve VARSAYILAN KAPALI bir seçenektir.
        self.chk_reset_records = QCheckBox(
            "Gelen cevap kayıtlarını ve gönderim geçmişini de SİL "
            "(önce şifreli yedek alınır)")
        self.chk_reset_records.setChecked(False)
        lay.addWidget(self.chk_reset_records)

        self.btn_reset = QPushButton("Seçili Oturum Verilerini Sıfırla")
        self.btn_reset.clicked.connect(self._do_reset)
        lay.addWidget(self.btn_reset)

        self.lbl_reset = QLabel("")
        self.lbl_reset.setWordWrap(True)
        lay.addWidget(self.lbl_reset)
        lay.addStretch(1)
        return w

    def _selected_reset_sections(self) -> list[str]:
        return [section for check, section in getattr(self, "_reset_checks", [])
                if check.isChecked()]

    # -- operasyon paneli (madde 8) ----------------------------------------

    def _page_operations(self) -> QWidget:
        """Üst yönetime sunulabilir tek ekranlık operasyon özeti.

        Sayılar VAKA KAYITLARINDAN türer (bkz. app/services/ops_metrics.py);
        panel kendi istatistiğini TUTMAZ. Böylece ekranda görünen rakam ile
        "Gelen Cevaplar" sekmesindeki liste hiçbir zaman ayrışmaz.
        """
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(30, 24, 30, 24)

        title = QLabel("Operasyon Paneli")
        title.setObjectName("Title")
        lay.addWidget(title)

        aciklama = QLabel(
            "Dönemin gönderim ve cevap durumu. Rakamlar kalıcı vaka "
            "kayıtlarından hesaplanır; ayrı bir istatistik tablosu tutulmaz.")
        aciklama.setWordWrap(True)
        lay.addWidget(aciklama)

        # -- filtre satırı
        filtre = QHBoxLayout()
        filtre.addWidget(QLabel("Dönem:"))
        self.ops_period = QLineEdit()
        self.ops_period.setPlaceholderText("2026-07 (boş = tüm dönemler)")
        self.ops_period.setFixedWidth(200)
        filtre.addWidget(self.ops_period)

        filtre.addWidget(QLabel("Gecikme eşiği (gün):"))
        self.ops_overdue = QSpinBox()
        self.ops_overdue.setRange(1, 365)
        self.ops_overdue.setValue(int(self.settings.get("overdue_days", 7) or 7))
        filtre.addWidget(self.ops_overdue)

        self.btn_ops_refresh = QPushButton("Yenile")
        self.btn_ops_refresh.clicked.connect(self._refresh_operations)
        filtre.addWidget(self.btn_ops_refresh)
        filtre.addStretch(1)
        lay.addLayout(filtre)

        # -- sayı kartları
        self._ops_cards = {}
        grid = QGridLayout()
        etiketler = ["Gönderilen", "Cevap bekleyen", "Mutabık", "Farklı",
                     "Geçersiz adres", "İnsan incelemesi",
                     "Ortalama cevap süresi", "Geciken vakalar"]
        for index, etiket in enumerate(etiketler):
            kart = StatCard(etiket.upper(), "—")
            self._ops_cards[etiket] = kart
            grid.addWidget(kart, index // 4, index % 4)
        lay.addLayout(grid)

        # -- geciken vakalar
        lay.addWidget(QLabel("Geciken vakalar (en uzun bekleyen üstte)"))
        self.ops_table = QTableWidget(0, 6)
        self.ops_table.setHorizontalHeaderLabels(
            ["Firma Kodu", "Firma Adı", "Dönem", "Sorumlu", "Bekleme (gün)",
             "Adres"])
        self.ops_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch)
        self.ops_table.setEditTriggers(QTableWidget.NoEditTriggers)
        lay.addWidget(self.ops_table, 1)

        # -- gönderim kuyruğu özeti
        self.ops_queue = QLabel("Gönderim kuyruğu: —")
        kuyruk_satiri = QHBoxLayout()
        kuyruk_satiri.addWidget(self.ops_queue, 1)
        # Sonucu belirsiz gönderimlerin İNSAN kararı (mail GÖNDERMEZ).
        self.btn_ops_unknown = QPushButton("Belirsiz gönderimler…")
        self.btn_ops_unknown.clicked.connect(self._open_send_unknown_dialog)
        kuyruk_satiri.addWidget(self.btn_ops_unknown)
        lay.addLayout(kuyruk_satiri)

        # -- şirket politikası (yalnızca YÖNETİCİ değiştirebilir)
        politika = QHBoxLayout()
        politika.addWidget(QLabel("Yuvarlama toleransı:"))
        self.ops_tolerance = QDoubleSpinBox()
        self.ops_tolerance.setDecimals(2)
        self.ops_tolerance.setRange(0.0, 1000.0)
        self.ops_tolerance.setSingleStep(0.01)
        politika.addWidget(self.ops_tolerance)
        self.btn_ops_policy = QPushButton("Politikayı Kaydet")
        self.btn_ops_policy.clicked.connect(self._save_tolerance_policy)
        politika.addWidget(self.btn_ops_policy)
        self.ops_role = QLabel("")
        politika.addWidget(self.ops_role)
        politika.addStretch(1)
        lay.addLayout(politika)

        self._load_tolerance_policy()
        return w

    def _load_tolerance_policy(self) -> None:
        """Şirket politikasını ayarlardan yükle ve yetkiye göre kilitle."""
        try:
            from app.services.authz import (
                PERM_CHANGE_POLICY,
                can,
                current_user,
                role_of,
            )
            from app.services.financial_guard import TolerancePolicy

            politika = TolerancePolicy.from_settings(self.settings)
            self.ops_tolerance.setValue(float(politika.amount_tolerance))
            rol = role_of(current_user(), self.settings)
            yetkili = can(PERM_CHANGE_POLICY, role=rol)
            # OPERASYON KULLANICISI POLİTİKAYI DEĞİŞTİREMEZ: alan salt-okunur
            # olur, "kaydet" düğmesi kapanır. Sessizce yok saymak yerine
            # kullanıcıya rolü de gösteriyoruz.
            self.ops_tolerance.setEnabled(yetkili)
            self.btn_ops_policy.setEnabled(yetkili)
            self.ops_role.setText(
                f"Rol: {rol}" + ("" if yetkili
                                 else " — politika değişikliği yönetici yetkisi ister"))
        except Exception as exc:  # noqa: BLE001 - panel uygulamayı düşürmez
            logger.warning(f"[operasyon] politika yüklenemedi: {exc}")

    def _save_tolerance_policy(self) -> None:
        """Yuvarlama toleransını kaydet (yalnızca yönetici)."""

        try:
            from app.services.action_audit import (
                ACTION_POLICY_CHANGED,
                ActionAuditLog,
            )
            from app.services.authz import (
                PERM_CHANGE_POLICY,
                PermissionDenied,
                current_user,
                require,
            )
            from app.services.financial_guard import TolerancePolicy

            require(PERM_CHANGE_POLICY, user=current_user(),
                    settings=self.settings)
            onceki = TolerancePolicy.from_settings(self.settings)
            yeni = TolerancePolicy(
                amount_tolerance=Decimal(str(self.ops_tolerance.value())),
                date_tolerance_days=onceki.date_tolerance_days,
                strict_currency=onceki.strict_currency,
                require_direction_match=onceki.require_direction_match)
            yeni.save_to(self.settings)
            ActionAuditLog().record(
                ACTION_POLICY_CHANGED, user=current_user(),
                target="amount_tolerance",
                old_value=str(onceki.amount_tolerance),
                new_value=str(yeni.amount_tolerance),
                reason="şirket yuvarlama politikası güncellendi")
            self.status_label.setText(
                f"Yuvarlama toleransı kaydedildi: {yeni.amount_tolerance}")
        except PermissionDenied as exc:
            QMessageBox.warning(self, "Yetki", str(exc))
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, "Politika", f"Kaydedilemedi: {exc}")

    def _refresh_operations(self) -> None:
        """Operasyon panelini kalıcı kayıtlardan yeniden hesapla."""
        try:
            from app.services.incoming_cases import IncomingCaseStore
            from app.services.ops_metrics import from_store

            donem = (self.ops_period.text() or "").strip()
            gun = int(self.ops_overdue.value())
            self.settings.set("overdue_days", gun)
            metrics = from_store(IncomingCaseStore(), period=donem or None,
                                 overdue_days=gun)
        except Exception as exc:  # noqa: BLE001 - panel asla çökertmez
            logger.warning(f"[operasyon] özet hesaplanamadı: {exc}")
            QMessageBox.warning(self, "Operasyon",
                                f"Özet hesaplanamadı: {exc}")
            return

        self.apply_ops_metrics(metrics)
        self._refresh_queue_summary()
        self.status_label.setText(
            f"Operasyon özeti güncellendi ({metrics.gonderilen} vaka).")

    def apply_ops_metrics(self, metrics) -> None:
        """Hesaplanmış özeti ekrana bas (test edilebilir saf adım)."""
        for etiket, deger in metrics.as_rows():
            # Kart etiketleri sabittir; "Geciken vakalar (>7 gün)" gibi
            # dinamik başlıkları eşleştirmek için ön ek karşılaştırılır.
            for ad, kart in self._ops_cards.items():
                if etiket.startswith(ad):
                    kart.set_value(deger)
                    break

        self.ops_table.setRowCount(0)
        for satir, vaka in enumerate(metrics.geciken_vakalar):
            self.ops_table.insertRow(satir)
            for sutun, deger in enumerate([
                vaka.company_code, vaka.company_name, vaka.period,
                vaka.responsible, str(vaka.waiting_days),
                "GEÇERSİZ" if vaka.address_invalid else "geçerli",
            ]):
                self.ops_table.setItem(satir, sutun,
                                       QTableWidgetItem(str(deger)))

    def _refresh_queue_summary(self) -> None:
        """Kalıcı gönderim kuyruğunun durum dağılımını göster."""
        try:
            from app.services.send_queue import SendQueue

            ozet = SendQueue().summary()
        except Exception as exc:  # noqa: BLE001
            logger.debug(f"[operasyon] kuyruk okunamadı: {exc}")
            self.ops_queue.setText("Gönderim kuyruğu: okunamadı")
            return
        self.ops_queue.setText(
            "Gönderim kuyruğu — "
            f"Sırada: {ozet.get('QUEUED', 0)} · "
            f"Gönderildi: {ozet.get('SENT', 0)} · "
            f"Başarısız: {ozet.get('FAILED', 0)} · "
            f"Belirsiz: {ozet.get('UNKNOWN', 0)} · "
            f"Yeniden denenecek: {ozet.get('RETRY', 0)}"
            + self._unresolved_unknown_suffix())

    def _unresolved_unknown_suffix(self) -> str:
        """İnsan kararı bekleyen belirsiz gönderim sayısı (okunamazsa boş)."""
        try:
            from app.services.mail_log import MailLog

            donem = (self.ops_period.text() or "").strip() or None
            sayi = len(MailLog().unresolved_unknowns(donem))
        except Exception as exc:  # noqa: BLE001 - özet satırı paneli düşürmez
            logger.debug(f"[operasyon] belirsiz sayısı okunamadı: {exc}")
            return ""
        return f" · Karar bekleyen belirsiz gönderim: {sayi}"

    def _open_send_unknown_dialog(self) -> None:
        """Belirsiz gönderim karar penceresini aç (mail GÖNDERMEZ)."""
        try:
            from app.mailing.send_unknown_dialog import SendUnknownDialog

            donem = (self.ops_period.text() or "").strip()
            dialog = SendUnknownDialog(settings=self.settings, period=donem,
                                       parent=self)
            dialog.resolved.connect(self._refresh_queue_summary)
            dialog.exec()
        except Exception as exc:  # noqa: BLE001 - pencere açılamazsa uygulama düşmez
            logger.warning(f"[operasyon] belirsiz gönderim penceresi açılamadı: {exc}")
            QMessageBox.warning(self, "Belirsiz Gönderimler", str(exc))

    def _page_credits(self) -> QWidget:
        """Ürün sahipliği bilgisini sade ve salt-okunur biçimde göster."""
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(40, 30, 40, 30)

        title = QLabel("Emeğine Geçenler")
        title.setObjectName("Title")
        lay.addWidget(title)

        card = QFrame()
        card.setObjectName("ResultCard")
        card.setMaximumWidth(820)
        card_lay = QVBoxLayout(card)
        card_lay.setContentsMargins(28, 24, 28, 24)
        credit = QLabel(
            "Bu ürün Abdulsamet Hatipoğlu tarafından üretilmiştir.\n"
            "Tüm hakları saklıdır."
        )
        credit.setObjectName("CreditsText")
        credit.setWordWrap(True)
        credit.setAlignment(Qt.AlignCenter)
        card_lay.addWidget(credit)

        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(card, 1)
        row.addStretch(1)
        lay.addLayout(row)
        lay.addStretch(1)
        return w

    def _do_reset(self) -> None:
        """Onay al, sonra YALNIZCA oturum durumunu temizle."""
        sections = self._selected_reset_sections()
        kayitlari_sil = bool(getattr(self, "chk_reset_records", None)
                             and self.chk_reset_records.isChecked())
        if not sections and not kayitlari_sil:
            self._warn("Sıfırlanacak bir alan seçin.")
            return
        if kayitlari_sil:
            self._do_reset_records(sections)
            return
        if QMessageBox.question(
                self, "Sıfırlama onayı",
                "Paneldeki kalıcı oturum verileri sıfırlanacak. "
                "Devam edilsin mi?\n\n"
                "(Gönderim geçmişi, snapshot'lar ve gelen cevapların "
                "finansal kayıtları SİLİNMEZ.)") != QMessageBox.Yes:
            self.lbl_reset.setText("Sıfırlama iptal edildi.")
            return
        self.apply_reset(sections)

    def _ask_backup_password(self) -> str:
        """Yedek parolasını ayardan/ortamdan al; yoksa kullanıcıya sor."""
        from app.services.backup import resolve_password

        parola = resolve_password(self.settings)
        if parola:
            return parola
        from PySide6.QtWidgets import QInputDialog

        parola, ok = QInputDialog.getText(
            self, "Yedek parolası",
            "Silmeden önce alınacak şifreli yedek için bir parola girin.\n"
            "Bu parolayı unutmayın; yedeği geri açmak için gerekir.",
            QLineEdit.Password)
        return parola.strip() if ok else ""

    def _do_reset_records(self, sections) -> None:
        """Kayıtları yedekleyip sil (iki aşamalı onay)."""
        if QMessageBox.warning(
                self, "Kayıtlar silinecek",
                "Gelen cevap kayıtları, gönderim geçmişi ve gönderim "
                "snapshot'ları SİLİNECEK.\n\nÖnce şifreli yedek alınır; "
                "yedek alınamazsa hiçbir şey silinmez.\n\nDevam edilsin mi?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No) != QMessageBox.Yes:
            self.lbl_reset.setText("Sıfırlama iptal edildi.")
            return
        parola = self._ask_backup_password()
        if not parola:
            self.lbl_reset.setText(
                "Yedek parolası girilmedi; hiçbir kayıt silinmedi.")
            return
        mesaj = self.apply_record_reset(parola)
        if sections:
            self.apply_reset(sections)
            mesaj = mesaj + "\n" + self.lbl_reset.text()
        self.lbl_reset.setText(mesaj)

    def apply_record_reset(self, password: str, base_dir=None) -> str:
        """Kayıtları yedekle + sil, ekranı tazele. Döner: durum mesajı."""
        from app.services.data_reset import reset_records

        sonuc = reset_records(password, base_dir=base_dir)
        if sonuc.backup_path:
            logger.info(f"Sıfırlama yedeği: {sonuc.backup_path}")
        page = getattr(self, "incoming_page", None)
        if page is not None and hasattr(page, "reset_ui_state"):
            try:
                page.reset_ui_state()
                if sonuc.ok:
                    page.lbl_summary.setText(
                        "Gelen cevap kayıtları silindi (yedek alındı).")
            except Exception as exc:  # noqa: BLE001 - sıfırlama çökertmez
                logger.warning(f"incoming_page tazelenemedi: {exc}")
        if not sonuc.ok:
            return f"HATA: {sonuc.error}"
        yedek = (f"Yedek: {sonuc.backup_path}" if sonuc.backup_path
                 else "Silinecek kayıt yoktu.")
        return "Gelen cevap kayıtları ve gönderim geçmişi silindi.\n" + yedek

    def apply_reset(self, sections) -> list[str]:
        """Sıfırlamayı uygula (onay ALINMIŞ kabul edilir).

        Ayrı bir metottur ki onay penceresi olmadan test edilebilsin ve
        onayın atlanması bir kaza sonucu mümkün olmasın.
        """
        temizlenen: list[str] = []
        if self.session is not None:
            temizlenen = self.session.reset(sections)

        # Ekrandaki geçici durum da temizlenir (kalıcı kayıtlara dokunmadan).
        from app.services.session_state import (
            SECTION_INCOMING,
            SECTION_MAILING,
            SECTION_RECONCILIATION,
        )

        if SECTION_RECONCILIATION in sections:
            self.tofas_edit.clear()
            self.firma_edit.clear()
            self.lbl_missing.setVisible(False)
        for name, section in (("mailing_page", SECTION_MAILING),
                              ("incoming_page", SECTION_INCOMING)):
            page = getattr(self, name, None)
            if section in sections and page is not None and hasattr(
                    page, "reset_ui_state"):
                try:
                    page.reset_ui_state()
                except Exception as exc:  # noqa: BLE001 - sıfırlama çökertmez
                    logger.warning(f"{name} sıfırlanamadı: {exc}")

        mesaj = ("Sıfırlanan alanlar: " + ", ".join(temizlenen)
                 if temizlenen else "Sıfırlanacak kayıtlı veri yoktu.")
        self.lbl_reset.setText(
            mesaj + "\nGönderim geçmişi ve finansal kayıtlar korundu.")
        logger.info(f"Oturum sıfırlandı: {temizlenen}")
        return temizlenen

    def _navigate_to(self, target: str) -> None:
        """Sayfalar arası geçiş isteği (ad -> sekme)."""
        adlar = {"incoming": "Gelen Cevaplar", "mailing": "Mutabakat Mailleri",
                 "ratio": "Oran", "reset": "Sıfırla"}
        istenen = adlar.get(target, target)
        for index in range(self.nav.count()):
            if self.nav.item(index).text() == istenen:
                self.nav.setCurrentRow(index)
                return

    def set_outlook_account(self, account) -> None:
        """Açılışta arka planda kurulan Outlook bağlantısını mailing sayfasına aktarır."""
        page = getattr(self, "mailing_page", None)
        if page is not None:
            page.set_connected_account(account)

    def _page_settings(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        title = QLabel("Ayarlar")
        title.setObjectName("Title")
        lay.addWidget(title)

        lay.addWidget(QLabel("Firma Adı"))
        self.set_company = QLineEdit(self.settings.company_name)
        self.set_company.setReadOnly(False)
        lay.addWidget(self.set_company)

        # Gerçek gönderimler (toplu mutabakat, Reply-All) YALNIZ bu SMTP'ye
        # sahip Outlook hesabından çıkar; boşsa gönderim engellenir.
        lay.addWidget(QLabel("Kurumsal giden posta kutusu SMTP"))
        self.set_outgoing_smtp = QLineEdit(self.settings.outgoing_mailbox_smtp)
        self.set_outgoing_smtp.setPlaceholderText("ornek@sirket.com")
        lay.addWidget(self.set_outgoing_smtp)

        lay.addWidget(QLabel("Tema"))
        self.set_theme = QComboBox()
        self.set_theme.addItems(["dark", "light"])
        self.set_theme.setCurrentText(self.settings.theme)
        self.set_theme.currentTextChanged.connect(self._change_theme)
        lay.addWidget(self.set_theme)

        # Üretilen dosyaların (sonuç Excel'i, mektuplar, taslaklar) klasörü.
        from app.services.output_location import saved_output_folder

        lay.addWidget(QLabel("Çıktı Klasörü (üretilen Excel ve mektuplar)"))
        satir = QHBoxLayout()
        self.lbl_output_folder = QLabel(
            saved_output_folder(self.settings) or "(henüz seçilmedi — ilk "
            "kayıtta sorulur)")
        self.lbl_output_folder.setWordWrap(True)
        satir.addWidget(self.lbl_output_folder, 1)
        btn_klasor = QPushButton("Değiştir…")
        btn_klasor.clicked.connect(lambda: self._choose_output_folder())
        satir.addWidget(btn_klasor)
        lay.addLayout(satir)

        btn_save = QPushButton("Ayarları Kaydet")
        btn_save.clicked.connect(self._save_settings)
        lay.addWidget(btn_save)
        lay.addStretch(1)
        return w

    def _page_logs(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        title = QLabel("Loglar")
        title.setObjectName("Title")
        lay.addWidget(title)
        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        lay.addWidget(self.log_view, 1)
        # Route loguru into the log view.
        # Handler ID SAKLANIR: kapanışta kaldırılmazsa her pencere yeni bir
        # sink bırakır. Testlerde defalarca kurulan pencerelerde sink'ler
        # birikir, kapatılmış widget'lara yazmaya çalışılır ve bellek sızar.
        self._log_sink_id = logger.add(
            self._append_log, format="{time:HH:mm:ss} | {level} | {message}")
        return w

    def _remove_log_sink(self) -> None:
        """Log view sink'ini kaldır (birden çok kez çağrılabilir)."""
        sink_id = getattr(self, "_log_sink_id", None)
        if sink_id is None:
            return
        self._log_sink_id = None
        try:
            logger.remove(sink_id)
        except (ValueError, RuntimeError):
            # Zaten kaldırılmış olabilir; kapanış bundan etkilenmemeli.
            pass

    # -- kalıcı oturum (FAZ 7) ---------------------------------------------

    def _restore_session(self) -> None:
        """Son oturumu geri yükle. Eksik dosya UYARILIR ama state SİLİNMEZ."""
        if self.session is None:
            return
        from app.services.session_state import SECTION_RECONCILIATION, SECTION_UI

        try:
            state = self.session.section(SECTION_RECONCILIATION)
            self.tofas_edit.setText(str(state.get("tofas_path", "") or ""))
            self.firma_edit.setText(str(state.get("firma_path", "") or ""))

            ui = self.session.section(SECTION_UI)
            width, height = ui.get("width"), ui.get("height")
            if width and height:
                screen = QApplication.primaryScreen()
                if screen is not None:
                    available = screen.availableGeometry()
                    safe_width, safe_height = _clamp_window_size(
                        width, height, available.width(), available.height())
                    self.resize(safe_width, safe_height)
                else:
                    self.resize(int(width), int(height))
            tab = ui.get("tab")
            if tab is not None and 0 <= int(tab) < self.nav.count():
                self.nav.setCurrentRow(int(tab))

            # Mail sayfası kendi Excel'ini arka planda geri yükler. Bu da
            # pencere kurulduktan SONRA başlar: açılış hiçbir koşulda
            # dosya okumasını beklemez.
            page = getattr(self, "mailing_page", None)
            if page is not None and hasattr(page, "restore_last_report"):
                page.restore_last_report()

            self._warn_missing_files()
        except Exception as exc:  # noqa: BLE001 - oturum ASLA çökertmez
            logger.warning("Oturum geri yüklenemedi: {}", exc)

    def _warn_missing_files(self) -> None:
        """Kayıtlı ama artık olmayan dosyaları TEK seferde bildir.

        Var olmayan bir dosyayı varmış gibi kullanmak, yanlış veriyle
        mutabakat üretmenin en sessiz yoludur; bu yüzden açıkça söylenir.
        Buna rağmen state SİLİNMEZ: kullanıcı dosyayı geri koyabilir.

        Uyarı MODAL PENCEREYLE gösterilmez. Açılışta çıkan bir iletişim
        kutusu uygulamayı görünmeden kilitler ve kullanıcı onu kapattığında
        bilgi kaybolur. Bunun yerine sayfada KALICI bir uyarı şeridi durur:
        dosya geri konana kadar görünür kalır.
        """
        missing = self.session.missing_paths()
        if not missing:
            self.lbl_missing.setVisible(False)
            return
        from app.services.session_state import SessionState

        self.lbl_missing.setText(SessionState.describe_missing(missing))
        self.lbl_missing.setVisible(True)
        self.status_label.setText(
            f"{len(missing)} hatırlanan dosya bulunamadı — Mutabakat "
            "sekmesindeki uyarıya bakın.")

    def _save_session(self) -> None:
        """Ana pencerenin durumunu kalıcı oturuma yaz."""
        if self.session is None:
            return
        from app.services.session_state import SECTION_RECONCILIATION, SECTION_UI

        try:
            self.session.update(SECTION_RECONCILIATION, {
                "tofas_path": self.tofas_edit.text().strip(),
                "firma_path": self.firma_edit.text().strip(),
                "mode": self._current_mode(),
            }, save=False)
            self.session.update(SECTION_UI, {
                "tab": self.nav.currentRow(),
                "width": self.width(),
                "height": self.height(),
            })
        except Exception as exc:  # noqa: BLE001
            logger.warning("Oturum kaydedilemedi: {}", exc)

    # -- actions ------------------------------------------------------------

    def _append_log(self, message: str) -> None:
        try:
            self.log_view.append(message.rstrip())
        except RuntimeError:
            pass  # widget gone during shutdown

    def _pick_tofas(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "TOFAŞ Ekstresi Seç", self.settings.default_folder,
            "Excel (*.xlsx *.xls);;Tüm dosyalar (*.*)")
        if path:
            self.tofas_edit.setText(path)
            self._publish_tofas_source()

    def _publish_tofas_source(self) -> None:
        """Seçilen TOFAŞ ekstresini «Gelen Cevaplar» sekmesine bildir.

        Böylece firmaların mailine eklediği ekstreler, dosya hattıyla AYNI
        TOFAŞ kayıtlarına karşı çalıştırılır (tek doğruluk kaynağı). Yalnızca
        YOL ve MOD aktarılır; dosya, tarama sırasında arka plan thread'inde
        okunur — UI thread'i hiç bloklanmaz.
        """
        # Seçim değiştiğinde kalıcı oturuma da yazılır: kullanıcı yarın
        # aynı dosyalarla devam eder.
        self._save_session()
        page = getattr(self, "incoming_page", None)
        if page is None:
            return
        try:
            page.set_tofas_source(self.tofas_edit.text().strip(),
                                  self._current_mode())
        except Exception as exc:  # noqa: BLE001 - bildirim ana akışı bozmasın
            logger.warning("TOFAŞ kaynağı gelen cevaplar sekmesine "
                           "aktarılamadı: {}", exc)

    def _pick_firma(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Firma Ekstresi Seç", self.settings.default_folder,
            "Ekstre (*.xlsx *.xls *.csv *.pdf *.txt);;Tüm dosyalar (*.*)")
        if path:
            self.firma_edit.setText(path)
            self._save_session()

    def _track_thread(self, thread: QThread) -> None:
        """Canlı thread'i sakla; bittiğinde listeden düş. Erken GC ve çökmeyi önler.

        Temizlik BAĞLI METODA bağlanır: ``finished`` worker thread'inde
        yayınlandığı için lambda bağlamak listeyi başka thread'den değiştirir.
        """
        self._threads.append(thread)
        thread.finished.connect(self._forget_finished_threads)

    def _forget_finished_threads(self) -> None:
        alive = []
        for thread in self._threads:
            try:
                if not thread.isFinished():
                    alive.append(thread)
            except RuntimeError:
                continue      # C++ nesnesi silinmiş
        self._threads = alive

    def closeEvent(self, event) -> None:  # noqa: N802
        """Uygulama kapanırken çalışan thread'leri düzgünce bitir (çökme önlenir)."""
        # Son durum kalıcı oturuma yazılır (kaydetme hatası kapanışı engellemez).
        try:
            self._save_session()
        except Exception:  # noqa: BLE001
            pass
        # Mail sayfasının KENDİ thread'leri var (ekstre/mektup üretimi ve
        # gönderim). Onlar beklenmeden süreç kapanırsa Windows'ta 0xC0000409
        # ile çökme oluyor.
        for name in ("mailing_page", "incoming_page"):
            page = getattr(self, name, None)
            if page is not None and hasattr(page, "shutdown"):
                try:
                    page.shutdown()
                except Exception:  # noqa: BLE001 - kapanış asla çökertmemeli
                    pass
        for t in list(self._threads):
            try:
                t.quit()
                t.wait(3000)
            except RuntimeError:
                pass
        # Sink EN SONDA kaldırılır: kapanış sırasındaki loglar da görünsün.
        self._remove_log_sink()
        event.accept()

    def _current_mode(self) -> str:
        return self.mode_combo.currentData() or "birlikte"

    def _on_mode_changed(self, _index: int) -> None:
        """Seçilen firma modunu kalıcı ayara yaz."""
        try:
            self.settings.set("firma_modu", self._current_mode())
        except Exception:  # noqa: BLE001 - ayar yazımı asla çökertmemeli
            pass
        # Mod, hangi hesap satırlarının dikkate alınacağını belirler; gelen
        # ekstre karşılaştırması da aynı modla çalışmalıdır.
        # Uyarı ÖNCE güncellenir: yayınlama adımı (sekme kurulmamışsa)
        # hata verse bile kullanıcı eksik eşlemeden haberdar olmalı.
        self._warn_missing_customer_map()
        self._publish_tofas_source()

    def _warn_missing_customer_map(self) -> None:
        """120* eşleme tablosu boşken müşteri modunda kullanıcıyı uyar.

        Uyarı iş akışını DURDURMAZ; yalnızca "mutabakat çalıştı" izlenimiyle
        eksik sonuç alınmasını engeller. MODAL PENCERE KULLANILMAZ: mod her
        değiştiğinde açılan bir iletişim kutusu akışı kilitler ve kapatılınca
        bilgi kaybolur. Bunun yerine sayfada KALICI şerit durur; kullanıcı
        satıcı moduna geçince ya da eşleme dolunca kendiliğinden kaybolur.
        """
        try:
            from app.services.customer_accounts import customer_mapping_warning
            mesaj = customer_mapping_warning(self._current_mode())
        except Exception:  # noqa: BLE001 - uyarı üretimi asla çökertmemeli
            return
        self.lbl_customer_map.setText(mesaj.replace("\n\n", " "))
        self.lbl_customer_map.setVisible(bool(mesaj))

    def _load_belge_turleri(self) -> None:
        tofas_path = self.tofas_edit.text().strip()
        if not tofas_path:
            self._warn("Önce TOFAŞ ekstresini seçin.")
            return
        self._set_busy(True, "Belge türleri okunuyor...")
        self._worker = PeekWorker(tofas_path, mode=self._current_mode())
        self._worker.finished.connect(self._on_belge_turleri)
        self._worker.failed.connect(self._on_error)
        # run_in_thread başlatmayı, quit ve temizliği kendisi yapar.
        self._thread = run_in_thread(self._worker)
        self._track_thread(self._thread)

    def _on_belge_turleri(self, turler: list) -> None:
        self._set_busy(False, "Belge türleri yüklendi.")
        self.belge_container.clear()
        self._belge_checks.clear()
        excluded = set(self.settings.excluded_belge_turu)
        for tur in turler:
            item = QListWidgetItem(self.belge_container)
            cb = QCheckBox(f"Belge türü: {tur}")
            cb.setChecked(tur in excluded)
            cb.setProperty("belge_turu", tur)
            self._belge_checks.append(cb)
            self.belge_container.setItemWidget(item, cb)
            item.setSizeHint(cb.sizeHint())

    def _current_exclusions(self) -> list[str]:
        return [
            cb.property("belge_turu")
            for cb in self._belge_checks if cb.isChecked()
        ]

    def _choose_output_folder(self) -> str:
        """Kullanıcıya çıktı klasörünü sor, kaydet. İptal → boş."""
        from app.services.output_location import (
            save_output_folder,
            saved_output_folder,
        )

        baslangic = saved_output_folder(self.settings) or str(
            self.settings.default_folder)
        yol = QFileDialog.getExistingDirectory(
            self, "Üretilen dosyalar nereye kaydedilsin?", baslangic)
        if not yol:
            return ""
        save_output_folder(self.settings, yol)
        if hasattr(self, "lbl_output_folder"):
            self.lbl_output_folder.setText(yol)
        page = getattr(self, "mailing_page", None)
        if page is not None and hasattr(page, "set_default_output_dir"):
            page.set_default_output_dir(yol)
        return yol

    def _remember_output_folder(self, folder: str) -> None:
        """Başka bir ekranda seçilen klasörü ortak ayar olarak kaydet."""
        from app.services.output_location import save_output_folder

        save_output_folder(self.settings, folder)
        if hasattr(self, "lbl_output_folder"):
            self.lbl_output_folder.setText(folder)

    def _ensure_output_folder(self) -> str:
        """Kayıtlı klasörü döndür; yoksa BİR KEZ sor ve hatırla."""
        from app.services.output_location import saved_output_folder

        return saved_output_folder(self.settings) or self._choose_output_folder()

    def _start_reconcile(self) -> None:
        tofas_path = self.tofas_edit.text().strip()
        firma_path = self.firma_edit.text().strip()
        if not tofas_path or not firma_path:
            self._warn("Hem TOFAŞ hem firma ekstresini seçin.")
            return

        # Eksik 120* eşlemesi sonucu sessizce eksik bırakır; çalıştırmadan
        # önce bir kez söylenir.
        self._warn_missing_customer_map()

        cikti = self._ensure_output_folder()
        if not cikti:
            self._warn("Sonucun kaydedileceği klasör seçilmedi; mutabakat "
                       "başlatılmadı.")
            return

        exclusions = self._current_exclusions()
        self.settings.excluded_belge_turu = exclusions  # persist selection

        self._set_busy(True, "Mutabakat çalışıyor...")
        self.btn_run.setEnabled(False)
        self._worker = ReconcileWorker(
            tofas_path, firma_path, exclusions, mode=self._current_mode(),
            output_dir=cikti,
        )
        self._worker.progress.connect(self._on_progress)
        self._worker.finished.connect(self._on_finished)
        self._worker.failed.connect(self._on_error)
        # run_in_thread başlatmayı, quit ve temizliği kendisi yapar.
        self._thread = run_in_thread(self._worker)
        self._track_thread(self._thread)

    def _on_progress(self, msg: str, pct: int) -> None:
        self.status_label.setText(msg)
        self.progress.setValue(pct)

    def _on_finished(self, result: ReconciliationResult) -> None:
        self._result = result
        self._set_busy(False, "Mutabakat tamamlandı.")
        self.btn_run.setEnabled(True)
        self._populate_table(result)
        self._update_dashboard(result)
        s = result.summary
        if s.diptoplam_uyari:
            self._warn(s.diptoplam_uyari)
        yol = getattr(self._worker, "output_path", "") if self._worker else ""
        if yol:
            self.status_label.setText(f"Mutabakat tamamlandı. Sonuç: {yol}")
        self.nav.setCurrentRow(0)

    def _on_error(self, message: str) -> None:
        self._set_busy(False, "Hata oluştu.")
        self.btn_run.setEnabled(True)
        self._warn(f"İşlem sırasında hata oluştu:\n\n{message}")

    def _populate_table(self, result: ReconciliationResult) -> None:
        rows: list[tuple] = []
        # Görsel satır -> (firma_rec, tofas_rec) eşlemesi (evidence için).
        self._row_meta = (
            [(p.firma, p.tofas) for p in result.matched]
            + [(p.firma, p.tofas) for p in result.amount_mismatch]
            + [(rec, None) for rec in result.only_firma]
            + [(None, rec) for rec in result.only_tofas]
        )

        def _sign(p) -> str:
            return "Aynı işaret!" if getattr(p, "isaret_uyari", False) else ""

        for p in result.matched:
            rows.append((
                "Eşleşti",
                p.firma.reference_raw or p.firma.reference or "",
                p.tofas.reference_raw or p.tofas.reference or "",
                _fmt_date(p.firma.inv_date or p.tofas.belge_tarihi),
                str(p.firma.amount), str(p.tofas.amount),
                str(p.kurus_farki), _sign(p), p.rule.value,
                p.firma.account or "", p.tofas.main_account or p.tofas.firma_kodu or "",
                p.firma.comment or p.tofas.metin or "",
                _COLOR_MATCHED,
            ))
        for p in result.amount_mismatch:
            rows.append((
                "Tutar farkı",
                p.firma.reference_raw or p.firma.reference or "",
                p.tofas.reference_raw or p.tofas.reference or "",
                _fmt_date(p.firma.inv_date or p.tofas.belge_tarihi),
                str(p.firma.amount), str(p.tofas.amount),
                str(p.kurus_farki), _sign(p), p.rule.value,
                p.firma.account or "", p.tofas.main_account or p.tofas.firma_kodu or "",
                p.firma.comment or p.tofas.metin or "",
                _COLOR_DIFF,
            ))
        for rec in result.only_firma:
            rows.append((
                "Sadece firmada",
                rec.reference_raw or rec.reference or "", "",
                _fmt_date(rec.inv_date), str(rec.amount), "", "", "", "",
                rec.account or "", "", rec.comment or "",
                _COLOR_ONLY_FIRMA,
            ))
        for rec in result.only_tofas:
            rows.append((
                "Sadece TOFAŞ'ta", "",
                rec.reference_raw or rec.reference or "",
                _fmt_date(rec.belge_tarihi), "", str(rec.amount), "", "", "",
                "", rec.main_account or rec.firma_kodu or "", rec.metin or "",
                _COLOR_ONLY_TOFAS,
            ))

        # Tablonun yeniden çizimini toplu yap (büyük veride donmayı azaltır).
        self.table.setUpdatesEnabled(False)
        try:
            self.table.clearContents()
            self.table.setRowCount(len(rows))
            ncol = len(self._table_headers)
            for r, row in enumerate(rows):
                color = row[-1]
                for c in range(ncol):
                    item = QTableWidgetItem(str(row[c]))
                    item.setBackground(color)
                    self.table.setItem(r, c, item)
        finally:
            self.table.setUpdatesEnabled(True)

    def _show_evidence(self, row: int, _col: int) -> None:
        """'Bu tutar nereden geldi?' — seçili satırın kaynak izini göster."""
        if not getattr(self, "_row_meta", None) or row >= len(self._row_meta):
            return
        firma_rec, tofas_rec = self._row_meta[row]

        def _block(title: str, rec) -> str:
            if rec is None:
                return ""
            src = rec.source_file or "-"
            name = Path(src).name if src and src != "-" else "-"
            line = [f"— {title} —",
                    f"Kaynak: {name}",
                    f"Satır: {rec.source_row if rec.source_row is not None else '-'}",
                    f"Alan: Tutar = {rec.amount}"]
            amt_src = getattr(rec, "amount_source", None)
            if amt_src:
                human = {"amount": "Tutar kolonu",
                         "debit-credit": "Borç - Alacak",
                         "balance": "Bakiye (son çare)"}.get(amt_src, amt_src)
                line.append(f"Tutar kaynağı: {human}")
            cur = getattr(rec, "currency", None)
            if cur:
                line.append(f"Para birimi: {cur}")
            line.append(f"Referans: {rec.reference_raw or rec.reference or '-'}")
            line.append(f"Çıkarım yöntemi: {rec.extraction_method or '-'}")
            return "\n".join(line)

        parts = [b for b in (_block("Firma ekstresi", firma_rec),
                             _block("TOFAŞ ekstresi", tofas_rec)) if b]
        self._info("\n\n".join(parts) or "Bu satır için kaynak bilgisi yok.")

    def _update_dashboard(self, result: ReconciliationResult) -> None:
        s = result.summary
        total = s.total_firma
        eslesen = s.matched
        eslesmeyen = max(total - eslesen, 0)
        rate = (eslesen / total * 100.0) if total else 0.0

        self.dash_company.setText(self.settings.company_name or "MUTABAKAT SONUCU")
        self.dash_rate.setText(f"%{rate:.2f}".replace(".", ","))
        self.dash_bar.setValue(int(round(rate)))
        self.card_total.set_value(f"{total:,}".replace(",", "."))
        self.card_eslesen.set_value(f"{eslesen:,}".replace(",", "."))
        self.card_eslesmeyen.set_value(f"{eslesmeyen:,}".replace(",", "."))

        # Durum ışığı — ilk 3 saniyede sonucu anlat.
        if rate >= 98.0:
            icon, text, color = "🟢", "Mutabakat başarılı — kontrol tamamlandı", "#2e7d32"
        elif rate >= 90.0:
            icon, text, color = (
                "🟡",
                f"Mutabakat kontrol gerektiriyor — {eslesmeyen} kayıt incelenmeli",
                "#b8860b",
            )
        else:
            icon, text, color = (
                "🔴",
                f"Mutabakat başarısız — {eslesmeyen} kayıt eşleşmedi",
                "#c62828",
            )
        self.dash_status.setText(f"{icon}  {text}")
        self.dash_status.setStyleSheet(f"color: {color}; font-weight: 600;")
        self.dash_bar.setStyleSheet(
            f"QProgressBar#DashBar::chunk {{ background-color: {color}; border-radius: 7px; }}"
        )
        self.dash_runid.setText(f"Mutabakat No: {s.run_id}" if s.run_id else "")

    def _write_again(self) -> None:
        if not self._result:
            self._warn("Önce bir mutabakat çalıştırın.")
            return
        tofas_path = self.tofas_edit.text().strip()
        cikti = self._ensure_output_folder()
        if not cikti:
            self._warn("Kaydedilecek klasör seçilmedi.")
            return
        try:
            from app.services.output_location import result_target
            from app.services.result_writer import ResultWriter

            yol = ResultWriter().write(
                tofas_path, self._result,
                target=result_target(tofas_path, cikti))
            self._info(f"Sonuç kaydedildi:\n{yol}")
        except Exception as exc:  # noqa: BLE001
            self._warn(f"Yazma hatası: {exc}")

    def _save_settings(self) -> None:
        self.settings.company_name = self.set_company.text().strip()
        self.settings.outgoing_mailbox_smtp = self.set_outgoing_smtp.text()
        self.settings.theme = self.set_theme.currentText()
        if self.settings.last_error:
            self._warn(f"Ayarlar kaydedilemedi: {self.settings.last_error}")
        else:
            self._info("Ayarlar kaydedildi.")

    def _change_theme(self, name: str) -> None:
        self.apply_theme(name)
        self.settings.theme = name

    # -- helpers ------------------------------------------------------------

    def apply_theme(self, name: str) -> None:
        self.setStyleSheet(get_theme(name))

    def _set_busy(self, busy: bool, message: str) -> None:
        self.status_label.setText(message)
        self.progress.setValue(0 if busy else 100)

    def _warn(self, message: str) -> None:
        QMessageBox.warning(self, "Uyarı", message)

    def _info(self, message: str) -> None:
        QMessageBox.information(self, "Bilgi", message)


def _fmt_date(d) -> str:
    return d.isoformat() if d else ""


# Açılışta Outlook bağlantısı için BEKLENECEK EN UZUN SÜRE.
#
# NEDEN SINIR VAR
#   ``get_default_account()`` tek bir COM ``Dispatch`` çağrısıdır ve zaman
#   aşımı YOKTUR. Outlook asılıysa, profil/parola penceresi açıksa ya da
#   onarım modundaysa çağrı hiç dönmez. Sınır olmadığı sürece kullanıcı
#   açılış ekranında SONSUZA KADAR bekliyordu — oysa uygulamanın ana işi
#   (Excel mutabakatı) Outlook'tan tamamen bağımsızdır.
#
#   Süre, yavaş kurumsal Exchange profillerine yetecek kadar uzun, kullanıcıyı
#   bekletmeyecek kadar kısa seçildi. Zaman aşımı bağlantıyı İPTAL ETMEZ:
#   bağlantı arka planda sürer, kurulduğunda mail özellikleri kendiliğinden
#   açılır.
OUTLOOK_STARTUP_TIMEOUT_MS = 10_000


def _bekle_outlook(worker, timeout_ms: int = OUTLOOK_STARTUP_TIMEOUT_MS) -> bool:
    """Worker bitene kadar bekle; UI canlı kalır. Zaman aşımında ``False``.

    Beklerken olay döngüsü çalıştığı için açılış ekranı donmaz ("not
    responding" yok). Dönüş değeri ``True`` ise bağlantı denemesi tamamlandı
    (başarılı ya da başarısız); ``False`` ise hâlâ sürüyor → kısıtlı açılış.
    """
    from PySide6.QtCore import QEventLoop, QTimer

    if worker.isFinished():
        return True

    loop = QEventLoop()
    worker.finished.connect(loop.quit)
    zamanlayici = QTimer()
    zamanlayici.setSingleShot(True)
    zamanlayici.timeout.connect(loop.quit)
    zamanlayici.start(max(0, int(timeout_ms)))
    try:
        loop.exec()
    finally:
        zamanlayici.stop()
    return worker.isFinished()


def main() -> int:
    app = QApplication(sys.argv)

    from app.ui.startup import OutlookConnectWorker, SplashScreen

    splash = SplashScreen()
    splash.center_on_screen()
    splash.show()
    app.processEvents()

    # Sonucu tutacak kutu (closure için).
    state = {"account": None, "error": None, "done": False}

    worker = OutlookConnectWorker()

    def on_ok(account):
        state["account"] = account
        state["done"] = True

    def on_failed(msg):
        state["error"] = msg
        state["done"] = True

    worker.ok.connect(on_ok)
    worker.failed.connect(on_failed)
    worker.start()

    # Arka plan bağlantısını beklerken UI'yı canlı tut (donma yok) — ama
    # SINIRSIZ bekleme yok: Outlook asılırsa ana pencere yine açılır.
    tamamlandi = _bekle_outlook(worker, OUTLOOK_STARTUP_TIMEOUT_MS)

    window = MainWindow()
    # Worker'a REFERANS tut: pencere yaşadıkça QThread çöp toplanmasın
    # (çalışan bir QThread yıkılırsa Qt süreci düşürür).
    window._outlook_startup_worker = worker

    # Arka planda kurulan bağlantıyı mailing sayfasına aktar. ``None``
    # geçirilmez: bağlantı kurulmadıysa sayfa "bağlı" görünmemelidir.
    if state["account"] is not None:
        try:
            window.set_outlook_account(state["account"])
        except Exception as exc:  # noqa: BLE001 - aktarım ana akışı düşürmez
            logger.warning(f"Outlook hesabı arayüze aktarılamadı: {exc}")

    window.show()
    splash.close()

    if not tamamlandi:
        # Bağlantı HÂLÂ sürüyor: pencere kısıtlı modda açıldı. Bağlantı
        # kurulduğunda mail özellikleri kendiliğinden etkinleşsin diye
        # sinyaller pencereye bağlanır (sinyal main thread'e kuyruklanır;
        # COM nesnesi thread'ler arasında TAŞINMAZ).
        worker.ok.connect(window.set_outlook_account)
        worker.failed.connect(
            lambda msg: logger.warning(
                f"Outlook bağlantısı arka planda başarısız: {msg}"))
        logger.warning(
            f"Outlook bağlantısı {OUTLOOK_STARTUP_TIMEOUT_MS} ms içinde "
            "tamamlanmadı; uygulama kısıtlı modda açıldı.")
        QMessageBox.information(
            window, "Outlook bağlantısı sürüyor",
            "Outlook bağlantısı beklenenden uzun sürdü; uygulama sizi "
            "bekletmemek için açıldı.\n\n"
            "Excel mutabakatı ŞİMDİ kullanılabilir. Mail gönderme ve gelen "
            "cevap tarama, bağlantı kurulur kurulmaz etkinleşecektir."
        )
    elif state["error"] is not None:
        QMessageBox.warning(
            window, "Outlook bağlantısı kurulamadı",
            "Uygulama Outlook olmadan açıldı. Excel mutabakatı kullanılabilir; "
            "mail gönderme ve gelen cevap tarama özellikleri bağlantı "
            "kurulana kadar kullanılamaz.\n\n"
            f"Ayrıntı: {state['error']}\n\n"
            "Outlook'un açık ve pywin32'nin kurulu olduğundan emin olun."
        )
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
