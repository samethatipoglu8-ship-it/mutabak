"""Mutabakat Pro paketi."""
