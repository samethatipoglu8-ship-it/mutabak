"""Roller, yetkiler ve gerekçesi zorunlu finansal karar değişikliği (madde 7).

NEDEN
    Mutabakat, sonuçları denetime giren bir finansal süreçtir. "Kim, ne
    zaman, neden?" sorusunun cevabı yoksa sistemin ürettiği rapor bir kanıt
    değil, yalnızca bir görüntüdür.

    Bu modül üç şeyi tanımlar:

      1. ROL  — Yönetici (ADMIN) ile operasyon kullanıcısı (OPERATOR)
         ayrıdır. Operasyon kullanıcısı gönderim yapar, adres düzeltir,
         inceleme yürütür; şirket politikasını (yuvarlama toleransı, rol
         atama) DEĞİŞTİREMEZ.
      2. YETKİ — Her hassas işlem bir yetkiye bağlıdır ve yetkisiz çağrı
         sessizce geçilmez, ``PermissionDenied`` fırlatır.
      3. GEREKÇE — Finansal kararı değiştiren işlemde açıklama ZORUNLUDUR.

DENETİM
    Her yetkili işlem ``ActionAuditLog``a kullanıcı adıyla yazılır. Günlük
    SALT EKLENİR; uygulama içinde silme/temizleme API'si YOKTUR.
"""

from __future__ import annotations

import getpass
import os
from dataclasses import dataclass
from typing import Any

from loguru import logger

# -- roller ----------------------------------------------------------------
ROLE_ADMIN = "ADMIN"
ROLE_OPERATOR = "OPERATOR"
ROLES = (ROLE_ADMIN, ROLE_OPERATOR)

# -- yetkiler --------------------------------------------------------------
PERM_VIEW = "VIEW"
PERM_SEND_MAIL = "SEND_MAIL"
PERM_CHANGE_ADDRESS = "CHANGE_ADDRESS"
PERM_CLOSE_DIFFERENCE = "CLOSE_DIFFERENCE"
PERM_MANUAL_RECONCILE = "MANUAL_RECONCILE"
PERM_CHANGE_POLICY = "CHANGE_POLICY"
PERM_MANAGE_ROLES = "MANAGE_ROLES"
#: Sonucu belirsiz kalan (SEND_UNKNOWN) bir gönderimin insan çözümü. Şimdilik
#: tek izin; ``send_unknown_resolution.DECISION_PERMISSION`` karar başına
#: eşler, böylece VERIFIED_SENT ve REOPENED ileride AYRI izinlere bölünebilir.
PERM_RESOLVE_SEND_UNKNOWN = "RESOLVE_SEND_UNKNOWN"

#: Operasyon kullanıcısı günlük işi yapar; POLİTİKA ve ROL yönetimi yapamaz.
_OPERATOR_PERMISSIONS = frozenset({
    PERM_VIEW, PERM_SEND_MAIL, PERM_CHANGE_ADDRESS,
    PERM_CLOSE_DIFFERENCE, PERM_MANUAL_RECONCILE,
    PERM_RESOLVE_SEND_UNKNOWN,
})
_ADMIN_PERMISSIONS = _OPERATOR_PERMISSIONS | {PERM_CHANGE_POLICY,
                                              PERM_MANAGE_ROLES}

_PERMISSIONS: dict[str, frozenset[str]] = {
    ROLE_ADMIN: frozenset(_ADMIN_PERMISSIONS),
    ROLE_OPERATOR: _OPERATOR_PERMISSIONS,
}

#: Ayarlardaki rol haritası: {kullanıcı_adı: ROL}
_ROLE_MAP_KEY = "user_roles"
#: Hiç rol tanımlanmamışsa geçerli olan rol.
DEFAULT_ROLE = ROLE_OPERATOR


class PermissionDenied(PermissionError):
    """Kullanıcının rolü bu işlemi yapmaya yetmiyor."""


class ReasonRequired(ValueError):
    """Finansal karar değişikliği gerekçesiz yapılamaz."""


def current_user() -> str:
    """İşlemi yapan kullanıcı (Windows oturum adı)."""
    try:
        return (os.environ.get("MUTABAKAT_USER")
                or getpass.getuser() or "bilinmeyen")
    except Exception:  # noqa: BLE001 - oturum adı okunamazsa iş durmaz
        return "bilinmeyen"


def role_of(user: str = "", settings: Any = None) -> str:
    """Kullanıcının rolü. Tanımlı değilse ``DEFAULT_ROLE``.

    Rol haritası ayarlarda tutulur; böylece yönetici, kurulum sonrası
    kullanıcıları koda dokunmadan yetkilendirebilir.
    """
    user = (user or current_user()).strip().lower()
    ortam = (os.environ.get("MUTABAKAT_ROLE") or "").strip().upper()
    if ortam in ROLES:
        return ortam
    if settings is None:
        return DEFAULT_ROLE
    try:
        harita = settings.get(_ROLE_MAP_KEY, {}) or {}
        rol = str(harita.get(user, "")).strip().upper()
    except Exception:  # noqa: BLE001 - bozuk ayar varsayılana düşer
        return DEFAULT_ROLE
    return rol if rol in ROLES else DEFAULT_ROLE


def set_role(user: str, role: str, *, settings: Any,
             actor: str = "", audit: Any = None) -> None:
    """Kullanıcıya rol ata. YALNIZCA yönetici yapabilir."""
    role = (role or "").strip().upper()
    if role not in ROLES:
        raise ValueError(f"Tanınmayan rol: {role}")
    actor = actor or current_user()
    require(PERM_MANAGE_ROLES, user=actor, settings=settings)
    harita = dict(settings.get(_ROLE_MAP_KEY, {}) or {})
    onceki = harita.get(user.strip().lower(), "")
    harita[user.strip().lower()] = role
    settings.set(_ROLE_MAP_KEY, harita)
    _audit(audit, action="ROLE_CHANGED", target=user, user=actor,
           old_value=onceki, new_value=role,
           reason="rol ataması")


def permissions_of(role: str) -> frozenset[str]:
    return _PERMISSIONS.get((role or "").strip().upper(), frozenset())


def can(permission: str, *, user: str = "", settings: Any = None,
        role: str = "") -> bool:
    """Kullanıcı bu işlemi yapabilir mi?"""
    rol = (role or role_of(user, settings)).strip().upper()
    return permission in permissions_of(rol)


def require(permission: str, *, user: str = "", settings: Any = None,
            role: str = "") -> str:
    """Yetkiyi doğrula; yoksa ``PermissionDenied`` fırlat. Döner: rol."""
    rol = (role or role_of(user, settings)).strip().upper()
    if permission not in permissions_of(rol):
        raise PermissionDenied(
            f"'{permission}' işlemi için yetkiniz yok (rol: {rol or '—'}). "
            "Bu işlem yönetici yetkisi gerektirir.")
    return rol


# -- gerekçesi zorunlu finansal karar --------------------------------------

@dataclass(frozen=True)
class DecisionChange:
    """Uygulanan finansal karar değişikliğinin kanıtı."""

    case_id: str
    old_status: str
    new_status: str
    reason: str
    user: str
    role: str


def change_financial_decision(case: Any, status: str, *, reason: str,
                              user: str = "", settings: Any = None,
                              role: str = "", audit: Any = None
                              ) -> DecisionChange:
    """Bir vakanın finansal kararını GEREKÇESİYLE değiştir.

    Arayüzün kullandığı TEK yol budur. Üç şey birlikte garanti edilir:

      * yetki (``MANUAL_RECONCILE``),
      * gerekçe (boş olamaz),
      * denetim kaydı (kullanıcı adı + eski/yeni değer + gerekçe).

    Gerekçe zorunluluğu biçimsel değildir: "neden mutabık saydın?" sorusunun
    cevabı aylar sonra yalnızca burada bulunur.
    """
    from app.services.case_tracking import apply_manual_status

    aktor = user or current_user()
    rol = require(PERM_MANUAL_RECONCILE, user=aktor, settings=settings,
                  role=role)
    gerekce = (reason or "").strip()
    if not gerekce:
        raise ReasonRequired(
            "Finansal kararı değiştirmek için GEREKÇE zorunludur. "
            "Bu açıklama denetim kaydına yazılır.")
    onceki = str(getattr(case, "final_status", "") or "")
    apply_manual_status(case, status, note=gerekce, user=aktor)
    yeni = str(getattr(case, "final_status", "") or "")
    _audit(audit, action="FINANCIAL_DECISION_CHANGED",
           target=str(getattr(case, "case_id", "") or ""),
           user=aktor, old_value=onceki, new_value=yeni, reason=gerekce,
           company_code=str(getattr(case, "company_code", "") or ""))
    return DecisionChange(case_id=str(getattr(case, "case_id", "") or ""),
                          old_status=onceki, new_status=yeni,
                          reason=gerekce, user=aktor, role=rol)


def _audit(audit: Any, **kwargs) -> None:
    """Denetim kaydı yaz. Günlük yoksa/yazılamazsa iş DURMAZ."""
    try:
        if audit is None:
            from app.services.action_audit import ActionAuditLog

            audit = ActionAuditLog()
        audit.record(**kwargs)
    except Exception as exc:  # noqa: BLE001 - denetim işi çökertmez
        logger.warning(f"[yetki] denetim kaydı yazılamadı: {exc}")
