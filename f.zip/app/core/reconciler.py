"""Deterministic TOFAŞ reconciliation engine.

Reference side is always the firma (supplier) statement. For each firma
invoice we look it up in the TOFAŞ export the way a clerk does a VLOOKUP.
All arithmetic is Decimal; no AI participates in matching.

Because firms differ in which column holds the invoice number, and TOFAŞ may
carry it in "Referans" or "Referans anahtar 1/2", each record exposes *all*
candidate reference values. Matching tries every firma-candidate against every
TOFAŞ-candidate. To prevent false positives from coincidental number overlap,
a reference match is confirmed only when the amount also agrees (integer part).

## Katmanlı GLOBAL eşleştirme (V4.1.2)

Eskiden her firma satırı sırayla (greedy) gezilip ilk uygun TOFAŞ satırı
kapılıyordu; sonuç dosya satır sırasına bağımlıydı ve amount-teyitsiz zayıf bir
eşleşme, amount-teyitli doğru bir eşleşmenin satırını çalabiliyordu.

Artık cascade KATMAN KATMAN, her katman TÜM kayıtlar üzerinde bir *bipartite
maximum matching* olarak çalışır. Katman sırası muhasebe önceliğini korur:

  T1  exact referans + tutar (teyitli)
  T2  fuzzy referans + tutar (teyitli)
  T3  tutar + belge tarihi (±pencere)
  T4  exact referans, tutar TEYİTSİZ (sarı/tutar-farkı olarak işaretlenir)

Tüm teyitli katmanlar (T1-T3) T4'ten ÖNCE bittiği için, zayıf T4 katmanı bir
teyitli eşleşmeyi asla çalamaz. Katman içindeki eşleştirme, adayları sabit
(row_index) sırada gezen deterministik bir augmenting-path (Kuhn) algoritmasıyla
yapılır; aynı girdi her zaman aynı çıktıyı verir.

Amounts are compared on magnitude (abs); only the integer part must match, a
kuruş (decimal) difference is tolerated and recorded. Signs should be opposite
(firma vs TOFAŞ); if not, a warning flag is set.

TOFAŞ duplicate references with mixed signs: the negative-signed row is the
match candidate; positive duplicates remain for leftover reporting.
"""

from __future__ import annotations

import heapq
from collections import defaultdict
from datetime import timedelta
from decimal import ROUND_HALF_UP, Decimal
from typing import Iterable, Optional

from app.models.domain import (
    CrossMatch,
    FirmaRecord,
    MatchedPair,
    MatchRule,
    MatchStatus,
    ReconciliationResult,
    Side,
    Summary,
    TofasRecord,
)
from app.utils.normalization import reference_fuzzy_key

_CENT = Decimal("0.01")

# ---------------------------------------------------------------------------
# İŞ KURALI — TUTAR TOLERANSI (onaylandı: lira altı)
#
# Bir eşleşmede tolere edilen en büyük |tutar| farkı. 0.99 = "kuruş farkları
# tolere edilir, 1 TL ve üzeri fark tutar farkıdır" kuralının birebir
# karşılığıdır (README ve mevcut testler bu kuralı tanımlar).
#
# Değiştirmek isteyen kurum ``Reconciler(amount_tolerance=...)`` ile
# geçebilir: "0.01" gerçek kuruş toleransı, "0" birebir tutar demektir.
# Kullanılan değer her çalıştırmada audit kaydına ve sonuç Excel'inin
# "Çalıştırma Parametreleri" bloğuna yazılır; sonuç daima izlenebilirdir.
# ---------------------------------------------------------------------------
DEFAULT_AMOUNT_TOLERANCE = Decimal("0.99")


class Reconciler:
    """Runs the deterministic firma→TOFAŞ matching cascade (tiered global)."""

    def __init__(
        self,
        excluded_belge_turu: Optional[Iterable[str]] = None,
        date_tolerance_days: int = 0,
        enable_cross_match: bool = True,
        cross_max_subset: int = 5,
        cross_max_pool: int = 20,
        amount_tolerance: Decimal | str | float | None = None,
        strict_currency: bool = False,
        cross_max_candidates: int = 6,
    ) -> None:
        self.excluded_belge_turu = {str(x).strip() for x in (excluded_belge_turu or [])}
        # Tutar+tarih katmanında izin verilen |gün| farkı. 0 => birebir tarih.
        self.date_tolerance_days = max(0, int(date_tolerance_days))
        # Bire-çok (subset-sum) çapraz eşleşme ayarları.
        self.enable_cross_match = bool(enable_cross_match)
        self.cross_max_subset = max(2, int(cross_max_subset))   # alt-küme üst sınırı
        self.cross_max_pool = max(2, int(cross_max_pool))       # aday havuzu üst sınırı
        # Tek bir eşleşmede tolere edilen mutlak |tutar| farkı.
        #
        # İŞ KURALI: README ve mevcut testler "kuruş farkı tolere edilir, TAM
        # SAYI kısmı farklıysa tutar farkıdır" diyor — yani tolerans bir liranın
        # altıdır. Varsayılan 0.99 bu kuralı BİREBİR korur, ancak eski
        # ``int(a) == int(b)`` uygulamasının asimetrisini giderir: 999.99 ↔
        # 1000.00 (1 kuruş fark) artık eşleşir, eskiden eşleşmiyordu.
        #
        # Daha katı bir mutabakat isteyen kurum "0.01" (gerçek kuruş toleransı)
        # ya da "0" (birebir tutar) verebilir; değer audit'e ve Excel özetine
        # yazılır, böylece sonucun hangi toleransla üretildiği izlenebilir.
        if amount_tolerance is None:
            tol = DEFAULT_AMOUNT_TOLERANCE
        elif isinstance(amount_tolerance, Decimal):
            tol = amount_tolerance
        else:
            tol = Decimal(str(amount_tolerance))
        self.amount_tolerance = tol.copy_abs()
        self.amount_tolerance_cents = self._cents(self.amount_tolerance)
        # True ise, taraflardan birinin para birimi boşsa eşleşmeye izin verilmez.
        self.strict_currency = bool(strict_currency)
        # Bir tekil satır için üretilecek en fazla alt-küme adayı (global seçim).
        self.cross_max_candidates = max(1, int(cross_max_candidates))

    def reconcile(
        self,
        firma: list[FirmaRecord],
        tofas: list[TofasRecord],
        sap_total: Optional[Decimal] = None,
        firma_total: Optional[Decimal] = None,
    ) -> ReconciliationResult:
        result = ReconciliationResult()
        result.excluded_belge_turu = sorted(self.excluded_belge_turu)
        # Bire-çok aramasında tarama bütçesi tükendi mi? Tükendiyse sonuç
        # DETERMİNİSTİK ama OPTİMUM OLMAYABİLİR; bu sessizce "normal eşleşme"
        # gibi gösterilmez, aşağıda veri kalitesi uyarısına dönüşür.
        self._budget_exhausted = False

        active_tofas = [
            r for r in tofas
            if (r.belge_turu or "").strip() not in self.excluded_belge_turu
        ]

        exact_index = self._build_index(active_tofas, fuzzy=False)
        fuzzy_index = self._build_index(active_tofas, fuzzy=True)
        amount_bucket = self._build_amount_bucket(active_tofas)

        firma_by_idx = {r.row_index: r for r in firma}
        tofas_by_idx = {r.row_index: r for r in active_tofas}

        matched_firma: set[int] = set()
        matched_tofas: set[int] = set()
        # (firma_idx, tofas_idx, rule, adj, rev_adj) sırayla toplanır; en son
        # classify edilir. ``adj`` o katmanın TÜM adaylarını taşır (sadece
        # kazananı değil) — FAZ 4 P0 güvenlik kapısı (identity/economic-event/
        # ambiguity) bu adaylara bakarak "rekabet eden başka bir aday var
        # mıydı?" sorusunu cevaplar. ``rev_adj`` (tofas_idx -> [firma_idx])
        # KATMAN BAŞINA BİR KEZ kurulur (bkz. ``run_tiers``) — "bu TOFAŞ
        # satırını hangi BAŞKA firma satırları da aday gösterdi?" sorusunu
        # O(1) yanıtlar. Bu önbellek OLMADAN (``adj.items()`` her çift için
        # yeniden taranarak) tipik bire-bir ağırlıklı iş yüklerinde O(N²)
        # yavaşlama oluşur — bkz. tests/test_performance.py::
        # test_throughput_stays_linear (bu regresyon o test tarafından
        # yakalandı ve bu önbellekle giderildi).
        # ``adj`` katman başına YENİDEN kurulduğu için (aynı
        # MatchRule.REFERENCE_EXACT T1'de ve T4'te farklı adj'lara sahiptir)
        # her çift KENDİ katmanının adj/rev_adj'ını taşır; f_idx bir katmanda
        # en fazla bir kez eşleştiği için sıralamada hiçbir çakışma (ve
        # dolayısıyla bu nesnelerin karşılaştırılması) olmaz.
        pairs: list[tuple[int, int, MatchRule, dict[int, list[int]], dict[int, list[int]]]] = []

        # -- katmanlar: her biri TÜM kalan kayıtlar üzerinde global matching ----
        # ÖNCE tutar-TEYİTLİ katmanlar (T1-T3). Sonra bire-çok (subset-sum).
        # EN SON tutar-TEYİTSİZ zayıf katman (T4) — böylece ne zayıf katman
        # teyitli eşleşmeyi ne de temiz bir subset-sum grubunu çalabilir.
        confirmed_tiers = (
            (MatchRule.REFERENCE_EXACT, self._edges_reference, dict(index=exact_index, fuzzy=False, require_amount=True)),
            (MatchRule.REFERENCE_FUZZY, self._edges_reference, dict(index=fuzzy_index, fuzzy=True, require_amount=True)),
            (MatchRule.AMOUNT_DATE, self._edges_amount_date, dict(bucket=amount_bucket)),
        )
        weak_tier = (
            (MatchRule.REFERENCE_EXACT, self._edges_reference, dict(index=exact_index, fuzzy=False, require_amount=False)),
        )

        def run_tiers(tier_defs):
            for rule, edge_fn, kw in tier_defs:
                adj = edge_fn(
                    firma, firma_by_idx, tofas_by_idx,
                    matched_firma, matched_tofas, **kw,
                )
                rev_adj: dict[int, list[int]] = defaultdict(list)
                for f, ts in adj.items():
                    for t in ts:
                        rev_adj[t].append(f)
                assignment = self._max_bipartite_matching(sorted(adj.keys()), adj)
                for f_idx, t_idx in sorted(assignment.items()):
                    matched_firma.add(f_idx)
                    matched_tofas.add(t_idx)
                    pairs.append((f_idx, t_idx, rule, adj, rev_adj))

        run_tiers(confirmed_tiers)

        # -- P2: bire-çok (subset-sum) çapraz eşleşme — zayıf katmandan ÖNCE ----
        if self.enable_cross_match:
            self._cross_match(
                firma, active_tofas, firma_by_idx, tofas_by_idx,
                exact_index, fuzzy_index, matched_firma, matched_tofas, result,
            )

        run_tiers(weak_tier)

        # -- T5: PARA BİRİMİ ÇELİŞKİSİ — en son, tüm eşleştirmeler bittikten sonra
        #
        # SORUN: ``_currency_compatible`` yukarıdaki TÜM katmanlarda kenar
        # kurulmasını engelliyor. İki taraf da para birimi bildirip bunlar
        # farklıysa, aynı fatura no hiçbir katmanda eşleşmiyor ve kalem AYNI
        # ANDA ``only_firma`` VE ``only_tofas`` kovasına düşüyordu. Muhasebeci
        # Excel'de aynı fatura numarasını hem "sadece firmada" hem "sadece
        # TOFAŞ'ta" bloğunda görüp bunu kendisi fark etmek zorundaydı — oysa
        # bu "eksik fatura" değil, BAMBAŞKA bir aksiyon gerektiren para birimi
        # uyuşmazlığıdır.
        #
        # BU BİR EŞLEŞME DEĞİLDİR: kalem mutabık sayılmaz, tutarlar
        # karşılaştırılmaz, ``matched``e girmez. Yalnızca iki satır
        # ETİKETLENEREK bir araya getirilir.
        #
        # EN SONDA ÇALIŞIR: yalnızca başka hiçbir katmanın alamadığı
        # artıkları tüketir, dolayısıyla hiçbir meşru eşleşmeyi çalamaz.
        #
        # TUTAR EŞİTLİĞİ ARANMAZ: kur çevrimi yapılmış bir ekstrede tutarlar
        # zaten tutmaz (100 EUR ↔ 3.500 TRY). Tutar şartı konulsa gerçek
        # vakaların çoğu kaçardı. Güçlü kimlik referanstır.
        currency_pairs = self._currency_conflict_pairs(
            firma, exact_index, matched_firma, matched_tofas,
        )

        # -- classify (deterministik: firma satır sırasına göre) ----------------
        for f_idx, t_idx, rule, adj, rev_adj in sorted(pairs, key=lambda p: p[0]):
            self._classify(
                result, firma_by_idx[f_idx], tofas_by_idx[t_idx], rule,
                adj=adj, rev_adj=rev_adj,
                firma_by_idx=firma_by_idx, tofas_by_idx=tofas_by_idx,
            )

        for f_idx, t_idx in currency_pairs:
            self._classify_currency_conflict(
                result, firma_by_idx[f_idx], tofas_by_idx[t_idx])
            # Çifte raporlamayı ÖNLE: bu iki satır artık "sadece firmada" ya
            # da "sadece TOFAŞ'ta" listelerine DE girmemeli; aksi hâlde aynı
            # fatura üç yerde görünür ve sayımlar şişer.
            matched_firma.add(f_idx)
            matched_tofas.add(t_idx)

        for firma_record in firma:
            if firma_record.row_index not in matched_firma:
                result.only_firma.append(firma_record)
        for tofas_record in active_tofas:
            if tofas_record.row_index not in matched_tofas:
                result.only_tofas.append(tofas_record)

        result.summary = self._summarize(
            result, firma, active_tofas, sap_total, firma_total
        )
        if self._budget_exhausted:
            # SESSİZ KALMAZ: yaklaşık bir bire-çok seçimi, kesin bir eşleşme
            # gibi gösterilemez. Uyarı Excel özetine ve gelen mail hattındaki
            # veri kalitesi raporuna taşınır; kullanıcı bu eşleşmeleri elle
            # doğrulamalıdır.
            result.data_quality.append(
                "CROSS_MATCH_APPROXIMATE: Bire-çok eşleştirmede arama bütçesi "
                "tükendi; seçim deterministiktir ancak EN İYİ olmayabilir. "
                "Bire-çok (mor) satırları elle doğrulayın."
            )
        return result

    @property
    def cross_match_approximate(self) -> bool:
        """Son çalıştırmada bire-çok araması bütçe nedeniyle kısaldı mı?"""
        return getattr(self, "_budget_exhausted", False)

    # -- indexing -----------------------------------------------------------

    def _build_index(self, tofas: list[TofasRecord], fuzzy: bool) -> dict[str, list[TofasRecord]]:
        """Index TOFAŞ rows by every candidate reference key.

        A row is registered under each of its candidate references. Duplicate
        handling: when a key maps to multiple rows and at least one is negative,
        only the negative rows are kept as candidates.
        """
        raw: dict[str, list[TofasRecord]] = defaultdict(list)
        for r in tofas:
            keys = set()
            for ref in (r.all_references or ([r.reference] if r.reference else [])):
                if not ref:
                    continue
                keys.add(reference_fuzzy_key(ref) if fuzzy else ref)
            for k in keys:
                if k:
                    raw[k].append(r)

        index: dict[str, list[TofasRecord]] = {}
        for key, rows in raw.items():
            uniq: list[TofasRecord] = []
            seen = set()
            for x in rows:
                if x.row_index not in seen:
                    uniq.append(x)
                    seen.add(x.row_index)
            has_negative = any(x.amount < 0 for x in uniq)
            if has_negative and len(uniq) > 1:
                index[key] = [x for x in uniq if x.amount < 0]
            else:
                index[key] = uniq
        return index

    def _build_amount_bucket(self, tofas: list[TofasRecord]) -> dict[int, list[TofasRecord]]:
        """|tutar| KURUŞ -> o tutardaki TOFAŞ satırları (orijinal sırada).

        Tutar+tarih katmanı bu kova üzerinden çalışır; tarih penceresi burada
        değil, kenar üretiminde uygulanır (böylece ±gün toleransı esnek kalır).
        Kova artık tam sayı kısmı yerine kuruş anahtarlıdır; tolerans komşu
        kovalara bakılarak uygulanır (bkz. ``_edges_amount_date``).
        """
        bucket: dict[int, list[TofasRecord]] = defaultdict(list)
        for r in tofas:
            bucket[self._cents(r.amount)].append(r)
        return bucket

    # -- edge builders (katman adayları) ------------------------------------

    @staticmethod
    def _currency_unknown(a: Optional[str], b: Optional[str]) -> bool:
        """Taraflardan en az birinin para birimi bilinmiyor mu?"""
        return not a or not b

    def _currency_compatible(self, a: Optional[str], b: Optional[str]) -> bool:
        """Para birimleri uyumlu mu?

        İkisi de doluysa eşit olmalı. Biri boşsa (çoğu ekstrede currency kolonu
        yoktur) varsayılan olarak kısıtlama uygulanmaz — ancak eşleşme
        ``para_birimi_uyari`` bayrağıyla işaretlenir, yani asla SESSİZ olmaz.
        ``strict_currency=True`` ile bilinmeyen para birimi eşleşmeyi engeller.
        """
        if not a or not b:
            return not self.strict_currency
        return a.strip().upper() == b.strip().upper()

    def _firma_keys(self, rec: FirmaRecord, fuzzy: bool) -> list[str]:
        refs = rec.all_references or ([rec.reference] if rec.reference else [])
        out = []
        for ref in refs:
            if not ref:
                continue
            key = reference_fuzzy_key(ref) if fuzzy else ref
            if key:  # fuzzy key None olabilir (anlamsız çekirdek) — ele
                out.append(key)
        return out

    @staticmethod
    def _cents(value: Decimal) -> int:
        """|tutar|'ı kuruşa (tam sayı) çevir — yarım yukarı yuvarlayarak.

        Tüm tutar karşılaştırmaları ve alt-küme toplamları bu tam sayı kuruş
        uzayında yapılır; float hatası yoktur ve toplama birebir doğrudur.
        """
        return int(value.copy_abs().quantize(_CENT, rounding=ROUND_HALF_UP) * 100)

    def _amounts_match(self, a: Decimal, b: Decimal) -> bool:
        """İki tutar (mutlak değer) yapılandırılmış tolerans içinde mi?

        Eskiden ``int(|a|) == int(|b|)`` (tam sayı kısmı) kullanılıyordu; bu hem
        AŞIRI toleranslı (1000.01 ↔ 1000.99 eşleşiyordu, 0.98 fark) hem de
        YETERSİZ toleranslıydı (999.99 ↔ 1000.00 eşleşmiyordu, 0.01 fark).
        Artık açık ve yapılandırılabilir bir mutlak fark kullanılır.
        """
        return abs(self._cents(a) - self._cents(b)) <= self.amount_tolerance_cents

    def _edges_reference(
        self, firma, firma_by_idx, tofas_by_idx, matched_firma, matched_tofas,
        *, index, fuzzy, require_amount,
    ) -> dict[int, list[int]]:
        """Referans katmanı için firma_idx -> [tofas_idx] kenarları.

        fuzzy=False → exact referans (exact_index); fuzzy=True → baştaki 0/ayraç
        farkını tolere eden fuzzy anahtar (fuzzy_index). require_amount=True ise
        yalnızca tutarı da tutan (teyitli) adaylar; False ise tutar teyidi
        olmadan (zayıf T4) — bu katman en sonda, tüm teyitli katmanlardan
        sonra çalışır, dolayısıyla teyitli bir eşleşmeyi çalamaz.
        """
        adj: dict[int, list[int]] = {}
        for rec in firma:
            if rec.row_index in matched_firma:
                continue
            cand_idxs: list[int] = []
            seen: set[int] = set()
            for key in self._firma_keys(rec, fuzzy=fuzzy):
                for cand in index.get(key, []):
                    if cand.row_index in matched_tofas or cand.row_index in seen:
                        continue
                    if not self._currency_compatible(rec.currency, cand.currency):
                        continue
                    if require_amount and not self._amounts_match(rec.amount, cand.amount):
                        continue
                    seen.add(cand.row_index)
                    cand_idxs.append(cand.row_index)
            if cand_idxs:
                adj[rec.row_index] = sorted(cand_idxs)
        return adj

    def _currency_conflict_pairs(
        self, firma, exact_index, matched_firma, matched_tofas,
    ) -> list[tuple[int, int]]:
        """Birebir referansı tutan ama para birimi ÇELİŞEN artık çiftleri bul.

        Yalnızca İKİ TARAF DA para birimi bildirmiş ve bunlar farklıysa çift
        kurulur. Biri boşsa çelişki YOK sayılır: o durum zaten mevcut
        ``para_birimi_uyari`` bayrağıyla taşınıyor ve ``strict_currency``
        ayarının konusudur; burada yeni bir karar üretilmez.

        Çağrıldığı yer tüm eşleştirme katmanlarından SONRAdır, bu yüzden
        ``matched_*`` kümeleri nihaidir ve bu fonksiyon hiçbir eşleşmeyi
        bozamaz. Deterministiklik: firma satır sırası, sonra TOFAŞ satır
        sırası; her iki taraf da en fazla bir kez kullanılır.
        """
        out: list[tuple[int, int]] = []
        kullanilan_tofas: set[int] = set()
        for rec in sorted(firma, key=lambda r: r.row_index):
            if rec.row_index in matched_firma or not rec.currency:
                continue
            adaylar = []
            for key in self._firma_keys(rec, fuzzy=False):
                for cand in exact_index.get(key, []):
                    if cand.row_index in matched_tofas:
                        continue
                    if cand.row_index in kullanilan_tofas:
                        continue
                    if not cand.currency:
                        continue
                    if (rec.currency.strip().upper()
                            == cand.currency.strip().upper()):
                        continue      # çelişki yok
                    adaylar.append(cand.row_index)
            if adaylar:
                secilen = min(adaylar)
                kullanilan_tofas.add(secilen)
                out.append((rec.row_index, secilen))
        return out

    def _edges_amount_date(
        self, firma, firma_by_idx, tofas_by_idx, matched_firma, matched_tofas,
        *, bucket,
    ) -> dict[int, list[int]]:
        """Tutar+tarih katmanı: aynı |tutar| tam kısımda, tarih penceresi içinde."""
        tol = self.date_tolerance_days
        adj: dict[int, list[int]] = {}
        for rec in firma:
            if rec.row_index in matched_firma or rec.inv_date is None:
                continue
            key = self._cents(rec.amount)
            cand_idxs: list[int] = []
            # Kuruş toleransı: komşu kovalar da taranır, ardından kesin kontrol.
            span = self.amount_tolerance_cents
            for k in range(key - span, key + span + 1):
                for cand in bucket.get(k, []):
                    if cand.row_index in matched_tofas or cand.belge_tarihi is None:
                        continue
                    if not self._currency_compatible(rec.currency, cand.currency):
                        continue
                    if not self._amounts_match(rec.amount, cand.amount):
                        continue
                    if abs((rec.inv_date - cand.belge_tarihi).days) > tol:
                        continue
                    cand_idxs.append(cand.row_index)
            if cand_idxs:
                adj[rec.row_index] = sorted(cand_idxs)
        return adj

    # -- deterministic bipartite matching -----------------------------------

    @staticmethod
    def _max_bipartite_matching(firma_ids_sorted: list[int], adj: dict[int, list[int]]) -> dict[int, int]:
        """Kuhn augmenting-path maksimum eşleştirme. Adaylar sabit sırada
        gezildiği için sonuç deterministiktir. Döner: {firma_idx: tofas_idx}."""
        match_t2f: dict[int, int] = {}  # tofas_idx -> firma_idx

        def try_augment(f: int, visited: set[int]) -> bool:
            for t in adj.get(f, []):
                if t in visited:
                    continue
                visited.add(t)
                if t not in match_t2f or try_augment(match_t2f[t], visited):
                    match_t2f[t] = f
                    return True
            return False

        for f in firma_ids_sorted:
            try_augment(f, set())
        return {f: t for t, f in match_t2f.items()}

    # -- P2: bire-çok / çapraz (subset-sum) eşleşme --------------------------

    @staticmethod
    def _build_ref_index(records, fuzzy: bool) -> dict[str, list]:
        """Kayıtları (firma ya da tofas) referans anahtarına göre indeksle.
        Çapraz eşleşmede aday havuzunu referansa göre daraltmak için kullanılır."""
        idx: dict[str, list] = defaultdict(list)
        for r in records:
            keys = set()
            for ref in (r.all_references or ([r.reference] if r.reference else [])):
                if not ref:
                    continue
                k = reference_fuzzy_key(ref) if fuzzy else ref
                if k:
                    keys.add(k)
            for k in keys:
                idx[k].append(r)
        return idx

    def _cross_pool(self, rec, exact_idx, fuzzy_idx, matched_other, self_ref_keys_fn):
        """rec (tek satır) için, referansla bağlı kalan KARŞI-taraf adaylarını
        döndür. Önce exact referans; yoksa fuzzy. (row_index, int|tutar|) listesi
        ve kural (CROSS_SUBSET_REF) döner. Aday yoksa (None, kural) → tarih
        havuzu çağıran tarafça denenir."""
        for fuzzy in (False, True):
            index = fuzzy_idx if fuzzy else exact_idx
            seen: set[int] = set()
            pool: list[tuple[int, int]] = []
            for key in self_ref_keys_fn(rec, fuzzy):
                for cand in index.get(key, []):
                    if cand.row_index in matched_other or cand.row_index in seen:
                        continue
                    if not self._currency_compatible(rec.currency, cand.currency):
                        continue
                    if cand.amount.copy_abs() == 0:
                        continue
                    seen.add(cand.row_index)
                    pool.append((cand.row_index, self._cents(cand.amount)))
            if len(pool) >= 2:
                return sorted(pool)[: self.cross_max_pool], MatchRule.CROSS_SUBSET_REF
        return [], MatchRule.CROSS_SUBSET_REF

    @staticmethod
    def _build_date_index(records) -> dict:
        """Kayıtları belge tarihine göre indeksle (her kova row_index sırasında).

        Eskiden tarih havuzu her tekil satır için TÜM karşı-taraf kayıtları
        taranarak kuruluyordu: O(n²). 20.000 eşleşmemiş satırda bu, mutabakatı
        dakikalarca askıda bırakıyordu. Artık tarih başına kova kurulur ve
        yalnızca ±tolerans günündeki kovalara bakılır.
        """
        idx: dict = defaultdict(list)
        for r in records:
            d = getattr(r, "belge_tarihi", None) or getattr(r, "inv_date", None)
            if d is not None:
                idx[d].append(r)
        return idx

    def _cross_pool_date(self, rec_date, rec_currency, date_index, matched_other):
        """Referans havuzu boşsa: tarih penceresi içindeki karşı-taraf adayları.

        Yalnızca date_tolerance_days > 0 iken devreye girer (aksi halde referanssız
        toplamların sahte eşleşme riski yüksektir). Sonuç eskisiyle AYNIdır —
        row_index'i en küçük ``cross_max_pool`` aday — ama kovalar row_index
        sıralı olduğu için havuz dolunca tarama erken biter.
        """
        if rec_date is None or self.date_tolerance_days <= 0:
            return [], MatchRule.CROSS_SUBSET_DATE
        tol = self.date_tolerance_days
        buckets = [
            date_index.get(rec_date + timedelta(days=k), ())
            for k in range(-tol, tol + 1)
        ]
        pool: list[tuple[int, int]] = []
        for cand in heapq.merge(*buckets, key=lambda r: r.row_index):
            if cand.row_index in matched_other:
                continue
            if not self._currency_compatible(rec_currency, cand.currency):
                continue
            if cand.amount.copy_abs() == 0:
                continue
            pool.append((cand.row_index, self._cents(cand.amount)))
            if len(pool) >= self.cross_max_pool:
                break
        if len(pool) >= 2:
            return pool, MatchRule.CROSS_SUBSET_DATE
        return [], MatchRule.CROSS_SUBSET_DATE

    # Tek bir tekil satır için taranacak en fazla alt-küme kombinasyonu.
    # C(20,5)+... ≈ 21.700 olduğundan varsayılan sınır pratikte tam taramaya
    # izin verir; yalnızca patolojik havuzlarda devreye girer.
    _SUBSET_SCAN_BUDGET = 25_000

    def _find_subsets(
        self, pool: list[tuple[int, int]], target_cents: int, limit: int
    ) -> list[list[int]]:
        """pool içinde |tutar| KURUŞ toplamı target'a (tolerans dahilinde) eşit
        olan alt-kümeleri bul.

        Toplamlar tam sayı kuruş üzerinden yapılır; eskiden her satırın tutarı
        ``int()`` ile kesiliyordu, bu yüzden 100.60 + 200.60 = 301.20 grubu
        (kesilmiş 100+200=300 ≠ 301) BULUNAMIYORDU.

        Deterministik sıra: önce en küçük kardinalite, sonra sözlüksel
        (row_index) sıra. En fazla ``limit`` aday döner; adaylar global seçime
        girer (ilk bulunanı doğrudan uygulamak satır sırasına bağımlıydı).
        """
        out: list[list[int]] = []
        if target_cents <= 0 or len(pool) < 2:
            return out
        n = len(pool)
        max_k = min(self.cross_max_subset, n)
        tol = self.amount_tolerance_cents

        # -- ulaşılabilirlik budaması ---------------------------------------
        # k elemanla üretilebilecek EN KÜÇÜK ve EN BÜYÜK toplam bilinir; hedef
        # bu aralığın dışındaysa o kardinalite için tek bir kombinasyon bile
        # denenmez. Çözümsüz aramaların ezici çoğunluğu burada elenir
        # (ör. 1.000.000'luk hedef, küçük tutarlardan oluşan bir havuz).
        asc = sorted(v for _, v in pool)
        lo_pref = [0]
        for v in asc:
            lo_pref.append(lo_pref[-1] + v)
        hi_pref = [0]
        for v in reversed(asc):
            hi_pref.append(hi_pref[-1] + v)

        # Sonek (suffix) uç değerleri — kısmi bir seçimden hedefe ULAŞILABİLİR
        # mi sorusunu O(1)'de yanıtlar.
        vals = [v for _, v in pool]
        suf_max = [0] * (n + 1)
        suf_min = [0] * (n + 1)
        for i in range(n - 1, -1, -1):
            suf_max[i] = vals[i] if i == n - 1 else max(vals[i], suf_max[i + 1])
            suf_min[i] = vals[i] if i == n - 1 else min(vals[i], suf_min[i + 1])

        # Tarama bütçesi: patolojik havuzlarda motorun kilitlenmesini önler.
        # Bütçe sabit ve sıra deterministik olduğu için sonuç tekrarlanabilir.
        budget = [self._SUBSET_SCAN_BUDGET]

        def dfs(start: int, slots: int, cur: int, chosen: list[int]) -> bool:
            """Sözlüksel (index) sırada k-elemanlı alt-kümeleri gez.

            Sıra ``combinations`` ile BİREBİR aynıdır — yani çıktı sırası ve
            dolayısıyla determinizm korunur — ama koşan toplam tutulduğu için
            her kombinasyon O(k) yerine O(1) maliyetlidir ve ulaşılamayan
            dallar hiç açılmaz. Döner: True ⇒ arama durdurulsun.
            """
            if slots == 0:
                if abs(cur - target_cents) <= tol:
                    out.append([pool[i][0] for i in chosen])
                    if len(out) >= limit:
                        return True
                return False
            need = target_cents - cur
            if need > slots * suf_max[start] + tol:
                return False               # kalanların en büyüğüyle bile yetmez
            if need < slots * suf_min[start] - tol:
                return False               # kalanların en küçüğüyle bile aşar
            for i in range(start, n - slots + 1):
                budget[0] -= 1
                if budget[0] <= 0:
                    # This is a search cut-off, not a normal "enough results"
                    # stop. Surface it through the same user-visible warning as
                    # the global candidate-selection budget.
                    self._budget_exhausted = True
                    return True
                chosen.append(i)
                stop = dfs(i + 1, slots - 1, cur + vals[i], chosen)
                chosen.pop()
                if stop:
                    return True
            return False

        for k in range(2, max_k + 1):
            if lo_pref[k] - tol > target_cents:
                break                      # daha büyük k daha da büyük toplar
            if hi_pref[k] + tol < target_cents:
                continue                   # bu k ile hedefe ulaşılamaz
            if dfs(0, k, 0, []):
                return out
        return out

    # -- aday üretimi + GLOBAL seçim ----------------------------------------
    #
    # Eskiden bire-çok eşleşme greedy'ydi: firma satırları row_index sırasında
    # gezilir, bulunan İLK alt-küme anında sabitlenir ve karşı satırlar
    # tüketilirdi. Bu, sonucun DOSYA SATIR SIRASINA bağlı olması demekti —
    # aynı veri farklı sırada verildiğinde farklı sayıda eşleşme çıkıyordu.
    #
    # Artık iki aşamalıdır:
    #   1) ADAY ÜRETİMİ  — hiçbir şey tüketilmeden, tüm tekil satırlar için
    #      olası alt-küme adayları üretilir (girdi sırasından bağımsız).
    #   2) GLOBAL SEÇİM  — çakışan adaylar arasından, toplam skoru en yüksek
    #      olan AYRIK (disjoint) aday kümesi seçilir.

    _SIDE_ORDER = {Side.FIRMA: 0, Side.TOFAS: 1}

    def _candidate_score(self, rule: MatchRule, many_count: int, kurus_diff: int) -> int:
        """Aday kalite skoru (yüksek = güçlü kanıt).

        Referansla bağlı bir grup, yalnızca tarih penceresiyle bulunmuş bir
        gruptan daima daha güçlüdür; küçük gruplar büyük gruplardan; kuruş
        farkı olmayan gruplar farklı olanlardan güçlüdür.
        """
        base = 100 if rule is MatchRule.CROSS_SUBSET_REF else 60
        return base - 2 * max(0, many_count - 2) - min(kurus_diff, 20)

    def _cross_candidates(self, firma, active_tofas, firma_by_idx, tofas_by_idx,
                          exact_index, fuzzy_index, matched_firma, matched_tofas):
        """Her iki yön için tüm bire-çok adaylarını üret (hiçbirini uygulamadan)."""
        firma_exact = self._build_ref_index(firma, fuzzy=False)
        firma_fuzzy = self._build_ref_index(firma, fuzzy=True)

        def firma_keys(rec, fuzzy):
            return self._firma_keys(rec, fuzzy=fuzzy)

        free_tofas = [t for t in active_tofas if t.row_index not in matched_tofas]
        free_firma = [f for f in firma if f.row_index not in matched_firma]
        # Tarih havuzu yalnızca gerektiğinde kurulur (tolerans kapalıysa boşuna
        # indeks kurmayalım).
        if self.date_tolerance_days > 0:
            tofas_by_date = self._build_date_index(free_tofas)
            firma_by_date = self._build_date_index(free_firma)
        else:
            tofas_by_date = firma_by_date = {}

        cands: list[dict] = []

        def emit(side, one, many_idx_list, rule, by_idx):
            many = [by_idx[i] for i in many_idx_list]
            total_one = one.amount.copy_abs()
            total_many = sum((m.amount.copy_abs() for m in many), Decimal("0"))
            kurus = (total_one - total_many).copy_abs()
            cur_warn = any(
                self._currency_unknown(one.currency, m.currency) for m in many
            )
            if side is Side.FIRMA:
                f_ids, t_ids = {one.row_index}, set(many_idx_list)
            else:
                f_ids, t_ids = set(many_idx_list), {one.row_index}
            cands.append({
                "side": side, "one": one, "many": many, "rule": rule,
                "total_one": total_one, "total_many": total_many,
                "kurus": kurus, "currency_warn": cur_warn,
                "firma_ids": f_ids, "tofas_ids": t_ids,
                "score": self._candidate_score(
                    rule, len(many), self._cents(kurus)),
                "key": (self._SIDE_ORDER[side], one.row_index,
                        tuple(sorted(many_idx_list))),
            })

        # Yön A: bir FIRMA satırı ↔ çok TOFAŞ satırı
        for rec in sorted(free_firma, key=lambda r: r.row_index):
            target = self._cents(rec.amount)
            if target == 0:
                continue
            pool, rule = self._cross_pool(rec, exact_index, fuzzy_index,
                                          matched_tofas, firma_keys)
            if not pool:
                pool, rule = self._cross_pool_date(
                    rec.inv_date, rec.currency, tofas_by_date, matched_tofas)
            for subset in self._find_subsets(pool, target, self.cross_max_candidates):
                emit(Side.FIRMA, rec, subset, rule, tofas_by_idx)

        # Yön B: bir TOFAŞ satırı ↔ çok FIRMA satırı
        for rec in sorted(free_tofas, key=lambda r: r.row_index):
            target = self._cents(rec.amount)
            if target == 0:
                continue
            pool, rule = self._cross_pool(rec, firma_exact, firma_fuzzy,
                                          matched_firma, firma_keys)
            if not pool:
                pool, rule = self._cross_pool_date(
                    rec.belge_tarihi, rec.currency, firma_by_date, matched_firma)
            for subset in self._find_subsets(pool, target, self.cross_max_candidates):
                emit(Side.TOFAS, rec, subset, rule, firma_by_idx)

        return cands

    @staticmethod
    def _conflict_components(cands: list[dict]) -> list[list[int]]:
        """Kayıt paylaşan adayları bağlantılı bileşenlere ayır (union-find).

        Bileşenler birbirinden bağımsız çözülebilir; bu, global seçimi gerçek
        veri boyutunda uygulanabilir kılar (çakışma kümeleri pratikte küçüktür).
        """
        parent = list(range(len(cands)))

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a, b):
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[max(ra, rb)] = min(ra, rb)

        owner: dict[tuple[str, int], int] = {}
        for i, c in enumerate(cands):
            for tag, ids in (("F", c["firma_ids"]), ("T", c["tofas_ids"])):
                for rid in ids:
                    prev = owner.get((tag, rid))
                    if prev is None:
                        owner[(tag, rid)] = i
                    else:
                        union(prev, i)

        groups: dict[int, list[int]] = defaultdict(list)
        for i in range(len(cands)):
            groups[find(i)].append(i)
        return [sorted(g) for _, g in sorted(groups.items())]

    # Bir bileşende denenecek en fazla arama düğümü. Aşılırsa deterministik
    # greedy'ye düşülür (sonuç yine satır sırasından bağımsızdır, sadece
    # optimum olma garantisi kalkar).
    _SEARCH_NODE_BUDGET = 50_000

    def _select_candidates(self, cands: list[dict]) -> list[dict]:
        """Çakışmayan (ayrık) adaylardan toplam skoru en yüksek kümeyi seç.

        Seçim yalnızca adayların kendi özelliklerine ve sabit bir sözlüksel
        tie-break anahtarına dayanır; girdi satır sırasına DEĞİL.
        """
        if not cands:
            return []
        chosen: list[dict] = []
        for comp in self._conflict_components(cands):
            items = sorted((cands[i] for i in comp), key=lambda c: (-c["score"], c["key"]))
            chosen.extend(self._best_disjoint(items))
        return sorted(chosen, key=lambda c: c["key"])

    def _best_disjoint(self, items: list[dict]) -> list[dict]:
        """Bir bileşen içinde en iyi ayrık alt-kümeyi bul (dal-budama)."""
        n = len(items)
        best: dict = {"score": -1, "picked": []}
        budget = [self._SEARCH_NODE_BUDGET]
        suffix_max = [0] * (n + 1)   # kalan adaylardan alınabilecek üst sınır
        for i in range(n - 1, -1, -1):
            suffix_max[i] = suffix_max[i + 1] + max(0, items[i]["score"])

        def dfs(i: int, used_f: set, used_t: set, score: int, picked: list) -> None:
            if budget[0] <= 0:
                return
            budget[0] -= 1
            if score > best["score"] or (
                score == best["score"]
                and [p["key"] for p in picked] < [p["key"] for p in best["picked"]]
            ):
                best["score"] = score
                best["picked"] = list(picked)
            if i >= n or score + suffix_max[i] < best["score"]:
                return
            c = items[i]
            if not (c["firma_ids"] & used_f) and not (c["tofas_ids"] & used_t):
                picked.append(c)
                dfs(i + 1, used_f | c["firma_ids"], used_t | c["tofas_ids"],
                    score + c["score"], picked)
                picked.pop()
            dfs(i + 1, used_f, used_t, score, picked)

        dfs(0, set(), set(), 0, [])
        if budget[0] > 0:
            return best["picked"]
        # Bütçe tükendi → deterministik greedy (skor, sonra sabit anahtar).
        # Sonuç tekrarlanabilir ama EN İYİ olmayabilir; kullanıcı bunu
        # bilmeli (aksi hâlde yaklaşık bir eşleşme kesin gibi görünür).
        self._budget_exhausted = True
        used_f: set[int] = set()
        used_t: set[int] = set()
        out: list[dict] = []
        for c in items:
            if c["firma_ids"] & used_f or c["tofas_ids"] & used_t:
                continue
            used_f |= c["firma_ids"]
            used_t |= c["tofas_ids"]
            out.append(c)
        return out

    def _cross_match(self, firma, active_tofas, firma_by_idx, tofas_by_idx,
                     exact_index, fuzzy_index, matched_firma, matched_tofas, result):
        cands = self._cross_candidates(
            firma, active_tofas, firma_by_idx, tofas_by_idx,
            exact_index, fuzzy_index, matched_firma, matched_tofas,
        )
        for c in self._select_candidates(cands):
            self._record_cross(result, c, matched_firma, matched_tofas)

    @staticmethod
    def _record_cross(result, c, matched_firma, matched_tofas):
        side, one, many = c["side"], c["one"], c["many"]
        result.cross_matches.append(CrossMatch(
            single_side=side,
            one_firma=one if side == Side.FIRMA else None,
            one_tofas=one if side == Side.TOFAS else None,
            many_tofas=list(many) if side == Side.FIRMA else [],
            many_firma=list(many) if side == Side.TOFAS else [],
            rule=c["rule"],
            total_one=c["total_one"],
            total_many=c["total_many"],
            kurus_farki=c["kurus"],
            para_birimi_uyari=c["currency_warn"],
            score=c["score"],
        ))
        matched_firma.update(c["firma_ids"])
        matched_tofas.update(c["tofas_ids"])

    # -- classification -------------------------------------------------------
    #
    # FAZ 4 — P0 GÜVENLİK KAPISI (docs/claude-audit/17_P0_MATCHING_SAFETY_DESIGN.md)
    #
    # Katman sırasının/bipartite seçiminin/subset-sum'ın KENDİSİ bu fazda
    # DEĞİŞMEDİ: ``run_tiers``, ``_max_bipartite_matching``,
    # ``_cross_candidates``/``_find_subsets``/``_select_candidates`` hiçbiri
    # dokunulmadı. Bu bölüm yalnızca, KATMANLAR ZATEN BİR ÇİFT SEÇTİKTEN
    # SONRA, o çiftin ``matched`` SAYILIP SAYILMAYACAĞINA karar verir —
    # doc 17 §2 Kademe 3'ün tanımladığı sınır tam burasıdır.
    #
    # Karar sırası (ilk uyan kazanır):
    #   1) IDENTITY_CONFLICT  — BLOCK.  Doc 17 §4 satır 1. Yalnızca HER İKİ
    #      tarafta da VERİFİYE EDİLMİŞ kimlik (``tax_id``) VARSA ve bunlar
    #      FARKLIYSA tetiklenir. ``tax_id`` hiçbir yükleyici tarafından
    #      doldurulmadığından bu kontrol BUGÜN GERÇEK VERİDE DORMANT'tır.
    #   2) ECONOMIC_EVENT_REVIEW — REVIEW. Doc 17 §4 satır 2/4. Yalnızca
    #      REFERANS-tabanlı katmanlarda (T1/T2/T4) ve yalnızca rekabet eden
    #      bir ADAYIN row_classifier'dan GÜVENLE (anahtar kelime eşleşmesiyle)
    #      gelen, kazanandan FARKLI bir ekonomik olay etiketi taşıdığında
    #      tetiklenir. AMOUNT_DATE (T3) ve bire-çok (subset-sum) katmanları
    #      BİLEREK kapsam dışıdır (kullanıcı talimatı: bu katmanların
    #      semantiği değiştirilmeyecek).
    #   3) Hiçbiri tetiklenmezse: MEVCUT davranış DEĞİŞMEDEN çalışır
    #      (tutar karşılaştırması, isaret_uyari, para_birimi_uyari) — yalnızca
    #      bir ``ambiguous`` bayrağı EK OLARAK hesaplanır (doc 17 §4 satır 5);
    #      bu bayrak kararı DEĞİŞTİRMEZ, sadece GÖRÜNÜR kılar.

    def _classify(self, result, firma, tofas, rule, *, adj=None, rev_adj=None,
                  firma_by_idx=None, tofas_by_idx=None):
        if self._identity_conflict(firma, tofas):
            result.identity_conflict.append(MatchedPair(
                firma=firma, tofas=tofas, rule=MatchRule.IDENTITY_CONFLICT,
                status=MatchStatus.IDENTITY_CONFLICT, kurus_farki=Decimal("0"),
                original_rule=rule,
            ))
            return

        if (adj is not None and rule in self._REFERENCE_BASED_RULES
                and self._economic_event_conflict(
                    firma, tofas, adj, rev_adj, firma_by_idx, tofas_by_idx)):
            result.economic_event_review.append(MatchedPair(
                firma=firma, tofas=tofas, rule=MatchRule.ECONOMIC_EVENT_CONFLICT,
                status=MatchStatus.ECONOMIC_EVENT_REVIEW, kurus_farki=Decimal("0"),
                original_rule=rule,
            ))
            return

        fa = firma.amount.copy_abs()
        ta = tofas.amount.copy_abs()
        kurus = (fa - ta).copy_abs()
        both_nonzero = firma.amount != 0 and tofas.amount != 0
        same_sign = both_nonzero and ((firma.amount > 0) == (tofas.amount > 0))
        cur_warn = self._currency_unknown(firma.currency, tofas.currency)
        ambiguous, ambiguous_reason = (
            self._ambiguity(firma, tofas, adj, rev_adj, firma_by_idx, tofas_by_idx)
            if adj is not None else (False, None)
        )

        if self._amounts_match(fa, ta):
            result.matched.append(MatchedPair(
                firma=firma, tofas=tofas, rule=rule,
                status=MatchStatus.MATCHED, kurus_farki=kurus,
                isaret_uyari=same_sign, para_birimi_uyari=cur_warn,
                ambiguous=ambiguous, ambiguous_reason=ambiguous_reason,
            ))
        else:
            result.amount_mismatch.append(MatchedPair(
                firma=firma, tofas=tofas, rule=rule,
                status=MatchStatus.AMOUNT_DIFF, kurus_farki=kurus,
                isaret_uyari=same_sign, para_birimi_uyari=cur_warn,
                ambiguous=ambiguous, ambiguous_reason=ambiguous_reason,
            ))

    #: Ekonomik olay çelişkisi kontrolünün uygulandığı katmanlar. Tutar+tarih
    #: (T3) ve bire-çok (subset-sum) katmanları BİLEREK kapsam dışıdır.
    _REFERENCE_BASED_RULES = frozenset({MatchRule.REFERENCE_EXACT, MatchRule.REFERENCE_FUZZY})

    @staticmethod
    def _identity_conflict(firma, tofas) -> bool:
        """Doc 17 §4 satır 1 — HER İKİ tarafta da verifiye edilmiş kimlik
        VARSA ve bunlar FARKLIYSA True. Tek taraflı ya da eksik ``tax_id``
        asla çelişki SAYILMAZ (doc 17 §4 satır 3: eksik kimlik → ALLOW)."""
        if not firma.tax_id or not tofas.tax_id:
            return False
        return firma.tax_id.strip() != tofas.tax_id.strip()

    def _economic_event_conflict(self, firma, tofas, adj, rev_adj,
                                 firma_by_idx, tofas_by_idx) -> bool:
        """Doc 17 §4 satır 2/4 — kazanan çiftin rekabet ettiği ADAYLAR
        arasında, row_classifier'dan GÜVENLE (confirmed=True) gelen ve
        kazanandan FARKLI bir etiket taşıyan biri var mı?

        ``confirmed=False`` (sinyal yok / eşleşmedi) olan bir aday HİÇBİR
        ZAMAN çelişki saymaz — aksi hâlde row_classifier'ın her zaman var
        olan ``INVOICE`` varsayılanı, metni boş her rekabet eden satırı
        yanlışlıkla "çelişkili" ilan ederdi (bkz. row_classifier.py
        ``classify_row_with_confidence`` docstring'i).

        PERFORMANS: firma-yönü rakipler ``rev_adj`` (tofas_idx ->
        [firma_idx], katman başına BİR KEZ kurulan ters indeks — bkz.
        ``reconcile``) üzerinden O(1) bulunur; ``adj.items()`` ARTIK HER
        ÇİFT İÇİN YENİDEN TARANMAZ (eski hâli O(N²) üretiyordu, bkz.
        tests/test_performance.py::test_throughput_stays_linear).
        """
        from app.services.row_classifier import classify_row_with_confidence

        f_idx, t_idx = firma.row_index, tofas.row_index
        firma_label, _ = classify_row_with_confidence(
            text=firma.comment, reference=firma.reference_raw)
        tofas_label, _ = classify_row_with_confidence(
            text=tofas.metin, belge_turu=tofas.belge_turu,
            reference=tofas.reference_raw)

        # TOFAŞ-yönü rakipler: aynı firma satırının adj listesindeki BAŞKA
        # TOFAŞ adayları.
        for sib_t in adj.get(f_idx, []):
            if sib_t == t_idx:
                continue
            sib = tofas_by_idx.get(sib_t)
            if sib is None:
                continue
            sib_label, sib_confirmed = classify_row_with_confidence(
                text=sib.metin, belge_turu=sib.belge_turu,
                reference=sib.reference_raw)
            if sib_confirmed and sib_label != tofas_label:
                return True

        # Firma-yönü rakipler: aynı TOFAŞ satırını adj'ında taşıyan BAŞKA
        # firma adayları (ters indeksten O(1)).
        for f in rev_adj.get(t_idx, []):
            if f == f_idx:
                continue
            sib = firma_by_idx.get(f)
            if sib is None:
                continue
            sib_label, sib_confirmed = classify_row_with_confidence(
                text=sib.comment, reference=sib.reference_raw)
            if sib_confirmed and sib_label != firma_label:
                return True

        return False

    @staticmethod
    def _ambiguity(firma, tofas, adj, rev_adj, firma_by_idx, tofas_by_idx):
        """Doc 17 §4 satır 5 — birden fazla eşit-geçerli aday VARDI ve
        adaylar FARKLI bildirilmiş karşı taraf (firma_kodu/account)
        taşıyordu mu? Trivial/interchangeable (hepsi aynı ya da hepsi boş)
        adaylarda False döner — seçim yine deterministiktir, bu yalnızca
        bilgilendirir, KARARI DEĞİŞTİRMEZ.

        PERFORMANS: bkz. ``_economic_event_conflict`` — firma-yönü adaylar
        ``rev_adj``'dan O(1) okunur, ``adj.items()`` TARANMAZ.
        """
        f_idx, t_idx = firma.row_index, tofas.row_index

        tofas_candidates = adj.get(f_idx, [])
        kodlar = sorted({
            tofas_by_idx[t].firma_kodu
            for t in tofas_candidates
            if t in tofas_by_idx and tofas_by_idx[t].firma_kodu
        })
        if len(kodlar) > 1:
            return True, (
                "Birden fazla eşit-geçerli TOFAŞ adayı farklı tedarikçi "
                f"kodu bildiriyor: {kodlar}")

        firma_candidates = rev_adj.get(t_idx, [])
        hesaplar = sorted({
            firma_by_idx[f].account
            for f in firma_candidates
            if f in firma_by_idx and firma_by_idx[f].account
        })
        if len(hesaplar) > 1:
            return True, (
                "Birden fazla eşit-geçerli firma adayı farklı cari kod "
                f"bildiriyor: {hesaplar}")

        return False, None

    def _classify_currency_conflict(self, result, firma, tofas) -> None:
        """Para birimi çelişkisini AYRI listeye yaz — mutabık SAYMA.

        ``kurus_farki`` BİLEREK sıfır bırakılır: farklı para birimindeki iki
        tutarın çıkarılması anlamsız bir sayı üretir ve muhasebeci bunu
        gerçek bir fark sanar. Kur çevrimi yapılmaz (ürün kararı: motor kur
        tablosu tutmaz), bu yüzden karşılaştırılabilir bir fark YOKTUR.
        """
        result.currency_diff.append(MatchedPair(
            firma=firma, tofas=tofas,
            rule=MatchRule.REFERENCE_CURRENCY_CONFLICT,
            status=MatchStatus.CURRENCY_DIFF,
            kurus_farki=Decimal("0"),
            isaret_uyari=False,
            # Para birimi BİLİNMİYOR değil, ÇELİŞİYOR. Mevcut bayrak
            # "bilinmiyor" anlamına geldiği için işaretlenmez; çelişki
            # bilgisini durumun kendisi taşır.
            para_birimi_uyari=False,
        ))

    # -- summary ------------------------------------------------------------

    @staticmethod
    def _summarize(result, firma, active_tofas, sap_total, firma_total):
        firma_sum = sum((r.amount for r in firma), Decimal("0"))
        tofas_sum = sum((r.amount for r in active_tofas), Decimal("0"))
        # Option A: dip toplam = 320/323 filtreli TOFAŞ toplamı. SAP sarı satırı
        # tüm hesapları kapsadığı için filtreli toplamla karşılaştırılmaz;
        # yalnızca bilgi amaçlı taşınır, uyarı üretilmez.
        warn = None
        return Summary(
            total_firma=len(firma),
            total_tofas=len(active_tofas),
            matched=len(result.matched),
            amount_diff=len(result.amount_mismatch),
            cross_matched=len(result.cross_matches),
            currency_diff=len(result.currency_diff),
            identity_conflict=len(result.identity_conflict),
            economic_event_review=len(result.economic_event_review),
            ambiguous_matches=sum(1 for m in result.matched if m.ambiguous),
            only_firma=len(result.only_firma),
            only_tofas=len(result.only_tofas),
            firma_diptoplam=firma_sum,
            tofas_diptoplam_hesap=tofas_sum,
            tofas_diptoplam_sap=sap_total,
            diptoplam_uyari=warn,
            fark=firma_sum.copy_abs() - tofas_sum.copy_abs(),
        )
