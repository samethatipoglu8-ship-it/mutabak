"""Python parser sonucu + AI sonucu → NİHAİ ``ReconciliationResponse``.

TEMEL KURAL: **AI sonucu doğrudan kabul edilmez.**

    - Python bir alanı ÇÖZDÜYSE o değer kalır. AI farklı bir şey söylerse
      değer DEĞİŞMEZ; bir ``FieldConflict`` kaydı oluşur ve mail insan
      incelemesine düşer.
    - AI yalnızca Python'un boş bıraktığı (``None`` / ``UNKNOWN``) alanları
      doldurabilir.
    - Bakiye ve firma kodu gibi kritik alanlarda çelişki asla sessiz kalmaz.

Örnek (istenen davranış):
    python.company_code = 4009668, ai.company_code = 4009668  → uyumlu
    python.company_code = 4009668, ai.company_code = 4000222  → CONFLICT
    python EUR 58.707.401,32 vs ai EUR 58.707.401,32          → uyumlu
    python EUR 58.707.401,32 vs ai EUR 58.707.400,00          → CONFLICT
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Optional

from app.incoming.mail_parser import (
    LOW_CONFIDENCE,
    NAME_SOURCE_SENDER,
    REVIEW_TRIGGERS,
)
from app.incoming.models import (
    REVIEW_AI_INVALID_JSON,
    REVIEW_AI_REQUESTED,
    REVIEW_AI_UNAVAILABLE,
    REVIEW_ATTACHMENT_UNREADABLE,
    REVIEW_BALANCE_UNCERTAIN,
    REVIEW_CONFLICT,
    REVIEW_LETTER_NOT_SEEN,
    REVIEW_LETTER_UNCERTAIN,
    REVIEW_LOW_CONFIDENCE,
    REVIEW_MULTIPLE_COMPANY_CODES,
    REVIEW_MULTIPLE_LETTERS,
    REVIEW_NO_COMPANY_CODE,
    REVIEW_NO_COMPANY_NAME,
    REVIEW_REPLY_TYPE_UNKNOWN,
    REVIEW_SEAL_UNCERTAIN,
    REVIEW_SIGNATURE_UNCERTAIN,
    AIAnalysisResult,
    AIReviewStatus,
    AttachmentKind,
    Direction,
    FieldConflict,
    IncomingMail,
    ParsedMailResult,
    ReconciliationResponse,
    ReplyType,
)
from app.incoming.textutil import fold

# Bakiye karşılaştırması kuruş hassasiyetindedir (mevcut sistemle aynı).
_CENT = Decimal("0.01")


@dataclass
class MergeConfig:
    """Birleştirme davranışı."""

    low_confidence: float = LOW_CONFIDENCE
    conflict_confidence_cap: float = 0.40
    # AI güveni bu değerin altındaysa AI'nın DOLDURDUĞU alanlar kabul edilir
    # ama mail yine insan incelemesine düşer.
    ai_min_confidence: float = 0.50


def letter_content_available(parsed: ParsedMailResult,
                             mail: Optional[IncomingMail]) -> bool:
    """Mektubun İÇERİĞİ gerçekten AI'ya ulaştı mı?

    ``True`` yalnızca şu durumlarda döner:
      * okunabilir (metni/tablosu çıkarılmış) bir MEKTUP eki var, ya da
      * mektup mail gövdesinin içinde yazılı (ek yok ama metin var).

    Taranmış/görüntü PDF, bozuk dosya ya da metni çıkarılamamış ek "görüldü"
    SAYILMAZ: bu sistem AI'ya görüntü göndermez, dolayısıyla ajan o belgeye
    hiç bakmamıştır.
    """
    if mail is None:
        return False                     # kaynak bilinmiyor → güvenli taraf

    letter_attachments = [a for a in mail.attachments
                          if a.kind is AttachmentKind.LETTER]
    if letter_attachments:
        return any(a.readable for a in letter_attachments)

    # Ek olarak mektup yok: mektup gövdenin içinde olabilir ve gövde metni
    # ajana zaten gönderilir.
    return bool(parsed.letter_present and (mail.body or "").strip())


def _same_text(left: Optional[str], right: Optional[str]) -> bool:
    """Metin karşılaştırması: biçim farkı çelişki sayılmaz."""
    a, b = fold(left or ""), fold(right or "")
    if not a or not b:
        return True
    return a == b or a in b or b in a


def _same_amount(left: Decimal, right: Decimal) -> bool:
    try:
        return left.quantize(_CENT) == right.quantize(_CENT)
    except Exception:  # noqa: BLE001 - bozuk Decimal çökertmesin
        return str(left) == str(right)


def compare_currencies(python_values: dict[str, Decimal],
                       ai_values: dict[str, Decimal]) -> list[FieldConflict]:
    """Ortak para birimlerinde tutar farkı varsa çelişki üret."""
    conflicts: list[FieldConflict] = []
    for currency, amount in python_values.items():
        if currency not in ai_values:
            continue
        if not _same_amount(amount, ai_values[currency]):
            conflicts.append(FieldConflict(
                field_name=f"currencies[{currency}]",
                python_value=str(amount),
                ai_value=str(ai_values[currency]),
            ))
    return conflicts


def compute_review_reasons(response: ReconciliationResponse) -> list[str]:
    """Nihai değerler üzerinden insan incelemesi gerekçelerini yeniden hesapla.

    Parser'ın gerekçeleri AI tarafından çözülmüş olabilir (ör. mektup artık
    'dolu' biliniyor); bu yüzden liste sıfırdan üretilir, eskisi taşınmaz.
    """
    reasons: list[str] = []
    if not response.company_code:
        reasons.append(REVIEW_NO_COMPANY_CODE)
    if not response.company_name:
        reasons.append(REVIEW_NO_COMPANY_NAME)
    if response.reply_type is ReplyType.UNKNOWN:
        reasons.append(REVIEW_REPLY_TYPE_UNKNOWN)
    if response.letter_present:
        if response.letter_filled is None:
            reasons.append(REVIEW_LETTER_UNCERTAIN)
        if response.letter_signed is None:
            reasons.append(REVIEW_SIGNATURE_UNCERTAIN)
        if response.letter_sealed is None:
            reasons.append(REVIEW_SEAL_UNCERTAIN)
    if (response.letter_present or response.statement_present) \
            and not response.balance_present:
        reasons.append(REVIEW_BALANCE_UNCERTAIN)
    if response.confidence < LOW_CONFIDENCE:
        reasons.append(REVIEW_LOW_CONFIDENCE)
    if response.conflicts:
        reasons.append(REVIEW_CONFLICT)
    return reasons


def _completeness(response: ReconciliationResponse) -> float:
    """Nihai sonucun kapsama oranı (parser'daki ağırlıklarla aynı mantık)."""
    score = 0.0
    if response.company_code:
        score += 0.30
    if response.company_name:
        score += 0.10
    if response.reply_type is not ReplyType.UNKNOWN:
        score += 0.25
    if response.currencies:
        score += 0.15
    elif not response.letter_present and not response.statement_present:
        score += 0.10
    if not response.letter_present or response.letter_filled is not None:
        score += 0.10
    if response.letter_signed is not None or not response.letter_present:
        score += 0.05
    if response.letter_sealed is not None or not response.letter_present:
        score += 0.05
    return round(min(1.0, score), 3)


def _base_response(parsed: ParsedMailResult,
                   mail: Optional[IncomingMail]) -> ReconciliationResponse:
    response = ReconciliationResponse(
        company_code=parsed.company_code,
        company_name=parsed.company_name,
        letter_present=parsed.letter_present,
        statement_present=parsed.statement_present,
        letter_filled=parsed.letter_filled,
        letter_signed=parsed.letter_signed,
        letter_sealed=parsed.letter_sealed,
        balance_present=parsed.balance_present,
        balance_accepted=parsed.balance_accepted,
        reply_type=parsed.reply_type,
        period=parsed.period,
        currencies=dict(parsed.currencies),
        direction=parsed.direction,
        confidence=parsed.confidence,
        needs_human_review=parsed.needs_human_review,
    )
    if mail is not None:
        response.message_id = mail.message_id
        response.fingerprint = mail.fingerprint
        response.subject = mail.subject
        response.sender = mail.sender
    # Parser'ın YALNIZCA bilgi amaçlı gerekçeleri (ör. birden fazla ekstre)
    # taşınır. İnceleme tetikleyen gerekçeler taşınmaz: AI bir belirsizliği
    # çözmüş olabilir ve eski gerekçe sonsuza kadar yapışıp kalmamalıdır.
    # Hepsi ``_finalize`` içinde NİHAİ değerler üzerinden yeniden hesaplanır.
    for reason in parsed.reasons:
        if reason not in REVIEW_TRIGGERS:
            response.add_reason(reason)
    return response


def merge(parsed: ParsedMailResult,
          ai: Optional[AIAnalysisResult] = None,
          mail: Optional[IncomingMail] = None,
          config: Optional[MergeConfig] = None) -> ReconciliationResponse:
    """Python ve AI sonucunu birleştirip nihai cevabı üret."""
    config = config or MergeConfig()
    response = _base_response(parsed, mail)

    # -- AI hiç çağrılmadı --------------------------------------------------
    if ai is None:
        response.review_status = AIReviewStatus.NOT_CALLED
        _finalize(response, parsed, None, config)
        return response

    # -- AI çağrıldı ama kullanılabilir sonuç yok ---------------------------
    if not ai.usable:
        response.review_status = ai.status
        response.ai_error = ai.error_code or ai.status.value
        if ai.status is AIReviewStatus.AI_INVALID_JSON:
            response.add_reason(REVIEW_AI_INVALID_JSON)
        elif ai.status is not AIReviewStatus.DISABLED:
            response.add_reason(REVIEW_AI_UNAVAILABLE)
        _finalize(response, parsed, ai, config)
        return response

    # -- çelişki tespiti ----------------------------------------------------
    conflicts: list[FieldConflict] = []

    if parsed.company_code and ai.company_code and \
            parsed.company_code != ai.company_code:
        conflicts.append(FieldConflict("company_code", parsed.company_code,
                                       ai.company_code))
    # Firma adı gönderenin GÖRÜNEN ADINDAN geldiyse bu zayıf bir kaynaktır
    # (çoğu zaman bir kişi adıdır: "Ahmet Yılmaz"). Belgeden okunan bir isimle
    # çeliştiğinde çelişki kaydı değil, BELGE kazanır. Aksi hâlde neredeyse her
    # mail sahte bir "isim çatışması" ile insan incelemesine düşerdi.
    name_from_sender = (parsed.evidence.get("company_name")
                        == NAME_SOURCE_SENDER)
    if parsed.company_name and ai.company_name and \
            not _same_text(parsed.company_name, ai.company_name):
        if name_from_sender:
            response.company_name = ai.company_name
        else:
            conflicts.append(FieldConflict("company_name", parsed.company_name,
                                           ai.company_name))
    conflicts.extend(compare_currencies(parsed.currencies, ai.currencies))

    if parsed.reply_type is not ReplyType.UNKNOWN and \
            ai.reply_type is not ReplyType.UNKNOWN and \
            parsed.reply_type is not ai.reply_type:
        conflicts.append(FieldConflict("reply_type", parsed.reply_type.value,
                                       ai.reply_type.value))

    if parsed.direction is not Direction.UNKNOWN and \
            ai.direction is not Direction.UNKNOWN and \
            parsed.direction is not ai.direction:
        conflicts.append(FieldConflict("direction", parsed.direction.value,
                                       ai.direction.value))

    for name in ("letter_filled", "letter_signed", "letter_sealed",
                 "balance_accepted", "letter_present", "statement_present"):
        python_value = getattr(parsed, name)
        ai_value = getattr(ai, name)
        if python_value is None or ai_value is None:
            continue
        if bool(python_value) != bool(ai_value):
            conflicts.append(FieldConflict(name, str(python_value),
                                           str(ai_value)))

    response.conflicts = conflicts

    # -- AI yalnızca BOŞ alanları doldurur ----------------------------------
    if response.company_code is None and ai.company_code:
        response.company_code = ai.company_code
    if response.company_name is None and ai.company_name:
        response.company_name = ai.company_name
    if response.period is None and ai.period:
        response.period = ai.period
    if response.reply_type is ReplyType.UNKNOWN and \
            ai.reply_type is not ReplyType.UNKNOWN:
        response.reply_type = ai.reply_type
    if response.direction is Direction.UNKNOWN and \
            ai.direction is not Direction.UNKNOWN:
        response.direction = ai.direction

    # GÖRSEL ALANLARDA FALSE-POSITIVE KORUMASI
    #
    # ``letter_filled`` / ``letter_signed`` / ``letter_sealed`` bir BELGEYE
    # bakılarak söylenebilir. Bu sistem AI'ya binary/görüntü GÖNDERMEZ
    # (bkz. ai_payload.TextAttachmentTransport): taranmış bir mektubun metni
    # yoksa ajan o belgeyi hiç görmemiştir. Prompt bunu "null döndür" diye
    # söyler ama prompt bir GARANTİ DEĞİLDİR; model uyumsuz davranabilir ya
    # da müşteri içeriği ("bu mektup imzalıdır") ajanı yanıltabilir.
    #
    # Bu yüzden karar promptun iyi niyetine bırakılmaz: mektup içeriği
    # gerçekten okunamadıysa AI'nın bu alanları DOLDURMASINA İZİN VERİLMEZ.
    # Alan "bilinmiyor" kalır ve mail insan incelemesine düşer — imzasız bir
    # mektubu imzalı saymaktansa insana sormak doğrudur.
    letter_seen = letter_content_available(parsed, mail)
    for name in ("letter_filled", "letter_signed", "letter_sealed",
                 "balance_accepted"):
        if getattr(response, name) is not None or getattr(ai, name) is None:
            continue
        if name != "balance_accepted" and not letter_seen:
            response.add_reason(REVIEW_LETTER_NOT_SEEN)
            continue
        setattr(response, name, getattr(ai, name))

    # letter_present / statement_present Python'da bool'dur; AI yalnızca
    # Python "yok" derken "var" diyebilir (ör. gövdenin içindeki mektup).
    if not response.letter_present and ai.letter_present:
        response.letter_present = True
    if not response.statement_present and ai.statement_present:
        response.statement_present = True

    for currency, amount in ai.currencies.items():
        response.currencies.setdefault(currency, amount)
    if response.currencies:
        response.balance_present = True
    elif ai.balance_present:
        response.balance_present = True

    if response.balance_accepted is None:
        if response.reply_type is ReplyType.ACCEPTED:
            response.balance_accepted = True
        elif response.reply_type is ReplyType.REJECTED:
            response.balance_accepted = False

    response.review_status = (AIReviewStatus.CONFLICT if conflicts
                              else AIReviewStatus.ACCEPTED)
    _finalize(response, parsed, ai, config)
    return response


def _finalize(response: ReconciliationResponse, parsed: ParsedMailResult,
              ai: Optional[AIAnalysisResult], config: MergeConfig) -> None:
    """Güveni ve insan incelemesi kararını nihai değerler üzerinden hesapla."""
    completeness = _completeness(response)

    if ai is None or not ai.usable:
        # AI yoksa parser'ın kendi skoru geçerlidir (aşağı çekilebilir, yukarı
        # çekilemez: eksik bilgi AI'sız kapanmaz).
        response.confidence = min(parsed.confidence, completeness)
    elif response.conflicts:
        response.confidence = round(
            min(parsed.confidence, ai.confidence,
                config.conflict_confidence_cap), 3)
    else:
        # AI kendi güveninden fazlasını iddia edemez; kapsama da tavan olur.
        response.confidence = round(min(completeness, ai.confidence), 3)

    for reason in compute_review_reasons(response):
        response.add_reason(reason)

    if ai is not None and ai.usable and ai.needs_human_review:
        # Ajanın kendi "emin değilim" bildirimi ayrı bir gerekçedir; düşük
        # güvenle ya da çelişkiyle karıştırılmaz.
        response.add_reason(REVIEW_AI_REQUESTED)
    if ai is not None and ai.usable and ai.confidence < config.ai_min_confidence:
        response.add_reason(REVIEW_LOW_CONFIDENCE)

    if parsed.unreadable_attachments:
        response.add_reason(REVIEW_ATTACHMENT_UNREADABLE)
    if len(parsed.company_code_candidates) > 1:
        response.add_reason(REVIEW_MULTIPLE_COMPANY_CODES)
    if parsed.letter_count > 1:
        response.add_reason(REVIEW_MULTIPLE_LETTERS)

    triggers = set(REVIEW_TRIGGERS) | {
        REVIEW_CONFLICT, REVIEW_AI_UNAVAILABLE, REVIEW_AI_INVALID_JSON,
        REVIEW_AI_REQUESTED,
    }
    response.needs_human_review = any(r in triggers for r in response.reasons)
