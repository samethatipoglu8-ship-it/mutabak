"""Shared SQLite connection policy for local durable stores.

Every operational store uses the same timeout, WAL, busy-wait and foreign-key
policy.  Keeping that policy in one place prevents a newly added queue or
audit store from silently behaving differently under concurrent workers.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path


def open_sqlite_connection(
    path: str | Path,
    *,
    isolation_level: str | None = None,
    enable_wal: bool = True,
) -> sqlite3.Connection:
    """Open a durable local store connection with the application policy.

    The 30-second busy window turns short, concurrent write bursts into a
    queued operation rather than an immediate ``database is locked`` error.
    WAL keeps readers available while a worker records a result.  Callers own
    the returned connection and must close it (normally via their ``_session``
    context manager).
    """
    conn = sqlite3.connect(str(path), timeout=30.0, isolation_level=isolation_level)
    conn.execute("PRAGMA busy_timeout=30000")
    conn.execute("PRAGMA foreign_keys=ON")
    if enable_wal:
        conn.execute("PRAGMA journal_mode=WAL")
    return conn
