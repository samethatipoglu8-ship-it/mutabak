"""Background worker for reconciliation.

Runs the heavy load+match+write work off the GUI thread so the interface
never freezes ("not responding"). Communicates via Qt signals only.
"""

from __future__ import annotations

import weakref
from typing import Iterable, Optional

from PySide6.QtCore import QObject, QThread, Signal

from app.models.domain import ReconciliationResult
from app.services.reconciliation_service import ReconciliationService


class ReconcileWorker(QObject):
    """Worker object moved onto a QThread."""

    progress = Signal(str, int)         # message, percent
    finished = Signal(object)           # ReconciliationResult
    failed = Signal(str)                # error message

    def __init__(
        self,
        tofas_path: str,
        firma_path: str,
        excluded_belge_turu: Optional[Iterable[str]],
        service: Optional[ReconciliationService] = None,
        mode: str = "birlikte",
        output_dir: Optional[str] = None,
    ) -> None:
        super().__init__()
        self._output_dir = output_dir
        self._tofas_path = tofas_path
        self._firma_path = firma_path
        self._excluded = list(excluded_belge_turu or [])
        self._service = service or ReconciliationService()
        self._mode = mode
        self.output_path = ""

    def run(self) -> None:
        try:
            result: ReconciliationResult = self._service.run(
                self._tofas_path,
                self._firma_path,
                excluded_belge_turu=self._excluded,
                write_result=True,
                progress=lambda m, p: self.progress.emit(m, p),
                mode=self._mode,
                output_dir=self._output_dir,
            )
            self.output_path = getattr(self._service, "last_output_path", "")
            self.finished.emit(result)
        except Exception as exc:  # noqa: BLE001 - surface to UI, never crash
            self.failed.emit(str(exc))


class PeekWorker(QObject):
    """Worker that reads the distinct belge türü list from a TOFAŞ file."""

    finished = Signal(list)
    failed = Signal(str)

    def __init__(self, tofas_path: str, service: Optional[ReconciliationService] = None,
                 mode: str = "birlikte") -> None:
        super().__init__()
        self._tofas_path = tofas_path
        self._service = service or ReconciliationService()
        self._mode = mode

    def run(self) -> None:
        try:
            turler = self._service.peek_belge_turleri(self._tofas_path, mode=self._mode)
            self.finished.emit(turler)
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))


class WorkerBinding(QObject):
    """Bir işçinin sinyallerini sayfaya bağlar; işçi eskidiğinde YUTAR.

    NEDEN BAĞLANTI KOPARILMIYOR
        İlk çözüm, eskimiş işçinin sinyallerini ``disconnect()`` ile
        koparmaktı. Ama bir işçi bittiğinde ``run_in_thread`` onu
        ``deleteLater`` ile silmeye alıyor; thread sonlandıktan sonra o
        nesnenin C++ tarafı gitmiş olabiliyor ve üzerinde ``disconnect()``
        çağırmak Python düzeyinde yakalanamayan bir çökmeye (bus error /
        access violation) yol açıyordu.

        Bu sınıf sorunu bağlantıya DOKUNMADAN çözer: bağlantılar hep ayakta
        kalır, ama ``retire()`` çağrıldıktan sonra gelen sinyaller sayfaya
        İLETİLMEZ. Böylece eskimiş işçinin progress/finished/failed sinyali
        yeni işin durumunu bozamaz.

    SAHİPLİK
        Binding sayfanın çocuğudur; sayfa silinince o da silinir.
    """

    def __init__(self, page, worker, on_progress, on_finished, on_failed) -> None:
        super().__init__(page)
        self._page = page
        # İşçiye ZAYIF referans tutulur. Güçlü referans, ``run_in_thread``ün
        # ``deleteLater`` ile sildiği işçinin Python sarmalayıcısını hayatta
        # tutuyor; silinmiş C++ nesnesi daha sonra (sayfa yıkılırken) tekrar
        # ele alındığında süreç çöküyordu.
        self._worker_ref = weakref.ref(worker)
        self._on_progress = on_progress
        self._on_finished = on_finished
        self._on_failed = on_failed
        self.active = True
        worker.progress.connect(self._progress)
        worker.finished.connect(self._finished)
        worker.failed.connect(self._failed)

    @property
    def worker(self):
        return self._worker_ref()

    def retire(self) -> None:
        """İşçiyi eskit: bundan sonraki sinyalleri sayfaya ulaşmaz."""
        self.active = False
        self._on_progress = self._on_finished = self._on_failed = None
        # ``retire`` çoğu zaman BU binding'in kendi slot'u içinden çağrılır
        # (finished -> _work_done -> retire). ``deleteLater`` bu durumda
        # güvenlidir; ``setParent(None)`` ise sinyal yayılırken alıcıyı
        # ağaçtan koparır ve çökmeye yol açabilir — yapılmaz.
        self.deleteLater()

    # -- sinyal kapıları ---------------------------------------------------

    def _dispatch(self, slot, *args) -> None:
        if not self.active or slot is None:
            return
        # ``_on_action_error`` gibi bazı işleyiciler hangi işçiden geldiğini
        # ``sender()`` ile okur; sinyal artık BINDING üzerinden geçtiği için
        # kaynak ayrıca burada bildirilir.
        onceki = getattr(self._page, "_signal_source", None)
        self._page._signal_source = self.worker
        try:
            slot(*args)
        finally:
            self._page._signal_source = onceki

    def _progress(self, message: str, percent: int) -> None:
        self._dispatch(self._on_progress, message, percent)

    def _finished(self, result) -> None:
        self._dispatch(self._on_finished, result)

    def _failed(self, message: str) -> None:
        self._dispatch(self._on_failed, message)


def run_in_thread(worker: QObject) -> QThread:
    """Move ``worker`` to a new QThread, wire safe cleanup, and start it.

    "Not responding" donmasının başlıca sebepleri: (1) thread hiç
    başlatılmaması, (2) iş bittikten sonra thread'in quit edilmemesi,
    (3) worker/thread nesnelerinin erken çöp toplanması. Bu helper üçünü de
    çözer: worker'ın 'finished'/'failed' sinyallerine bağlanıp thread'i
    durdurur, thread bitince hem worker hem thread deleteLater ile temizlenir.

    Çağıran taraf yine de worker+thread referansını sinyal bağlantıları
    kurulana kadar tutmalıdır (main_window bunu yapıyor).
    """
    thread = QThread()
    worker.moveToThread(thread)
    thread.started.connect(worker.run)

    # İş bitince (başarılı ya da hatalı) thread'i durdur.
    if hasattr(worker, "finished"):
        worker.finished.connect(thread.quit)
    if hasattr(worker, "failed"):
        worker.failed.connect(thread.quit)

    # Thread tamamen bitince nesneleri güvenle sil (donma/çökme önlenir).
    thread.finished.connect(worker.deleteLater)
    thread.finished.connect(thread.deleteLater)

    thread.start()
    return thread
