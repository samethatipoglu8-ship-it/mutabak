"""FAZ 9 — sorumlu (R) bazlı mutabakat oranı.

KAYNAK
    Sorumlu bilgisi TEK bir yerden gelir: «Mutabakat Mailleri» sayfasındaki
    ``(R)`` alanı. Bu değer gönderim anında mail günlüğüne ve snapshot'a
    yazılır. Sorumlu MAİLDEN TAHMİN EDİLMEZ — gelen cevabın göndereni,
    imzası ya da CC'si sorumluyu belirlemez.

TEKİLLEŞTİRME
    Sayım birimi FİRMA + DÖNEMDİR. Aynı firmaya aynı dönemde iki mail
    gitmişse bu İKİ FİRMA DEĞİLDİR; aynı firma iki kez cevap verdiyse yine
    tek firmadır. Aksi hâlde oran, tekrar gönderim yapılan aylarda sessizce
    şişerdi.

ANA KPI (açıkça tanımlı)
    ``oran = MUTABIK / TOPLAM FİRMA * 100``

    İkinci metrik olarak ``MUTABIK / CEVAPLANAN`` da hesaplanır; bu, cevap
    gelmemiş firmaları dışarıda bıraktığı için DAİMA daha yüksektir ve ana
    KPI'ın yerine geçmez.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Iterable, Optional, Sequence

# Sorumlusu boş olan firmalar bu başlık altında toplanır — sessizce
# düşürülmezler, çünkü "kimsenin sorumlu olmadığı firma" bir bulgudur.
UNASSIGNED = "(sorumlu atanmamış)"

STATUS_MUTABIK = "MUTABIK"
STATUS_RED = "RED"
STATUS_INCELEME = "İNCELEME"
STATUS_BEKLENIYOR = "CEVAP BEKLENİYOR"


@dataclass
class ResponsibleStats:
    """Bir sorumlunun dönem karnesi."""

    responsible: str = ""
    total: int = 0                 # toplam firma (tekilleştirilmiş)
    mutabik: int = 0
    red: int = 0
    inceleme: int = 0
    bekleyen: int = 0

    @property
    def answered(self) -> int:
        """Cevap gelen firma sayısı."""
        return self.total - self.bekleyen

    @property
    def ratio(self) -> Decimal:
        """ANA KPI: MUTABIK / TOPLAM FİRMA * 100."""
        return self._percent(self.mutabik, self.total)

    @property
    def answered_ratio(self) -> Decimal:
        """İKİNCİL metrik: MUTABIK / CEVAPLANAN * 100."""
        return self._percent(self.mutabik, self.answered)

    @staticmethod
    def _percent(part: int, whole: int) -> Decimal:
        if whole <= 0:
            return Decimal("0.00")
        return (Decimal(part) / Decimal(whole) * 100).quantize(Decimal("0.01"))

    def add(self, status: str) -> None:
        self.total += 1
        if status == STATUS_MUTABIK:
            self.mutabik += 1
        elif status == STATUS_RED:
            self.red += 1
        elif status == STATUS_INCELEME:
            self.inceleme += 1
        else:
            self.bekleyen += 1


@dataclass
class RatioReport:
    """Dönem geneli + sorumlu kırılımı."""

    period: str = ""
    rows: list[ResponsibleStats] = field(default_factory=list)
    total: ResponsibleStats = field(default_factory=ResponsibleStats)

    def by_responsible(self, name: str) -> Optional[ResponsibleStats]:
        for row in self.rows:
            if row.responsible == name:
                return row
        return None


def _latest_case(cases: Sequence) -> Optional[object]:
    """Bir firmanın SON cevabı.

    Firma düzeltme yollamış olabilir; geçerli olan en son değerlendirmedir.
    Sıralama ``updated_at`` ile yapılır (eşitlikte ``case_id`` deterministik
    ayrım sağlar — rastgele bir kayıt seçilmez).
    """
    if not cases:
        return None
    return sorted(cases, key=lambda c: (c.updated_at or "", c.case_id))[-1]


def compute_ratios(sent_entries: Iterable, cases: Iterable,
                   period: Optional[str] = None) -> RatioReport:
    """Gönderim günlüğü + gelen cevap kayıtlarından oranı hesapla.

    ``sent_entries`` — ``MailLogEntry`` listesi (BAŞARIYLA gönderilmiş
    olanlar). Payda budur: mail gitmemiş bir firma orana giremez.
    ``cases`` — ``IncomingCase`` listesi.
    """
    # 1) Payda: firma + dönem bazında tekilleştirilmiş gönderimler.
    firms: dict[tuple[str, str], str] = {}
    for entry in sent_entries:
        code = (getattr(entry, "company_code", "") or "").strip()
        entry_period = (getattr(entry, "period", "") or "").strip()
        if not code:
            continue
        if period and entry_period != period:
            continue
        key = (code, entry_period)
        sorumlu = (getattr(entry, "responsible", "") or "").strip()
        # Sorumlu sonradan düzeltilmiş olabilir: DOLU olan değer korunur,
        # boş bir kayıt dolu olanı ezmez.
        if sorumlu or key not in firms:
            firms[key] = sorumlu or firms.get(key, "")

    # 2) Cevaplar firma + döneme göre gruplanır.
    by_firm: dict[tuple[str, str], list] = {}
    for case in cases:
        code = (getattr(case, "company_code", "") or "").strip()
        case_period = (getattr(case, "period", "") or "").strip()
        if not code:
            continue
        if period and case_period != period:
            continue
        by_firm.setdefault((code, case_period), []).append(case)

    report = RatioReport(period=period or "")
    buckets: dict[str, ResponsibleStats] = {}
    for key, sorumlu in sorted(firms.items()):
        ad = sorumlu or UNASSIGNED
        stats = buckets.setdefault(ad, ResponsibleStats(responsible=ad))
        son = _latest_case(by_firm.get(key, []))
        durum = (son.final_status if son is not None else STATUS_BEKLENIYOR)
        stats.add(durum or STATUS_BEKLENIYOR)
        report.total.add(durum or STATUS_BEKLENIYOR)

    report.total.responsible = "TOPLAM"
    # En düşük oran en üstte: kullanıcı önce sorunlu sorumluyu görsün.
    report.rows = sorted(buckets.values(),
                         key=lambda s: (s.ratio, s.responsible))
    return report


def format_percent(value: Decimal) -> str:
    """TR biçiminde yüzde: 81.67 -> '%81,67'."""
    return "%" + f"{value:.2f}".replace(".", ",")
