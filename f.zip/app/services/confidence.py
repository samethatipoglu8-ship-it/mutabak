"""FAZ 11 — 0-100 güven puanı ve ZORUNLU açıklaması (§11).

PUAN BİR KARAR DEĞİLDİR
    Güven puanı "bu mutabakat doğru" demez; «elimizdeki veri bu kararı ne
    kadar destekliyor» der. Bu yüzden puanın yanında açıklama ZORUNLUDUR:
    90 puan da 20 puan da tek başına anlamsızdır, neyin ölçüldüğü yazılmadan.

DAĞILIM (görev şartı)
    Mail gövdesi analizi ............ 40 puan
    Belge kalitesi (ek okunabildi mi) 30 puan
    Finansal kontrol ................ 30 puan

TAHMİN YOK
    Veri yoksa puan verilmez (0) ve açıklamaya "kontrol edilemedi" yazılır.
    Eksik veriyi iyimser yorumlamak, olmayan bir mutabakatı varmış gibi
    göstermenin en sessiz yoludur.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

# Bölüm tavanları.
BODY_MAX = 40
DOCUMENT_MAX = 30
FINANCIAL_MAX = 30

# Firmanın net tavır bildirdiği cevap türleri.
_CLEAR_REPLIES = frozenset({"ACCEPTED", "REJECTED"})
# Tavır var ama koşullu/kısmi.
_PARTIAL_REPLIES = frozenset({
    "PARTIALLY_ACCEPTED", "REQUESTED_CORRECTION", "INFORMATION_ONLY",
})

# Ekstre karşılaştırmasının sonucu.
_MATCHED = frozenset({"MATCHED", "STATEMENT_MATCHED", "RECONCILED"})
_DIFFERENCE = frozenset({
    "DIFFERENCE", "DIFFERENCE_FOUND", "STATEMENT_DIFFERENCE_FOUND",
})


@dataclass
class ConfidenceScore:
    """Puan + neden o puan olduğu."""

    total: int = 0
    body_points: int = 0
    document_points: int = 0
    financial_points: int = 0
    explanation: str = ""
    parts: list[str] = field(default_factory=list)

    @property
    def value(self) -> int:
        return max(0, min(100, self.total))


def score_case(
    *,
    has_reply: bool,
    reply_type: str = "",
    attachment_present: bool = False,
    attachment_readable: bool = False,
    comparison_done: bool = False,
    difference_found: Optional[bool] = None,
    contradiction: bool = False,
) -> ConfidenceScore:
    """Bir case için 0-100 güven puanı üret.

    ``difference_found`` üç değerlidir: ``True`` fark var, ``False`` fark yok,
    ``None`` karşılaştırma yapılamadı. Son durumda finansal puan verilmez.
    """
    score = ConfidenceScore()
    reply = (reply_type or "").strip().upper()

    # -- 1) Mail gövdesi ---------------------------------------------------
    if not has_reply:
        score.parts.append("Firma henüz cevap vermedi (gövde analizi yok).")
    elif reply in _CLEAR_REPLIES:
        score.body_points = BODY_MAX
        score.parts.append(
            "Mail gövdesinde net bir mutabakat/ret ifadesi bulundu.")
    elif reply in _PARTIAL_REPLIES:
        score.body_points = BODY_MAX // 2
        score.parts.append(
            "Mail gövdesi şartlı/kısmi bir ifade taşıyor; net değil.")
    else:
        score.parts.append(
            "Mail geldi ancak gövdeden net bir tavır çıkarılamadı.")

    # -- 2) Belge kalitesi -------------------------------------------------
    if attachment_readable:
        score.document_points = DOCUMENT_MAX
        score.parts.append("Ekteki belge okunabildi.")
    elif attachment_present:
        score.document_points = DOCUMENT_MAX // 3
        score.parts.append("Ek var ancak okunamadı (bozuk/taranmış olabilir).")
    else:
        score.parts.append("Ek belge yok; ekstre kontrolü yapılamadı.")

    # -- 3) Finansal kontrol -----------------------------------------------
    if comparison_done and difference_found is False:
        score.financial_points = FINANCIAL_MAX
        score.parts.append("Ekstre karşılaştırıldı; finansal fark bulunmadı.")
    elif comparison_done and difference_found is True:
        score.financial_points = 20
        score.parts.append(
            "Ekstre karşılaştırıldı; finansal fark bulundu "
            "(veri var ama mutabakat sağlanmadı).")
    else:
        score.parts.append(
            "Finansal karşılaştırma yapılamadı; sonuç kontrol edilemedi.")

    score.total = (score.body_points + score.document_points
                   + score.financial_points)

    if contradiction:
        # Mail "mutabıkız" derken rakam fark gösteriyorsa güven DÜŞER: iki
        # kaynak birbiriyle çelişiyordur, biri mutlaka yanlıştır.
        score.total = min(score.total, 50)
        score.parts.append(
            "Mail gövdesi ile ekstre sonucu ÇELİŞİYOR; ekstre kararı esas "
            "alındı ve güven düşürüldü.")

    score.explanation = " ".join(score.parts)
    return score


def score_from_case(case: Any) -> ConfidenceScore:
    """Kalıcı bir ``IncomingCase`` kaydından puanı yeniden üret.

    Ekrandaki her satır için aynı kuralın çalışması içindir; puan case'in
    içinde saklansa bile kaynak veriden yeniden hesaplanabilir olmalıdır.
    """
    statement = getattr(case, "statement_result", None) or {}
    status = str(statement.get("status") or "").upper()

    ekler = getattr(case, "incoming_attachments", None) or []
    ek_var = bool(ekler) or bool(statement.get("source_filename"))
    okunabildi = status in _MATCHED | _DIFFERENCE or bool(
        statement.get("rows_loaded"))

    yapildi = status in _MATCHED | _DIFFERENCE
    fark: Optional[bool] = None
    if status in _MATCHED:
        fark = False
    elif status in _DIFFERENCE:
        fark = True

    return score_case(
        has_reply=bool(getattr(case, "has_reply", False)),
        reply_type=getattr(case, "reply_type", ""),
        attachment_present=ek_var,
        attachment_readable=okunabildi,
        comparison_done=yapildi,
        difference_found=fark,
        contradiction=str(getattr(case, "outcome", "")).upper() == "CONTRADICTION",
    )
