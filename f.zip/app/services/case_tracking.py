"""FAZ 11 — gönderim anında case üretimi ve manuel durum yönetimi.

NEDEN GEREKLİ
    "Gelen Cevaplar" ekranı şimdiye kadar yalnızca CEVAP GELEN mailleri
    gösteriyordu: bir firmaya mutabakat gönderilmiş ama cevap vermemişse o
    firma hiçbir yerde görünmüyordu. Oysa takip ekranının asıl işi tam da
    budur — «kime gönderdim, kim cevap vermedi?»

    Bu modül gönderim anındaki snapshot'tan (``SentReconciliationSnapshot``)
    yön başına bir iş kaydı üretir. Cevap gelmemişse durum
    ``CEVAP BEKLENİYOR``dur; cevap geldiğinde AYNI kayıt güncellenir, ikinci
    bir satır doğmaz.

YÖN AYRI SATIRDIR
    Bir firmaya M ve S birlikte gönderilse bile (tek mail, dört ek) takip
    ekranında iki satır görünür: biri FBL5H, diğeri FBL1H tarafını temsil
    eder. X yönü kullanıcı kararı gereği S ile birleşiktir.

MANUEL MÜDAHALE GERİ ALINABİLİR
    Kullanıcı bir satırı elle yeşile aldığında ÖNCEKİ durum saklanır; aynı
    butona ikinci kez basıldığında kayıt eski hâline döner. Her iki işlem de
    işlem geçmişine yazılır — hiçbir değişiklik iz bırakmadan olmaz.
"""

from __future__ import annotations

from typing import Any, Iterable

from app.services.incoming_cases import IncomingCase, IncomingCaseStore
from app.services.snapshot_records import source_for_direction

# Ekranda gösterilen manuel durumlar ve renkleri (§9, §10).
STATUS_MUTABIK = "MUTABIK"
STATUS_RED = "RED"
STATUS_SARTLI = "ŞARTLI"
STATUS_MANUEL = "MANUEL"
STATUS_WAITING = "CEVAP BEKLENİYOR"
STATUS_INCELEME = "İNCELEME"
STATUS_PROCESSING = "İŞLENİYOR"
STATUS_INVOICE = "FATURA GELDİ - İNCELENECEK"

COLOR_GREEN = "YEŞİL"
COLOR_RED = "KIRMIZI"
COLOR_YELLOW = "SARI"
COLOR_GREY = "GRİ"
COLOR_BLUE = "MAVİ"
COLOR_PURPLE = "MOR"

# Durum -> renk. Tek tanım: ekran da, rapor da buradan okur.
STATUS_COLORS: dict[str, str] = {
    STATUS_MUTABIK: COLOR_GREEN,
    STATUS_RED: COLOR_RED,
    STATUS_SARTLI: COLOR_YELLOW,
    STATUS_MANUEL: COLOR_GREY,
    STATUS_INVOICE: COLOR_GREY,
    STATUS_WAITING: COLOR_BLUE,
    STATUS_PROCESSING: COLOR_BLUE,
    STATUS_INCELEME: COLOR_PURPLE,
}

# Manuel butonların ürettiği durumlar (§9).
MANUAL_STATUSES = (STATUS_MUTABIK, STATUS_RED, STATUS_SARTLI, STATUS_MANUEL)


def color_for(status: str) -> str:
    """Durumun rengi (bilinmeyen durum MOR = incelenmeli)."""
    return STATUS_COLORS.get((status or "").strip().upper(), COLOR_PURPLE)


def _attachment_meta(snapshot: Any) -> list[dict[str, Any]]:
    """Gönderilen eklerin kimliği — dosya İÇERİĞİ taşınmaz, yalnızca hash."""
    out: list[dict[str, Any]] = []
    for attachment in getattr(snapshot, "attachments", ()) or ():
        out.append({
            "name": (getattr(attachment, "name", "")
                     or getattr(attachment, "filename", "")),
            "sha256": getattr(attachment, "sha256", ""),
            "path": getattr(attachment, "path", ""),
            "size": getattr(attachment, "size", 0),
        })
    return out


def directions_of(snapshot: Any) -> list[str]:
    """Snapshot'ın yönleri; yön bilinmiyorsa tek bir boş yön döner."""
    directions = [d for d in (getattr(snapshot, "directions", ()) or ()) if d]
    return directions or [""]


def case_from_snapshot(snapshot: Any, balance_type: str) -> IncomingCase:
    """Gönderim snapshot'ından TEK yönün iş kaydını üret (cevap beklenir)."""
    case = IncomingCase(
        send_id=getattr(snapshot, "send_id", ""),
        snapshot_id=getattr(snapshot, "snapshot_id", ""),
        company_code=getattr(snapshot, "company_code", ""),
        company_name=getattr(snapshot, "company_name", ""),
        period=getattr(snapshot, "period", ""),
        responsible=getattr(snapshot, "responsible", ""),
        subject=getattr(snapshot, "subject", ""),
        message_id=getattr(snapshot, "message_id", ""),
        conversation_id=getattr(snapshot, "conversation_id", ""),
        balance_type=balance_type,
        data_source_type=source_for_direction(balance_type),
        has_reply=False,
        sent_date=(getattr(snapshot, "sent_at", "")
                   or getattr(snapshot, "created_at", "")),
        recipients="; ".join(getattr(snapshot, "recipients", ()) or ()),
        cc="; ".join(getattr(snapshot, "cc", ()) or ()),
        original_attachments=_attachment_meta(snapshot),
        fbl1h_sha256=getattr(snapshot, "fbl1h_sha256", ""),
        fbl5h_sha256=getattr(snapshot, "fbl5h_sha256", ""),
        final_status=STATUS_WAITING,
        status_color=COLOR_BLUE,
        outcome="AWAITING_REPLY",
        reply_type="",
        confidence=0.0,
        confidence_100=0,
        confidence_explanation=(
            "Cevap bekleniyor; henüz değerlendirilecek bir veri yok."),
        needs_human_review=False,
    )
    case.add_mail_event(
        "OUT", mail_id=case.message_id, subject=case.subject,
        occurred_at=case.sent_date, snippet="Mutabakat maili gönderildi",
        attachment_count=len(case.original_attachments),
        attachment_hashes=[a.get("sha256", "")
                           for a in case.original_attachments])
    case.add_event(
        "MAIL_SENT",
        f"Mutabakat maili gönderildi ({balance_type or 'yön yok'})",
        new_value=STATUS_WAITING,
        detail=f"send_id={case.send_id} snapshot_id={case.snapshot_id}")
    return case


def seed_cases(store: IncomingCaseStore,
               snapshots: Iterable[Any]) -> tuple[int, int]:
    """Snapshot listesinden case üret. (yeni, korunan) sayısını döndürür.

    Zaten var olan bir kayıt ASLA ezilmez: gönderim kaydı yeniden okunduğunda
    firmanın verdiği cevap ve kullanıcının kararı kaybolmaz.
    """
    created = 0
    kept = 0
    for snapshot in snapshots:
        for balance_type in directions_of(snapshot):
            case = case_from_snapshot(snapshot, balance_type)
            if store.get(case.case_id) is not None:
                kept += 1
                continue
            if store.upsert(case):
                created += 1
    return created, kept


class InvalidAddressCaseClosed(ValueError):
    """Adresi teslimata kapalı bir vaka, yeni adres girilmeden kapatılamaz."""


#: Vakayı KAPATAN manuel durumlar (dosya bu kararla biter).
_CLOSING_STATUSES = frozenset({STATUS_MUTABIK, STATUS_RED})


def apply_manual_status(case: IncomingCase, status: str, *,
                        note: str = "", user: str = "") -> IncomingCase:
    """Kullanıcının elle verdiği durumu uygula (GERİ ALINABİLİR).

    Aynı duruma İKİNCİ kez basmak kararı geri alır: ``previous_status``
    saklandığı için kayıt eski hâline döner. Her iki yön de işlem geçmişine
    yazılır; sessiz değişiklik yoktur.
    """
    status = (status or "").strip().upper()
    if status not in MANUAL_STATUSES:
        raise ValueError(f"Tanınmayan manuel durum: {status}")

    # ADRESİ GEÇERSİZ VAKA KAPATILAMAZ.
    #
    # Mail hiç ulaşmamışsa firma mutabakat mektubunu görmemiştir; vakayı
    # MUTABIK/RED diye kapatmak, hiç sorulmamış bir soruyu cevaplanmış
    # saymaktır. Kapanış YENİ iletişim adresi girildikten sonra serbesttir.
    # (Geri alma yolu bilinçli olarak açık bırakılır: yanlışlıkla verilmiş
    # bir kararı geri almak her zaman güvenlidir.)
    if status in _CLOSING_STATUSES and not (
            case.manual_override and case.final_status == status):
        from app.services.invalid_address import can_close

        izin, gerekce = can_close(case)
        if not izin:
            raise InvalidAddressCaseClosed(gerekce)

    if case.manual_override and case.final_status == status:
        onceki = case.previous_status or STATUS_INCELEME
        case.add_event("MANUAL_REVERT",
                       f"Manuel durum geri alındı ({status} → {onceki})",
                       old_value=case.final_status, new_value=onceki,
                       user=user)
        case.final_status = onceki
        case.status_color = color_for(onceki)
        case.manual_override = False
        case.manual_note = ""
        case.previous_status = ""
        return case

    case.previous_status = case.final_status or STATUS_INCELEME
    case.add_event("MANUAL_STATUS",
                   f"Kullanıcı durumu elle {status} yaptı",
                   old_value=case.previous_status, new_value=status,
                   user=user, detail=note)
    case.final_status = status
    case.status_color = color_for(status)
    case.manual_override = True
    case.manual_note = note
    # Manuel MUTABIK/RED kararı incelemeyi kapatır; ŞARTLI/MANUEL açık bırakır.
    case.needs_human_review = status in (STATUS_MANUEL, STATUS_SARTLI)
    return case


# Firmanın "faturaları gönderdim" dediğini gösteren ifadeler (§13).
# Tamamen deterministik: sözlük eşleşmesi, AI yok. Liste dar tutulur —
# "fatura" kelimesinin geçmesi tek başına yeterli DEĞİLDİR, çünkü mutabakat
# mailinin kendisi de faturalardan söz eder.
_INVOICE_PHRASES: tuple[str, ...] = (
    # Türkçe
    "faturalari ektedir", "faturaları ektedir", "faturalari gonderiyoruz",
    "faturaları gönderiyoruz", "faturalar ekte", "fatura ekte",
    "faturalari ilettik", "faturaları ilettik", "ekte faturalar",
    "fatura orneklerini", "fatura örneklerini", "faturalari paylasiyoruz",
    "faturaları paylaşıyoruz", "ilgili faturalar ekte",
    # İngilizce
    "invoices are attached", "please find attached the invoices",
    "attached the invoices", "we are sending the invoices",
    "invoice copies attached", "find enclosed the invoices",
)


def detects_invoice(body: str = "", attachment_names: Iterable[str] = ()
                    ) -> bool:
    """Firma fatura/belge gönderdi mi? (§13 — deterministik)

    İki koşuldan biri yeterlidir:
      * gövdede "faturaları ektedir" gibi AÇIK bir ifade geçiyorsa, ya da
      * ek dosya adı fatura/invoice içeriyorsa.

    Yalnızca "fatura" kelimesinin geçmesi yeterli sayılmaz: mutabakat
    yazışmasının kendisi zaten faturalardan söz eder ve her maili griye
    almak takip listesini anlamsız kılardı.
    """
    metin = (body or "").lower()
    for harf, yerine in (("ı", "i"), ("İ", "i"), ("ş", "s"), ("ğ", "g"),
                         ("ü", "u"), ("ö", "o"), ("ç", "c")):
        metin = metin.replace(harf, yerine)
    if any(phrase.lower() in metin for phrase in _INVOICE_PHRASES):
        return True
    for name in attachment_names or ():
        alt = (name or "").lower()
        if "fatura" in alt or "invoice" in alt:
            return True
    return False


def mark_invoice_received(case: IncomingCase, *, detail: str = "",
                          user: str = "") -> IncomingCase:
    """Firma fatura/belge gönderdi → GRİ, kullanıcı incelemeli (§13)."""
    if case.invoice_received and case.final_status == STATUS_INVOICE:
        return case
    case.previous_status = case.final_status or STATUS_INCELEME
    case.invoice_received = True
    case.final_status = STATUS_INVOICE
    case.status_color = COLOR_GREY
    case.needs_human_review = True
    case.add_event("INVOICE_RECEIVED",
                   "Firma fatura/belge gönderdi; manuel inceleme bekleniyor",
                   old_value=case.previous_status,
                   new_value=case.final_status, user=user, detail=detail)
    return case
