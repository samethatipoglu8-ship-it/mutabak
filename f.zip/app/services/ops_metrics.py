"""Operasyon özeti — üst yönetime sunulabilir tek ekranlık tablo (madde 8).

ÖLÇÜLENLER
    Gönderilen · Cevap bekleyen · Mutabık · Farklı · Geçersiz adres ·
    İnsan incelemesi · Ortalama cevap süresi · Geciken vakalar

TASARIM
    * Sayımlar VAKA KAYITLARINDAN türer; ayrı bir "istatistik tablosu"
      tutulmaz. İki kaynak olsaydı biri güncellenip diğeri unutulur ve panel
      gerçeği göstermeyi bırakırdı.
    * Bir vaka BİRDEN ÇOK kutuya girebilir (ör. hem "farklı" hem "insan
      incelemesi"); bu kasıtlıdır — kutular durum değil, İŞ YÜKÜ gösterir.
      Tek istisnalar: "gönderilen" toplam sayıdır, "cevap bekleyen" ise
      yalnızca cevabı gelmemişleri sayar.
    * Qt/SQLite/COM bilmez; saf hesap yapar ve istisna fırlatmaz.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable, Optional

from app.services.case_tracking import (
    STATUS_INCELEME,
    STATUS_INVOICE,
    STATUS_MANUEL,
    STATUS_MUTABIK,
    STATUS_RED,
    STATUS_SARTLI,
)
from app.services.invalid_address import GECERSIZ_ADRES

#: Cevap bu süreyi aştıysa vaka GECİKMİŞ sayılır (iş günü değil, takvim günü).
DEFAULT_OVERDUE_DAYS = 7

#: "Fark var" sayılan nihai durumlar.
_DIFFERENCE_STATUSES = frozenset({STATUS_RED, STATUS_SARTLI})
#: İnsan incelemesi gerektiren nihai durumlar.
_REVIEW_STATUSES = frozenset({STATUS_INCELEME, STATUS_MANUEL, STATUS_INVOICE})


def _parse(value: Any) -> Optional[datetime]:
    """ISO zaman damgasını güvenle çöz (çözülemezse ``None``)."""
    metin = str(value or "").strip()
    if not metin:
        return None
    try:
        an = datetime.fromisoformat(metin.replace("Z", "+00:00"))
    except ValueError:
        return None
    return an if an.tzinfo else an.replace(tzinfo=timezone.utc)


def _hours(delta: timedelta) -> float:
    return round(delta.total_seconds() / 3600.0, 1)


@dataclass
class OverdueCase:
    """Geciken tek bir vaka (ekranda listelenir)."""

    company_code: str = ""
    company_name: str = ""
    period: str = ""
    responsible: str = ""
    sent_at: str = ""
    waiting_days: int = 0
    address_invalid: bool = False


@dataclass
class OpsMetrics:
    """Operasyon panelinin tüm sayıları."""

    gonderilen: int = 0
    cevap_bekleyen: int = 0
    mutabik: int = 0
    farkli: int = 0
    gecersiz_adres: int = 0
    insan_incelemesi: int = 0
    #: Cevap veren vakalarda gönderim → ilk cevap ortalaması (saat).
    ortalama_cevap_saati: Optional[float] = None
    #: Ortalamanın kaç vakadan hesaplandığı (şeffaflık için).
    cevap_orneklem: int = 0
    geciken: int = 0
    geciken_vakalar: list[OverdueCase] = field(default_factory=list)
    esik_gun: int = DEFAULT_OVERDUE_DAYS
    period: str = ""

    @property
    def cevap_orani(self) -> float:
        """Cevap alınan vakaların oranı (0-1)."""
        if not self.gonderilen:
            return 0.0
        return round((self.gonderilen - self.cevap_bekleyen)
                     / self.gonderilen, 3)

    def ortalama_cevap_metni(self) -> str:
        """Ortalama cevap süresini insan diliyle yaz."""
        if self.ortalama_cevap_saati is None:
            return "—"
        if self.ortalama_cevap_saati < 48:
            return f"{self.ortalama_cevap_saati:.1f} saat"
        return f"{self.ortalama_cevap_saati / 24:.1f} gün"

    def as_rows(self) -> list[tuple[str, str]]:
        """Panelde gösterilecek (etiket, değer) çiftleri."""
        return [
            ("Gönderilen", str(self.gonderilen)),
            ("Cevap bekleyen", str(self.cevap_bekleyen)),
            ("Mutabık", str(self.mutabik)),
            ("Farklı", str(self.farkli)),
            ("Geçersiz adres", str(self.gecersiz_adres)),
            ("İnsan incelemesi", str(self.insan_incelemesi)),
            ("Ortalama cevap süresi", self.ortalama_cevap_metni()),
            (f"Geciken vakalar (>{self.esik_gun} gün)", str(self.geciken)),
        ]


def _final(case: Any) -> str:
    return str(getattr(case, "final_status", "") or "").strip().upper()


def compute(cases: Iterable[Any], *, now: Optional[datetime] = None,
            overdue_days: int = DEFAULT_OVERDUE_DAYS,
            period: str = "") -> OpsMetrics:
    """Vaka kayıtlarından operasyon özetini çıkar.

    ``now`` testler için dışarıdan verilebilir; verilmezse şimdiki zaman.
    """
    an = now or datetime.now(timezone.utc)
    esik = timedelta(days=max(0, int(overdue_days)))
    metrics = OpsMetrics(esik_gun=int(overdue_days), period=period)

    cevap_sureleri: list[float] = []
    for case in cases or ():
        metrics.gonderilen += 1
        durum = _final(case)
        adres_gecersiz = (str(getattr(case, "address_status", "") or "")
                          == GECERSIZ_ADRES)
        if adres_gecersiz:
            metrics.gecersiz_adres += 1

        cevap_var = bool(getattr(case, "has_reply", False))
        if not cevap_var:
            metrics.cevap_bekleyen += 1

        if durum == STATUS_MUTABIK:
            metrics.mutabik += 1
        elif durum in _DIFFERENCE_STATUSES:
            metrics.farkli += 1

        if durum in _REVIEW_STATUSES or bool(
                getattr(case, "needs_human_review", False)):
            # MUTABIK ya da RED kararı VERİLMİŞ bir vaka, bayrağı temizlenmemiş
            # olsa da iş yükü değildir; panel gerçek kuyruğu göstermelidir.
            if durum not in (STATUS_MUTABIK, STATUS_RED):
                metrics.insan_incelemesi += 1

        gonderim = _parse(getattr(case, "sent_date", ""))
        cevap = _parse(getattr(case, "last_reply_date", ""))
        if gonderim is not None and cevap is not None and cevap >= gonderim:
            cevap_sureleri.append(_hours(cevap - gonderim))

        # GECİKME yalnızca CEVAP BEKLEYEN vakalar için anlamlıdır.
        if not cevap_var and gonderim is not None and (an - gonderim) > esik:
            gun = int((an - gonderim).total_seconds() // 86400)
            metrics.geciken += 1
            metrics.geciken_vakalar.append(OverdueCase(
                company_code=str(getattr(case, "company_code", "") or ""),
                company_name=str(getattr(case, "company_name", "") or ""),
                period=str(getattr(case, "period", "") or ""),
                responsible=str(getattr(case, "responsible", "") or ""),
                sent_at=str(getattr(case, "sent_date", "") or ""),
                waiting_days=gun,
                address_invalid=adres_gecersiz))

    if cevap_sureleri:
        metrics.cevap_orneklem = len(cevap_sureleri)
        metrics.ortalama_cevap_saati = round(
            sum(cevap_sureleri) / len(cevap_sureleri), 1)
    # En çok bekleyen en üstte: kullanıcı listeyi sıralamak zorunda kalmasın.
    metrics.geciken_vakalar.sort(key=lambda c: c.waiting_days, reverse=True)
    return metrics


def from_store(store: Any, *, period: Optional[str] = None,
               now: Optional[datetime] = None,
               overdue_days: int = DEFAULT_OVERDUE_DAYS) -> OpsMetrics:
    """Vaka deposundan özet üret. Depo okunamazsa BOŞ özet döner."""
    try:
        cases = store.find(period=period) if period else store.all()
    except Exception:  # noqa: BLE001 - panel asla çökertmez
        cases = []
    return compute(cases, now=now, overdue_days=overdue_days,
                   period=period or "")
