"""Sonucu belirsiz kalan (SEND_UNKNOWN) gönderimin güvenli, denetlenebilir İNSAN çözümü.

NEDEN
    ``Send()`` hata verdi ya da süreç gönderim sırasında öldü: mail gitmiş
    OLABİLİR. Sistem bunu hiçbir koşulda KENDİSİ "gitti" ya da "gitmedi"
    saymaz ve otomatik yeniden göndermez. Çözüm, yetkili bir kullanıcının
    GEREKÇELİ kararıdır; karar denetlenebilir ve geri alınamaz biçimde kaydedilir.

ÜÇ KARAR
    * ``VERIFIED_SENT``  "Gönderilmiş olarak doğrula" — kalıcı engel (terminal).
    * ``REOPENED``       "Gönderilmediğini doğrula ve yeniden gönderime aç" —
                         Send() ÇAĞIRMAZ; yalnız engeli kaldırır. Firma ancak
                         kullanıcının bir sonraki MANUEL gönderim aksiyonunda gider.
    * ``UNDER_REVIEW``   "İncelemede bırak" — durum DEĞİŞMEZ (engelli kalır).

GARANTİLER
    * Yetki: karar başına izin ``DECISION_PERMISSION`` ile eşlenir (şimdilik
      hepsi ``RESOLVE_SEND_UNKNOWN``; ileride bölünebilir).
    * Gerekçe zorunlu; boşsa ``ReasonRequired``.
    * Sıra: yetki -> gerekçe -> durum/geçiş -> kanıt -> AUDIT(ATTEMPT, zorunlu)
      -> kuyruk -> ``send_resolutions`` -> audit(APPLIED, en iyi çaba).
      Audit yazılamazsa durum DEĞİŞMEZ (fail-closed). Yalnız ATTEMPT varsa
      karar uygulanmamıştır.
    * Kanıt eksikse sistem ``SENT`` varsaymaz; kullanıcı açıkça "kanıt olmadan
      karar veriyorum" demelidir. Outlook/kuyruk ``SENT`` diyorsa REOPEN
      SERT biçimde reddedilir.
    * İdempotent: aynı karar ikinci kez uygulanmaz (yeni satır/audit yok).
    * ``MailLog.mail_sends`` satırlarına dokunulmaz; çözümler ekleme-yönlü
      ``send_resolutions`` tablosundadır.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Any, Optional

from loguru import logger

from app.services import authz
from app.services.action_audit import (
    ACTION_SEND_UNKNOWN_DENIED,
    ACTION_SEND_UNKNOWN_RESOLUTION,
    ActionAuditLog,
)
from app.services.authz import PermissionDenied, ReasonRequired, current_user
from app.services.mail_log import (
    DECISION_REOPENED,
    DECISION_UNDER_REVIEW,
    DECISION_VERIFIED_SENT,
    RESOLUTION_DECISIONS,
    STATE_NONE,
    STATE_REOPENED,
    STATE_SENT,
    STATE_UNKNOWN,
    STATE_VERIFIED_SENT,
    EffectiveState,
    MailLog,
    MailLogEntry,
    SendResolution,
)
from app.services.mail_log import STATUS_SENT as LOG_STATUS_SENT
from app.services.send_queue import (
    STATUS_SENT as QUEUE_SENT,
)
from app.services.send_queue import (
    QueueItem,
    QueueUnavailableError,
    SendQueue,
)

# -- kural tabloları (tek yerde; testler bunları da doğrular) -----------------

#: Karar -> gereken izin. Bölmek için yalnız burası ve ``authz`` değişir.
DECISION_PERMISSION: dict[str, str] = {
    DECISION_VERIFIED_SENT: authz.PERM_RESOLVE_SEND_UNKNOWN,
    DECISION_REOPENED: authz.PERM_RESOLVE_SEND_UNKNOWN,
    DECISION_UNDER_REVIEW: authz.PERM_RESOLVE_SEND_UNKNOWN,
}

#: Karar -> uygulanabileceği etkin durumlar.
ALLOWED_FROM: dict[str, frozenset[str]] = {
    DECISION_VERIFIED_SENT: frozenset({STATE_UNKNOWN, STATE_REOPENED}),
    DECISION_REOPENED: frozenset({STATE_UNKNOWN}),       # VERIFIED_SENT terminal
    DECISION_UNDER_REVIEW: frozenset({STATE_UNKNOWN}),
}

#: Karar -> uygulanınca etkin durum (None: durum değişmez).
TARGET_STATE: dict[str, Optional[str]] = {
    DECISION_VERIFIED_SENT: STATE_VERIFIED_SENT,
    DECISION_REOPENED: STATE_REOPENED,
    DECISION_UNDER_REVIEW: None,
}

EVIDENCE_PRESENT = "VAR"
EVIDENCE_MISSING = "YOK"


# -- hatalar --------------------------------------------------------------------

class ResolutionError(Exception):
    """Çözüm uygulanamadı (durum DEĞİŞMEDİ)."""


class NotUnknown(ResolutionError):
    """Firma bu dönemde çözülecek belirsiz bir gönderime sahip değil."""


class InvalidTransition(ResolutionError):
    """Mevcut etkin durumdan bu karara geçiş yasak."""


class EvidenceAcknowledgementRequired(ResolutionError):
    """Kanıt yok; kullanıcı bunu açıkça kabul etmeden karar verilemez."""


class ContradictsEvidence(ResolutionError):
    """Mevcut kanıt mailin GİTTİĞİNİ söylüyor; yeniden gönderime açılamaz."""


class DuplicateRiskAcknowledgementRequired(ResolutionError):
    """Mailin gitmediğine dair kesin kanıt yok; yeniden gönderime açmak için
    mükerrer-mail riskinin İKİNCİ, açık onayı gerekir."""


#: Kanıt durumu (Outlook + kuyruk). ``UNKNOWN`` ASLA ``NOT_SENT`` sayılmaz.
STATUS_EV_SENT = "SENT"
STATUS_EV_NOT_SENT = "NOT_SENT"
STATUS_EV_UNKNOWN = "UNKNOWN"

DUPLICATE_RISK_WARNING = ("Gönderildiğine dair kesin kanıt yok; yeniden "
                          "gönderim mükerrer mail yaratabilir")


class AuditUnavailable(ResolutionError):
    """Denetim kaydı yazılamadı; durum değiştiren karar uygulanmaz."""


# -- veri sınıfları ---------------------------------------------------------------

@dataclass(frozen=True)
class Evidence:
    """Kararın dayandığı, kullanıcıya gösterilen kanıt (salt-okunur özet)."""

    level: str                          # VAR | YOK
    mail_log: dict
    queue: Optional[list]               # None: kuyruk okunamadı
    queue_error: str = ""
    outlook: Optional[dict] = None      # kullanıcının çalıştırdığı kontrol
    #: SENT: Outlook/kuyruk gittiğini gösteriyor · NOT_SENT: Outlook gitmediğini
    #: KANITLADI · UNKNOWN: diğer her şey (kontrol yok / belirsiz sonuç).
    status: str = STATUS_EV_UNKNOWN

    def as_dict(self) -> dict:
        return {"level": self.level, "status": self.status,
                "mail_log": self.mail_log, "queue": self.queue,
                "queue_error": self.queue_error, "outlook": self.outlook}


@dataclass(frozen=True)
class UnknownCase:
    """Çözüm bekleyen belirsiz gönderim (liste satırı)."""

    company_code: str
    company_name: str
    period: str
    state: str
    basis_row_id: int
    sent_at: str
    recipients: str
    subject: str
    under_review: bool
    evidence_level: str


@dataclass(frozen=True)
class UnknownDetail:
    """Karar ekranı: durum + kanıt + geçmiş kararlar."""

    state: EffectiveState
    entry: Optional[MailLogEntry]
    evidence: Evidence
    resolutions: list


@dataclass(frozen=True)
class ResolutionResult:
    changed: bool
    decision: str
    prior_state: str
    new_state: str
    resolution_id: str = ""
    reason: str = ""
    user: str = ""


# -- kanıt -----------------------------------------------------------------------

def _entry_summary(e: Optional[MailLogEntry]) -> dict:
    if e is None:
        return {}
    return {"status": e.status, "sent_at": e.sent_at, "reason": e.reason,
            "recipients": e.recipients, "subject": e.subject,
            "message_id": e.message_id, "conversation_id": e.conversation_id,
            "entry_id": e.entry_id, "identity_verified": e.identity_verified,
            "send_id": e.send_id}


def _queue_summary(i: QueueItem) -> dict:
    return {"queue_id": i.queue_id, "batch_id": i.batch_id, "status": i.status,
            "attempts": i.attempts, "claimed_at": i.claimed_at,
            "updated_at": i.updated_at, "reason": i.reason,
            "entry_id": i.entry_id, "message_id": i.message_id,
            "conversation_id": i.conversation_id}


def _outlook_summary(check: Any) -> Optional[dict]:
    if check is None:
        return None
    return {"status": str(getattr(check, "status", "") or ""),
            "location": str(getattr(check, "location", "") or ""),
            "entry_id": str(getattr(check, "entry_id", "") or ""),
            "message_id": str(getattr(check, "message_id", "") or ""),
            "reason": str(getattr(check, "reason", "") or "")}


def collect_evidence(log: MailLog, queue: Optional[SendQueue], period: str,
                     company_code: str, state: EffectiveState,
                     outlook_check: Any = None) -> Evidence:
    """Mevcut kanıtı topla. Kuyruk okunamazsa ``queue=None`` (gizlenmez).

    Sistem burada HİÇBİR ŞEY varsaymaz: yalnız kayıtlı kimlikleri ve
    kullanıcının çalıştırdığı Outlook kontrolünün sonucunu raporlar.
    """
    entry = log.entry_by_row_id(state.basis_row_id) if state.basis_row_id else None
    kuyruk: Optional[list] = None
    hata = ""
    if queue is not None:
        try:
            kuyruk = [_queue_summary(i)
                      for i in queue.by_company(period, company_code)]
        except QueueUnavailableError as exc:
            hata = str(exc)
    outlook = _outlook_summary(outlook_check)

    kimlikler = [bool(entry and (entry.message_id or entry.entry_id))]
    kimlikler += [bool(q["message_id"] or q["entry_id"]) for q in (kuyruk or [])]
    if outlook:
        kimlikler.append(bool(outlook["entry_id"] or outlook["message_id"])
                         or outlook["status"] == "SENT")
    # Kanıt DURUMU: yalnız açık kanıt NOT_SENT/SENT yapar; gerisi UNKNOWN.
    if (outlook and outlook["status"] == "SENT") or any(
            q["status"] == QUEUE_SENT for q in (kuyruk or [])):
        durum = STATUS_EV_SENT
    elif outlook and outlook["status"] == "NOT_SENT":
        durum = STATUS_EV_NOT_SENT
    else:
        durum = STATUS_EV_UNKNOWN
    return Evidence(EVIDENCE_PRESENT if any(kimlikler) else EVIDENCE_MISSING,
                    _entry_summary(entry), kuyruk, hata, outlook, durum)


def _contradicts_reopen(kanit: Evidence, log: MailLog, period: str,
                        company_code: str) -> str:
    """REOPEN'i yasaklayan kanıt var mı? Döner: gerekçe ya da ''."""
    # Günlükte bu (dönem, firma) için BAŞARIYLA gönderilmiş bir kayıt varsa
    # (sonradan başka bir belirsizlik oluşmuş olsa bile) mektup zaten gitmiştir;
    # eski kural da "herhangi bir SENT satırı kalıcı engeldir" idi.
    for e in log.entries(period=period):
        if e.company_code == company_code and e.status == LOG_STATUS_SENT:
            return ("Günlükte bu dönem için bu firmaya BAŞARIYLA gönderilmiş "
                    "bir kayıt var; yeniden gönderime açılamaz (mükerrer "
                    "mektup).")
    if kanit.outlook and kanit.outlook["status"] == "SENT":
        return ("Outlook/Gönderilmiş Öğeler bu mailin GÖNDERİLDİĞİNİ "
                "gösteriyor; yeniden gönderime açılamaz (mükerrer mektup).")
    for q in kanit.queue or []:
        if q["status"] == QUEUE_SENT:
            return ("Gönderim kuyruğu bu firmaya mailin GİTTİĞİNİ "
                    f"gösteriyor ({q['queue_id']}); yeniden gönderime açılamaz.")
    return ""


# -- okuma API'si ---------------------------------------------------------------

def list_unresolved(log: MailLog, period: Optional[str] = None
                    ) -> list[UnknownCase]:
    """İnsan kararı bekleyen belirsiz gönderimler."""
    sonuc: list[UnknownCase] = []
    for e in log.unresolved_unknowns(period):
        d = log.effective_state(e.period, e.company_code)
        sonuc.append(UnknownCase(
            company_code=e.company_code, company_name=e.company_name,
            period=e.period, state=d.state, basis_row_id=d.basis_row_id,
            sent_at=e.sent_at, recipients=e.recipients, subject=e.subject,
            under_review=d.under_review,
            evidence_level=(EVIDENCE_PRESENT
                            if (e.message_id or e.entry_id)
                            else EVIDENCE_MISSING)))
    return sonuc


def list_reopened(log: MailLog, period: str) -> list[str]:
    """Yeniden gönderime AÇILMIŞ (henüz gönderilmemiş) firma kodları."""
    return sorted(k for k, d in log.effective_states(period).items()
                  if d.state == STATE_REOPENED)


def describe(log: MailLog, queue: Optional[SendQueue], period: str,
             company_code: str, outlook_check: Any = None) -> UnknownDetail:
    """Karar ekranı için durum + kanıt + geçmiş kararlar (SALT-OKUNUR)."""
    durum = log.effective_state(period, company_code)
    return UnknownDetail(
        state=durum,
        entry=log.entry_by_row_id(durum.basis_row_id)
        if durum.basis_row_id else None,
        evidence=collect_evidence(log, queue, period, company_code, durum,
                                  outlook_check),
        resolutions=log.resolutions(period, company_code))


# -- karar ----------------------------------------------------------------------

def _audit_detail(phase: str, rid: str, decision: str, role: str,
                  kanit: Optional[Evidence], risk_onayi: bool = False) -> str:
    outlook = (kanit.outlook["status"] if kanit and kanit.outlook else "")
    seviye = kanit.level if kanit else ""
    durum = kanit.status if kanit else ""
    return (f"phase={phase};resolution_id={rid};decision={decision};"
            f"role={role};evidence={seviye};evidence_status={durum};"
            f"outlook={outlook}" + (";duplicate_risk_ack=1" if risk_onayi else ""))


def _already_applied(decision: str, durum: EffectiveState,
                     gerekce: str) -> bool:
    """Aynı karar zaten uygulanmış mı? (idempotensi)"""
    if decision == DECISION_VERIFIED_SENT:
        return durum.state == STATE_VERIFIED_SENT
    if decision == DECISION_REOPENED:
        return durum.state == STATE_REOPENED
    return (durum.state == STATE_UNKNOWN and durum.under_review
            and durum.last_review is not None
            and durum.last_review.reason == gerekce)


def resolve(decision: str, period: str, company_code: str, *, reason: str,
            log: MailLog, queue: Optional[SendQueue] = None,
            audit: Any = None, user: str = "", settings: Any = None,
            role: str = "", outlook_check: Any = None,
            ack_no_evidence: bool = False,
            confirm_duplicate_risk: bool = False) -> ResolutionResult:
    """Belirsiz bir gönderimi İNSAN kararıyla çöz.

    ``Send()`` ÇAĞIRMAZ. Hata anında durum DEĞİŞMEZ; ayrıntı modül açıklamasında.

    REOPEN ve kanıt durumu: Outlook/kuyruk/günlük SENT ise KESİN red; Outlook
    NOT_SENT ise normal; UNKNOWN (ya da hiç kontrol yok) ise ancak zorunlu
    gerekçeye ek olarak ``confirm_duplicate_risk=True`` (ikinci açık onay) ile.
    Sistem UNKNOWN'ı kendi başına NOT_SENT saymaz.
    """
    if decision not in RESOLUTION_DECISIONS:
        raise ValueError(f"Tanınmayan karar: {decision}")
    aktor = user or current_user()

    if decision == DECISION_REOPENED and queue is None:
        raise ValueError(
            "Yeniden gönderime açmak için gönderim kuyruğu verilmelidir "
            "(kuyruk kaydı açılmazsa bir sonraki gönderim engellenir).")
    if audit is None:
        audit = ActionAuditLog()

    # 1) YETKİ
    try:
        rol = authz.require(DECISION_PERMISSION[decision], user=aktor,
                            settings=settings, role=role)
    except PermissionDenied:
        _try_audit(audit, ACTION_SEND_UNKNOWN_DENIED, aktor,
                   f"{period}/{company_code}", company_code, period,
                   "", decision, "", f"decision={decision};role={role}")
        raise

    # 2) GEREKÇE
    gerekce = (reason or "").strip()
    if not gerekce:
        raise ReasonRequired(
            "Belirsiz gönderimi çözmek için GEREKÇE zorunludur. Bu açıklama "
            "denetim kaydına yazılır.")

    # 3) DURUM / GEÇİŞ (okunamazsa istisna yükselir: fail-closed)
    durum = log.effective_state(period, company_code)
    if durum.state in (STATE_NONE, STATE_SENT):
        raise NotUnknown(
            f"{company_code} için {period} döneminde çözülecek belirsiz bir "
            f"gönderim yok (durum: {durum.state}).")
    hedef = TARGET_STATE[decision] or durum.state
    if _already_applied(decision, durum, gerekce):
        return ResolutionResult(False, decision, durum.state, durum.state,
                                reason=gerekce, user=aktor)
    if durum.state not in ALLOWED_FROM[decision]:
        raise InvalidTransition(
            f"'{durum.state}' durumundan '{decision}' kararına geçiş yapılamaz.")

    # 4) KANIT
    kanit = collect_evidence(log, queue, period, company_code, durum,
                             outlook_check)
    if decision != DECISION_UNDER_REVIEW:
        # Outlook'un "NOT_SENT" demesi, REOPEN için kimlik olmasa da yeterli kanıttır.
        yeterli = (kanit.level == EVIDENCE_PRESENT
                   or (decision == DECISION_REOPENED
                       and kanit.status == STATUS_EV_NOT_SENT))
        if not yeterli and not ack_no_evidence:
            raise EvidenceAcknowledgementRequired(
                "Bu gönderim için kayıtlı kanıt yok (Message-ID/EntryID/Outlook "
                "doğrulaması). Sistem 'gönderildi' ya da 'gönderilmedi' "
                "varsaymaz; kanıtsız karar için açık onay gerekir.")
    risk_onayi = False
    if decision == DECISION_REOPENED:
        if queue is not None and kanit.queue is None:
            # Kuyruk okunamıyor: gönderildiğini gösteren kayıt görülemez.
            raise QueueUnavailableError(
                f"Gönderim kuyruğu okunamadı ({kanit.queue_error}); "
                "yeniden gönderime açılamaz.")
        neden = _contradicts_reopen(kanit, log, period, company_code)
        if neden:
            raise ContradictsEvidence(neden)
        if kanit.status == STATUS_EV_UNKNOWN:
            if not confirm_duplicate_risk:
                raise DuplicateRiskAcknowledgementRequired(
                    DUPLICATE_RISK_WARNING + ". Devam etmek için mükerrer-mail "
                    "riskini açıkça onaylayın.")
            risk_onayi = True

    # 5) AUDIT(ATTEMPT) — ZORUNLU
    rid = uuid.uuid4().hex
    if not audit.record(
            ACTION_SEND_UNKNOWN_RESOLUTION, user=aktor,
            target=f"{period}/{company_code}", company_code=company_code,
            period=period, old_value=durum.state, new_value=hedef,
            reason=gerekce,
            detail=_audit_detail("ATTEMPT", rid, decision, rol, kanit,
                                 risk_onayi)):
        raise AuditUnavailable(
            "Denetim kaydı yazılamadı; karar UYGULANMADI.")

    # 6) KUYRUK
    if queue is not None and decision != DECISION_UNDER_REVIEW:
        try:
            if decision == DECISION_REOPENED:
                queue.reopen_unknown(period, company_code, gerekce)
            else:
                queue.settle_sent(period, company_code, gerekce)
        except QueueUnavailableError:
            if decision == DECISION_REOPENED:
                raise                       # fail-closed: açma yarım kalmasın
            logger.warning(
                f"[çözüm] {company_code}: kuyruk SENT'e çekilemedi; karar yine "
                "kaydedilecek (kapı MailLog üzerinden engelli kalır).")

    # 7) KAYIT (ekleme-yönlü; okuma-karar-yazma atomik)
    sonuc = log.append_resolution(
        period=period, company_code=company_code, decision=decision,
        allowed_from=ALLOWED_FROM[decision], reason=gerekce, user=aktor,
        role=rol,
        evidence={**kanit.as_dict(), "duplicate_risk_ack": risk_onayi},
        resolution_id=rid)
    if not sonuc.applied:
        # Yarış: başka biri araya girdi. Aynı sonuçsa no-op, değilse hata.
        if sonuc.prior.state == hedef and TARGET_STATE[decision]:
            return ResolutionResult(False, decision, sonuc.prior.state,
                                    sonuc.prior.state, reason=gerekce,
                                    user=aktor)
        raise InvalidTransition(
            f"Durum bu sırada '{sonuc.prior.state}' oldu; karar uygulanmadı.")

    # 8) AUDIT(APPLIED) — en iyi çaba (durum zaten kaydedildi)
    _try_audit(audit, ACTION_SEND_UNKNOWN_RESOLUTION, aktor,
               f"{period}/{company_code}", company_code, period,
               durum.state, hedef, gerekce,
               _audit_detail("APPLIED", rid, decision, rol, kanit, risk_onayi))
    res: SendResolution = sonuc.resolution  # type: ignore[assignment]
    return ResolutionResult(True, decision, durum.state, res.new_state,
                            resolution_id=res.resolution_id, reason=gerekce,
                            user=aktor)


def _try_audit(audit: Any, action: str, user: str, target: str, company: str,
               period: str, old: str, new: str, reason: str,
               detail: str) -> None:
    try:
        ok = audit.record(action, user=user, target=target,
                          company_code=company, period=period, old_value=old,
                          new_value=new, reason=reason, detail=detail)
        if not ok:
            logger.warning(f"[çözüm] denetim kaydı yazılamadı ({action}).")
    except Exception as exc:  # noqa: BLE001 - en iyi çaba kayıtları işi bozmaz
        logger.warning(f"[çözüm] denetim kaydı yazılamadı ({action}): {exc}")
