"""'Gelen Cevaplar' ekranı — gelen mutabakat maillerini okur ve analiz eder.

Bu ekran mevcut sayfalara DOKUNMAZ; ana pencereye yeni bir sayfa olarak
eklenir. Tüm iş arka plandadır (``IncomingMailPipelineWorker``), iptal
kooperatiftir ve kapanışta thread'ler düzgünce durdurulur — mevcut
``MailingPage`` kalıbının aynısı.

Ekranın tek işi göstermektir: karar mantığı ``app/incoming/pipeline.py``
içindedir ve Qt bilmez.
"""

from __future__ import annotations

from datetime import datetime, timedelta

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QSizePolicy,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from app.incoming.models import ReconciliationResponse
from app.services.authz import PermissionDenied, change_financial_decision
from app.services.case_tracking import (
    STATUS_MANUEL,
    STATUS_MUTABIK,
    STATUS_RED,
    STATUS_SARTLI,
    InvalidAddressCaseClosed,
    apply_manual_status,
    seed_cases,
)
from app.services.incoming_cases import _current_user
from app.ui.worker import WorkerBinding, run_in_thread

# Üç değerli alanların gösterimi: "bilinmiyor" ile "hayır" AYNI ŞEY DEĞİLDİR.
_TRISTATE = {True: "Evet", False: "Hayır", None: "?"}

_COLUMNS = ("Firma Kodu", "Firma Adı", "Cevap", "Bakiye", "Yön", "Mektup",
            "Dolu", "İmza", "Kaşe", "Güven", "İnceleme", "AI", "Konu")

# FAZ 10 — kalıcı iş kayıtlarının (IncomingCase) kolonları. Nihai durum
# kullanıcı için SADE tutulur; tüm teknik kanıt detay ekranındadır.
_CASE_COLUMNS = (
    "Durum", "Firma Kodu", "Firma Adı", "Bakiye", "Konu", "Gönderilen",
    "Gelen", "Mutabakat Yap", "Body Kararı", "Ekstre Kararı",
    "Finansal Fark", "Nihai Karar", "Güven", "Güven Açıklaması",
    "Son Mail Özeti", "Ek", "Fatura", "Hazır Mail", "Karşılaştır", "Geçmiş",
)

# Tek seferde çizilen satır sayısı. Her satır üç QWidget taşır (manuel
# butonlar, Karşılaştır, Geçmiş); 3.000 satırı birden çizmek pencereyi
# saniyelerce kilitler. Sayfalama bunu sabit maliyete indirir.
PAGE_SIZE = 200

# Buton yerleştirilen kolonlar (metin yazılmaz, widget konur).
_COL_MANUAL = 7
_COL_COMPARE = 18
_COL_HISTORY = 19


class _ShrinkingStatusLabel(QLabel):
    """Uzun durum metninin pencerenin zorunlu genişliğini büyütmesini önle.

    ``QLabel`` için ``setMinimumWidth(0)`` tek başına yeterli değildir:
    Qt, kelime kaydırmalı etikette metinden türetilen ``minimumSizeHint``
    değerini yerleşime yine iletir. Bu ekranda etiket bilgi amaçlıdır;
    dar alanda çok satıra yayılabilir ve hiçbir işlem düğmesini ekrandan
    dışarı itemez.
    """

    def minimumSizeHint(self) -> QSize:  # noqa: N802 - Qt API adı
        hint = super().minimumSizeHint()
        return QSize(0, hint.height())

# Nihai durumun satır rengi — ekranda üç saniyede okunabilsin.
_STATUS_COLORS = {
    "MUTABIK": "#2d5a2d",
    "RED": "#5a2d2d",
    "İNCELEME": "#5a5327",
    "CEVAP BEKLENİYOR": "#2d3f5a",
}


def _short_hash(value: str) -> str:
    """Hash'i tabloda okunur kısalt (tam değeri detay ekranı gösterir)."""
    return f"{value[:8]}…" if value else "—"


def _fmt_balances(response: ReconciliationResponse) -> str:
    if not response.currencies:
        return "—"
    return "; ".join(f"{code} {amount:,.2f}"
                     for code, amount in sorted(response.currencies.items()))


def _case_values(case) -> tuple:
    """Bir ``IncomingCase``ın tablo satırı — Qt bilmez, testte doğrudan sürülür.

    Yön (M/S) ayrı satırdır: aynı firma iki kez görünebilir ve bu doğrudur.
    """
    statement = case.statement_result or {}
    fark = case.financial_difference or statement.get("difference") or ""
    para = case.difference_currency or statement.get("currency") or ""
    ekler = case.incoming_attachments or []
    return (
        case.status_color or "—",
        case.company_code or "—",
        case.company_name or "—",
        case.balance_type or "—",
        case.subject or "",
        (case.sent_date or "")[:10],
        (case.last_reply_date or case.received_at or "")[:16].replace("T", " "),
        "",                                   # Mutabakat Yap (butonlar)
        case.body_decision or _body_verdict(case),
        case.statement_decision or (statement.get("status") or "—"),
        f"{fark} {para}".strip() if fark not in ("", "0") else "—",
        case.final_status or "—",
        str(case.confidence_100 or 0),
        case.confidence_explanation or "—",
        (case.latest_reply_snippet or "")[:80],
        f"{len(ekler)} ek" if ekler else "—",
        "Evet" if case.invoice_received else "—",
        "Var" if case.prepared_reply_path else "—",
        "",                                   # Karşılaştır (buton)
        "",                                   # Geçmiş (buton)
    )


def _body_verdict(case) -> str:
    """Mail GÖVDESİNİN kararı — ekstre kararından AYRI tutulur.

    İkisi aynı şey değildir ve biri diğerinin yerine geçemez; çelişki
    tam olarak bu ayrımdan doğar.
    """
    kabul = (case.body_result or {}).get("balance_accepted")
    if case.reply_type == "ACCEPTED" or kabul is True:
        return "Kabul"
    if case.reply_type in ("REJECTED", "PARTIALLY_ACCEPTED",
                           "REQUESTED_CORRECTION") or kabul is False:
        return "Ret"
    return "Belirsiz"


def _case_detail_lines(case) -> list[str]:
    """Detay ekranının tam kanıt zinciri."""
    statement = case.statement_result or {}
    snapshot = case.snapshot_result or {}
    lines = [
        f"Firma: {case.company_code} {case.company_name}".strip(),
        f"Dönem: {case.period or '—'}",
        f"Sorumlu (R): {case.responsible or '—'}",
        "",
        "— BAĞLANDIĞI GÖNDERİM —",
        f"Gönderim ID: {case.send_id or '—'}",
        f"Snapshot ID: {case.snapshot_id or '—'}",
        f"Eşleştirme: {case.match_method} "
        f"(güven {case.match_confidence:.0%})",
        f"Referans türü: {snapshot.get('reference', '—')}",
        f"Gönderilen satır: {snapshot.get('sent_record_count', '—')}",
        f"Yön dağılımı: {snapshot.get('sent_directions') or '—'}",
        f"FBL1H hash: {snapshot.get('fbl1h_sha256') or '—'}",
        f"FBL5H hash: {snapshot.get('fbl5h_sha256') or '—'}",
        "",
        "— GELEN CEVAP —",
        f"Gönderen: {case.sender}",
        f"Konu: {case.subject}",
        f"Gelen tarih: {case.received_at or '—'}",
        f"Message-ID: {case.message_id or '—'}",
        f"Ek dosya: {snapshot.get('incoming_filename') or statement.get('source_filename') or '—'}",
        "",
        "— BODY (mail semantiği) —",
        f"Cevap türü: {case.reply_type}",
        f"Bakiye kabul: {(case.body_result or {}).get('balance_accepted')}",
        f"AI durumu: {case.ai_status or '—'}",
    ]
    for conflict in (case.body_result or {}).get("conflicts") or []:
        lines.append(f"  ÇELİŞKİ {conflict.get('field')}: "
                     f"python={conflict.get('python')} / ai={conflict.get('ai')}")

    lines += [
        "",
        "— EKSTRE (deterministik motor) —",
        f"Durum: {statement.get('status', '—')}",
        f"Okunan satır: {statement.get('rows_loaded', '—')}",
        f"Eşleşen: {statement.get('matched', '—')} · "
        f"Tutar farkı: {statement.get('amount_diff', '—')} · "
        f"Bire-çok: {statement.get('cross_matched', '—')}",
        f"Yalnız firmada: {statement.get('only_firma', '—')} "
        f"(toplam {statement.get('only_firma_total', '—')})",
        f"Yalnız gönderilende: {statement.get('only_tofas', '—')} "
        f"(toplam {statement.get('only_tofas_total', '—')})",
        f"Toplam fark: {statement.get('difference', '—')} "
        f"{statement.get('currency', '')}".rstrip(),
        "",
        f"— NİHAİ DURUM: {case.final_status} —",
        f"Teknik sonuç: {case.outcome}",
        f"İnsan incelemesi: {'GEREKLİ' if case.needs_human_review else 'hayır'}",
    ]
    if case.reasons:
        lines.append("")
        lines.append("Gerekçeler:")
        lines.extend(f"  • {r}" for r in case.reasons)
    return lines


def _prepared_mail_dir():
    """Taslak klasörü: kullanıcının seçtiği çıktı klasörü, yoksa profil."""
    from pathlib import Path

    try:
        from app.services.output_location import saved_output_folder
        from app.services.settings import Settings

        secili = saved_output_folder(Settings())
        if secili:
            return Path(secili) / "fark_mail_taslaklari"
    except Exception:  # noqa: BLE001 - ayar okunamazsa eski yer kullanılır
        pass
    from app.utils.paths import app_data_dir

    return app_data_dir() / "prepared_mails"


def _save_prepared_mail(mail) -> str:
    """Hazırlanan cevabı diske yaz ve yolunu döndür (yazılamazsa boş)."""
    try:
        base = _prepared_mail_dir()
        base.mkdir(parents=True, exist_ok=True)
        ad = f"{mail.company_code or 'firma'}_{mail.case_id[:12] or 'case'}.txt"
        hedef = base / ad
        govde = f"Konu: {mail.subject}" + chr(10) * 2 + mail.body
        hedef.write_text(govde, encoding="utf-8")
        return str(hedef)
    except OSError as exc:
        from loguru import logger

        logger.warning(f"[fark-maili] taslak yazılamadı: {exc}")
        return ""


def _blocked_summary(engelli) -> str:
    """Gönderilemeyen mailleri GEREKÇEYE göre grupla (sessiz atlama yok)."""
    if not engelli:
        return ""
    sayac: dict[str, int] = {}
    for mail in engelli:
        sebep = getattr(mail, "blocked_reason", "") or "belirtilmemiş"
        sayac[sebep] = sayac.get(sebep, 0) + 1
    satirlar = [f"  • {adet} firma — {sebep}"
                for sebep, adet in sorted(sayac.items(),
                                          key=lambda kv: -kv[1])[:6]]
    return "Gönderilmeyecekler:\n" + "\n".join(satirlar)


class _StoredComparison:
    """Kayıtlı case'ten fark maili üretmek için ince sarmalayıcı.

    Karşılaştırma sonucu case'e JSON olarak yazılmıştır; motor nesnesi
    saklanmaz. Fark tablosu bu yüzden satır satır DEĞİL, toplam fark
    üzerinden yazılır — uydurma satır üretilmez.
    """

    def __init__(self, case) -> None:
        self._case = case
        self.statement = None

    @property
    def difference_total(self):
        from decimal import Decimal

        try:
            return Decimal(str(self._case.financial_difference or "0"))
        except Exception:  # noqa: BLE001
            return Decimal("0")


class IncomingPage(QWidget):
    """Gelen kutusunu tarar, cevapları çözümler ve tabloda gösterir."""

    def __init__(self, session=None, outgoing_smtp_provider=None) -> None:
        super().__init__()
        # () -> str; Settings.outgoing_mailbox_smtp'i gönderim anında okur.
        self._outgoing_smtp_provider = outgoing_smtp_provider
        if session is None:
            try:
                from app.services.session_state import SessionState

                session = SessionState()
            except Exception:  # noqa: BLE001 - oturum hatası sayfayı açmayı engellemez
                session = None
        self._session = session
        # Gelen cevapların KALICI iş kayıtları (FAZ 6). Bellekteki
        # ``_results`` yalnızca son taramanın görüntüsüdür.
        try:
            from app.services.incoming_cases import IncomingCaseStore

            self._cases = IncomingCaseStore()
        except Exception:  # noqa: BLE001
            self._cases = None
        try:
            from app.services.send_snapshot import SnapshotStore

            self._snapshots = SnapshotStore()
        except Exception:  # noqa: BLE001
            self._snapshots = None
        # Teslim edilemeyen adresler: kullanıcı yeni adres girerken bu defter
        # sorgulanır — başka bir vakada zaten patlamış bir adres kabul edilmez.
        try:
            from app.services.address_registry import AddressRegistry

            self._address_registry = AddressRegistry()
        except Exception:  # noqa: BLE001
            self._address_registry = None
        # Rol haritası ilk ihtiyaçta okunur (bkz. _settings_store).
        self._settings = None
        self._threads: list = []
        self._worker = None
        #: işçi kimliği -> WorkerBinding. Eskimiş işçinin sinyalleri bu
        #: kayıttan "retire" edilerek kesilir; bağlantı KOPARILMAZ (silinmiş
        #: nesne üzerinde disconnect süreci çökertiyordu).
        self._bindings: dict = {}
        #: sinyal dağıtımı sırasında kaynağı bildiren alan (bkz. WorkerBinding)
        self._signal_source = None
        self._results: list[ReconciliationResponse] = []
        # Dönüş tespiti sonucu ve karşılaştırmada kullanılacak TOFAŞ kayıtları.
        self._scan_result = None
        self._tofas_records: list = []
        self._tofas_path: str = ""
        self._tofas_mode: str = "yabanci"
        self._active_scan_worker = None
        self._build_ui()
        self._restore_session()

    # -- arayüz ------------------------------------------------------------

    def _toolbar_rows(self) -> list:
        """Araç çubuğunun satırları (küçük ekran testleri buna bakar).

        Araç çubuğu tek satıra hapsedilmemeli; bu metot sözleşmeyi
        ölçülebilir kılar.
        """
        return list(getattr(self, "_toolbar_row_layouts", []))

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)

        # ARAÇ ÇUBUĞU BİRDEN FAZLA SATIRA DAĞITILIR.
        #
        # 15 denetim tek bir QHBoxLayout'ta tutulduğunda satırın zorunlu
        # genişliği ~1482 px, sayfanın minimumu ~1504 px, ana pencerenin
        # minimumu ~1873 px oluyordu. Bu değer 1920 px ekrana sığdığı için
        # birinci turun testleri yeşil kalıyor, ama saha makinelerinin
        # çoğunluğu olan 1366x768'de pencere ekrandan geniş kalıyor ve
        # sağdaki düğmeler ("Fark Maili Gönder", "Tüm Ekstreleri
        # Karşılaştır") ERİŞİLEMEZ oluyordu.
        #
        # Denetimler anlamlı gruplara bölünür: tarama ayarları, vaka
        # aksiyonları, toplu gönderim. Her satırın zorunlu genişliği tek
        # başına küçük olduğundan pencere 1366 px'in (ve 1024 px'in) altına
        # inebilir. Düğmelerin hiçbiri kaldırılmaz, davranış değişmez.
        self._toolbar_row_layouts: list = []

        top = QHBoxLayout()
        self._toolbar_row_layouts.append(top)
        top.addWidget(QLabel("Son"))
        self.days_spin = QSpinBox()
        self.days_spin.setRange(1, 365)
        self.days_spin.setValue(7)
        self.days_spin.setSuffix(" gün")
        top.addWidget(self.days_spin)

        top.addWidget(QLabel("En fazla"))
        self.limit_spin = QSpinBox()
        self.limit_spin.setRange(1, 2000)
        self.limit_spin.setValue(50)
        self.limit_spin.setSuffix(" mail")
        top.addWidget(self.limit_spin)

        self.chk_unread = QCheckBox("Yalnızca okunmamışlar")
        top.addWidget(self.chk_unread)

        self.btn_scan = QPushButton("Gelen Kutusunu Tara")
        self.btn_scan.clicked.connect(self._scan)
        top.addWidget(self.btn_scan)

        # Kapsamlı akış: yalnızca BİZİM gönderdiğimiz mutabakat maillerinin
        # zinciri taranır; teslim hatası ayrıştırılır, ekler mevcut mutabakat
        # motoruna sokulur. Tüm iş arka plan thread'inde çalışır.
        self.btn_cancel = QPushButton("İptal")
        self.btn_cancel.setEnabled(False)
        self.btn_cancel.clicked.connect(self._cancel_current)
        top.addWidget(self.btn_cancel)

        # §7 — görünen tüm satırları sırayla karşılaştırır. UI kilitlenmez,
        # bir satırın hatası partiyi durdurmaz.
        # §4 — VAKA BAZLI AKSİYON MERKEZİ. Temel akış budur; toplu
        # düğmeler korunur ama tek vaka için burası kullanılır.
        top.addStretch(1)
        root.addLayout(top)

        # --- 2. satır: VAKA AKSİYONLARI ---------------------------------
        actions_row = QHBoxLayout()
        self._toolbar_row_layouts.append(actions_row)

        self.btn_action = QPushButton("Aksiyon Al")
        self.btn_action.setToolTip(
            "Seçili vakanın durumunu analiz eder, uygun aksiyonu önerir ve "
            "düzenlenebilir mail hazırlar. Varsayılan davranış TASLAKTIR.")
        self.btn_action.clicked.connect(self._take_action_on_selected)
        actions_row.addWidget(self.btn_action)

        # §2/§3 — TASLAK ve BELİRSİZ gönderimleri Outlook'a sorarak çözer.
        # Bu düğme olmadan tek bir ağ kesintisi vakayı kalıcı kilitliyor,
        # elle gönderilen taslak da hiçbir zaman zinciri ilerletmiyordu.
        self.btn_verify = QPushButton("Outlook'tan Doğrula")
        self.btn_verify.setToolTip(
            "Açılan taslaklar gerçekten gönderilmiş mi ve sonucu belirsiz "
            "kalan gönderimler Gönderilmiş Öğeler'de var mı — Outlook'a "
            "sorar. Mail GÖNDERMEZ.")
        self.btn_verify.clicked.connect(self._verify_with_outlook)
        actions_row.addWidget(self.btn_verify)

        # Uzun başlıklı dönüş taraması aynı ilk satırda tutulduğunda 1366 px
        # ekranı aşıyordu. Vaka aksiyonlarıyla birlikte ikinci satırda kalır;
        # böylece tarama ayarları ve tüm düğmeler erişilebilir olur.
        self.btn_replies = QPushButton("Gelen Maillerin Dönüşlerini Tespit Et")
        self.btn_replies.setToolTip(
            "Gönderilen mutabakat maillerinin cevaplarını bulur, teslim "
            "edilemeyenleri ayırır ve ekteki ekstreyi mutabakat motoruyla "
            "karşılaştırır.")
        self.btn_replies.clicked.connect(self._scan_replies)
        actions_row.addWidget(self.btn_replies)

        actions_row.addStretch(1)
        root.addLayout(actions_row)

        # --- 3. satır: TOPLU GÖNDERİM / KARŞILAŞTIRMA -------------------
        bulk_row = QHBoxLayout()
        self._toolbar_row_layouts.append(bulk_row)

        self.btn_reminder = QPushButton("Hatırlatma Gönder")
        self.btn_reminder.setToolTip(
            "Açık işi olan firmalara, EN SON gönderdiğimiz mailin üzerinden "
            "Reply-All ile hatırlatma gönderir; ekler yeniden iliştirilir.")
        self.btn_reminder.clicked.connect(self._send_reminders)
        bulk_row.addWidget(self.btn_reminder)

        self.btn_difference = QPushButton("Fark Maili Gönder")
        self.btn_difference.setToolTip(
            "Fark bulunan satırlar için, firmadan eksik belgeleri isteyen "
            "cevabı hazırlar ve Reply-All ile gönderir.")
        self.btn_difference.clicked.connect(self._send_difference_mails)
        bulk_row.addWidget(self.btn_difference)

        self.btn_compare_all = QPushButton("Tüm Ekstreleri Karşılaştır")
        self.btn_compare_all.setToolTip(
            "Görünen tüm satırları güncel FBL datasıyla karşılaştırır. "
            "Hatalı satır işaretlenir, diğerlerine devam edilir.")
        self.btn_compare_all.clicked.connect(self._compare_all)
        bulk_row.addWidget(self.btn_compare_all)

        bulk_row.addStretch(1)
        self.lbl_ai = _ShrinkingStatusLabel("")
        # DURUM ETİKETİ PENCERENİN EN KÜÇÜK GENİŞLİĞİNİ BELİRLEMEMELİ.
        #
        # Etiketin metni uzun ("Direct Line: secret girilmemiş — AI
        # fallback kapalı…"). Varsayılan QLabel metnini kırpmaz ve TAM
        # genişliğini zorunlu en-küçük boyut olarak dayatır. Bu etiket 15
        # denetimli tek satırlık araç çubuğunun içinde olduğu için sayfanın
        # minimumu ~2040 px'e, ana pencerenin minimumu ~2410 px'e çıkıyordu:
        # pencere 1920x1080 bir ekrana SIĞMIYOR, sağdaki butonlar ekran
        # dışında kalıyordu. ``_clamp_window_size`` doğru değeri hesaplasa
        # bile ``resize()`` zorunlu minimumun altına inemediği için kırpma
        # sürüyordu.
        #
        # ``Ignored`` yatay politika + word wrap: etiket yerleşimden ARTAN
        # alanı kullanır, kendi metnini dayatmaz. Bilgi kaybı yoktur;
        # tam metin ipucu olarak da durur.
        self.lbl_ai.setWordWrap(True)
        self.lbl_ai.setMinimumWidth(0)
        self.lbl_ai.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        root.addLayout(bulk_row)

        # AI erişim durumunu eylem düğmeleriyle aynı satıra koymak, uzun
        # hata metninde satırın minimumunu büyütüyordu. Kendi satırında
        # daralabilir/kaydırılabilir kaldığı için bilgi görünür, araç çubuğu
        # ise küçük ekranda taşmaz.
        root.addWidget(self.lbl_ai)

        # Ekteki ekstrenin NE ile karşılaştırılacağı her zaman görünür olsun;
        # kaynak yoksa kullanıcı bunu tarama sonunda değil, ÖNCE bilmelidir.
        self.lbl_tofas = QLabel("")
        self.lbl_tofas.setWordWrap(True)
        root.addWidget(self.lbl_tofas)

        prog = QHBoxLayout()
        self.progress = QProgressBar()
        self.progress.setValue(0)
        prog.addWidget(self.progress, 1)
        self.lbl_status = QLabel("Hazır")
        prog.addWidget(self.lbl_status, 2)
        root.addLayout(prog)

        # §4 — Excel benzeri kolon filtresi. Büyük veri setinde tablo yeniden
        # çizilmez, yalnızca satır gizlenir (hızlı ve donmaz).
        filt = QHBoxLayout()
        filt.addWidget(QLabel("Filtre:"))
        self.case_filter = QLineEdit()
        self.case_filter.setPlaceholderText(
            "Firma / kod / durum / konu / karar ara…")
        self.case_filter.textChanged.connect(self._apply_case_filter)
        filt.addWidget(self.case_filter, 2)

        filt.addWidget(QLabel("Kolon:"))
        self.filter_column = QComboBox()
        self.filter_column.addItem("Tüm kolonlar", -1)
        for index, name in enumerate(_CASE_COLUMNS):
            if index not in (_COL_MANUAL, _COL_COMPARE, _COL_HISTORY):
                self.filter_column.addItem(name, index)
        self.filter_column.currentIndexChanged.connect(
            lambda _i: self._apply_case_filter(self.case_filter.text()))
        filt.addWidget(self.filter_column, 1)

        self.chk_only_review = QCheckBox("Yalnızca inceleme gerekenler")
        self.chk_only_review.stateChanged.connect(
            lambda _s: self._apply_case_filter(self.case_filter.text()))
        filt.addWidget(self.chk_only_review)

        # Sayfalama: tablo her zaman sabit sayıda satır çizer.
        self.btn_prev = QPushButton("‹")
        self.btn_prev.setFixedWidth(30)
        self.btn_prev.clicked.connect(lambda: self._go_page(-1))
        filt.addWidget(self.btn_prev)
        self.lbl_page = QLabel("—")
        filt.addWidget(self.lbl_page)
        self.btn_next = QPushButton("›")
        self.btn_next.setFixedWidth(30)
        self.btn_next.clicked.connect(lambda: self._go_page(1))
        filt.addWidget(self.btn_next)
        root.addLayout(filt)

        # İki görünüm: kalıcı mutabakat cevapları (asıl iş görünümü) ve
        # ham mail analizi (mevcut ekran, olduğu gibi korunur).
        self.tabs = QTabWidget()

        self.case_table = QTableWidget(0, len(_CASE_COLUMNS))
        self.case_table.setHorizontalHeaderLabels(list(_CASE_COLUMNS))
        self.case_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.case_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.case_table.cellDoubleClicked.connect(self._show_case_details)
        case_header = self.case_table.horizontalHeader()
        case_header.setSectionResizeMode(QHeaderView.Interactive)
        case_header.setStretchLastSection(True)
        self.tabs.addTab(self.case_table, "Mutabakat Cevapları")

        self.table = QTableWidget(0, len(_COLUMNS))
        self.table.setHorizontalHeaderLabels(list(_COLUMNS))
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.cellDoubleClicked.connect(self._show_details)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setStretchLastSection(True)
        self.tabs.addTab(self.table, "Ham Mail Analizi")

        root.addWidget(self.tabs, 1)

        self.lbl_summary = QLabel(
            "Gelen kutusunu tarayın: her mail önce Python ile çözümlenir, "
            "yalnızca belirsiz kalanlar Copilot ajanına sorulur.")
        self.lbl_summary.setWordWrap(True)
        root.addWidget(self.lbl_summary)

        self._refresh_ai_status()
        self._refresh_tofas_label()

    # -- kalıcı oturum (FAZ 7) ---------------------------------------------

    def _restore_session(self) -> None:
        """Filtreleri ve son tarama sonuçlarını geri yükle.

        Sonuçlar RAM'den değil KALICI iş kayıtlarından okunur; böylece
        uygulama kapanıp açıldığında ekran boş kalmaz.
        """
        if self._session is not None:
            from app.services.session_state import SECTION_INCOMING

            try:
                state = self._session.section(SECTION_INCOMING)
                self.days_spin.setValue(int(state.get("days", 7) or 7))
                self.limit_spin.setValue(int(state.get("limit", 50) or 50))
                self.chk_unread.setChecked(bool(state.get("unread_only", False)))
                self._last_scan_at = str(state.get("last_scan_at", "") or "")
            except Exception as exc:  # noqa: BLE001 - oturum asla çökertmez
                from loguru import logger

                logger.warning(f"[oturum] gelen cevaplar geri yüklenemedi: {exc}")
        self._load_cases()

    def _save_session(self) -> None:
        if self._session is None:
            return
        from app.services.session_state import SECTION_INCOMING

        try:
            self._session.update(SECTION_INCOMING, {
                "days": self.days_spin.value(),
                "limit": self.limit_spin.value(),
                "unread_only": self.chk_unread.isChecked(),
                "last_scan_at": getattr(self, "_last_scan_at", ""),
            })
        except Exception as exc:  # noqa: BLE001
            from loguru import logger

            logger.warning(f"[oturum] gelen cevaplar kaydedilemedi: {exc}")

    def _load_cases(self) -> None:
        """Kalıcı iş kayıtlarını tabloya yükle (tarama yapmadan).

        §3.8/§4 — GÖNDERİLMİŞ her mutabakat, cevap gelmese bile burada
        görünür. Gönderim snapshot'larından yön başına case üretilir; cevabı
        gelmiş kayıtlar EZİLMEZ.
        """
        if self._cases is None:
            return
        self._seed_cases_from_snapshots()
        try:
            self._case_rows = self._cases.all()
            # Önceki süreç gönderim sırasında kapandıysa kalıcı IN_PROGRESS
            # kaydı güvenle SEND_UNKNOWN'a yükseltilir. OPEN'a çevirmek
            # mükerrer gönderime izin verirdi.
            from app.services.case_actions import recover_stale_actions

            for case in self._case_rows:
                if recover_stale_actions(case):
                    self._cases.upsert(case)
        except Exception as exc:  # noqa: BLE001
            from loguru import logger

            logger.warning(f"[oturum] iş kayıtları okunamadı: {exc}")
            self._case_rows = []
        self._fill_case_table()

    def reset_ui_state(self) -> None:
        """Ekranın GEÇİCİ durumunu temizle (FAZ 8).

        Filtreler ve son taramanın ham görüntüsü gider. KALICI iş kayıtları
        (gelen cevapların finansal sonuçları) SİLİNMEZ ve tabloda durmaya
        devam eder — bunlar denetim kaydıdır.
        """
        self._results = []
        self._scan_result = None
        self._last_scan_at = ""
        self.days_spin.setValue(7)
        self.limit_spin.setValue(50)
        self.chk_unread.setChecked(False)
        self.table.setRowCount(0)
        self._busy("Oturum sıfırlandı.", 0)
        self.lbl_summary.setText(
            "Oturum sıfırlandı. Kayıtlı mutabakat cevapları korundu.")
        self._load_cases()

    def _refresh_ai_status(self) -> None:
        try:
            from app.incoming.ai_config import status_line

            self.lbl_ai.setText(status_line())
        except Exception as exc:  # noqa: BLE001 - durum etiketi kritik değil
            self.lbl_ai.setText(f"Direct Line durumu okunamadı: {exc}")

    # -- tarama ------------------------------------------------------------

    def _scan(self) -> None:
        from app.incoming.worker import IncomingMailPipelineWorker

        if self._reject_if_busy("Gelen Kutusunu Tara"):
            return
        self._refresh_ai_status()
        since = datetime.now() - timedelta(days=self.days_spin.value())
        settings = self._settings_store()
        worker = IncomingMailPipelineWorker(
            limit=self.limit_spin.value(),
            since=since,
            unread_only=self.chk_unread.isChecked(),
            account_smtp=(settings.incoming_mailbox_smtp if settings else ""),
        )
        self.btn_scan.setEnabled(False)
        self._start_work(worker, self._on_finished)

    def _on_finished(self, results) -> None:
        self._results = list(results or [])
        self._fill_table()
        self._work_done()
        self.btn_scan.setEnabled(True)

        from app.incoming.pipeline import summarize

        summary = summarize(self._results)
        self.lbl_summary.setText(
            f"{summary['toplam']} mail işlendi — "
            f"{summary['insan_incelemesi']} insan incelemesi, "
            f"{summary['ai_cagrildi']} mailde AI'ya soruldu, "
            f"{summary['ai_catisma']} çelişki, "
            f"{summary['ai_ulasilamadi']} AI ulaşılamadı, "
            f"{summary['onbellek']} daha önce işlenmişti."
        )

    # -- dönüş tespiti (kapsamlı akış) -------------------------------------

    def _scan_replies(self) -> None:
        """Gönderilen mutabakat maillerinin dönüşlerini tespit et.

        TOFAŞ kayıtları bu ekranda yüklü değilse ekstre karşılaştırması
        yapılmaz; sonuçta bu durum AÇIKÇA yazılır (sessizce "fark var"
        denmez).
        """
        from app.incoming.worker import ReplyScanWorker

        if self._reject_if_busy("Dönüş Taraması"):
            return
        self._refresh_ai_status()
        since = datetime.now() - timedelta(days=self.days_spin.value())
        settings = self._settings_store()
        worker = ReplyScanWorker(
            limit=max(self.limit_spin.value(), 1),
            since=since,
            tofas_records=self._tofas_records or None,
            tofas_path=self._tofas_path or None,
            mode=self._tofas_mode,
            # Finansal karşılaştırmanın referansı: o firmaya GÖNDERİLEN paket.
            snapshot_store=self._snapshots,
            case_store=self._cases,
            account_smtp=(settings.incoming_mailbox_smtp if settings else ""),
        )
        self._save_session()
        self._active_scan_worker = worker
        self.btn_scan.setEnabled(False)
        self.btn_replies.setEnabled(False)
        self._start_work(worker, self._on_replies_finished)

    def set_tofas_source(self, path: str, mode: str = "yabanci") -> None:
        """Ekstre karşılaştırmasında kullanılacak TOFAŞ ekstresinin YOLU.

        Kayıtlar burada DEĞİL, tarama sırasında arka plan thread'inde okunur:
        100 bin satırlık bir SAP dosyasını UI thread'inde açmak uygulamayı
        dondururdu. Ayrıca her taramada dosya yeniden okunur, böylece SAP
        dosyası güncellendiyse eski kayıtlarla karşılaştırma yapılmaz.
        """
        self._tofas_path = str(path or "")
        self._tofas_mode = mode or "yabanci"
        self._tofas_records = []          # yol verildiyse kayıtlar tazelenir
        self._refresh_tofas_label()

    def set_tofas_records(self, records) -> None:
        """Kayıtları doğrudan ver (test ve programatik kullanım için).

        Verilmezse dönüş taraması yine çalışır; yalnızca ekteki ekstre
        karşılaştırılamaz ve ilgili kayıtlar insan incelemesine düşer.
        """
        self._tofas_records = list(records or [])
        self._refresh_tofas_label()

    def _refresh_tofas_label(self) -> None:
        """Kullanıcı, karşılaştırmanın hangi dosyayla yapılacağını GÖRSÜN."""
        if self._tofas_records:
            text = f"Karşılaştırma kaynağı: {len(self._tofas_records)} TOFAŞ kaydı"
        elif self._tofas_path:
            from pathlib import Path as _P

            text = f"Karşılaştırma kaynağı: {_P(self._tofas_path).name}"
        else:
            text = ("Karşılaştırma kaynağı yok — Mutabakat sekmesinden TOFAŞ "
                    "ekstresi seçin (ekler karşılaştırılamaz).")
        self.lbl_tofas.setText(text)

    def _on_replies_finished(self, result) -> None:
        self._scan_result = result
        from datetime import datetime as _dt

        self._last_scan_at = _dt.now().isoformat(timespec="seconds")
        self._save_session()
        # Tablo KALICI kayıtlardan tazelenir; ekran kapanınca kaybolmaz.
        self._load_cases()
        self._work_done()
        self.btn_scan.setEnabled(True)
        self.btn_replies.setEnabled(True)

        if result is None:
            return
        summary = result.summary
        self.lbl_summary.setText(" | ".join(summary.as_lines()))

        lines = list(summary.as_lines())
        # Ekstre karşılaştırması yapılamadıysa nedeni EN ÜSTTE görünsün:
        # sessizce "fark yok" ya da "fark var" izlenimi verilmemeli.
        load_error = getattr(self._active_scan_worker, "tofas_load_error", "")
        if load_error:
            lines.insert(0, f"UYARI: {load_error}")
            lines.insert(1, "")
        flagged = result.attention_items()
        if flagged:
            lines.append("")
            lines.append("DİKKAT GEREKTİRENLER:")
            for item in flagged[:15]:
                başlık = item.company_code or item.mail.sender or "—"
                lines.append(f"• {başlık} — {item.status.value}")
                for reason in item.why()[:3]:
                    lines.append(f"    {reason}")
            if len(flagged) > 15:
                lines.append(f"… ve {len(flagged) - 15} kayıt daha.")
        if result.cancelled:
            lines.append("")
            lines.append("NOT: Tarama iptal edildi; kalan mailler işlenmedi.")

        QMessageBox.information(self, "Dönüş Tespiti", "\n".join(lines))

    def _on_error(self, message: str) -> None:
        """İşçi hatası: durumu bildir ve arayüzü TEKRAR KULLANILABİLİR yap.

        ``btn_compare_all``/``btn_reminder``/``btn_difference`` buraya
        SONRADAN eklendi: işi başlatan kod bunları kapatıyor, yalnızca
        BAŞARI işleyicisi geri açıyordu. İşçi hata verdiğinde kullanıcı
        aksiyonu kalıcı olarak erişilemez hâle geliyordu.
        """
        self._work_done()
        self.btn_scan.setEnabled(True)
        self.btn_replies.setEnabled(True)
        self.btn_compare_all.setEnabled(True)
        self.btn_reminder.setEnabled(True)
        self.btn_difference.setEnabled(True)
        self._busy("Hata.", 0)
        QMessageBox.critical(self, "Gelen Cevaplar", message)

    def _fill_table(self) -> None:
        self.table.setRowCount(len(self._results))
        for row, response in enumerate(self._results):
            values = (
                response.company_code or "—",
                response.company_name or "—",
                response.reply_type.value,
                _fmt_balances(response),
                response.direction.value,
                "Var" if response.letter_present else "Yok",
                _TRISTATE[response.letter_filled],
                _TRISTATE[response.letter_signed],
                _TRISTATE[response.letter_sealed],
                f"{response.confidence:.2f}",
                "GEREKLİ" if response.needs_human_review else "—",
                response.review_status.value,
                response.subject or "",
            )
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setData(Qt.UserRole, row)
                self.table.setItem(row, column, item)
        self.table.resizeColumnsToContents()

    # -- kalıcı iş kayıtları tablosu (FAZ 10) ------------------------------

    def _fill_case_table(self) -> None:
        """Yalnızca GEÇERLİ SAYFAYI çiz (büyük veri setinde donma yok)."""
        self._filtered = self._filter_cases()
        toplam = len(self._filtered)
        sayfa_sayisi = max(1, (toplam + PAGE_SIZE - 1) // PAGE_SIZE)
        self._page = max(0, min(getattr(self, "_page", 0), sayfa_sayisi - 1))
        bas = self._page * PAGE_SIZE
        dilim = self._filtered[bas:bas + PAGE_SIZE]

        self.case_table.setUpdatesEnabled(False)
        try:
            self.case_table.clearContents()
            self.case_table.setRowCount(len(dilim))
            for row, case in enumerate(dilim):
                renk = _STATUS_COLORS.get(case.final_status)
                for column, value in enumerate(_case_values(case)):
                    if column in (_COL_MANUAL, _COL_COMPARE, _COL_HISTORY):
                        continue
                    item = QTableWidgetItem(str(value))
                    item.setData(Qt.UserRole, row)
                    if renk:
                        item.setBackground(QColor(renk))
                    self.case_table.setItem(row, column, item)
                self.case_table.setCellWidget(row, _COL_MANUAL,
                                              self._manual_buttons(row))
                self.case_table.setCellWidget(
                    row, _COL_COMPARE,
                    self._row_button("Karşılaştır", self._compare_row, row))
                self.case_table.setCellWidget(
                    row, _COL_HISTORY,
                    self._row_button("Geçmiş", self._show_history, row))
        finally:
            self.case_table.setUpdatesEnabled(True)
        self.case_table.resizeColumnsToContents()

        self.lbl_page.setText(
            f"{bas + 1 if dilim else 0}-{bas + len(dilim)} / {toplam}"
            f"  (sayfa {self._page + 1}/{sayfa_sayisi})")
        self.btn_prev.setEnabled(self._page > 0)
        self.btn_next.setEnabled(self._page + 1 < sayfa_sayisi)

    def _go_page(self, delta: int) -> None:
        self._page = max(0, getattr(self, "_page", 0) + delta)
        self._fill_case_table()

    def _case_at(self, row: int):
        """Ekrandaki satır numarasından GERÇEK case'i bul (sayfa kayması)."""
        filtered = getattr(self, "_filtered", None)
        if filtered is None:
            filtered = getattr(self, "_case_rows", [])
        index = getattr(self, "_page", 0) * PAGE_SIZE + row
        if 0 <= index < len(filtered):
            return filtered[index]
        return None

    # -- satır widget'ları --------------------------------------------------

    def _row_button(self, label: str, slot, row: int) -> QWidget:
        """Tek butonluk hücre widget'ı (satır numarası kapatılarak bağlanır)."""
        button = QPushButton(label)
        button.setProperty("row", row)
        button.clicked.connect(lambda _checked=False, r=row: slot(r))
        return button

    def _manual_buttons(self, row: int) -> QWidget:
        """§9 — Mutabık / Red / Şartlı / Manuel butonları.

        Aynı butona ikinci kez basmak kararı GERİ ALIR (previous_status).
        """
        holder = QWidget()
        layout = QHBoxLayout(holder)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)
        for label, status, renk in (
            ("✓", STATUS_MUTABIK, "#2d5a2d"),
            ("✗", STATUS_RED, "#5a2d2d"),
            ("~", STATUS_SARTLI, "#5a5327"),
            ("?", STATUS_MANUEL, "#4a4a4a"),
        ):
            button = QPushButton(label)
            button.setFixedWidth(26)
            button.setToolTip(f"{status} (ikinci basış geri alır)")
            button.setStyleSheet(f"background:{renk};")
            button.clicked.connect(
                lambda _c=False, r=row, s=status: self._set_manual_status(r, s))
            layout.addWidget(button)
        return holder

    # -- filtre -------------------------------------------------------------

    def _filter_cases(self) -> list:
        """Filtreden geçen TÜM case'ler (sayfa değil — toplu işlem bunu alır)."""
        rows = getattr(self, "_case_rows", [])
        needle = ""
        column = -1
        only_review = False
        if hasattr(self, "case_filter"):
            needle = (self.case_filter.text() or "").strip().lower()
            column = self.filter_column.currentData()
            only_review = self.chk_only_review.isChecked()

        out = []
        for case in rows:
            if only_review and not case.needs_human_review:
                continue
            if needle:
                degerler = _case_values(case)
                if column is None or column < 0:
                    metin = " ".join(str(v) for v in degerler).lower()
                else:
                    metin = str(degerler[column]).lower() \
                        if column < len(degerler) else ""
                if needle not in metin:
                    continue
            out.append(case)
        return out

    def _apply_case_filter(self, text: str) -> None:
        """Filtre değişti: ilk sayfaya dön ve yeniden çiz."""
        if not hasattr(self, "case_table"):
            return
        self._page = 0
        self._fill_case_table()

    def visible_cases(self) -> list:
        """Filtreden geçen satırların case'leri.

        Toplu işlem GÖRÜNEN SAYFAYLA sınırlı değildir: kullanıcı "tüm
        ekstreleri karşılaştır" dediğinde filtrenin tamamı işlenir, yalnızca
        ekranda çizili 200 satır değil.
        """
        return list(getattr(self, "_filtered", None)
                    or getattr(self, "_case_rows", []))

    def _seed_cases_from_snapshots(self) -> None:
        """Gönderim kayıtlarından eksik case'leri üret (sessizce başarısız olmaz)."""
        store = getattr(self, "_snapshots", None)
        if store is None or self._cases is None:
            return
        try:
            created, _kept = seed_cases(self._cases, store.all())
            if created:
                from loguru import logger

                logger.info(f"[case] {created} gönderim takibe alındı")
        except Exception as exc:  # noqa: BLE001 - ekran açılmayı sürdürür
            from loguru import logger

            logger.warning(f"[case] gönderimler takibe alınamadı: {exc}")

    # -- karşılaştırma ------------------------------------------------------

    def _comparison_service(self):
        """Güncel FBL kaynaklarıyla karşılaştırma servisi.

        Dosya yolları oturumdan gelir: kullanıcı yeni FBL yüklemediği sürece
        SON yüklenen dosyalar kullanılır (§2).
        """
        from app.services.case_comparison import CaseComparisonService
        from app.services.current_fbl_reconciliation import (
            CurrentFblReconciliationService,
        )
        from app.services.incoming_attachments import IncomingAttachmentStore

        fbl1h = fbl5h = ""
        if self._session is not None:
            fbl1h = self._session.get("mailing", "fbl1h_path", "") or ""
            fbl5h = self._session.get("mailing", "fbl5h_path", "") or ""
        return CaseComparisonService(
            fbl_service=CurrentFblReconciliationService(fbl1h, fbl5h),
            case_store=self._cases,
            attachment_store=IncomingAttachmentStore(),
        )

    # -- §4: vaka bazlı aksiyon merkezi ------------------------------------

    def _take_action_on_selected(self) -> None:
        """Seçili satır için Aksiyon Al penceresini aç."""
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.information(
                self, "Aksiyon Al",
                "Önce tablodan bir vaka satırı seçin.")
            return
        self._take_action(row)

    def _take_action(self, row: int) -> None:
        """Vaka durumunu analiz et, aksiyon önerisiyle pencereyi aç.

        GÜVENLİ VARSAYILAN: pencere hiçbir şey göndermez; kullanıcı
        taslak açmayı ya da (ayrı onayla) göndermeyi seçer.
        """
        # Aksiyon penceresi mail GÖNDEREBİLİR: çalışan iş varken açılmaz.
        # Aksi hâlde aksiyon işçisi reddedilir ve vaka kilidi sızar.
        if self._reject_if_busy("Aksiyon Al"):
            return
        case = self._case_at(row)
        if case is None or self._cases is None:
            return

        from app.incoming.action_dialog import (
            RESULT_DRAFT,
            RESULT_RECOMPARE,
            RESULT_RESOLVE,
            RESULT_SEND,
            ActionDialog,
        )

        dialog = ActionDialog(case, self)
        if dialog.exec() != QDialog.Accepted:
            return
        sonuc = dialog.result_action

        if sonuc == RESULT_RECOMPARE:
            self._start_compare([case])
            return

        if sonuc == RESULT_RESOLVE:
            self._resolve_open_actions(case)
            return

        if sonuc not in (RESULT_DRAFT, RESULT_SEND):
            return

        self._send_action_mail(case, dialog.mail_payload(),
                               send=(sonuc == RESULT_SEND))

    def _resolve_open_actions(self, case) -> None:
        """Aksiyonları tamamlandı işaretle — HANGİLERİ olduğu SORULUR.

        Önceki sürüm vakadaki BÜTÜN açık aksiyonları tek tıkla
        kapatıyordu: kullanıcı yalnızca ekstre talebini kapatmak isterken
        eksik fatura talebi de sessizce kapanıyordu. Varsayılan, seçili
        (önerilen) aksiyondur; toplu kapatma AYRI onay ister.
        """
        from app.services.case_actions import (
            STATUS_RESOLVED,
            open_actions,
            suggest_action,
            upsert_action,
        )
        from app.services.incoming_cases import _now

        acik = open_actions(case)
        if not acik:
            QMessageBox.information(self, "Aksiyon",
                                    "Bu vakada açık aksiyon yok.")
            return

        hedefler = acik
        if len(acik) > 1:
            onerilen = suggest_action(case).action_type
            secili = [a for a in acik if a.action_type == onerilen] or [acik[0]]
            ad = secili[0].action_type
            cevap = QMessageBox.question(
                self, "Hangi aksiyonlar kapatılsın?",
                f"Bu vakada {len(acik)} açık aksiyon var.\n\n"
                f"EVET  → yalnızca '{ad}' kapatılır (önerilen)\n"
                f"HAYIR → {len(acik)} aksiyonun TAMAMI kapatılır\n\n"
                "Yanlışlıkla kapatılan aksiyon takip edilemez hâle gelir.",
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel,
                QMessageBox.Yes)
            if cevap == QMessageBox.Cancel:
                return
            hedefler = secili if cevap == QMessageBox.Yes else acik

        for aksiyon in hedefler:
            aksiyon.status = STATUS_RESOLVED
            aksiyon.resolved_at = _now()
            upsert_action(case, aksiyon)
        case.add_event(
            "ACTION_RESOLVED",
            f"{len(hedefler)} aksiyon tamamlandı olarak işaretlendi",
            detail=", ".join(a.action_type for a in hedefler))
        self._cases.upsert(case)
        self._load_cases()

    def _send_action_mail(self, case, payload: dict, *, send: bool) -> None:
        """Aksiyon mailini arka planda gönder ya da taslağını aç.

        KİLİT WORKER BİTENE KADAR TUTULUR.
            Önceki sürümde kilit ``finally`` içinde, worker daha
            BAŞLAMADAN bırakılıyordu; çift tıklama koruması sahteydi.
            Kilit artık ``_on_action_sent`` içinde — başarı, hata ve
            iptal yollarının HEPSİNDE — bırakılır.

        COM UI THREAD'İNDE ÇALIŞTIRILMAZ: iş ThreadReplyWorker'a verilir.
        """
        # ThreadReplyWorker YEREL import edilir (Qt/COM sınırı: modül
        # düzeyinde tutulmaz). Bu satır eksikti ve bu yol üretimde
        # NameError ile patlardı.
        from app.incoming.worker import ThreadReplyWorker
        from app.services.action_send import (
            build_request,
            case_lock,
            check_can_send,
            mail_context,
            new_attempt_id,
        )
        from app.services.case_actions import (
            STATUS_IN_PROGRESS,
            ActionItem,
            upsert_action,
        )

        tur = payload.get("action_type", "")

        # §2 — çözülmemiş SEND_UNKNOWN varken aynı aksiyon tekrar GİTMEZ.
        guard = check_can_send(case, tur)
        if not guard.allowed:
            QMessageBox.warning(self, "Gönderim engellendi", guard.reason)
            return

        # §2 — çift tıklama koruması. Kilit BURADA alınır, worker
        # tamamlanınca bırakılır.
        kilit = case_lock(case.case_id)
        if not kilit.acquire(blocking=False):
            QMessageBox.information(
                self, "Aksiyon",
                "Bu vaka için bir gönderim zaten sürüyor. "
                "İşlem bitene kadar yeni gönderim başlatılmaz.")
            return

        birakildi = False
        try:
            sahte_mail = type("_M", (), {
                "body": payload.get("body", ""),
                "attachments": payload.get("attachments", []),
            })()
            istek, hedef = build_request(case, sahte_mail, tur)
            if istek is None:
                QMessageBox.warning(self, "Zincir bulunamadı",
                                    hedef.blocked_reason)
                return
            # §4 — ana alıcı Outlook zincirinden gelir; yalnızca EK alıcı
            # eklenir, mevcut alıcı sessizce DEĞİŞTİRİLMEZ.
            ek_alicilar = [a.strip() for a in
                           str(payload.get("extra_recipients", "")).split(";")
                           if a.strip()]
            if ek_alicilar:
                istek.extra_recipients = ek_alicilar

            attempt = new_attempt_id()
            aksiyon = ActionItem(case_id=case.case_id, action_type=tur,
                                 attempt_id=attempt,
                                 status=STATUS_IN_PROGRESS,
                                 related_inbound_message_id=case.message_id)
            upsert_action(case, aksiyon)
            self._cases.upsert(case)

            ctx = mail_context(
                subject=str(getattr(case, "subject", "") or ""),
                body=payload.get("body", ""),
                recipients=payload.get("recipients", ""),
                cc="; ".join(ek_alicilar),
                attachments=payload.get("attachments", []),
                target_entry_id=hedef.entry_id,
                target_message_id=hedef.message_id)

            # PENDING SÖZLÜK: tek alan iki vakayı ezerdi.
            if not hasattr(self, "_pending_actions"):
                self._pending_actions = {}
            self._pending_actions[case.case_id] = {
                "action": aksiyon, "type": tur, "lock": kilit,
                "attempt": attempt, "context": ctx,
            }
            birakildi = True          # kilit artık worker'a devredildi

            self._busy("Aksiyon maili işleniyor…", 5)
            self._start_work(
                ThreadReplyWorker([(case.case_id, istek)], send=send,
                                  outgoing_smtp=self._outgoing_smtp()),
                self._on_action_sent, self._on_action_error)
        finally:
            # Worker BAŞLAMADIYSA kilit hemen bırakılır; başladıysa
            # bırakma sorumluluğu _on_action_sent'e geçmiştir.
            if not birakildi:
                kilit.release()

    def _verify_targets(self) -> list:
        """Doğrulanması gereken taslak ve belirsiz gönderimler.

        Yalnızca ELDE KİMLİK OLAN kayıtlar taranır; kimliksiz kayıt için
        Outlook'a sorulacak bir şey yoktur.
        """
        hedefler = []
        for case in (self._case_rows or []):
            taslak = str(getattr(case, "last_draft_entry_id", "") or "")
            if taslak:
                hedefler.append((case.case_id, "DRAFT", taslak, ""))
                continue
            if str(getattr(case, "pending_unknown_action", "") or ""):
                hedefler.append((
                    case.case_id, "UNKNOWN",
                    str(getattr(case, "last_outbound_entry_id", "") or ""),
                    str(getattr(case, "last_outbound_message_id", "") or "")))
        return hedefler

    def _verify_with_outlook(self) -> None:
        """Taslak/belirsiz kayıtları arka planda doğrula (COM UI'da ÇALIŞMAZ)."""
        from app.incoming.worker import ThreadVerifyWorker

        if self._reject_if_busy("Doğrulama"):
            return
        if self._cases is None:
            return
        hedefler = self._verify_targets()
        if not hedefler:
            QMessageBox.information(
                self, "Doğrulama",
                "Doğrulanacak taslak ya da sonucu belirsiz gönderim yok.")
            return
        self._busy("Outlook doğrulanıyor…", 5)
        self._start_work(ThreadVerifyWorker(hedefler), self._on_verified)

    def _on_verified(self, results) -> None:
        """Doğrulama sonucunu uygula. MAİL GÖNDERİLMEZ, yalnız durum düzelir."""
        from app.services.action_send import (
            confirm_draft_sent,
            resolve_send_unknown,
        )

        self._work_done()
        if self._cases is None:
            return
        sayim = {"SENT": 0, "NOT_SENT": 0, "UNKNOWN": 0}
        for case_id, kind, verify in results or []:
            durum = str(getattr(verify, "status", "UNKNOWN") or "UNKNOWN")
            sayim[durum] = sayim.get(durum, 0) + 1
            case = self._cases.get(case_id)
            if case is None:
                continue
            degisti = False
            if kind == "DRAFT" and durum == "SENT":
                degisti = confirm_draft_sent(
                    case,
                    entry_id=str(getattr(case, "last_draft_entry_id", "") or ""),
                    sent_entry_id=str(getattr(verify, "entry_id", "") or ""),
                    message_id=str(getattr(verify, "message_id", "") or ""),
                    conversation_id=str(
                        getattr(verify, "conversation_id", "") or ""))
            elif kind == "UNKNOWN":
                degisti = bool(resolve_send_unknown(case, verify))
            if degisti:
                self._cases.upsert(case)
        self._load_cases()
        QMessageBox.information(
            self, "Doğrulama sonucu",
            f"Gönderildiği doğrulanan: {sayim.get('SENT', 0)}\n"
            f"Gönderilmediği doğrulanan: {sayim.get('NOT_SENT', 0)}\n"
            f"Belirsiz kalan: {sayim.get('UNKNOWN', 0)}\n\n"
            "Belirsiz kalanlar için otomatik gönderim YAPILMAZ; "
            "Gönderilmiş Öğeler elle kontrol edilmelidir.")

    def _release_pending(self, case_id: str) -> dict:
        """Bekleyen işi kapat ve kilidini BIRAK (her yoldan çağrılabilir)."""
        bekleyenler = getattr(self, "_pending_actions", None) or {}
        kayit = bekleyenler.pop(case_id, None)
        if kayit:
            try:
                kayit["lock"].release()
            except RuntimeError:
                pass          # zaten bırakılmış
        return kayit or {}

    def _release_all_pending(self) -> None:
        """Kapanış/iptal: tüm bekleyen kilitleri bırak (sonsuz kilit olmasın)."""
        for case_id in list(getattr(self, "_pending_actions", None) or {}):
            self._release_pending(case_id)

    def _on_action_sent(self, results) -> None:
        """Aksiyon gönderim sonucunu işle (§2 durum ayrımı).

        Sonuçlar case_id ile eşleştirilir; iki vaka paralel işlenirse
        birbirinin kaydını EZMEZ.
        """
        from app.services.action_send import apply_result

        self._work_done()
        if self._cases is None:
            self._release_all_pending()
            return

        mesajlar = {
            "SENT": "Mail gönderildi ve zincir güncellendi.",
            "DRAFTED": ("Taslak Outlook'ta açıldı. GÖNDERİLMEDİ — zincir "
                        "ilerlemedi; aksiyon açık kaldı."),
            "SEND_UNKNOWN": ("Gönderim sonucu BELİRSİZ. Mail GÖNDERİLMİŞ "
                             "OLABİLİR; Gönderilmiş Öğeler kontrol "
                             "edilmeli. Otomatik tekrar gönderim "
                             "YAPILMADI."),
        }
        son_durum = ""
        islenen = set()
        for case_id, result in results or []:
            kayit = self._release_pending(case_id)
            islenen.add(case_id)
            if not kayit:
                continue
            case = self._cases.get(case_id)
            if case is None:
                continue
            son_durum = apply_result(case, kayit["action"], result,
                                     kayit["type"], context=kayit.get("context"))
            self._cases.upsert(case)

        # İPTAL / EKSİK SONUÇ YOLU.
        #
        # ThreadReplyWorker iptal edilirse ``results`` yalnızca İŞLENEN
        # vakaları taşır. Kalanların kilidi burada bırakılmazsa o vakalar
        # oturum boyunca kalıcı olarak kilitli kalır ve bir daha gönderim
        # yapılamaz. Bu vakalarda ``Send()`` HİÇ çağrılmadığı için durum
        # CANCELLED'dır — SEND_UNKNOWN değil.
        worker = self._signal_worker()
        for case_id in tuple(getattr(worker, "case_ids", ()) or ()):
            if case_id in islenen:
                continue
            kayit = self._release_pending(case_id)
            if not kayit:
                continue
            case = self._cases.get(case_id)
            if case is None:
                continue
            aksiyon = kayit.get("action")
            if aksiyon is not None:
                from app.services.case_actions import (
                    STATUS_CANCELLED,
                    upsert_action,
                )

                aksiyon.status = STATUS_CANCELLED
                aksiyon.user_note = (
                    (aksiyon.user_note + " | ") if aksiyon.user_note else ""
                ) + "İptal edildi; gönderim başlatılmadı."
                upsert_action(case, aksiyon)
            case.add_event("ACTION_CANCELLED",
                           "Aksiyon iptal edildi; mail GÖNDERİLMEDİ")
            self._cases.upsert(case)

        # NOT: burada _release_all_pending ÇAĞRILMAZ. İki worker paralel
        # çalışırsa biri diğerinin bekleyen kaydını temizler ve aynı vaka
        # için ikinci gönderim kapısı erken açılırdı. Bağlanamayan artık
        # kayıtlar hata yolunda ve kapanışta bırakılır.

        self._load_cases()
        QMessageBox.information(
            self, "Aksiyon sonucu",
            mesajlar.get(son_durum,
                         f"Gönderilemedi ({son_durum or 'bilinmiyor'})."))

    def _compare_row(self, row: int) -> None:
        """Tek satırı karşılaştır (§6) — arka planda."""
        case = self._case_at(row)
        if case is None:
            return
        self._start_compare([case])

    def _compare_all(self) -> None:
        """Görünen tüm satırları karşılaştır (§7)."""
        if self._reject_if_busy("Karşılaştır"):
            return
        cases = self.visible_cases()
        if not cases:
            QMessageBox.information(self, "Karşılaştır",
                                    "Karşılaştırılacak satır yok.")
            return
        if QMessageBox.question(
                self, "Tüm ekstreleri karşılaştır",
                f"{len(cases)} satır güncel FBL datasıyla karşılaştırılacak.\n"
                "İşlem arka planda çalışır, ekran donmaz. Devam edilsin mi?"
        ) != QMessageBox.Yes:
            return
        self._start_compare(cases)

    def _start_compare(self, cases) -> None:
        from app.incoming.worker import CaseCompareWorker

        self.btn_compare_all.setEnabled(False)
        self._busy(f"{len(cases)} satır karşılaştırılıyor…", 5)
        self._start_work(CaseCompareWorker(cases, self._comparison_service()),
                         self._on_compared)

    def _on_compared(self, outcomes) -> None:
        from app.services.case_comparison import summarize

        self._work_done()
        self.btn_compare_all.setEnabled(True)
        self._load_cases()

        ozet = summarize(outcomes or [])
        self._busy(f"Karşılaştırma bitti — {ozet['basarili']}/{ozet['toplam']} "
                   f"başarılı", 100)
        QMessageBox.information(
            self, "Karşılaştırma sonucu",
            f"Toplam satır: {ozet['toplam']}\n"
            f"Başarılı: {ozet['basarili']}\n"
            f"Fark bulunan: {ozet['fark']}\n"
            f"Ekstre gelmemiş: {ozet['ekstre_yok']}\n"
            f"Okunamayan: {ozet['okunamadi']}\n"
            f"Hatalı: {ozet['hata']}")

    # -- thread üzerinden cevap (hatırlatma / fark maili) -------------------

    def _confirm_mails(self, baslik: str, hazir, engelli) -> bool:
        """Gönderimden ÖNCE ne gideceğini ve neyin gitmeyeceğini göster."""
        if not hazir:
            QMessageBox.information(
                self, baslik,
                "Gönderilebilecek mail yok.\n\n"
                + _blocked_summary(engelli))
            return False

        ornek = hazir[0]
        detay = [f"Gönderilecek mail: {len(hazir)}",
                 f"Gönderilmeyecek: {len(engelli)}"]
        if engelli:
            detay.append("")
            detay.append(_blocked_summary(engelli))
        detay += ["", "— ÖRNEK MAİL —",
                  f"Firma: {ornek.company_code} {ornek.company_name}",
                  f"Konu: {ornek.subject}",
                  f"Ek: {len(getattr(ornek, 'attachments', []) or [])}",
                  "", (getattr(ornek, "body", "") or "")[:600]]

        dialog = QDialog(self)
        dialog.setWindowTitle(baslik)
        dialog.resize(760, 520)
        layout = QVBoxLayout(dialog)
        metin = QTextEdit()
        metin.setReadOnly(True)
        metin.setPlainText("\n".join(detay))
        layout.addWidget(metin)
        layout.addWidget(QLabel(
            "Onaylarsanız mailler ORİJİNAL zincire Reply-All olarak "
            "gönderilir ve işlem geçmişine yazılır."))
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("Gönder")
        buttons.button(QDialogButtonBox.Cancel).setText("Vazgeç")
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        return dialog.exec() == QDialog.Accepted

    def _send_reminders(self) -> None:
        """§3.5/§3.6 — cevap vermemiş firmalara hatırlatma (ekleriyle)."""
        from app.services.reminder_mail import build_many, eligible_cases

        if self._reject_if_busy("Hatırlatma"):
            return
        cases = eligible_cases(self.visible_cases())
        if not cases:
            QMessageBox.information(
                self, "Hatırlatma",
                "Cevap bekleyen ve zinciri bilinen satır yok.")
            return

        hazir, engelli = build_many(cases)
        if not self._confirm_mails("Hatırlatma gönder", hazir, engelli):
            return

        from app.mailing.outlook_client import ReplyRequest

        istekler = []
        for reminder in hazir:
            istekler.append((reminder.case_id, ReplyRequest(
                body=reminder.body, conversation_id=reminder.conversation_id,
                message_id=reminder.message_id,
                attachments=list(reminder.attachments),
                code=reminder.company_code)))
        self._start_reply_send(istekler, "REMINDER_SENT",
                               "Hatırlatma gönderildi")

    def _send_difference_mails(self) -> None:
        """§12 — fark bulunan satırlar için belge talebi maili."""
        from app.services.case_comparison import STATEMENT_DIFFERENCE
        from app.services.difference_mail import build_from_comparison

        if self._reject_if_busy("Fark maili"):
            return
        cases = [c for c in self.visible_cases()
                 if c.statement_decision == STATEMENT_DIFFERENCE]
        if not cases:
            QMessageBox.information(
                self, "Fark maili",
                "Fark bulunan satır yok. Önce 'Karşılaştır' çalıştırın.")
            return

        hazir, engelli = [], []
        for case in cases:
            mail = build_from_comparison(case, _StoredComparison(case))
            mail.case_id = getattr(case, "case_id", "")
            mail.company_code = case.company_code
            mail.company_name = case.company_name
            mail.conversation_id = case.conversation_id
            mail.message_id = case.message_id
            (hazir if mail.ready else engelli).append(mail)

        # Hazırlanan metin diske yazılır: "Hazır Mail" kolonu bunu gösterir
        # ve kullanıcı göndermeden önce/sonra dosyadan okuyabilir.
        for mail in hazir:
            yol = _save_prepared_mail(mail)
            if yol and self._cases is not None:
                case = self._cases.get(mail.case_id)
                if case is not None:
                    case.prepared_reply_path = yol
                    case.add_event("DIFFERENCE_MAIL_PREPARED",
                                   "Fark maili hazırlandı", detail=yol)
                    self._cases.upsert(case)
        self._load_cases()

        if not self._confirm_mails("Fark maili gönder", hazir, engelli):
            return

        from app.mailing.outlook_client import ReplyRequest

        istekler = [(m.case_id, ReplyRequest(
            body=m.body, conversation_id=m.conversation_id,
            message_id=m.message_id, code=m.company_code)) for m in hazir]
        self._start_reply_send(istekler, "DIFFERENCE_MAIL_SENT",
                               "Fark maili gönderildi")

    def _start_reply_send(self, istekler, olay: str, aciklama: str) -> None:
        from app.incoming.worker import ThreadReplyWorker

        self._pending_event = (olay, aciklama)
        self.btn_reminder.setEnabled(False)
        self.btn_difference.setEnabled(False)
        self._busy(f"{len(istekler)} mail gönderiliyor…", 5)
        self._start_work(ThreadReplyWorker(
            istekler, send=True, outgoing_smtp=self._outgoing_smtp()),
                         self._on_replies_sent)

    def _on_replies_sent(self, results) -> None:
        """Sonuçları case'lere ve işlem geçmişine yaz."""
        self._work_done()
        self.btn_reminder.setEnabled(True)
        self.btn_difference.setEnabled(True)
        olay, aciklama = getattr(self, "_pending_event", ("REPLY_SENT", "Cevap gönderildi"))

        # §9 — SONUÇLAR AYRI SAYILIR. SEND_UNKNOWN'ı "başarısız" kovasına
        # atmak tehlikelidir: mail gitmiş OLABİLİR ve kullanıcı yeniden
        # göndermeye kalkarsa firma ikinci maili alır.
        from app.services.action_send import apply_result
        from app.services.case_actions import ActionItem

        sayim: dict[str, int] = {"SENT": 0, "SEND_UNKNOWN": 0, "FAILED": 0,
                                 "SKIPPED": 0, "DRAFTED": 0}
        atlanan: list[str] = []
        for case_id, result in results or []:
            case = self._cases.get(case_id) if self._cases else None
            durum = getattr(result, "status", "") or "FAILED"
            sayim[durum] = sayim.get(durum, 0) + 1
            if durum not in ("SENT", "DRAFTED"):
                atlanan.append(f"{getattr(result, 'code', '')}: "
                               f"{getattr(result, 'reason', '')[:70]}")
            if case is None:
                continue
            basarili = durum == "SENT"
            case.add_event(olay if basarili else f"{olay}_{durum}",
                           aciklama if basarili else f"{aciklama} — {durum}",
                           detail=getattr(result, "reason", ""))
            # ZİNCİR İLERLESİN: yeni kimlikler vakaya yazılır, aksi hâlde
            # bir sonraki hatırlatma yine İLK maili hedefler.
            aksiyon = ActionItem(case_id=case_id, action_type=olay)
            apply_result(case, aksiyon, result, olay)
            self._cases.upsert(case)

        gonderilen = sayim.get("SENT", 0)

        self._load_cases()
        belirsiz = sayim.get("SEND_UNKNOWN", 0)
        self._busy(f"Gönderildi: {gonderilen} · Belirsiz: {belirsiz} · "
                   f"Atlanan: {len(atlanan)}", 100)
        detay = (f"Gönderildi (SENT)   : {gonderilen}\n"
                 f"BELİRSİZ (UNKNOWN)  : {belirsiz}\n"
                 f"Başarısız (FAILED)  : {sayim.get('FAILED', 0)}\n"
                 f"Atlandı (SKIPPED)   : {sayim.get('SKIPPED', 0)}")
        if belirsiz:
            detay += ("\n\nBELİRSİZ olanlar GÖNDERİLMİŞ OLABİLİR. "
                      "Gönderilmiş Öğeler kontrol edilmeli; bu vakalara "
                      "otomatik tekrar gönderim YAPILMAZ.")
        if atlanan:
            detay += "\n\n" + "\n".join(atlanan[:15])
        QMessageBox.information(self, "Gönderim sonucu", detay)

    # -- manuel durum -------------------------------------------------------

    def _set_manual_status(self, row: int, status: str) -> None:
        """§9 — kullanıcının elle verdiği kararı uygula (geri alınabilir)."""
        case = self._case_at(row)
        if case is None or self._cases is None:
            return
        # KARARI GERİ ALMA gerekçe istemez; YENİ bir finansal karar ister.
        geri_alma = case.manual_override and case.final_status == status
        note = ""
        if not geri_alma:
            note, ok = QInputDialog.getText(
                self, f"{status} gerekçesi",
                "Bu kararı neden veriyorsunuz? (denetim kaydına yazılır)")
            if not ok:
                return
            if not (note or "").strip():
                QMessageBox.warning(
                    self, "Gerekçe zorunlu",
                    "Finansal kararı değiştirmek için gerekçe yazmalısınız. "
                    "Bu açıklama denetim kaydına işlenir.")
                return

        def _uygula() -> None:
            if geri_alma:
                apply_manual_status(case, status, note=note,
                                    user=_current_user())
            else:
                change_financial_decision(case, status, reason=note,
                                          user=_current_user(),
                                          settings=self._settings_store())

        try:
            _uygula()
        except InvalidAddressCaseClosed as exc:
            # Vaka kapatılamaz ÇÜNKÜ mail hiç ulaşmadı. Kullanıcıyı boş bir
            # uyarıyla bırakmak yerine çözümü aynı adımda sunuyoruz.
            if not self._ask_new_address(case):
                QMessageBox.warning(self, "Durum", str(exc))
                return
            try:
                _uygula()
            except ValueError as tekrar:
                QMessageBox.warning(self, "Durum", str(tekrar))
                return
        except PermissionDenied as exc:
            QMessageBox.warning(self, "Yetki", str(exc))
            return
        except ValueError as exc:
            QMessageBox.warning(self, "Durum", str(exc))
            return
        self._cases.upsert(case)
        self._load_cases()
        self._busy(f"{case.company_code} → {case.final_status}", 100)

    def _settings_store(self):
        """Rol haritasının okunacağı ayar deposu (açılamazsa ``None``).

        Rol haritası ``settings.json``dadır; oturum nesnesi onu taşımaz. Depo
        açılamazsa ``None`` döner ve yetki VARSAYILAN role (operasyon) düşer —
        yani kullanıcı yönetici yetkisi KAZANMAZ, kaybeder. Şüphede yetkiyi
        daraltmak doğrudur.
        """
        if self._settings is None:
            try:
                from app.services.settings import Settings

                self._settings = Settings()
            except Exception:  # noqa: BLE001 - ayar okunamazsa varsayılan rol
                return None
        return self._settings

    def _ask_new_address(self, case) -> bool:
        """Teslim edilemeyen adres yerine YENİ adres al. Döner: girildi mi?

        Adres, adres defterine de sorulur: kullanıcı başka bir vakada zaten
        patlamış bir adresi girerse kabul EDİLMEZ.
        """
        from app.services.invalid_address import set_replacement_address

        eski = str(getattr(case, "invalid_address", "") or "")
        yeni, ok = QInputDialog.getText(
            self, "Yeni iletişim adresi",
            f"{case.company_code} için mail teslim edilemedi"
            + (f" ({eski})" if eski else "")
            + ". Yeni iletişim adresini girin:")
        if not ok or not (yeni or "").strip():
            return False
        registry = getattr(self, "_address_registry", None)
        hata = set_replacement_address(case, yeni, user=_current_user(),
                                       registry=registry)
        if hata:
            QMessageBox.warning(self, "Yeni iletişim adresi", hata)
            return False
        if self._cases is not None:
            self._cases.upsert(case)
        self._busy(f"{case.company_code} → yeni adres: {case.replacement_address}",
                   100)
        return True

    # -- işlem geçmişi ------------------------------------------------------

    def _show_history(self, row: int) -> None:
        """§15 — case'in tüm işlem geçmişi (audit trail)."""
        case = self._case_at(row)
        if case is None:
            return
        satirlar = []
        for event in case.timeline or []:
            satirlar.append(
                f"[{event.get('at', '')[:19].replace('T', ' ')}] "
                f"{event.get('kind', '')} — {event.get('description', '')}")
            if event.get("old_value") or event.get("new_value"):
                satirlar.append(f"      {event.get('old_value') or '—'} → "
                                f"{event.get('new_value') or '—'}")
            if event.get("user"):
                satirlar.append(f"      kullanıcı: {event['user']}")
            if event.get("detail"):
                satirlar.append(f"      {event['detail']}")
        if not satirlar:
            satirlar = ["Bu kayıt için henüz işlem geçmişi yok."]

        # §14 — zincirdeki her gelen/giden mail ayrı ayrı listelenir.
        mailler = case.mail_events or []
        if mailler:
            satirlar += ["", "— MAİL ZİNCİRİ —"]
            for event in mailler:
                yon = "→ GİDEN" if event.get("direction") == "OUT" else "← GELEN"
                satirlar.append(
                    f"[{(event.get('at') or '')[:19].replace('T', ' ')}] {yon} "
                    f"{event.get('subject', '')}")
                ayrinti = []
                if event.get("sender"):
                    ayrinti.append(f"gönderen: {event['sender']}")
                if event.get("reply_type"):
                    ayrinti.append(f"tür: {event['reply_type']}")
                ayrinti.append(f"ek: {event.get('attachment_count', 0)}")
                if event.get("mail_id"):
                    ayrinti.append(f"id: {event['mail_id'][:40]}")
                satirlar.append("      " + " · ".join(ayrinti))
                if event.get("snippet"):
                    satirlar.append(f"      {event['snippet'][:120]}")

        dialog = QDialog(self)
        dialog.setWindowTitle(
            f"İşlem Geçmişi — {case.company_code} {case.balance_type}")
        dialog.resize(760, 460)
        layout = QVBoxLayout(dialog)
        metin = QTextEdit()
        metin.setReadOnly(True)
        metin.setPlainText("\n".join(satirlar))
        layout.addWidget(metin)
        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        buttons.rejected.connect(dialog.reject)
        buttons.accepted.connect(dialog.accept)
        layout.addWidget(buttons)
        dialog.exec()

    def _show_case_details(self, row: int, _column: int) -> None:
        """Detay ekranı: TÜM teknik kanıt burada gösterilir."""
        case = self._case_at(row)
        if case is None:
            return
        QMessageBox.information(self, "Mutabakat cevabı ayrıntısı",
                                "\n".join(_case_detail_lines(case)))

    def _show_details(self, row: int, _column: int) -> None:
        if not 0 <= row < len(self._results):
            return
        response = self._results[row]
        lines = [
            f"Konu: {response.subject}",
            f"Gönderen: {response.sender}",
            f"Firma: {response.company_code or '—'} "
            f"{response.company_name or ''}",
            f"Cevap türü: {response.reply_type.value}",
            f"Bakiye kabul: {_TRISTATE[response.balance_accepted]}",
            f"Dönem: {response.period or '—'}",
            f"Bakiyeler: {_fmt_balances(response)}",
            f"Mektup: {'var' if response.letter_present else 'yok'} | "
            f"dolu: {_TRISTATE[response.letter_filled]} | "
            f"imza: {_TRISTATE[response.letter_signed]} | "
            f"kaşe: {_TRISTATE[response.letter_sealed]}",
            f"Ekstre: {'var' if response.statement_present else 'yok'}",
            f"Güven: {response.confidence:.2f}",
            f"AI durumu: {response.review_status.value}",
        ]
        if response.ai_error:
            lines.append(f"AI hatası: {response.ai_error}")
        if response.conflicts:
            lines.append("")
            lines.append("ÇELİŞKİLER (Python değeri korunmuştur):")
            lines.extend(
                f"  • {c.field_name}: python={c.python_value} / ai={c.ai_value}"
                for c in response.conflicts)
        if response.reasons:
            lines.append("")
            lines.append("Gerekçeler: " + ", ".join(response.reasons))
        QMessageBox.information(self, "Mail ayrıntısı", "\n".join(lines))

    # -- iş parçacığı yönetimi (MailingPage ile aynı kalıp) ----------------

    def _track(self, thread) -> None:
        """Thread referansını tut ve bitince temizle.

        ``QThread.finished`` worker thread'inde yayınlanır; temizlik BAĞLI
        METODA bağlanır ki liste sayfanın thread'inde güncellensin.
        """
        self._threads.append(thread)
        thread.finished.connect(self._forget_finished_threads)

    def _forget_finished_threads(self) -> None:
        alive = []
        for thread in self._threads:
            try:
                if not thread.isFinished():
                    alive.append(thread)
            except RuntimeError:
                continue      # C++ nesnesi silinmiş
        self._threads = alive

    def _busy(self, message: str, percent: int = 0) -> None:
        self.lbl_status.setText(message)
        self.progress.setValue(percent)

    def _signal_worker(self):
        """Sinyali yayan işçi.

        Sinyaller artık ``WorkerBinding`` üzerinden geçtiği için ``sender()``
        binding'i döndürür; gerçek işçi ``_signal_source``ta bildirilir.
        Doğrudan bağlı eski çağrı yollarında ``sender()`` hâlâ geçerlidir.
        """
        worker = getattr(self, "_signal_source", None)
        if worker is not None:
            return worker
        return self.sender()

    def _on_action_error(self, message: str) -> None:
        """Aksiyon worker'ı hata verirse yalnız kendi vakalarını temizle."""
        worker = self._signal_worker()
        case_ids = tuple(getattr(worker, "case_ids", ()) or ())
        for case_id in case_ids:
            kayit = self._release_pending(case_id)
            if not kayit or self._cases is None:
                continue
            case = self._cases.get(case_id)
            if case is None:
                continue
            action = kayit.get("action")
            if action is not None:
                from app.services.case_actions import (
                    STATUS_FAILED_PRE_SEND,
                    upsert_action,
                )

                action.status = STATUS_FAILED_PRE_SEND
                action.user_note = (
                    (action.user_note + " | ") if action.user_note else ""
                ) + f"Worker hatası: {message[:200]}"
                upsert_action(case, action)
            case.add_event("ACTION_WORKER_FAILED",
                           "Aksiyon worker'ı sonuç üretemedi",
                           detail=message[:300])
            self._cases.upsert(case)
        self._on_error(message)

    def _is_busy(self) -> bool:
        """TEK İŞÇİ SÖZLEŞMESİ: sayfada çalışan bir iş var mı?"""
        return self._worker is not None

    def _reject_if_busy(self, title: str) -> bool:
        """Çalışan iş varken yeni aksiyonu reddet ve NEDENİNİ söyle."""
        if not self._is_busy():
            return False
        QMessageBox.information(
            self, title,
            "Şu anda başka bir işlem çalışıyor.\n\n"
            "Aynı anda yalnızca bir işlem yürütülür; aksi hâlde tarama veya "
            "gönderim iki kez başlayabilir. İşlemin bitmesini bekleyin ya da "
            "'İptal' ile durdurun.")
        return True

    def _detach_worker(self, worker) -> None:
        """Eskimiş işçinin sinyallerini sayfadan KES.

        Bağlantılar koparılmaz (bkz. ``WorkerBinding``): işçi bittiğinde
        ``deleteLater`` ile siliniyor ve silinmiş nesne üzerinde
        ``disconnect()`` çağırmak süreci çökertiyordu. Yerine işçinin
        binding'i "eskimiş" işaretlenir; sinyalleri artık yutulur.
        """
        binding = self._bindings.pop(id(worker), None)
        if binding is not None:
            binding.retire()

    def _preempt_worker(self, worker_type: type | None = None) -> None:
        """Çalışan işi sayfanın KENDİ kararıyla geçersiz kıl.

        İptal etmek yetmez: işçi iptalden önce finished/failed yayıp YENİ
        işin arayüz durumunu sıfırlayabilir. Sinyaller koparılır ve
        sahiplik bırakılır.
        """
        worker = self._worker
        if worker is None:
            return
        if worker_type is not None and not isinstance(worker, worker_type):
            return
        if hasattr(worker, "cancel"):
            worker.cancel()
        self._detach_worker(worker)
        self._worker = None

    def _outgoing_smtp(self) -> str:
        """Kurumsal giden posta kutusu SMTP'si; GÖNDERİM ANINDA okunur.

        Sağlayıcı (ana pencerenin ayarları) verilmemişse ya da hata verirse
        boş döner; boş SMTP gerçek gönderimi fail-closed engeller.
        """
        provider = self._outgoing_smtp_provider
        if provider is None:
            return ""
        try:
            return str(provider() or "").strip()
        except Exception:  # noqa: BLE001 - okunamayan ayar = gönderme
            return ""

    def _start_work(self, worker, on_finished, on_error=None) -> bool:
        """İşçiyi arka planda başlat.

        TEK İŞÇİ SÖZLEŞMESİ: çalışan iş varken yeni işçi BAŞLATILMAZ ve
        ``False`` döner. Eskiden ``self._worker`` koşulsuz eziliyor, eski
        işçi arka planda çalışmaya devam ediyordu: İptal yalnızca yeni
        işçiye gidiyor, eski işçinin sinyalleri yeni işin durumunu
        bozuyordu (mükerrer gönderim/tarama riski).
        """
        if self._is_busy():
            # SON SAVUNMA HATTI: aksiyon işleyicisi _reject_if_busy ile
            # önceden kontrol etmeyi atlamış olsa da iş sessizce yutulmaz.
            self._reject_if_busy("İşlem")
            return False
        self._worker = worker
        # Sinyaller DOĞRUDAN bağlanmaz: binding, işçi eskidiğinde gelen
        # sinyalleri yutar (bkz. WorkerBinding / _detach_worker).
        self._bindings[id(worker)] = WorkerBinding(
            self, worker, self._busy, on_finished,
            on_error or self._on_error)
        self.btn_cancel.setEnabled(True)
        self._track(run_in_thread(worker))
        return True

    def _cancel_current(self) -> None:
        worker = self._worker
        if worker is None or not hasattr(worker, "cancel"):
            return
        worker.cancel()
        self.btn_cancel.setEnabled(False)
        self._busy("Durduruluyor… (mevcut mail bitince duracak)",
                   self.progress.value())

    def _work_done(self) -> None:
        """İşi SONLANDIR: sahipliği bırak ve işçinin sinyallerini kopar.

        Sinyalleri koparmak şart: ``_work_done`` çağrıldıktan sonra aynı
        işçiden GEÇ GELEN bir finished/failed, o sırada başlatılmış YENİ
        işin durumunu sıfırlıyordu (iptal düğmesi kapanıyor, modal hata
        açılıyordu).
        """
        self.btn_cancel.setEnabled(False)
        worker = self._worker
        self._worker = None
        if worker is not None:
            self._detach_worker(worker)

    def shutdown(self, timeout_ms: int = 5000) -> None:
        """Uygulama kapanırken çalışan taramayı düzgünce durdur."""
        # Bekleyen aksiyon kilitleri MODÜL düzeyinde tutulur; sayfa
        # kapanırken bırakılmazsa aynı oturumda vaka kalıcı kilitli kalır.
        self._release_all_pending()
        worker = self._worker
        if worker is not None and hasattr(worker, "cancel"):
            worker.cancel()
        for thread in list(self._threads):
            try:
                thread.quit()
                thread.wait(timeout_ms)
            except RuntimeError:
                pass          # thread zaten silinmiş
        self._threads.clear()
        self._worker = None

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt arayüzü
        self.shutdown()
        super().closeEvent(event)
