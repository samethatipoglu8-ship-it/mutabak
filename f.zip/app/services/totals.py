"""Dip toplam (grand-total) satırı tespiti — çok dilli, explicit.

Eski mantık "referansı yok + tutarı var => dip toplam" varsayıyordu. Bu her
ERP'de doğru değildir: "Kur Farkı", "Devreden", "Açılış Fişi" gibi GERÇEK
muhasebe satırlarının da referansı olmayıp tutarı olabilir; onları toplam
sanmak mutabakatı bozar.

Bunun yerine dip toplam satırını AÇIKÇA tanırız: satırın herhangi bir
hücresinde "TOPLAM / GENEL TOPLAM / TOTAL / SUM / GESAMT ..." gibi bir toplam
anahtar kelimesi geçiyorsa o satır dip toplamdır. Salt sözlük araması; AI yok.
"""

from __future__ import annotations

import re

# Çok dilli toplam anahtar kelimeleri (normalize edilmiş: harfler küçük,
# TR karakterler sadeleştirilmiş, boşluk/simge atılmış).
_TOTAL_KEYWORDS: frozenset[str] = frozenset({
    # Türkçe
    "toplam", "geneltoplam", "aratoplam", "genltoplam", "toplamtutar",
    "toplamlar", "hesaptoplami", "borctoplami", "alacaktoplami", "bakiyetoplami",
    # English
    "total", "grandtotal", "subtotal", "sum", "totals", "totalamount",
    "balancetotal", "closingbalance",
    # German
    "gesamt", "gesamtsumme", "summe", "gesamtbetrag", "zwischensumme",
    "endsumme",
    # Italian
    "totale", "totalegenerale", "sommatotale", "totaledocumenti",
    # French
    "totalgeneral", "sommetotale", "totaux",
    # Spanish / Portuguese
    "totalgeneral", "sumatotal", "totalgeral", "somatotal",
    # Dutch / Polish / Romanian
    "totaalgeneraal", "sumaogolem", "totalgeneral",
})

_NORM_RE = re.compile(r"[^a-z0-9]")


def _norm_cell(value: object) -> str:
    text = str(value).strip().lower()
    trans = str.maketrans("çğıöşü", "cgiosu")
    text = text.translate(trans)
    return _NORM_RE.sub("", text)


def is_total_row(row: list[object]) -> bool:
    """Satırdaki herhangi bir hücre bir toplam anahtar kelimesi mi?"""
    if not row:
        return False
    for cell in row:
        if cell is None:
            continue
        n = _norm_cell(cell)
        if not n:
            continue
        if n in _TOTAL_KEYWORDS:
            return True
        # "genel toplam" gibi birleşik ya da ekli yazımları da yakala
        # (ör. "TOPLAM:", "Genel Toplam", "TOTAL EUR"). Kelime köklerini ara.
        for kw in ("geneltoplam", "aratoplam", "toplam", "grandtotal",
                   "subtotal", "gesamtsumme", "totalegenerale", "totalgeneral"):
            if kw in n:
                return True
    return False


# ---------------------------------------------------------------------------
# Açılış / devir (opening / carry-forward) satırı tespiti
# ---------------------------------------------------------------------------
# Kullanıcı kararı: açılış/devir satırları FATURA (kalem) eşleştirmesine
# GİRMEZ; yalnızca toplam bakiye kontrolünde kullanılır. 'Hesaplar arası
# virman' ise GERÇEK bir işlem sayılır ve burada YAKALANMAZ (kalem olarak
# kalır). Salt sözlük/alt-dize araması — AI yok.
_OPENING_KEYWORDS: frozenset[str] = frozenset({
    # Türkçe
    "devreden", "devir", "acilis", "acilisfisi", "oncekidonemdendevir",
    "oncekidonem", "nakliyekun", "devirbakiye", "devirbakiyesi",
    "acilisbakiyesi", "acilisbakiye",
    # English
    "opening", "openingbalance", "broughtforward", "carryforward",
    "carriedforward", "balanceforward", "broughtdown",
    # German / Italian / French / Spanish
    "eroffnungsbilanz", "anfangsbestand", "saldoiniziale",
    "riportoprecedente", "reportnouveau", "soldeinitial",
    "saldoinicial", "saldoanterior",
})

# Açılış tespitinde 'virman' geçen satır ASLA açılış sayılmaz (gerçek işlem).
_OPENING_EXCLUDE: frozenset[str] = frozenset({"virman"})


def is_opening_row(row: list[object]) -> bool:
    """Satır bir açılış/devir (opening/carry-forward) satırı mı?

    Fatura eşleştirmesinden hariç tutulur; toplam bakiye kontrolünde kullanılır.
    'Hesaplar arası virman' gibi gerçek işlem satırları hariç tutulur.
    """
    if not row:
        return False
    found = False
    for cell in row:
        if cell is None:
            continue
        n = _norm_cell(cell)
        if not n:
            continue
        if any(x in n for x in _OPENING_EXCLUDE):
            return False
        if n in _OPENING_KEYWORDS or any(kw in n for kw in _OPENING_KEYWORDS):
            found = True
    return found


# ---------------------------------------------------------------------------
# Fatura olmayan referans (denkleştirme / ödeme placeholder) tespiti
# ---------------------------------------------------------------------------
# Kullanıcı kararı: "Denkleştirme" ve "Ödeme" fatura değildir; karşılaştırmada
# kullanılmaz. Referans hücresinde GERÇEK belge no yerine böyle bir anahtar
# kelime yazıyorsa (ör. Referans = "DENKLEŞTİRME"), o satır kalem
# karşılaştırmasına alınmaz. Yalnızca referansın KENDİSİ bir anahtar
# kelimeyse tetiklenir (numara içeren gerçek referanslar etkilenmez).
_NONINVOICE_REF_KEYWORDS: frozenset[str] = frozenset({
    "denklestirme", "denklestir", "denklesme", "mahsup", "mahsupfisi",
    "odeme", "odemefisi", "tahsilat", "tahsil", "kapatma", "kapama",
    "clearing", "payment", "settlement", "ausgleich", "compensazione",
    "compensation", "compensacion",
    # Ay sonu virman/kapanış kayıtları. Gerçek bir FBL1H çıktısında
    # "07.2026 AYSONU V" değeri TEK BAŞINA 295 satırda referans olarak
    # geçiyordu; bunlar fatura değil dönem kapanış kalemleridir ve
    # eşleştirmeye girerse aynı anahtarı paylaşan yüzlerce satır
    # birbirine karışır.
    "aysonu", "aysonuv", "aysonuvirman", "virman", "virmanfisi",
    "dönemkapanis", "donemkapanis", "kapanisfisi",
})

#: "07.2026 AYSONU V" gibi DÖNEM ÖNEKLİ placeholder'lar için: baştaki
#: ay/yıl bilgisini at, kalanı anahtar kelime olarak değerlendir.
_PERIOD_PREFIX_RE = re.compile(r"^\d{1,4}[./\-]\d{2,4}\s*")


def is_noninvoice_ref(value: object) -> bool:
    """Referans değeri, gerçek belge no yerine bir 'fatura olmayan' anahtar
    kelime mi (denkleştirme/ödeme placeholder)? Yalnızca değer TAMAMEN böyle
    bir kelimeden ibaretse True (içinde rakam/gerçek kod varsa False)."""
    if value is None:
        return False

    # Önce dönem öneki ("07.2026 ...") atılır: bu bir belge numarası
    # değil, kalemin ait olduğu dönemdir. Kalanda rakam varsa değer
    # GERÇEK bir belge no sayılır ve dokunulmaz.
    ham = _PERIOD_PREFIX_RE.sub("", str(value).strip())
    n = _norm_cell(ham)
    if not n or any(ch.isdigit() for ch in n):
        return False
    return n in _NONINVOICE_REF_KEYWORDS
