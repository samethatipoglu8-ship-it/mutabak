"""Headless reply scanning and health reporting.

This module deliberately contains no Qt code.  A scheduled task can run the
same audited reply pipeline as the desktop screen, while the screen remains a
consumer of the same durable case and send stores.  It never sends mail.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional


def run_reply_scan(
    *,
    limit: int = 200,
    since: Optional[datetime] = None,
    folder_name: str = "",
    account_smtp: str = "",
    period: Optional[str] = None,
    tofas_path: str | Path | None = None,
    mode: str = "yabanci",
    company: Optional[str] = None,
    reader: Any = None,
    pipeline: Any = None,
    mail_log: Any = None,
    snapshot_store: Any = None,
    case_store: Any = None,
):
    """Run one idempotent inbound scan without a GUI or outbound side effect.

    A missing tracked-send record is a normal no-op.  Inbox access errors are
    intentionally allowed to reach the caller: a scheduler must mark a failed
    scan as failed instead of recording a false "healthy" result.
    """
    from app.incoming.reply_scan import ReplyScanService, ScanResult
    from app.incoming.tracking import MailTracker
    from app.services.incoming_cases import IncomingCaseStore
    from app.services.mail_log import MailLog
    from app.services.send_snapshot import SnapshotStore

    log = mail_log or MailLog()
    tracker = MailTracker.from_mail_log(log, period=period)
    if tracker.tracked_count == 0:
        return ScanResult()

    if reader is None:
        from app.incoming.outlook_reader import OutlookIncomingReader

        reader = OutlookIncomingReader(
            folder_name, account_smtp=account_smtp, require_account_smtp=True)
    if pipeline is None:
        from app.incoming.pipeline import build_default_pipeline

        pipeline = build_default_pipeline()

    tofas_records = []
    if tofas_path:
        from app.services.reconciliation_service import ReconciliationService

        tofas_records = ReconciliationService().load_tofas_records(
            tofas_path, mode=mode, company=company)

    snapshots = snapshot_store or SnapshotStore()
    cases = case_store or IncomingCaseStore()
    # METADATA-ÖNCE: tracker zaten yukarıda kuruldu (idempotent erken-çıkış
    # kontrolü için); read()'e verilince İLGİSİZ mailler için ek HİÇ
    # indirilmez (bkz. doc 21 / OutlookIncomingReader.read docstring'i).
    mails = reader.read(limit=max(1, int(limit)), since=since, tracker=tracker)
    return ReplyScanService(
        tracker,
        pipeline=pipeline,
        tofas_records=tofas_records,
        snapshot_store=snapshots,
        case_store=cases,
    ).scan(mails)


def health_snapshot(
    *,
    period: Optional[str] = None,
    mail_log: Any = None,
    case_store: Any = None,
    backup_dir: str | Path | None = None,
    now: Optional[datetime] = None,
) -> dict[str, Any]:
    """Return a machine-readable operational health snapshot.

    ``attention_required`` is a business status, not a process failure: the
    scheduled task has run correctly but one or more cases need ownership.
    Process failures still raise an exception for the scheduler to report.
    """
    from app.services.backup import backup_due, latest_backup
    from app.services.incoming_cases import IncomingCaseStore
    from app.services.mail_log import MailLog
    from app.services.ops_metrics import from_store

    at = now or datetime.now(timezone.utc)
    log = mail_log or MailLog()
    cases = case_store or IncomingCaseStore()
    # Yalnız İNSAN KARARI BEKLEYEN belirsiz gönderimler dikkat gerektirir;
    # çözülmüş (REOPENED/VERIFIED_SENT) ya da sonradan gönderilmiş firmalar
    # metrikten düşer.
    unknown = len(log.unresolved_unknowns(period))
    metrics = from_store(cases, period=period, now=at)
    latest = latest_backup(backup_dir)
    attention = unknown + metrics.geciken + metrics.gecersiz_adres + metrics.insan_incelemesi
    return {
        "generated_at": at.isoformat(timespec="seconds"),
        "period": period or "",
        "status": "attention_required" if attention else "healthy",
        "attention_count": attention,
        "send_unknown": unknown,
        "backup": {
            "latest_path": str(latest) if latest else "",
            "due": backup_due(backup_dir=backup_dir, now=at),
        },
        "metrics": {
            "sent": metrics.gonderilen,
            "waiting": metrics.cevap_bekleyen,
            "overdue": metrics.geciken,
            "invalid_address": metrics.gecersiz_adres,
            "human_review": metrics.insan_incelemesi,
            "difference": metrics.farkli,
        },
    }
