"""Provenance / evidence models for the canonical layer.

Answers "Bu değer nereden geldi?" — every canonical field can carry a
FieldEvidence describing how it was obtained, so extraction and reconciliation
stay auditable. Pure data models, no behaviour, no AI.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class ExtractionMethod(str, Enum):
    """How a value was produced. Ordered cheap -> expensive /
    deterministic -> probabilistic (matches the performance principle)."""

    DETERMINISTIC_TABULAR = "deterministic_tabular"   # xlsx / csv (loader.py)
    DETERMINISTIC_PDF = "deterministic_pdf"           # native/text pdf (pdfplumber)
    UBL_XML = "ubl_xml"                               # e-Fatura / e-Arşiv
    CONNECTOR = "connector"                           # ERP API
    OCR = "ocr"                                       # scanned pdf / png
    AI_FALLBACK = "ai_fallback"                       # LLM structured extraction
    MANUAL = "manual"                                 # human entry / correction


class FieldEvidence(BaseModel):
    """Traceability for a single extracted field value."""

    field_name: str
    value: Any = None
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)

    source_file: str | None = None
    source_page: int | None = None
    source_row: int | None = None
    source_text: str | None = None

    extraction_method: ExtractionMethod
