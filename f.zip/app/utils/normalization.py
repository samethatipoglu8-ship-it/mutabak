"""Deterministic normalization helpers for Mutabakat Pro.

Pure functions, no side effects, no AI. Same input always yields same output.
Handles the specific formats seen in TOFAŞ SAP exports and multi-language
supplier statements.
"""

from __future__ import annotations

import re
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import Optional

# ---------------------------------------------------------------------------
# Strings
# ---------------------------------------------------------------------------

_WS_RE = re.compile(r"\s+")


def clean_string(value: object) -> Optional[str]:
    """Trim, collapse internal whitespace, drop empty/NaN-like values."""
    if value is None:
        return None
    text = str(value).strip()
    if not text or text.lower() in {"nan", "none", "null"}:
        return None
    return _WS_RE.sub(" ", text)


# ---------------------------------------------------------------------------
# Amounts
# ---------------------------------------------------------------------------

_AMOUNT_ALLOWED_RE = re.compile(r"[^0-9,.\-]")


def normalize_amount(value: object) -> Decimal:
    """Parse a monetary value into :class:`Decimal`.

    Handles Turkish/European format (``1.250,75`` -> ``1250.75``), US format
    (``1,250.75``), plain machine numbers, parenthesized negatives, and a
    leading/trailing minus sign. Invalid/empty input yields ``Decimal('0')``.

    DİKKAT — ``0`` İKİ FARKLI ŞEY DEMEK OLABİLİR
        Bu fonksiyon geriye dönük uyum için okunamayan girdide de
        ``Decimal("0")`` döndürür. Yani "gerçekten sıfır" ile "okunamadı"
        ayırt edilemez. Sıfır tutarlar birbirine eşleşebildiği için, bozuk
        bir hücrenin sessizce 0 olması YANLIŞ bir eşleşme üretebilir.

        Bu ayrımın gerektiği her yerde :func:`try_normalize_amount`
        kullanın: geçersiz girdide ``None`` döner ve çağıran taraf kaydı
        veri kalitesi sorunu olarak işaretleyebilir.

    BELİRSİZLİK — TEK AYRAÇLI SAYILAR
        ``"1.234"`` hem 1,234 (ondalık) hem 1234 (binlik) olabilir; girdi
        tek başına bunu söylemez. Burada nokta ONDALIK kabul edilir
        (``1.234`` -> ``1.234``). SAP dışa aktarımlarında binlik ayracı
        kullanılıyorsa ondalık kısım da yazılır (``1.234,00``) ve
        belirsizlik oluşmaz.
    """
    result = try_normalize_amount(value)
    return Decimal("0") if result is None else result


def try_normalize_amount(value: object) -> Optional[Decimal]:
    """Tutarı ayrıştır; GERÇEKTEN okunamıyorsa ``None`` döndür.

    ``normalize_amount``tan tek farkı budur ve fark kritiktir:

        ``"0"`` / ``"0,00"`` / ``""`` / ``None``  → ``Decimal("0")``  (geçerli sıfır)
        ``"abc"`` / ``"---"`` / ``"NaN"``         → ``None``          (GEÇERSİZ)

    Boş hücre bilinçli olarak geçerli sıfır sayılır (ekstrelerde boş bakiye
    yaygındır); rakam içermeyen bir metin ise sayı DEĞİLDİR ve sıfır gibi
    davranması yanlış eşleşme üretir.
    """
    if value is None:
        return Decimal("0")
    if isinstance(value, bool):
        return None                      # True/False bir tutar değildir
    if isinstance(value, int):
        return Decimal(value)
    if isinstance(value, Decimal):
        return None if not value.is_finite() else value
    if isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            return None                  # NaN / sonsuz bir tutar değildir
        return Decimal(str(value))  # via str to avoid binary float noise

    text = str(value).strip()
    if not text:
        return Decimal("0")
    if text.lower() in {"nan", "none", "null"}:
        return None

    negative = False
    # Parenthesized accounting negative: (1.250,75)
    if text.startswith("(") and text.endswith(")"):
        negative = True
        text = text[1:-1].strip()
    # Leading or trailing minus (SAP/European exports use both).
    if text.startswith("-"):
        negative = not negative
        text = text[1:].strip()
    if text.endswith("-"):
        negative = not negative
        text = text[:-1].strip()

    # Rakam İÇERMEYEN bir metin sayı değildir ("abc", "---", "n/a").
    if not any(ch.isdigit() for ch in text):
        return None

    text = _AMOUNT_ALLOWED_RE.sub("", text).replace("-", "")
    if not text or text in {".", ","}:
        return None

    has_comma = "," in text
    has_dot = "." in text
    if has_comma and has_dot:
        if text.rfind(",") > text.rfind("."):
            text = text.replace(".", "").replace(",", ".")  # TR/EU
        else:
            text = text.replace(",", "")                    # US
    elif has_comma:
        text = text.replace(",", ".")                       # comma decimal

    try:
        result = Decimal(text)
    except InvalidOperation:
        return None                      # "12,5,6" gibi bozuk sayı

    return -result if negative else result


def abs_amount(value: Decimal) -> Decimal:
    """Absolute value helper (matching is done on magnitudes)."""
    return value.copy_abs()


# Bilinen para birimi kodları + kısa yerel adlar (döviz kolonu doğrulaması).
_KNOWN_CURRENCIES: frozenset[str] = frozenset({
    "TRY", "TL", "TRL", "EUR", "USD", "GBP", "CHF", "JPY", "SEK", "NOK",
    "DKK", "PLN", "RON", "CZK", "HUF", "RUB", "CNY", "CAD", "AUD", "AED",
    "€", "$", "£",
})


def clean_currency(value: object) -> Optional[str]:
    """Bir hücreyi para birimi koduna indir; makul değilse None.

    İşlem dövizi kolonu (İD/Dvz. Cinsi) bazen 'EUR'/'TL' gibi kod, bazen
    tek harf ('E'), bazen de alakasız/uzun/rakamlı bir değer taşır. Yalnızca
    kısa alfabetik bir kod (2-4 harf) ya da bilinen bir para birimi kabul
    edilir; aksi halde None (böylece rakamlı bir 'ID' kolonu yanlışlıkla para
    birimi guard'ını tetiklemez). Tek harf kısaltmaları genişletilir (E→EUR,
    T→TRY, D→USD değil — belirsiz olanlar None)."""
    text = clean_string(value)
    if text is None:
        return None
    up = text.strip().upper()
    if up in _KNOWN_CURRENCIES:
        return "TRY" if up == "TL" or up == "TRL" else up
    # Tek harf kısaltmalar (bazı yerli ekstrelerde Dvz. Cinsi = 'E'/'T')
    single = {"E": "EUR", "T": "TRY", "U": "USD", "S": "USD", "$": "USD",
              "€": "EUR", "£": "GBP"}
    if up in single:
        return single[up]
    # Salt alfabetik 2-4 harf → para birimi kodu kabul (ör. yeni/az bilinen)
    if up.isalpha() and 2 <= len(up) <= 4:
        return up
    return None


# ---------------------------------------------------------------------------
# Dates
# ---------------------------------------------------------------------------

_DATE_FORMATS = (
    "%Y-%m-%d", "%d.%m.%Y", "%d/%m/%Y", "%d-%m-%Y",
    "%Y/%m/%d", "%d.%m.%y", "%m/%d/%Y", "%Y.%m.%d",
)


# --- Excel seri tarihi ------------------------------------------------------
#
# Excel tarihleri, hücre "Genel"/sayı biçimindeyse okuyucuya SAYI olarak
# gelir (ör. 45678). Bu değerler eskiden tarih sayılmıyor, satır TARİHSİZ
# kalıyordu; tarih tabanlı eşleştirme katmanı da o satırda çalışamıyordu.
#
# Excel'in başlangıcı 1899-12-30'dur (1900 artık yıl hatası bu seçimle
# telafi edilir).
_EXCEL_EPOCH = date(1899, 12, 30)

# GÜVENLİK SINIRI — bu aralığın dışındaki sayılar tarih SAYILMAZ.
#
#   Bir tarih kolonunda sayı görmek tek başına "bu bir seri tarihtir"
#   demek değildir; belge numarası ya da tutar da olabilir. Aralık dar
#   tutulur: dışarıda kalan bir değer bugünkü davranışla aynı şekilde
#   None döner (kayıp yok), ama sayının yanlışlıkla tarihe çevrilmesi
#   YANLIŞ eşleşme üretirdi.
_EXCEL_SERIAL_MIN = 29221   # 1980-01-01
_EXCEL_SERIAL_MAX = 73050   # 2100-01-01


def _from_excel_serial(value: object) -> Optional[date]:
    """Excel seri numarasını tarihe çevir; makul aralık dışındaysa None."""
    if not isinstance(value, (str, int, float, Decimal)):
        return None
    try:
        serial = float(value)
    except (TypeError, ValueError):
        return None
    if serial != serial or serial in (float("inf"), float("-inf")):
        return None
    gun = int(serial)
    if not (_EXCEL_SERIAL_MIN <= gun <= _EXCEL_SERIAL_MAX):
        return None
    try:
        return _EXCEL_EPOCH + timedelta(days=gun)
    except (OverflowError, ValueError):  # pragma: no cover - aralık zaten dar
        return None


def normalize_date(value: object) -> Optional[date]:
    """Parse many date formats into a ``date`` (canonical YYYY-MM-DD).

    Metin biçimleri ÖNCE denenir; yalnızca hiçbiri tutmazsa değer bir
    Excel seri tarihi olarak yorumlanmaya çalışılır (bkz. yukarıdaki not).
    """
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, bool):
        return None                      # True/False bir tarih değildir
    if isinstance(value, (int, float)):
        return _from_excel_serial(value)

    text = str(value).strip()
    if not text or text.lower() in {"nan", "none", "null"}:
        return None
    text = text.split(" ")[0].split("T")[0]

    for fmt in _DATE_FORMATS:
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue

    # Metin biçimlerinin hiçbiri tutmadı: sayısal bir seri tarih olabilir
    # (ör. CSV'den gelen "45678" ya da pandas'ın "45678.0" yazımı).
    govde = text[:-2] if text.endswith(".0") else text
    if govde.isdigit():
        return _from_excel_serial(govde)
    return None


# ---------------------------------------------------------------------------
# Reference (invoice number) keys
# ---------------------------------------------------------------------------

_REF_STRIP_RE = re.compile(r"[^0-9A-Za-z]")


def normalize_reference(value: object) -> Optional[str]:
    """Canonical uppercase reference with separators removed.

    ``" 9607274 "`` -> ``"9607274"``; ``"fat-2024/001"`` -> ``"FAT2024001"``.
    Used for exact comparison after cleaning.
    """
    text = clean_string(value)
    if text is None:
        return None
    # Excel may hand us floats like 6532351.0 for numeric cells.
    if text.endswith(".0") and text[:-2].isdigit():
        text = text[:-2]
    return _REF_STRIP_RE.sub("", text).upper()


def reference_fuzzy_key(value: object) -> Optional[str]:
    """Fuzzy key: normalized reference with leading letters and zeros stripped.

    Lets ``0012345``, ``12345``, ``INV0012345``, and ``N/FACTURA 012345`` collapse
    to the same key. Only ever used when amounts already match, so it cannot cause
    false matches on its own.

    ÖNEMLİ: Baştaki harf/sıfırlar atıldıktan sonra geriye anlamlı bir çekirdek
    kalmıyorsa (ör. tamamen harften oluşan "AAA", "BBB" gibi referanslar) None
    döndürülür. Aksi halde bu tür referanslar aynı sahte anahtarda ("0")
    çakışıp, tutar da denk geldiğinde birbirine YANLIŞ eşleşirdi.
    """
    ref = normalize_reference(value)
    if ref is None:
        return None

    # Baştaki tüm harfleri (A-Z) ve hemen ardından gelen sıfırları (0) temizler.
    stripped = re.sub(r"^[A-Z0]+", "", ref)
    # Geriye anlamlı bir çekirdek kalmadıysa fuzzy eşleşmeye sokma.
    return stripped or None
