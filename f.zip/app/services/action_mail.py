"""Aksiyon türüne göre DÜZENLENEBİLİR mail metni üret.

İLKELER
    * VERİ UYDURULMAZ. Eksik alan "—" yazılır; tahmin edilmez.
    * Yalnızca motorun KANITLADIĞI satırlar listelenir.
    * "Yalnız firmada" ile "yalnız TOFAŞ'ta" satırları AYNI metinle
      istenmez: biri bize ulaşmamış faturadır, diğeri firmanın
      işlemediği kayıttır. Yanlış taraftan fatura istemek karşı tarafı
      haklı olarak şaşırtır.
    * Dil firma kodundan belirlenir (2 -> TR, 4 -> EN). Belirsizse mail
      HAZIRLANMAZ.
    * Metin taslaktır; kullanıcı göndermeden önce düzenleyebilir.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from typing import Any, Optional, Sequence

from app.mailing.mail_builder import classify_locale
from app.services.case_actions import (
    ACTION_LABELS,
    INTERNAL_ACTIONS,
    REMIND_FOR_REPLY,
    REQUEST_CORRECT_PERIOD,
    REQUEST_CORRECTED_STATEMENT,
    REQUEST_DIFFERENCE_EXPLANATION,
    REQUEST_MISSING_INVOICES,
    REQUEST_READABLE_DOCUMENTS,
    REQUEST_SIMPLIFIED_STATEMENT,
    REQUEST_STATEMENT,
    RESOLVE_CONTRADICTION,
)
from app.services.difference_mail import reply_subject

#: Mailde en fazla kaç satır gösterilir; fazlası EK dosyaya taşınır (§7).
MAX_SATIR = 20

_SELAM = {"tr": "Merhaba,", "en": "Dear Sir/Madam,"}
_IMZA = {"tr": "Teşekkürler,\nİyi çalışmalar.",
         "en": "Kind regards,"}

_GOVDE: dict[str, dict[str, str]] = {
    REMIND_FOR_REPLY: {
        "tr": "Konuya ilişkin dönüşünüzü rica ederiz.",
        "en": "We kindly ask for your feedback on this matter.",
    },
    REQUEST_STATEMENT: {
        "tr": "Mutabakat mektubumuza ilişkin cari hesap ekstrenizi "
              "paylaşmanızı rica ederiz.",
        "en": "We kindly ask you to share your account statement for the "
              "reconciliation period.",
    },
    REQUEST_CORRECT_PERIOD: {
        "tr": "Gönderdiğiniz ekstre mutabakat dönemine ait görünmüyor. "
              "İlgili döneme ait ekstreyi paylaşmanızı rica ederiz.",
        "en": "The statement you sent does not appear to cover the "
              "reconciliation period. Please share the statement for the "
              "correct period.",
    },
    REQUEST_DIFFERENCE_EXPLANATION: {
        "tr": "Kayıtlarımız ile ekstreniz arasında eşleşmeyen kalemler "
              "bulunmaktadır. Farkın açıklanmasını rica ederiz.",
        "en": "There are items that do not match between our records and "
              "your statement. We kindly ask for an explanation.",
    },
    REQUEST_CORRECTED_STATEMENT: {
        "tr": "Aşağıdaki kalemler bizim kayıtlarımızda yer almakta, ancak "
              "gönderdiğiniz ekstrede görünmemektedir. Kayıtlarınızı gözden "
              "geçirip güncel ekstreyi paylaşmanızı rica ederiz.\n\n"
              "NOT: Bu kalemlerin faturaları tarafımızda mevcuttur; "
              "yeniden fatura gönderilmesine gerek yoktur.",
        "en": "The items below exist in our records but do not appear in "
              "your statement. Please review your records and share an "
              "updated statement.\n\n"
              "NOTE: We already hold the invoices for these items; there is "
              "no need to resend them.",
    },
    REQUEST_MISSING_INVOICES: {
        "tr": "Aşağıdaki kalemler ekstrenizde yer almakta, ancak bizim "
              "kayıtlarımızda bulunmamaktadır. İlgili faturaları "
              "paylaşmanızı rica ederiz.",
        "en": "The items below appear in your statement but are not present "
              "in our records. We kindly ask you to share the related "
              "invoices.",
    },
    RESOLVE_CONTRADICTION: {
        "tr": "Mailinizde mutabık olduğunuzu belirtmişsiniz; ancak "
              "gönderdiğiniz ekstre ile kayıtlarımız arasında fark "
              "bulunmaktadır. Hangi bilginin esas alınması gerektiğini "
              "teyit etmenizi rica ederiz.",
        "en": "Your message states that you agree; however, there is a "
              "difference between your statement and our records. Please "
              "confirm which figure should be taken as final.",
    },
    REQUEST_READABLE_DOCUMENTS: {
        "tr": "Gönderdiğiniz belge okunamamıştır. Belgeyi okunabilir "
              "biçimde (dijital PDF veya Excel) yeniden paylaşmanızı rica "
              "ederiz.",
        "en": "The document you sent could not be read. Please resend it in "
              "a readable format (digital PDF or Excel).",
    },
}

#: §6 — sade/okunabilir ekstre talebinin ZORUNLU içeriği.
_SADE_EKSTRE = {
    "tr": (
        "Gönderdiğiniz ekstre otomatik olarak okunamamıştır. Mutabakatı "
        "tamamlayabilmemiz için ekstreyi mümkünse Excel ya da aranabilir "
        "PDF biçiminde, aşağıdaki alanları içerecek şekilde paylaşmanızı "
        "rica ederiz:\n"
        "  • Belge / fatura numarası\n"
        "  • Belge tarihi\n"
        "  • Kayıt tarihi\n"
        "  • Tutar\n"
        "  • Para birimi\n"
        "  • Borç / alacak yönü\n"
        "  • Açıklama\n"
        "  • Açık / kapalı durumu\n"
        "  • Mutabakat dönemi\n\n"
        "Ayrıca dosyanın işlenebilmesi için şunları rica ederiz:\n"
        "  • Tek başlık satırı kullanılması\n"
        "  • Birleştirilmiş hücre kullanılmaması\n"
        "  • Formül yerine değerlerin gönderilmesi\n"
        "  • Şifreli dosya gönderilmemesi\n"
        "  • Taranmış fotoğraf yerine dijital çıktı kullanılması\n"
        "  • Logo, boş satır ve ara toplamların kaldırılması\n"
        "  • Birden fazla para birimi varsa açıkça ayrılması"
    ),
    "en": (
        "The statement you sent could not be processed automatically. To "
        "complete the reconciliation, please share it as an Excel file or a "
        "searchable PDF, including the following fields:\n"
        "  • Document / invoice number\n"
        "  • Document date\n"
        "  • Posting date\n"
        "  • Amount\n"
        "  • Currency\n"
        "  • Debit / credit indicator\n"
        "  • Description\n"
        "  • Open / cleared status\n"
        "  • Reconciliation period\n\n"
        "To help us process the file, we also kindly ask for:\n"
        "  • A single header row\n"
        "  • No merged cells\n"
        "  • Values instead of formulas\n"
        "  • No password-protected files\n"
        "  • Digital output instead of scanned photographs\n"
        "  • Removal of logos, blank rows and subtotals\n"
        "  • Clear separation of multiple currencies"
    ),
}

_LISTE_BASLIK = {
    "tr": "Belge No | Tarih | Tutar | Para Birimi | Açıklama",
    "en": "Document No | Date | Amount | Currency | Description",
}


@dataclass
class ActionMail:
    """Hazırlanmış aksiyon maili (henüz GÖNDERİLMEDİ)."""

    case_id: str = ""
    action_type: str = ""
    company_code: str = ""
    company_name: str = ""
    locale: str = ""
    subject: str = ""
    body: str = ""
    attachments: list[str] = field(default_factory=list)
    recipients: str = ""
    cc: str = ""
    row_count: int = 0
    truncated: bool = False
    blocked_reason: str = ""

    @property
    def ready(self) -> bool:
        return not self.blocked_reason


def _fmt(value: Any) -> str:
    """Boş/okunamayan alan UYDURULMAZ: '—' yazılır."""
    text = "" if value is None else str(value).strip()
    return text or "—"


def _fmt_amount(value: Any) -> str:
    if value in (None, ""):
        return "—"
    try:
        return f"{Decimal(str(value)):,.2f}".replace(",", " ")
    except (InvalidOperation, ValueError, TypeError):
        return _fmt(value)


#: İki yönün başlıkları — finansal anlamları FARKLIDIR, karıştırılamaz.
_YON_BASLIK = {
    "only_firma": {
        "tr": "Ekstrenizde olup kayıtlarımızda BULUNMAYAN kalemler:",
        "en": "Items in your statement that are NOT in our records:",
    },
    "only_tofas": {
        "tr": "Kayıtlarımızda olup ekstrenizde GÖRÜNMEYEN kalemler:",
        "en": "Items in our records that do NOT appear in your statement:",
    },
}


def format_rows(rows: Sequence[dict], locale: str) -> tuple[str, bool]:
    """Kanıtlanmış satırları tabloya çevir. (metin, kırpıldı_mı)

    OLMAYAN BİR EKTEN SÖZ EDİLMEZ. Liste kırpıldığında metin "tam liste
    ektedir" DEMEZ — böyle bir ek üretilmiyordu ve firma olmayan bir
    dosyayı arıyordu. Yalnızca kaç kalemin gösterilmediği söylenir.
    """
    if not rows:
        return "", False
    satirlar = [_LISTE_BASLIK.get(locale, _LISTE_BASLIK["tr"])]
    satirlar.append("-" * 64)
    for r in rows[:MAX_SATIR]:
        if not isinstance(r, dict):
            continue
        satirlar.append(" | ".join((
            _fmt(r.get("reference")),
            _fmt(r.get("date")),
            _fmt_amount(r.get("amount")),
            _fmt(r.get("currency")),
            _fmt(r.get("description")),
        )))
    kirpildi = len(rows) > MAX_SATIR
    if kirpildi:
        kalan = len(rows) - MAX_SATIR
        satirlar.append(
            f"… yukarıda yalnızca ilk {MAX_SATIR} kalem gösterilmiştir; "
            f"kalan {kalan} kalem için ayrıca paylaşım yapılacaktır."
            if locale == "tr" else
            f"… only the first {MAX_SATIR} items are shown above; the "
            f"remaining {kalan} items will be shared separately.")
    return "\n".join(satirlar), kirpildi

def format_sections(rows: Any, locale: str) -> tuple[str, int, bool]:
    """Yön bazlı bölümler. (metin, toplam_satır, kırpıldı_mı)

    ``rows`` sözlükse her yön AYRI başlıkla yazılır ve listeler
    BİRLEŞTİRİLMEZ; liste verilirse tek tablo üretilir (geriye uyum).
    """
    if not rows:
        return "", 0, False
    if isinstance(rows, dict):
        parcalar: list[str] = []
        toplam = 0
        kirpildi = False
        for yon in ("only_firma", "only_tofas"):
            satirlar = rows.get(yon) or []
            if not satirlar:
                continue
            tablo, kirp = format_rows(satirlar, locale)
            if not tablo:
                continue
            baslik = _YON_BASLIK[yon].get(locale, _YON_BASLIK[yon]["tr"])
            parcalar += ["", baslik, tablo]
            toplam += len(satirlar)
            kirpildi = kirpildi or kirp
        return "\n".join(parcalar).strip("\n"), toplam, kirpildi
    tablo, kirp = format_rows(list(rows), locale)
    return tablo, len(list(rows)), kirp


def build_action_mail(case: Any, action_type: str, *,
                      rows: Any = None,
                      attachments: Optional[Sequence[str]] = None,
                      ) -> ActionMail:
    """Aksiyon için düzenlenebilir mail taslağı üret."""
    code = str(getattr(case, "company_code", "") or "")
    mail = ActionMail(
        case_id=str(getattr(case, "case_id", "") or ""),
        action_type=action_type,
        company_code=code,
        company_name=str(getattr(case, "company_name", "") or ""),
        subject=reply_subject(str(getattr(case, "subject", "") or "")),
        recipients=str(getattr(case, "recipients", "") or ""),
        cc=str(getattr(case, "cc", "") or ""),
        attachments=list(attachments or []),
    )

    if action_type in INTERNAL_ACTIONS:
        mail.blocked_reason = (
            f"'{ACTION_LABELS.get(action_type, action_type)}' iç bir "
            "aksiyondur; firmaya mail gönderilmez.")
        return mail

    locale = classify_locale(code)
    if locale not in ("tr", "en"):
        # DİL BELİRSİZSE DIŞ MAİL HAZIRLANMAZ (§6).
        mail.blocked_reason = (
            f"Firma kodu '{code}' 2/4 ile başlamıyor; mail dili "
            "belirlenemedi. Yanlış dilde talep gönderilmez.")
        return mail
    mail.locale = locale

    if action_type == REQUEST_SIMPLIFIED_STATEMENT:
        govde = _SADE_EKSTRE[locale]
    else:
        metinler = _GOVDE.get(action_type)
        if not metinler:
            mail.blocked_reason = (
                f"'{action_type}' için mail metni tanımlı değil.")
            return mail
        govde = metinler[locale]

    parcalar = [_SELAM[locale], "", govde]

    # Yön bazlı bölümler: "yalnız firmada" ile "yalnız TOFAŞ'ta"
    # AYRI başlıklar altında yazılır, listeler BİRLEŞTİRİLMEZ.
    tablo, toplam, kirpildi = format_sections(rows, locale)
    mail.row_count = toplam
    mail.truncated = kirpildi
    if tablo:
        parcalar += ["", tablo]

    parcalar += ["", _IMZA[locale]]
    mail.body = "\n".join(parcalar)
    return mail
