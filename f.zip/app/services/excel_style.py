"""Uygulamanın ürettiği TÜM Excel dosyaları için ortak görünüm sabitleri.

NEDEN AYRI MODÜL
    Biçim sabitleri eskiden ``result_writer`` içinde yaşıyordu ve
    ``statement_writer`` başlık rengini oradan import ediyordu: firmaya
    gönderilen ekstre, mutabakat sonucu yazıcısına bağımlı hâle gelmişti.
    Para/tarih biçimleri ise iki dosyada ayrı ayrı tanımlıydı; biri
    değiştiğinde diğeri sessizce farklı görünüyordu.

    Sunum sabitleri artık tek yerde. İki yazıcı da buradan okur; hiçbiri
    diğerine bağımlı değildir.

MUHASEBE GEREKÇESİ
    ``MONEY_FORMAT`` binlik ayracı ve iki ondalık verir: 22.542.009,59
    okunur, 22542009.59 okunmaz. Tutarın Excel'de GERÇEK SAYI olarak
    yazılması şarttır — aksi hâlde kolon toplanamaz, sıralanamaz,
    sayı filtresi uygulanamaz.
"""

from __future__ import annotations

#: Başlık satırı dolgusu (koyu mavi) ve üzerine beyaz kalın yazı.
HEADER_FILL = "FF4472C4"

#: Tutar hücreleri: binlik ayracı + iki ondalık.
MONEY_FORMAT = "#,##0.00"

#: Tarih hücreleri: Türkiye'de okunan biçim.
DATE_FORMAT = "DD.MM.YYYY"

# -- Durum renkleri ---------------------------------------------------------
# Renk tek başına durumu TAŞIMAZ: her satırda ayrıca metin olarak "Blok"
# kolonu vardır. Renk yalnızca gözle tarama hızı içindir (yazdırıldığında ya
# da renk körlüğünde bilgi kaybolmaz).
GREEN = "FFC6EFCE"    # eşleşti
YELLOW = "FFFFEB9C"   # tutar farkı
RED = "FFFFC7CE"      # sadece firmada (TOFAŞ'ta yok)
BLUE = "FFBDD7EE"     # sadece TOFAŞ'ta (firmada yok)
PURPLE = "FFE4DFEC"   # bire-çok eşleşme
ORANGE = "FFFCD5B4"   # para birimi farkı
# FAZ 4 (P0 güvenlik kapısı) — bkz. docs/claude-audit/17. Bu iki kova
# ``matched``/``amount_mismatch``/``currency_diff`` İLE AYNI ANLAMA GELMEZ;
# ayrı renkler kullanıcının bunları karıştırmamasını sağlar.
DARK_RED = "FFFF0000"     # kimlik çelişkisi — BLOCK, mutabık sayılmaz
LIGHT_ORANGE = "FFFFD966" # ekonomik olay çelişkisi — REVIEW, insan bakmalı

#: Olumsuz/uyarı metinleri için koyu kırmızı yazı rengi.
WARN_FONT = "FF9C0006"
