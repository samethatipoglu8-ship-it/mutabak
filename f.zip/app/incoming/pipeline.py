"""Gelen mutabakat maili hattı — orkestrasyon.

    IncomingMail
        ↓
    Python parser (deterministik)
        ↓
    güven / tamlık kontrolü
        ├── yeterli  → sonuç
        └── yetersiz → Copilot Studio ajanı (Direct Line)
                          ↓
                       JSON doğrulama
                          ↓
                       Python ile birleştirme (çelişki → insan)
        ↓
    ReconciliationResponse  (+ idempotency kaydı)

Hat Qt bilmez ve Outlook'a bağlanmaz: arka plan thread'inde güvenle çalışır
(``app/incoming/worker.py`` bunu kullanır). Hiçbir koşulda istisna sızdırmaz;
her mail için mutlaka bir sonuç üretir — en kötü hâlde "insan incelemesi".
"""

from __future__ import annotations

import threading
import time
import uuid
from dataclasses import dataclass
from typing import Callable, Iterable, Optional, Sequence

from loguru import logger

from app.incoming.ai_agent import CopilotReconciliationAgent
from app.incoming.idempotency import ProcessedMailStore
from app.incoming.mail_parser import MailParser
from app.incoming.merge import MergeConfig, merge
from app.incoming.models import (
    REVIEW_PARSER_ERROR,
    AIAnalysisResult,
    AIReviewStatus,
    IncomingMail,
    ParsedMailResult,
    ReconciliationResponse,
)

# Aynı mail başka bir işlem tarafından işleniyor.
REVIEW_DUPLICATE_IN_PROGRESS = "DUPLICATE_IN_PROGRESS"


@dataclass
class PipelineConfig:
    """Hattın davranışı."""

    # Python sonucunun AI'sız kabul edilebilmesi için gereken asgari güven.
    min_confidence: float = 0.75
    use_ai: bool = True
    store_results: bool = True
    # SİGORTA: ajan üst üste bu kadar kez cevap veremezse partinin kalanında
    # AI hiç denenmez. 500 mailin her biri için 4 deneme × 90 sn beklemek,
    # kullanıcı için "uygulama takıldı" demektir.
    ai_failure_threshold: int = 3

    # SİGORTA KENDİNİ SIFIRLAR (yarı-açık deneme).
    #
    # Eskiden sigorta bir kez açıldığında BİR DAHA KAPANMIYORDU: açıkken
    # AI hiç çağrılmadığı için "sağlıklı cevap" da gelemiyor, dolayısıyla
    # sıfırlama koşulu asla oluşmuyordu. Geçici bir ağ kesintisi, süreç
    # kapanana kadar AI'ı kalıcı olarak devre dışı bırakıyordu.
    #
    # Bu süre geçtikten sonra TEK bir deneme yapılır: başarılıysa sigorta
    # kapanır, başarısızsa yeniden açılır ve süre baştan başlar.
    ai_circuit_cooldown: float = 300.0   # saniye


class IncomingMailPipeline:
    """Gelen mailleri uçtan uca çözümler."""

    def __init__(
        self,
        parser: Optional[MailParser] = None,
        agent: Optional[CopilotReconciliationAgent] = None,
        store: Optional[ProcessedMailStore] = None,
        config: Optional[PipelineConfig] = None,
        merge_config: Optional[MergeConfig] = None,
    ) -> None:
        self._parser = parser or MailParser()
        self._agent = agent
        self._store = store
        self._config = config or PipelineConfig()
        self._merge_config = merge_config or MergeConfig()
        self._ai_failures = 0
        self._circuit_open = False
        self._circuit_opened_at: Optional[float] = None
        self._ai_lock = threading.Lock()

    @property
    def config(self) -> PipelineConfig:
        return self._config

    @property
    def agent(self) -> Optional[CopilotReconciliationAgent]:
        return self._agent

    # -- tek mail ----------------------------------------------------------

    def process(self, mail: IncomingMail,
                should_cancel: Optional[Callable[[], bool]] = None,
                request_id: str = "") -> ReconciliationResponse:
        """Tek bir maili işle. İSTİSNA FIRLATMAZ."""
        request_id = request_id or uuid.uuid4().hex[:12]
        started = time.monotonic()
        fingerprint = mail.fingerprint

        # 1) İdempotency: aynı mail ikinci kez AI'ya GİTMEZ.
        claim = None
        if self._store is not None:
            try:
                claim = self._store.claim(fingerprint, mail.message_id,
                                          mail.subject)
            except Exception as exc:  # noqa: BLE001 - kayıt hatası işi durdurmaz
                logger.error(
                    f"[incoming] request_id={request_id} idempotency kaydı "
                    f"okunamadı, mail yine de işlenecek: {exc}")
                claim = None
            if claim is not None and claim.duplicate:
                if claim.cached is not None:
                    logger.info(
                        f"[incoming] request_id={request_id} "
                        f"message_id={mail.message_id or '-'} "
                        "status=CACHED (daha önce işlendi, AI çağrılmadı)")
                    return claim.cached
                response = self._minimal_response(mail)
                response.add_reason(REVIEW_DUPLICATE_IN_PROGRESS)
                response.needs_human_review = True
                response.ai_error = claim.reason
                logger.warning(
                    f"[incoming] request_id={request_id} "
                    f"message_id={mail.message_id or '-'} "
                    f"status=DUPLICATE ({claim.reason})")
                return response

        try:
            response = self._run(mail, should_cancel, request_id)
        except Exception as exc:  # noqa: BLE001 - tek mail tüm partiyi düşürmesin
            logger.exception(
                f"[incoming] request_id={request_id} "
                f"message_id={mail.message_id or '-'} status=PARSER_ERROR")
            response = self._minimal_response(mail)
            response.add_reason(REVIEW_PARSER_ERROR)
            response.needs_human_review = True
            response.ai_error = f"{type(exc).__name__}: {exc}"
            if self._store is not None:
                self._store.fail(fingerprint, response.ai_error)
            return response

        response.duration_ms = int((time.monotonic() - started) * 1000)

        if self._store is not None and self._config.store_results:
            try:
                self._store.complete(fingerprint, response)
            except Exception as exc:  # noqa: BLE001 - sonuç yine de döner
                logger.error(
                    f"[incoming] request_id={request_id} sonuç kaydedilemedi: "
                    f"{exc}")

        logger.info(
            f"[incoming] request_id={request_id} "
            f"message_id={mail.message_id or '-'} "
            f"company_code={response.company_code or '-'} "
            f"reply={response.reply_type.value} "
            f"ai={response.review_status.value} "
            f"confidence={response.confidence:.2f} "
            f"review={'yes' if response.needs_human_review else 'no'} "
            f"duration_ms={response.duration_ms}")
        return response

    # -- toplu -------------------------------------------------------------

    def process_many(
        self,
        mails: Sequence[IncomingMail],
        on_progress: Optional[Callable[[int, int, IncomingMail], None]] = None,
        should_cancel: Optional[Callable[[], bool]] = None,
    ) -> list[ReconciliationResponse]:
        """Birden çok maili sırayla işle; iptal KOOPERATİFTİR.

        İptal edildiğinde o ana kadar üretilen sonuçlar döner — yarım kalan
        mail kaydedilmez, sonraki çalıştırmada baştan işlenir.
        """
        results: list[ReconciliationResponse] = []
        total = len(mails)
        for index, mail in enumerate(mails, start=1):
            if should_cancel is not None and should_cancel():
                break
            results.append(self.process(mail, should_cancel))
            if on_progress is not None:
                try:
                    on_progress(index, total, mail)
                except Exception:  # noqa: BLE001 - ilerleme bildirimi kritik değil
                    pass
        return results

    # -- iç akış -----------------------------------------------------------

    def _run(self, mail: IncomingMail,
             should_cancel: Optional[Callable[[], bool]],
             request_id: str) -> ReconciliationResponse:
        parsed: ParsedMailResult = self._parser.parse(mail)

        if not self._needs_ai(parsed):
            return merge(parsed, None, mail, self._merge_config)

        ai = self._call_ai(mail, parsed, should_cancel, request_id)
        return merge(parsed, ai, mail, self._merge_config)

    def _needs_ai(self, parsed: ParsedMailResult) -> bool:
        """AI fallback gerekli mi? (Python yeterliyse ÇAĞRILMAZ.)"""
        if not self._config.use_ai or self._agent is None:
            return False
        return not parsed.is_confident(self._config.min_confidence)

    def _call_ai(self, mail: IncomingMail, parsed: ParsedMailResult,
                 should_cancel: Optional[Callable[[], bool]],
                 request_id: str) -> AIAnalysisResult:
        agent = self._agent
        if agent is None:  # pragma: no cover - _needs_ai zaten kontrol etti
            return AIAnalysisResult(status=AIReviewStatus.DISABLED,
                                    request_id=request_id,
                                    needs_human_review=True)

        if not agent.available:
            return AIAnalysisResult(
                status=AIReviewStatus.DISABLED,
                request_id=request_id,
                error_code="DIRECT_LINE_DISABLED",
                reason=("Direct Line secret girilmemiş ya da kapalı; "
                        "AI fallback atlandı."),
                needs_human_review=True,
            )

        with self._ai_lock:
            circuit_open = self._circuit_open
            if circuit_open and self._circuit_opened_at is not None:
                gecen = time.monotonic() - self._circuit_opened_at
                if gecen >= self._config.ai_circuit_cooldown:
                    # Soğuma doldu: YARI AÇIK. Tek bir deneme yapılır.
                    self._circuit_open = False
                    self._circuit_opened_at = None
                    self._ai_failures = 0
                    circuit_open = False
                    logger.info(
                        f"[incoming] AI sigortası {gecen:.0f} sn sonra "
                        "yeniden deneniyor (yarı açık).")
        if circuit_open:
            return AIAnalysisResult(
                status=AIReviewStatus.AI_UNAVAILABLE,
                request_id=request_id,
                error_code="AI_CIRCUIT_OPEN",
                reason=(f"Ajan üst üste {self._config.ai_failure_threshold} kez "
                        "cevap veremedi; partinin kalanında AI denenmiyor. "
                        "Mailler insan incelemesine düşer."),
                needs_human_review=True,
            )

        try:
            result = agent.analyze(mail, parsed, request_id=request_id,
                                   should_cancel=should_cancel)
        except Exception as exc:  # noqa: BLE001 - AI hiçbir zaman hattı düşürmez
            logger.exception(
                f"[incoming] request_id={request_id} AI çağrısı beklenmedik "
                "biçimde başarısız oldu.")
            result = AIAnalysisResult(
                status=AIReviewStatus.AI_UNAVAILABLE,
                request_id=request_id,
                error_code="AI_CALL_FAILED",
                reason=f"{type(exc).__name__}: {exc}",
                needs_human_review=True,
            )

        self._record_ai_outcome(result)
        return result

    def _record_ai_outcome(self, result: AIAnalysisResult) -> None:
        """Sigortayı güncelle: art arda hatalar eşiği geçerse AI'yı kapat."""
        healthy = result.status in (AIReviewStatus.ACCEPTED,
                                    AIReviewStatus.AI_INVALID_JSON)
        with self._ai_lock:
            if healthy:
                # Cevap geldi (JSON bozuk olsa bile servis AYAKTA).
                self._ai_failures = 0
                return
            self._ai_failures += 1
            if (not self._circuit_open
                    and self._ai_failures >= self._config.ai_failure_threshold):
                self._circuit_open = True
                self._circuit_opened_at = time.monotonic()
                logger.error(
                    f"[incoming] AI sigortası AÇILDI: {self._ai_failures} "
                    f"ardışık hata ({result.error_code}). Bu partide AI "
                    "artık denenmeyecek; mailler insan incelemesine düşer.")

    @property
    def ai_circuit_open(self) -> bool:
        """Ajan cevap vermediği için AI devre dışı mı?"""
        with self._ai_lock:
            return self._circuit_open

    def reset_ai_circuit(self) -> None:
        """Sigortayı elle kapat (kullanıcı yeniden denemek istediğinde)."""
        with self._ai_lock:
            self._ai_failures = 0
            self._circuit_open = False

    @staticmethod
    def _minimal_response(mail: IncomingMail) -> ReconciliationResponse:
        return ReconciliationResponse(
            message_id=mail.message_id,
            fingerprint=mail.fingerprint,
            subject=mail.subject,
            sender=mail.sender,
            needs_human_review=True,
        )


def build_default_pipeline(store_path: Optional[str] = None,
                           use_ai: bool = True) -> IncomingMailPipeline:
    """Uygulamanın kullandığı varsayılan hat (main.py yapılandırmasına uyar).

    Direct Line secret girilmemişse AI katmanı yine kurulur ama çağrı
    yapılmaz: ilgili mailler ``DISABLED`` durumu ve insan incelemesi ile
    sonuçlanır — sessizce "her şey yolunda" denmez.
    """
    from app.incoming.ai_config import current_config
    from app.incoming.direct_line_client import DirectLineClient

    client = DirectLineClient(current_config())
    agent = CopilotReconciliationAgent(client)
    store = ProcessedMailStore(store_path) if store_path is not None \
        else ProcessedMailStore()
    return IncomingMailPipeline(
        agent=agent, store=store,
        config=PipelineConfig(use_ai=use_ai),
    )


def summarize(responses: Iterable[ReconciliationResponse]) -> dict[str, int]:
    """Toplu sonuç özeti (UI/log için)."""
    summary = {
        "toplam": 0, "insan_incelemesi": 0, "ai_cagrildi": 0,
        "ai_catisma": 0, "ai_ulasilamadi": 0, "onbellek": 0,
    }
    for response in responses:
        summary["toplam"] += 1
        if response.needs_human_review:
            summary["insan_incelemesi"] += 1
        if response.review_status in (AIReviewStatus.ACCEPTED,
                                      AIReviewStatus.CONFLICT):
            summary["ai_cagrildi"] += 1
        if response.review_status is AIReviewStatus.CONFLICT:
            summary["ai_catisma"] += 1
        if response.review_status in (AIReviewStatus.AI_UNAVAILABLE,
                                      AIReviewStatus.AI_INVALID_JSON,
                                      AIReviewStatus.AI_AUTH_FAILED):
            summary["ai_ulasilamadi"] += 1
        if response.from_cache:
            summary["onbellek"] += 1
    return summary
