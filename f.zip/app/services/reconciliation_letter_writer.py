"""PHASE C — segment başına mutabakat mektubu PDF üretimi.

Akış (şablon ASLA değiştirilmez):

    şablon PDF (salt okunur, bellekte önbelleklenir)
          +
    ReportLab ile üretilen şeffaf kaplama
          ↓
    pypdf merge_page
          ↓
    <firma>_<yön>_mutabakat.pdf

Kurallar (PHASE A/A.1/B kararlarıyla birebir):
  - Segment başına bir PDF: M ve S ayrı dosyalar, firma başına tek mail.
  - Yön kararı BURADA VERİLMEZ; ``StatementSegment`` olduğu gibi işlenir.
  - Yalnızca tutarı olan dövizler yazılır (``segment.display_balances``).
  - Bakiye 0 olsa bile PDF üretilir; metin ``mail_builder.zero_balance_block``.
  - Dil ``mail_builder.classify_locale`` ile firma kodundan belirlenir.
  - Türkçe şablon yoksa MISSING_TR_LETTER_TEMPLATE üretilir ve firma uyarı
    listesine yazılır; sahte Türkçe metin ÜRETİLMEZ.
  - Metin sığmazsa punto kademeli küçültülür; asla kısaltılmaz.

Qt, Outlook, harici program ya da web servisi kullanılmaz. Yalnızca
``reportlab`` (üretim), ``pypdf`` (birleştirme) ve ``PyYAML`` (yapılandırma).
"""

from __future__ import annotations

import io
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Iterable, Optional

from app.mailing.mail_builder import (
    _last_day_of_month,
    classify_locale,
    fmt_amount_tr,
    zero_balance_block,
)
from app.services.company_statement_service import (
    CompanyPackageDraft,
    StatementSegment,
)
from app.services.pdf_template import (
    BalanceBlock,
    FieldBox,
    MissingTemplateError,
    PdfTemplate,
    TemplateError,
    load_template,
    require_clean_template,
)

# Yön -> dosya adı eki (statement_writer ile aynı desen).
_DIRECTION_LABEL = {"M": "M", "S": "S", "": "TUM"}

# Desteklenen mektup dilleri. Dil belirlenemezse (firma kodu 2/4 ile
# başlamıyorsa) mektup ÜRETİLMEZ: yanlış dilde bir mutabakat mektubu geri
# alınamaz bir hatadır. Bu, mail_builder'daki toplu gönderim guard'ının
# (needs_confirmation) dosya tarafındaki karşılığıdır.
_SUPPORTED_LOCALES = ("tr", "en")
UNKNOWN_LOCALE_CODE = "UNKNOWN_LETTER_LOCALE"

# Bu işaretlerle başlayan uyarılar mektubu GÜVENSİZ kılar: metin sayfaya
# sığmamış ya da bakiye eksik yazılmıştır. Çağıran taraf bunları gönderimi
# engellemek için kullanır (bkz. CompanyPackageService).
BLOCKING_WARNING_MARKS = (
    "PDF alanı",              # metin alana sığmadı (sayfadan taşabilir)
    "PDF bakiye bloğuna",     # döviz satırları bloğa sığmadı
    "PDF bakiye satırı",      # tek bir bakiye satırı taştı
)


def is_blocking_warning(text: str) -> bool:
    """Bu uyarı mektubu gönderilemez kılar mı?"""
    return str(text).startswith(BLOCKING_WARNING_MARKS)


def template_status(
    locale: str,
    config_dir: Optional[Path] = None,
    project_root: Optional[Path] = None,
) -> str:
    """Şablon üretime hazır mı? Hazırsa boş string, değilse GEREKÇE.

    Gerekçe eksik dosyanın TAM YOLUNU içerir. Amaç, 600 firma için Excel
    üretip sonra "mektup üretilemedi" demek yerine, üretime BAŞLAMADAN önce
    kullanıcıya neyin eksik olduğunu söylemektir.
    """
    try:
        template = load_template(locale, config_dir, project_root)
        require_clean_template(template)
    except TemplateError as exc:
        return f"{getattr(exc, 'code', 'TEMPLATE_ERROR')}: {exc}"
    except Exception as exc:  # noqa: BLE001 - beklenmedik hata da rapor edilir
        return f"TEMPLATE_ERROR: {type(exc).__name__}: {exc}"
    return ""


def missing_templates(
    locales: Iterable[str],
    config_dir: Optional[Path] = None,
    project_root: Optional[Path] = None,
) -> dict[str, str]:
    """Verilen diller için eksik/bozuk şablonları döndür (dil -> gerekçe)."""
    problems: dict[str, str] = {}
    for locale in dict.fromkeys(locales):
        if locale not in _SUPPORTED_LOCALES:
            continue
        reason = template_status(locale, config_dir, project_root)
        if reason:
            problems[locale] = reason
    return problems


_registered_fonts: set[str] = set()


def letter_file_name(draft: CompanyPackageDraft,
                     segment: StatementSegment) -> str:
    """Mektup dosya adı: firma kodu + yön bilgisi taşır."""
    label = _DIRECTION_LABEL.get(segment.ms, segment.ms or "TUM")
    return f"{draft.company_code}_{label}_mutabakat.pdf"


@dataclass
class LetterPeriod:
    """Mektubun ait olduğu dönem.

    ``as_of``   : mutabakat tarihi — uygulamada seçilen ayın SON günü.
    ``issued_on``: mektubun düzenlenme/gönderim tarihi. Verilmezse bugündür;
                   testlerin sabit kalması için elle verilebilir.
    """

    year: int
    month: int
    issued_on: Optional[date] = None

    @property
    def as_of(self) -> date:
        return date(self.year, self.month,
                    _last_day_of_month(self.year, self.month))

    @property
    def issue_date(self) -> date:
        return self.issued_on or date.today()


def _register_fonts(template: PdfTemplate) -> None:
    """TTF fontları bir kez kaydet.

    Varsayılan Bitstream Vera reportlab ile birlikte gelir ve Türkçe karakter
    kapsamı tamdır (ş ğ ı İ ö ü ç). Kendi fontunuzu kullanmak için YAML'da
    dosya adı verin; makinenin sistem font klasörüne GÜVENİLMEZ.
    """
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont

    for name, file_name in (
        (template.font_regular, template.font_regular_file),
        (template.font_bold, template.font_bold_file),
    ):
        if name in _registered_fonts:
            continue
        try:
            pdfmetrics.getFont(name)
            _registered_fonts.add(name)
            continue
        except KeyError:
            pass
        pdfmetrics.registerFont(TTFont(name, file_name or f"{name}.ttf"))
        _registered_fonts.add(name)


_SIZE_STEP = 0.5


def _fit_size(text: str, font: str, max_width: float,
              size: float, min_size: float) -> tuple[float, bool]:
    """Metni sığdıran en büyük puntoyu bul.

    ``size``dan başlayıp yarımşar punto düşer; ``min_size``ın altına İNMEZ.
    Yarım punto adımı, şablondaki dar boşluklarda (ör. satır içi tarih)
    gereksiz yere küçülmeyi önler.

    Dönüş: (punto, sığdı mı). Sığmasa bile metin KISALTILMAZ.
    """
    from reportlab.pdfbase.pdfmetrics import stringWidth

    current = size
    while current >= min_size:
        if stringWidth(text, font, current) <= max_width:
            return current, True
        current -= _SIZE_STEP
    return max(min_size, 1.0), False


class ReconciliationLetterWriter:
    """Segment bazlı mutabakat mektubu PDF yazıcısı (Qt'siz, saf Python)."""

    def __init__(
        self,
        config_dir: Optional[Path] = None,
        project_root: Optional[Path] = None,
    ) -> None:
        self._config_dir = Path(config_dir) if config_dir else None
        self._project_root = Path(project_root) if project_root else None
        self._templates: dict[str, PdfTemplate] = {}
        self._template_bytes: dict[str, bytes] = {}

    # -- şablon ------------------------------------------------------------

    def template_for(self, locale: str) -> PdfTemplate:
        """Dile ait şablonu yükle, temizliğini doğrula ve önbellekle."""
        if locale in self._templates:
            return self._templates[locale]
        template = load_template(locale, self._config_dir, self._project_root)
        require_clean_template(template)          # kirliyse DirtyTemplateError
        _register_fonts(template)
        self._templates[locale] = template
        # Şablon bir kez okunur; her çıktı için diskten tekrar açılmaz ve
        # dosyanın kendisine ASLA yazılmaz.
        self._template_bytes[locale] = template.pdf_path.read_bytes()
        return template

    @staticmethod
    def locale_for(draft: CompanyPackageDraft) -> str:
        """Firma kodundan dil. Belirlenemezse 'unknown' döner — İngilizce'ye
        SESSİZCE düşülmez."""
        return classify_locale(draft.company_code)

    # -- üretim ------------------------------------------------------------

    def write(
        self,
        segment: StatementSegment,
        draft: CompanyPackageDraft,
        output_dir: str | Path,
        period: LetterPeriod,
    ) -> Path:
        """Tek bir segment için mektup üret ve yazılan yolu döndür."""
        locale = self.locale_for(draft)
        template = self.template_for(locale)

        overlay = self._build_overlay(segment, draft, template, period)
        target = Path(output_dir)
        target.mkdir(parents=True, exist_ok=True)
        out_path = target / letter_file_name(draft, segment)

        import pypdf

        # Her çıktı için şablonun TAZE bir kopyası klonlanır: merge_page sayfayı
        # yerinde değiştirir, bu yüzden önbellekteki sayfa nesnesi paylaşılmaz
        # ve şablon dosyasına asla dokunulmaz.
        writer = pypdf.PdfWriter(clone_from=io.BytesIO(
            self._template_bytes[locale]))
        writer.pages[0].merge_page(
            pypdf.PdfReader(io.BytesIO(overlay)).pages[0])
        with out_path.open("wb") as fh:
            writer.write(fh)
        return out_path

    def write_package(
        self,
        draft: CompanyPackageDraft,
        output_dir: str | Path,
        period: LetterPeriod,
    ) -> list[Path]:
        """Firmanın TÜM segmentleri için mektup üret.

        Dil belirlenemiyorsa ya da şablon eksikse firma uyarı listesine yazılır
        ve boş liste döner; üretim sessizce başka bir dile DÜŞMEZ.
        """
        locale = self.locale_for(draft)
        if locale not in _SUPPORTED_LOCALES:
            message = (
                f"{UNKNOWN_LOCALE_CODE}: firma kodu '{draft.company_code}' "
                "2/4 ile başlamıyor; dil belirlenemedi, mektup üretilmedi."
            )
            if message not in draft.warnings:
                draft.warnings.append(message)
            return []
        try:
            self.template_for(locale)
        except MissingTemplateError as exc:
            message = f"{exc.code}: {exc}"
            if message not in draft.warnings:
                draft.warnings.append(message)
            return []
        return [self.write(seg, draft, output_dir, period)
                for seg in draft.segments]

    def write_all(
        self,
        drafts: Iterable[CompanyPackageDraft],
        output_dir: str | Path,
        period: LetterPeriod,
    ) -> dict[str, list[Path]]:
        """Tüm firmalar için üret; firma kodu -> mektup yolları."""
        return {d.company_code: self.write_package(d, output_dir, period)
                for d in drafts}

    # -- kaplama -----------------------------------------------------------

    def _build_overlay(
        self,
        segment: StatementSegment,
        draft: CompanyPackageDraft,
        template: PdfTemplate,
        period: LetterPeriod,
    ) -> bytes:
        """Şablonun üzerine bindirilecek şeffaf sayfayı üret."""
        from reportlab.pdfgen import canvas

        buf = io.BytesIO()
        pdf = canvas.Canvas(buf, pagesize=(template.page_width,
                                           template.page_height))
        as_of = period.as_of.strftime(template.date_format)

        values = {
            "company_code": draft.company_code,
            "company_name": draft.company_name,
            "company_name_bottom": draft.company_name,
            "date_inline": as_of,
            "date_bottom": as_of,
            # Mektubun gönderildiği günün tarihi (mutabakat tarihinden farklı).
            "letter_date": period.issue_date.strftime(template.date_format),
        }

        for name, box in template.fields.items():
            text = values.get(name, "")
            self._draw_field(pdf, template, box, text, draft, name)

        if template.balances is not None:
            self._draw_balances(pdf, template, template.balances,
                                segment, draft)

        pdf.showPage()
        pdf.save()
        return buf.getvalue()

    def _cover(self, pdf, template: PdfTemplate,
               box: tuple[float, float, float, float]) -> None:
        """Yer tutucunun üzerini beyazla kapat.

        Yalnızca şablonda kapatılacak yer tutucu VARSA çizilir. Boş bir
        şablonda beyaz dikdörtgen çizmek, konum bir tık kayarsa gerçek
        içeriği siler. Şablon dosyası hiçbir durumda DEĞİŞMEZ; beyaz
        dikdörtgen yalnızca çıktıya çizilir.
        """
        if not template.cover_placeholders:
            return
        x0, y0, x1, y1 = box
        pdf.saveState()
        pdf.setFillColorRGB(1, 1, 1)
        pdf.setStrokeColorRGB(1, 1, 1)
        pdf.rect(x0, template.to_reportlab_y(y1),
                 x1 - x0, y1 - y0, stroke=0, fill=1)
        pdf.restoreState()

    def _draw_field(self, pdf, template: PdfTemplate, box: FieldBox,
                    text: str, draft: CompanyPackageDraft, name: str) -> None:
        self._cover(pdf, template, box.cover(template.cover_padding))
        if not text:
            return
        text = box.render(text)
        size, fits = _fit_size(text, template.font_regular, box.max_width,
                               box.size, box.min_size)
        if not fits:
            warning = (f"PDF alanı '{name}' taştı: '{text}' {box.max_width:.0f}"
                       f" pt alana {size:.0f} punto ile sığmadı.")
            if warning not in draft.warnings:
                draft.warnings.append(warning)
        pdf.setFont(template.font_regular, size)
        pdf.setFillColorRGB(0, 0, 0)
        y = template.to_reportlab_y(box.baseline_top)
        if box.align == "right":
            pdf.drawRightString(box.x1, y, text)
        elif box.align == "center":
            pdf.drawCentredString(box.center_x, y, text)
        else:
            pdf.drawString(box.x0, y, text)

    def _draw_balances(self, pdf, template: PdfTemplate, block: BalanceBlock,
                       segment: StatementSegment,
                       draft: CompanyPackageDraft) -> None:
        self._cover(pdf, template, block.cover_box)

        lines = self._balance_lines(segment, draft)
        if len(lines) > block.max_lines:
            draft.warnings.append(
                f"PDF bakiye bloğuna {len(lines)} satır sığmıyor "
                f"(en fazla {block.max_lines})."
            )
            lines = lines[:block.max_lines]

        pdf.setFillColorRGB(0, 0, 0)
        for i, text in enumerate(lines):
            size, fits = _fit_size(text, template.font_regular,
                                   block.max_width, block.size, block.min_size)
            if not fits:
                draft.warnings.append(f"PDF bakiye satırı taştı: '{text}'.")
            pdf.setFont(template.font_regular, size)
            pdf.drawString(block.x0,
                           template.to_reportlab_y(block.line_baseline(i)),
                           text)

    @staticmethod
    def _balance_lines(segment: StatementSegment,
                       draft: CompanyPackageDraft) -> list[str]:
        """Yazılacak bakiye satırları.

        Yalnızca TUTARI OLAN dövizler (PHASE A kural 12; kuruş hassasiyetli
        karar segmentte verilmiştir). Hepsi sıfırsa sıfır bakiye metni.
        """
        if not segment.display_balances:
            locale = classify_locale(draft.company_code)
            return [zero_balance_block(locale, draft.zero_balance_currency)]
        return [f"{currency}: {fmt_amount_tr(amount)}"
                for currency, amount in segment.display_balances.items()]
