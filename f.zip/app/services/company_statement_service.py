"""PHASE A — FBL1H tek dosyasını firma bazlı ekstrelere ayırma ve mutabakat
raporuyla birleştirme.

SAP FBL1H'dan tüm firmalar için tek seferde alınan Excel çıktısı okunur, satırlar
``Firma Kodu`` kolonuna göre gruplanır ve her firma için kendi ekstresi
(``CompanyStatement``) üretilir. Ardından daha önce yüklenmiş mutabakat raporu
Excel'i (``app.mailing.excel_loader.MailRow``) ile firma kodu üzerinden
karşılaştırılır ve her firma için bir ``CompanyPackageDraft`` çıkar.

İş kuralları (kullanıcı onaylı):
  1. FBL1H tek dosya olarak yüklenir.
  2. Satırlar Firma Kodu'na göre ayrılır.
  3. Her firmanın ekstresi yalnızca kendi satırlarından oluşur.
  4. Ara toplam / genel toplam ve açılış (devir) satırları dışlanır.
  5. Bakiye BELGE para birimi (EUR / USD / TRY) bazında hesaplanır.
  6. Mutabakat raporu ile firma kodu üzerinden karşılaştırılır.
  7. Tutar farklıysa **FBL1H güncel kaynaktır**; bakiye FBL1H ile güncellenir.
  8. Tutar aynıysa mevcut kayıt korunmuş sayılır.
  9. Bakiye 0 olsa bile firma paketi üretilir.
 10. Gönderimi engelleyen hiçbir 0 filtresi uygulanmaz.
 11. M/S/X hesap filtresi (kullanıcı tarafından kesinleştirildi):
       M   -> ana hesabı "120" ile BAŞLAYAN kayıtlar,
       S   -> ana hesabı "120" ile BAŞLAMAYAN kayıtlar,
       X   -> S ile aynı.
     M/S/X bilgisi FBL1H'da değil, mutabakat raporundaki firma kaydındadır;
     bu yüzden filtre yükleme sırasında değil, birleştirme sırasında uygulanır.
 12. Sıfır bakiye görünümü: döviz listesinde yalnızca tutarı OLAN dövizler yer
     alır (EUR=0, USD=5000 ise yalnızca USD). Firma tüm dövizlerde 0 ise mail
     yine gider; metin ``mail_builder.zero_balance_block`` ile üretilir.
 13. Segment yapısı: bir firmanın raporda hem M hem S/X kaydı olabilir. Her yön
     KENDİ ekstresini (segment) alır — ayrı Excel üretilecek — ama firma
     seviyesinde TEK mail paketi kalır:

         CompanyPackageDraft (firma = tek mail)
           └── segments: list[StatementSegment]
                 ├── M  -> ana hesabı 120* olan satırlar
                 └── S  -> ana hesabı 120 ile başlamayan satırlar (X dahil)

Mutabakat motoru, Outlook, PDF ve UI'a dokunulmaz.

Bu modül saf veri işler: dosya yazmaz, Qt kullanmaz, Outlook'a bağlanmaz.
Bu sayede tamamen test edilebilir ve arka plan thread'inde güvenle çalışır.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from pathlib import Path
from typing import Iterable, Optional, Sequence

from app.mailing.excel_loader import MailRow
from app.mailing.mail_builder import effective_ms, normalize_code
from app.models.domain import TofasRecord
from app.services.column_mapper import _norm as _norm_header
from app.services.column_mapper import map_tofas_columns
from app.services.customer_accounts import CustomerAccountMap, normalize_account
from app.services.errors import MappingError

# Mevcut yükleyicinin doğrulanmış yardımcıları. loader.py'ye DOKUNULMADIĞI için
# (kullanıcı kararı) bu iç fonksiyonlar olduğu gibi yeniden kullanılır; mantık
# ikinci kez yazılmaz.
from app.services.loader import _cell, _is_blank, _read_any
from app.services.totals import is_opening_row, is_total_row
from app.utils.email import is_valid_email
from app.utils.normalization import (
    clean_currency,
    clean_string,
    normalize_amount,
    normalize_date,
    normalize_reference,
)

_EXTRACTION_FBL1H = "deterministic_tabular"
_CENT = Decimal("0.01")
_ZERO = Decimal("0")

# Kural 11: "M" yönü müşteri/cari (120*) hesaplarını, "S"/"X" yönü 120 ile
# BAŞLAMAYAN tüm hesapları kapsar. Kullanıcı tarafından kesinleştirilmiş kural.
CUSTOMER_ACCOUNT_PREFIX = "120"

# Bakiye gösterim sırası; listede olmayan para birimleri alfabetik olarak sona
# eklenir (determinizm).
_CURRENCY_ORDER = ("TRY", "EUR", "USD")

# Segment sırası: önce M (müşteri/120*), sonra S (satıcı/120 dışı), en son yön
# bilinmeyen tek segment. Determinizm için sabittir.
_SEGMENT_ORDER = ("M", "S", "")

# Rapor Excel'i bakiyeleri "TL" koduyla tutar; FBL1H "TRY" yazar. İki taraf da
# clean_currency ile kanonikleştirilir (TL/TRL -> TRY).
_FALLBACK_CURRENCY = "TRY"

# "Şirket kodu para birimi" (ulusal para) kolonları column_mapper'da tanımlı
# değildir; yalnızca bu serviste, ikincil bilgi olarak tanınır. Ana bakiye
# hesabı DAİMA belge para biriminden yapılır (kural 5).
_LOCAL_AMOUNT_HEADERS = frozenset(_norm_header(h) for h in (
    "Şirket kodu para birimi değeri",
    "Ulusal para birimi değeri",
    "Ulusal para biriminde tutar",
))
_LOCAL_CURRENCY_HEADERS = frozenset(_norm_header(h) for h in (
    "Şirket kodu para birimi anahtarı",
    "Ulusal para birimi anahtarı",
))

# FBL5H (müşteri kalemleri) kimlik kolonları. column_mapper SAP'ın SATICI
# şablonuna göre yazıldığı için müşteri karşılıkları burada tanınır; böylece
# column_mapper.py'ye dokunulmaz. Gerçek FBL5H çıktısı geldiğinde bu listeler
# genişletilir — tanınmazsa sessizce boş kalmaz, MappingError verilir.
_CUSTOMER_CODE_HEADERS = frozenset(_norm_header(h) for h in (
    "Müşteri", "Müşteri numarası", "Müşteri no", "Müşteri kodu",
    "Müşteri hesabı", "Ortak hesap", "Cari hesap", "Müşteri hesap numarası",
))
_CUSTOMER_NAME_HEADERS = frozenset(_norm_header(h) for h in (
    "Müşteri hesabı: Ad 1", "Müşteri hesabı Ad 1", "Müşteri adı", "Ad 1",
    "Müşteri: Ad 1",
))


class StatementSource(str, Enum):
    """Ekstre hangi SAP raporundan geldi?

    Kullanıcı kararı: iki dosya AYRI yüklenir ve yön kaynağa göre belirlenir.
      FBL1H (satıcı münferit kalemleri) -> S / X segmenti
      FBL5H (müşteri münferit kalemleri) -> M segmenti

    Böylece "120 satırı hangi firmaya ait?" sorusu ortadan kalkar: müşteri
    raporu müşteri kodunu zaten taşır, eşleme tablosuna gerek kalmaz.
    """

    VENDOR_FBL1H = "FBL1H"
    CUSTOMER_FBL5H = "FBL5H"


# Yön -> o yönü besleyen kaynak. Yön bilinmiyorsa satıcı raporu kullanılır.
_SOURCE_FOR_DIRECTION: dict[str, StatementSource] = {
    "M": StatementSource.CUSTOMER_FBL5H,
    "S": StatementSource.VENDOR_FBL1H,
    "": StatementSource.VENDOR_FBL1H,
}

_SOURCE_LABEL = {
    StatementSource.VENDOR_FBL1H: "FBL1H (satıcı ekstresi)",
    StatementSource.CUSTOMER_FBL5H: "FBL5H (müşteri ekstresi)",
}


class BalanceStatus(str, Enum):
    """Firma bakiyesinin FBL1H ile rapor arasındaki durumu."""

    UNCHANGED = "UNCHANGED"                      # Kural 8: tutar aynı, korunmuş
    UPDATED_FROM_FBL1H = "UPDATED_FROM_FBL1H"    # Kural 7: fark var, FBL1H kazandı
    NEW_IN_FBL1H = "NEW_IN_FBL1H"                # Raporda yok, FBL1H'da var
    MISSING_IN_FBL1H = "MISSING_IN_FBL1H"        # Raporda var, FBL1H'da yok


@dataclass
class CompanyStatement:
    """Tek bir firmanın FBL1H ekstresi."""

    code: str                                    # normalize edilmiş (sağdan 8 hane)
    code_raw: str                                # dosyadaki ham Firma Kodu
    name: str = ""
    rows: list[TofasRecord] = field(default_factory=list)
    balances: dict[str, Decimal] = field(default_factory=dict)        # belge PB
    local_balances: dict[str, Decimal] = field(default_factory=dict)  # ulusal PB
    source_file: str = ""
    run_id: Optional[str] = None
    ms: str = ""                                 # uygulanan yön ("", "M", "S")
    # ``rows`` ile AYNI sırada ulusal para birimi tutarları (para birimi, tutar).
    # TofasRecord'da ulusal tutar alanı yok; filtreleme ikisini birlikte yapar.
    local_entries: list[tuple[str, Decimal]] = field(default_factory=list)

    @property
    def row_count(self) -> int:
        return len(self.rows)


@dataclass
class StatementLoadResult:
    """Bir SAP ekstre dosyasının (FBL1H ya da FBL5H) okunma sonucu."""

    statements: list[CompanyStatement] = field(default_factory=list)
    source: StatementSource = StatementSource.VENDOR_FBL1H
    source_file: str = ""
    run_id: Optional[str] = None
    total_rows: int = 0
    used_rows: int = 0
    excluded_total_rows: int = 0
    excluded_opening_rows: int = 0
    excluded_no_code_rows: int = 0
    # Firma koduna bağlanamayan 120* müşteri hesapları: hesap -> satır sayısı.
    # config/customer_accounts.yaml'a eşleme eklenince boşalır. Sessiz veri
    # kaybını görünür kılar.
    unmapped_customer_accounts: dict[str, int] = field(default_factory=dict)

    @property
    def company_count(self) -> int:
        return len(self.statements)

    def by_code(self) -> dict[str, CompanyStatement]:
        return {s.code: s for s in self.statements}


# Geriye dönük ad (tek kaynaklı dönemden kalma).
Fbl1hLoadResult = StatementLoadResult


@dataclass
class StatementSegment:
    """Bir firmanın TEK yöndeki (M ya da S) ekstresi ve bakiye durumu.

    Kural 13: her segment kendi Excel ekstresini alır. Bir firma hem M hem S
    kaydı taşıyorsa iki segment oluşur; mail yine tektir.
    """

    ms: str                                       # "M" | "S" | "" (yön bilinmiyor)
    statement: CompanyStatement
    balances: dict[str, Decimal] = field(default_factory=dict)
    previous_balances: dict[str, Decimal] = field(default_factory=dict)
    balance_status: BalanceStatus = BalanceStatus.NEW_IN_FBL1H
    changed_currencies: list[str] = field(default_factory=list)
    # Kural 12: maile yalnızca bunlar yazılır (yalnızca tutarı OLAN dövizler).
    display_balances: dict[str, Decimal] = field(default_factory=dict)
    is_zero_balance: bool = False
    # Kural 11: bu yönün filtresinin elediği satır sayısı (izlenebilirlik).
    excluded_by_ms_rows: int = 0
    # Bu yönü besleyen SAP dosyası YÜKLENMEDİ. Bakiye hesaplanamaz; sıfır
    # DEĞİLDİR. Paket katmanı bu segmenti gönderimi engelleyen sebep sayar —
    # "borcunuz yok" diyen yanlış bir mektup geri alınamaz.
    source_missing: bool = False

    @property
    def row_count(self) -> int:
        return self.statement.row_count


@dataclass
class CompanyPackageDraft:
    """Firma bazlı mail paketinin veri tarafı (PHASE A çıktısı).

    Bir firma = bir mail. Ekstre tarafı yöne göre segmentlere ayrılır
    (``segments``); Excel dosyaları, PDF mektubu ve mail gövdesi sonraki
    fazlarda bu taslaktan üretilir.

    Kapsama bağlı alanlar (``balances``, ``statement``, ``ms`` …) tek segmentli
    firmalar için kolaylık olsun diye BİRİNCİL segmente yönlendirilir; çok
    segmentli firmada daima ``segments`` üzerinden gidin. Firma geneline ait
    sinyaller (``is_zero_balance``, ``balance_status``, ``row_count``) tüm
    segmentler üzerinden hesaplanır.
    """

    company_code: str
    company_name: str = ""
    recipient_emails: list[str] = field(default_factory=list)
    responsible: str = ""
    segments: list[StatementSegment] = field(default_factory=list)
    source_run_id: Optional[str] = None
    warnings: list[str] = field(default_factory=list)
    # Sıfır bakiye mesajında kullanılacak para birimi (İngilizce metin için).
    zero_balance_currency: str = _FALLBACK_CURRENCY

    # -- firma geneli ------------------------------------------------------

    @property
    def directions(self) -> list[str]:
        """Bu firmada üretilen yönler, sabit sırada (ör. ``["M", "S"]``)."""
        return [s.ms for s in self.segments]

    @property
    def has_multiple_segments(self) -> bool:
        return len(self.segments) > 1

    def segment(self, ms: str) -> Optional[StatementSegment]:
        """Verilen yönün segmentini döndür (yoksa None)."""
        for s in self.segments:
            if s.ms == ms:
                return s
        return None

    @property
    def row_count(self) -> int:
        """Tüm segmentlerdeki toplam satır sayısı."""
        return sum(s.row_count for s in self.segments)

    @property
    def is_zero_balance(self) -> bool:
        """Firma TÜM segmentlerinde ve tüm dövizlerde 0 ise True.

        Tek bir dövizin ya da tek bir segmentin 0 olması firmayı sıfır yapmaz
        ve hiçbir koşulda mail gönderimini engellemez.
        """
        return all(s.is_zero_balance for s in self.segments) if self.segments else True

    @property
    def balance_status(self) -> BalanceStatus:
        """Segment durumlarının birleşimi (öncelik: UPDATED > MISSING > NEW)."""
        statuses = {s.balance_status for s in self.segments}
        if not statuses:
            return BalanceStatus.MISSING_IN_FBL1H
        for candidate in (
            BalanceStatus.UPDATED_FROM_FBL1H,
            BalanceStatus.MISSING_IN_FBL1H,
            BalanceStatus.NEW_IN_FBL1H,
        ):
            if candidate in statuses:
                return candidate
        return BalanceStatus.UNCHANGED

    # -- birincil segment kolaylıkları -------------------------------------

    @property
    def primary_segment(self) -> Optional[StatementSegment]:
        return self.segments[0] if self.segments else None

    @property
    def ms(self) -> str:
        return self.segments[0].ms if self.segments else ""

    @property
    def statement(self) -> Optional[CompanyStatement]:
        return self.segments[0].statement if self.segments else None

    @property
    def balances(self) -> dict[str, Decimal]:
        return self.segments[0].balances if self.segments else {}

    @property
    def previous_balances(self) -> dict[str, Decimal]:
        return self.segments[0].previous_balances if self.segments else {}

    @property
    def display_balances(self) -> dict[str, Decimal]:
        return self.segments[0].display_balances if self.segments else {}

    @property
    def changed_currencies(self) -> list[str]:
        return self.segments[0].changed_currencies if self.segments else []

    @property
    def excluded_by_ms_rows(self) -> int:
        return self.segments[0].excluded_by_ms_rows if self.segments else 0


def _q(value: Decimal) -> Decimal:
    """Karşılaştırma için kuruşa yuvarla (tutar eşitliği 2 hane üzerinden)."""
    return value.quantize(_CENT)


def _canonical_currency(value: object) -> str:
    """Para birimi kodunu kanonikleştir (TL/TRL -> TRY); okunamazsa TRY."""
    return clean_currency(value) or _FALLBACK_CURRENCY


def _add(bucket: dict[str, Decimal], currency: str, amount: Decimal) -> None:
    bucket[currency] = bucket.get(currency, _ZERO) + amount


def _ordered(currencies: Iterable[str]) -> list[str]:
    """Para birimlerini TRY, EUR, USD, sonra alfabetik sırada döndür."""
    return sorted(
        currencies,
        key=lambda c: (
            _CURRENCY_ORDER.index(c) if c in _CURRENCY_ORDER else len(_CURRENCY_ORDER),
            c,
        ),
    )


# YÖN AYRIMI ARTIK DOSYA SEÇİMİYLE YAPILIR (kullanıcı kararı).
#
#   FBL5H'a yüklenen HER satır  -> M
#   FBL1H'a yüklenen HER satır  -> S / X
#
# Ana hesap prefiksine (120*) BAKILMAZ: kullanıcı ayrımı SAP'tan çekerken
# yapıyor. Eski davranış (hesap numarasına göre süzme) ``account_matches_ms``
# ile korunur ve ``apply_ms_filter(..., filter_by_account=True)`` diyerek
# istenirse geri açılabilir — böylece kural değişse bile kod kaybolmaz.
FILTER_BY_ACCOUNT_PREFIX = False


def account_matches_ms(main_account: Optional[str], ms: str) -> bool:
    """Kural 11 — bir satır, firmanın M/S/X yönüne giriyor mu?

    ``M``  -> ana hesap ``120`` ile BAŞLAR.
    ``S``  -> ana hesap ``120`` ile BAŞLAMAZ (``X`` bu davranışı paylaşır;
              çağıran taraf ``effective_ms`` ile X'i S'ye indirger).
    ``""`` -> yön bilinmiyor; filtre uygulanmaz (satır korunur).

    Ana hesabı olmayan satır ``120`` ile başlamış sayılmaz: M'de elenir,
    S'de kalır.
    """
    if not ms:
        return True
    is_customer = bool(main_account) and \
        main_account.strip().startswith(CUSTOMER_ACCOUNT_PREFIX)
    return is_customer if ms == "M" else not is_customer


class CompanyStatementService:
    """FBL1H dosyasını firma bazlı ekstrelere ayırır ve raporla birleştirir."""

    def __init__(self, customer_accounts: Optional[CustomerAccountMap] = None) -> None:
        # 120* müşteri hesabı → firma kodu eşlemesi. Yapılandırma yoksa boş
        # eşleme ile çalışır: 120 satırları hiçbir firmaya atanmaz.
        try:
            self._customer_accounts = customer_accounts or CustomerAccountMap()
        except Exception:  # noqa: BLE001 - yapılandırma asla çökertmesin
            self._customer_accounts = CustomerAccountMap(mapping={})

    # -- yükleme -----------------------------------------------------------

    def load(
        self,
        path: str | Path,
        run_id: Optional[str] = None,
        source: StatementSource = StatementSource.VENDOR_FBL1H,
    ) -> StatementLoadResult:
        """Bir SAP ekstre dosyasını oku ve firma bazlı ekstreleri döndür."""
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"Dosya bulunamadı: {p}")
        headers, rows = _read_any(p)
        return self.parse(headers, rows, source_file=str(p), run_id=run_id,
                          source=source)

    def load_customer(
        self,
        path: str | Path,
        run_id: Optional[str] = None,
    ) -> StatementLoadResult:
        """FBL5H (müşteri kalemleri) dosyasını oku — M segmentini besler."""
        return self.load(path, run_id=run_id,
                         source=StatementSource.CUSTOMER_FBL5H)

    def parse(
        self,
        headers: Sequence[object],
        rows: Iterable[Sequence[object]],
        source_file: str = "",
        run_id: Optional[str] = None,
        source: StatementSource = StatementSource.VENDOR_FBL1H,
    ) -> StatementLoadResult:
        """Başlık + satırlardan firma bazlı ekstreleri üret (dosyasız, saf)."""
        headers = list(headers)
        mapping, ref_indexes = map_tofas_columns(headers)

        code_idx = mapping.get("firma_kodu")
        amount_idx = mapping.get("amount")
        name_idx = mapping.get("satici_ad")
        is_customer = source is StatementSource.CUSTOMER_FBL5H

        if is_customer:
            # FBL5H'ta kimlik kolonları müşteri adını taşır; SAP satıcı
            # şablonundan çözülemezse müşteri karşılıklarına bakılır.
            cust_code_idx, cust_name_idx = self._customer_identity_indexes(headers)
            if code_idx is None:
                code_idx = cust_code_idx
            if name_idx is None:
                name_idx = cust_name_idx

        missing: list[str] = []
        if code_idx is None:
            missing.append("Müşteri numarası" if is_customer else "Firma Kodu")
        if amount_idx is None:
            missing.append("Tutar (Belge para birimi değeri)")
        if missing:
            raise MappingError(
                f"{source.value} ekstresi okunamadı: gerekli kolonlar bulunamadı.",
                file=source_file or None,
                found_columns=[str(h) for h in headers],
                missing=missing,
            )

        currency_idx = mapping.get("currency")
        account_idx = mapping.get("main_account")
        local_amount_idx, local_currency_idx = self._local_currency_indexes(headers)

        # Anahtar kelime taraması YALNIZCA kimlik kolonlarında yapılır. Metin
        # kolonu serbest metindir; içinde "TOPLAM" geçen gerçek bir fatura satırı
        # asla ara toplam sanılmamalıdır.
        key_idxs = [
            i for i in (
                [code_idx, account_idx, name_idx, mapping.get("belge_turu"),
                 mapping.get("belge_no")] + list(ref_indexes)
            ) if i is not None
        ]

        result = StatementLoadResult(source=source, source_file=source_file,
                                     run_id=run_id)
        groups: dict[str, CompanyStatement] = {}

        for i, row in enumerate(rows):
            row = list(row) if row is not None else []
            if _is_blank(row):
                continue
            result.total_rows += 1

            key_cells = [_cell(row, idx) for idx in key_idxs]

            # Kural 4: ara toplam / genel toplam satırları.
            if is_total_row(key_cells):
                result.excluded_total_rows += 1
                continue
            # Kural 4: açılış / devir satırları.
            if is_opening_row(key_cells):
                result.excluded_opening_rows += 1
                continue

            amount = normalize_amount(_cell(row, amount_idx))
            account = normalize_account(_cell(row, account_idx))

            code_raw = clean_string(_cell(row, code_idx))
            code = normalize_code(code_raw) if code_raw else ""
            mapped_name = ""

            if not code:
                # SAP FBL1H'da "Firma Kodu" YALNIZCA satıcı (320/323)
                # kalemlerinde dolar; müşteri (120) kalemlerinde boştur. Bu
                # satırların firmasını ana hesabın alt kırılımından çözeriz.
                if account and account.startswith(CUSTOMER_ACCOUNT_PREFIX):
                    resolved = self._customer_accounts.resolve(account)
                    if resolved is None:
                        # Eşleme yok: TAHMİN ETME. Satır atanmaz ve raporlanır.
                        result.unmapped_customer_accounts[account] = (
                            result.unmapped_customer_accounts.get(account, 0) + 1
                        )
                        result.excluded_no_code_rows += 1
                        continue
                    code_raw, mapped_name = resolved
                    code = normalize_code(code_raw)
                # Kimlik kolonlarının TAMAMI boş ama tutarı olan satır, SAP'ın
                # para birimi bazlı GENEL TOPLAM satırıdır (anahtar kelime
                # taşımaz, bu yüzden is_total_row yakalayamaz).
                elif amount != _ZERO and all(
                    clean_string(c) is None for c in key_cells
                ):
                    result.excluded_total_rows += 1
                    continue
                else:
                    result.excluded_no_code_rows += 1
                    continue

            currency = _canonical_currency(_cell(row, currency_idx))

            statement = groups.get(code)
            if statement is None:
                statement = CompanyStatement(
                    code=code,
                    code_raw=code_raw or code,
                    source_file=source_file,
                    run_id=run_id,
                )
                groups[code] = statement

            # 120 satırlarında ad kolonu boştur; eşlemeden gelen unvan kullanılır.
            name = clean_string(_cell(row, name_idx)) or mapped_name
            if name and not statement.name:
                statement.name = name

            statement.rows.append(self._to_record(
                row_index=i,
                row=row,
                mapping=mapping,
                ref_indexes=ref_indexes,
                amount=amount,
                currency=currency,
                source_file=source_file,
                main_account=account,
                firma_kodu=code_raw or code,
            ))

            # Kural 5: bakiye belge para birimi bazında toplanır.
            _add(statement.balances, currency, amount)

            if local_amount_idx is not None:
                local_amount = normalize_amount(_cell(row, local_amount_idx))
                local_currency = _canonical_currency(_cell(row, local_currency_idx))
                _add(statement.local_balances, local_currency, local_amount)
                statement.local_entries.append((local_currency, local_amount))
            else:
                statement.local_entries.append((currency, _ZERO))

            result.used_rows += 1

        # Determinizm: firma kodu sırasına göre sabit çıktı.
        result.statements = [groups[c] for c in sorted(groups)]
        return result

    @staticmethod
    def _customer_identity_indexes(
        headers: Sequence[object],
    ) -> tuple[Optional[int], Optional[int]]:
        """FBL5H'ta müşteri numarası ve müşteri adı kolonlarını bul."""
        code_idx: Optional[int] = None
        name_idx: Optional[int] = None
        for idx, header in enumerate(headers):
            if header is None:
                continue
            n = _norm_header(header)
            if code_idx is None and n in _CUSTOMER_CODE_HEADERS:
                code_idx = idx
            elif name_idx is None and n in _CUSTOMER_NAME_HEADERS:
                name_idx = idx
        return code_idx, name_idx

    @staticmethod
    def _local_currency_indexes(
        headers: Sequence[object],
    ) -> tuple[Optional[int], Optional[int]]:
        """Ulusal (şirket kodu) para birimi tutar/kod kolonlarını bul."""
        amount_idx: Optional[int] = None
        currency_idx: Optional[int] = None
        for idx, header in enumerate(headers):
            if header is None:
                continue
            n = _norm_header(header)
            if amount_idx is None and n in _LOCAL_AMOUNT_HEADERS:
                amount_idx = idx
            elif currency_idx is None and n in _LOCAL_CURRENCY_HEADERS:
                currency_idx = idx
        return amount_idx, currency_idx

    @staticmethod
    def _to_record(
        *,
        row_index: int,
        row: Sequence[object],
        mapping: dict[str, int],
        ref_indexes: Sequence[int],
        amount: Decimal,
        currency: str,
        source_file: str,
        main_account: Optional[str] = None,
        firma_kodu: Optional[str] = None,
    ) -> TofasRecord:
        """Satırı mevcut ``TofasRecord`` modeline dönüştür (yeni model YOK)."""
        refs = [normalize_reference(_cell(row, idx)) for idx in ref_indexes]
        refs = [r for r in refs if r]
        return TofasRecord(
            row_index=row_index,
            fiscal_year=clean_string(_cell(row, mapping.get("fiscal_year"))),
            main_account=main_account,
            firma_kodu=firma_kodu,
            satici_ad=clean_string(_cell(row, mapping.get("satici_ad"))),
            reference=refs[0] if refs else None,
            reference_raw=(clean_string(_cell(row, ref_indexes[0]))
                           if ref_indexes else None),
            all_references=refs,
            belge_turu=clean_string(_cell(row, mapping.get("belge_turu"))),
            belge_tarihi=normalize_date(_cell(row, mapping.get("belge_tarihi"))),
            kayit_tarihi=normalize_date(_cell(row, mapping.get("kayit_tarihi"))),
            giris_tarihi=normalize_date(_cell(row, mapping.get("giris_tarihi"))),
            net_vade=normalize_date(_cell(row, mapping.get("net_vade"))),
            amount=amount,
            currency=currency,
            metin=clean_string(_cell(row, mapping.get("metin"))),
            source_file=source_file or None,
            source_row=row_index,
            extraction_method=_EXTRACTION_FBL1H,
        )

    # -- M/S/X filtresi ----------------------------------------------------

    @staticmethod
    def apply_ms_filter(
        statement: CompanyStatement,
        ms: str,
        filter_by_account: Optional[bool] = None,
    ) -> tuple[CompanyStatement, int]:
        """Ekstreyi firmanın M/S/X yönüne göre süz.

        Varsayılan davranış (``FILTER_BY_ACCOUNT_PREFIX = False``): HİÇBİR
        satır elenmez — yön ayrımı hangi dosyanın yüklendiğinden gelir.
        ``filter_by_account=True`` verilirse eski kural (M = 120*) uygulanır.

        Kaynak ekstre DEĞİŞTİRİLMEZ; süzülmüş yeni bir ``CompanyStatement`` ve
        elenen satır sayısı döner. Böylece denetim için ham ekstre elde kalır.
        """
        if filter_by_account is None:
            filter_by_account = FILTER_BY_ACCOUNT_PREFIX

        kept_rows: list[TofasRecord] = []
        kept_local: list[tuple[str, Decimal]] = []
        balances: dict[str, Decimal] = {}
        local_balances: dict[str, Decimal] = {}
        excluded = 0

        for i, rec in enumerate(statement.rows):
            if filter_by_account and not account_matches_ms(rec.main_account, ms):
                excluded += 1
                continue
            kept_rows.append(rec)
            _add(balances, rec.currency or _FALLBACK_CURRENCY, rec.amount)
            if i < len(statement.local_entries):
                local_currency, local_amount = statement.local_entries[i]
                kept_local.append((local_currency, local_amount))
                _add(local_balances, local_currency, local_amount)

        filtered = CompanyStatement(
            code=statement.code,
            code_raw=statement.code_raw,
            name=statement.name,
            rows=kept_rows,
            balances=balances,
            local_balances=local_balances,
            source_file=statement.source_file,
            run_id=statement.run_id,
            ms=ms,
            local_entries=kept_local,
        )
        return filtered, excluded

    # -- birleştirme -------------------------------------------------------

    def merge(
        self,
        fbl1h: Optional[StatementLoadResult],
        report_rows: Iterable[MailRow],
        fbl5h: Optional[StatementLoadResult] = None,
    ) -> list[CompanyPackageDraft]:
        """İki kaynağı mutabakat raporuyla firma kodu üzerinden birleştir.

        ``fbl1h`` satıcı ekstresi → S/X segmentini, ``fbl5h`` müşteri ekstresi
        → M segmentini besler. Bir yön raporda isteniyor ama kaynağı
        yüklenmemişse o segment BOŞ üretilir ve firmaya uyarı düşülür
        (kullanıcı eksik dosyayı yüklesin diye).

        Kural 7: bakiye farklıysa SAP kaynağı kazanır. Kural 8: aynıysa
        korunmuş sayılır. Kural 9-10: bakiye 0 olsa bile taslak üretilir.
        """
        report_groups: dict[str, list[MailRow]] = {}
        for r in report_rows:
            code = normalize_code(r.code_raw)
            if not code:
                continue
            report_groups.setdefault(code, []).append(r)

        loaded: dict[StatementSource, Optional[StatementLoadResult]] = {
            StatementSource.VENDOR_FBL1H: fbl1h,
            StatementSource.CUSTOMER_FBL5H: fbl5h,
        }
        by_source: dict[StatementSource, dict[str, CompanyStatement]] = {
            src: (res.by_code() if res is not None else {})
            for src, res in loaded.items()
        }
        run_id = next(
            (res.run_id for res in (fbl1h, fbl5h) if res is not None and res.run_id),
            None,
        )

        all_codes = set(report_groups)
        for statements in by_source.values():
            all_codes |= set(statements)

        drafts: list[CompanyPackageDraft] = []

        for code in sorted(all_codes):
            group = report_groups.get(code, [])
            warnings: list[str] = []

            # -- yönler (M/S/X) rapordan gelir; X, S'ye indirgenir -----------
            found = {m for m in (effective_ms(r.ms) for r in group) if m}
            directions = [d for d in _SEGMENT_ORDER if d in found]
            if not directions:
                if group:
                    # Rapor satırı VAR ama M/S okunamadı: yön bilinmiyor,
                    # hesap filtresi uygulanmaz.
                    directions = [""]
                    warnings.append(
                        "Raporda tanınmayan M/S değeri; hesap filtresi "
                        "uygulanmadı."
                    )
                else:
                    # Rapor satırı YOK: yönü, firmanın hangi kaynakta satırı
                    # olduğundan türet. Müşteri raporunda görünen firma M,
                    # satıcı raporunda görünen S tarafıdır.
                    directions = [
                        d for d, src in (
                            ("M", StatementSource.CUSTOMER_FBL5H),
                            ("S", StatementSource.VENDOR_FBL1H),
                        )
                        if code in by_source[src]
                    ] or [""]

            if not group:
                warnings.append(
                    "Firma mutabakat raporunda yok; alıcı adresi ve M/S "
                    "bilgisi bulunamadı."
                )

            # -- Kural 13: her yön için ayrı segment ------------------------
            # Yönün kaynağı: M -> FBL5H, S/"" -> FBL1H.
            segments = []
            for ms in directions:
                src = _SOURCE_FOR_DIRECTION[ms]
                source_missing = loaded[src] is None
                if source_missing:
                    # DİĞER dosyaya DÜŞÜLMEZ: satıcı satırlarını müşteri yönüne
                    # yazmak bakiyeyi ikiye katlar ve yanlış mektup üretir.
                    # Segment boş kalır ama SIFIR SAYILMAZ; paket engellenir.
                    warnings.append(
                        f"{ms or 'Bu'} yönü için {_SOURCE_LABEL[src]} "
                        "yüklenmedi; bu yönün bakiyesi HESAPLANAMADI. "
                        "Lütfen bu dosyayı da yükleyin."
                    )
                elif code not in by_source[src]:
                    warnings.append(
                        f"Firmanın {_SOURCE_LABEL[src]} dosyasında hiç satırı "
                        "yok; bakiye 0 kabul edildi."
                    )
                segment = self._build_segment(
                    code=code,
                    ms=ms,
                    source_statement=(None if source_missing
                                      else by_source[src].get(code)),
                    group=group,
                    source_file=("" if source_missing
                                 else loaded[src].source_file),
                    run_id=run_id,
                )
                segment.source_missing = source_missing
                segments.append(segment)

            emails: list[str] = []
            for r in group:
                for m in r.mails:
                    if is_valid_email(m) and m not in emails:
                        emails.append(m)
            if not emails:
                warnings.append("Firma mail adresi tanımlı değil.")
            invalid_emails = list(dict.fromkeys(
                value for r in group for value in [*r.invalid_mails, *r.mails]
                if not is_valid_email(value)))
            if invalid_emails:
                warnings.append(
                    "Geçersiz e-posta adresi: " + ", ".join(invalid_emails))

            responsibles = [r.responsible for r in group if r.responsible]
            if len(set(responsibles)) > 1:
                warnings.append(
                    "Aynı firma kodunda farklı mutabakat sorumluları var."
                )

            name = next(
                (s.statement.name for s in segments if s.statement.name), ""
            ) or next((r.name for r in group if r.name), "")

            drafts.append(CompanyPackageDraft(
                company_code=code,
                company_name=name,
                recipient_emails=emails,
                responsible=responsibles[0] if responsibles else "",
                segments=segments,
                source_run_id=run_id,
                warnings=warnings,
                zero_balance_currency=self._zero_currency(segments),
            ))

        return drafts

    def _build_segment(
        self,
        *,
        code: str,
        ms: str,
        source_statement: Optional[CompanyStatement],
        group: Sequence[MailRow],
        source_file: str = "",
        run_id: Optional[str] = None,
    ) -> StatementSegment:
        """Kural 11 + 13 — tek bir yön için ekstre segmentini kur."""
        if source_statement is not None:
            statement, excluded = self.apply_ms_filter(source_statement, ms)
        else:
            # Kaynak yüklenmemiş ya da firmanın o kaynakta satırı yok: boş
            # ekstre üretilir (None değil), böylece Excel/PDF tarafı özel durum
            # bilmek zorunda kalmaz.
            statement, excluded = CompanyStatement(
                code=code,
                code_raw=code,
                name=next((r.name for r in group if r.name), ""),
                source_file=source_file,
                run_id=run_id,
                ms=ms,
            ), 0

        current = dict(statement.balances)
        # Karşılaştırma tabanı da AYNI yönden alınır (bkz. _report_balances).
        previous = self._report_balances(group, ms)
        changed = self._changed_currencies(current, previous)

        if source_statement is None:
            status = BalanceStatus.MISSING_IN_FBL1H
        elif not group:
            status = BalanceStatus.NEW_IN_FBL1H
        elif changed:
            status = BalanceStatus.UPDATED_FROM_FBL1H   # Kural 7
        else:
            status = BalanceStatus.UNCHANGED            # Kural 8

        # -- Kural 12: yalnızca tutarı OLAN dövizler gösterilir -------------
        # Karar KURUŞ hassasiyetinde verilir: kuruş altı bir artık (ör. 0,004)
        # maile "0,00" olarak yazılırdı; "tutarı var" sayılmamalı. Gösterilen
        # değer ham (yuvarlanmamış) kalır.
        display = {
            c: current[c] for c in _ordered(current) if _q(current[c]) != _ZERO
        }

        return StatementSegment(
            ms=ms,
            statement=statement,
            balances=current,
            previous_balances=previous,
            balance_status=status,
            changed_currencies=changed,
            display_balances=display,
            is_zero_balance=not display,
            excluded_by_ms_rows=excluded,
        )

    @staticmethod
    def _zero_currency(segments: Sequence[StatementSegment]) -> str:
        """Sıfır bakiye mesajında kullanılacak para birimini seç.

        Önce firmanın FBL1H'da işlem gördüğü para birimleri (net 0 olsa bile),
        sonra rapordaki para birimleri, en son ``TRY``.
        """
        for attr in ("balances", "previous_balances"):
            for segment in segments:
                ordered = _ordered(getattr(segment, attr))
                if ordered:
                    return ordered[0]
        return _FALLBACK_CURRENCY

    @staticmethod
    def _report_balances(
        rows: Sequence[MailRow],
        ms: str = "",
    ) -> dict[str, Decimal]:
        """Rapor satırlarının bakiyesini para birimi bazında topla.

        ``ms`` verilirse YALNIZCA o yöndeki satırlar toplanır. Kural 11 gereği
        FBL1H tarafı da tek yöne süzüldüğü için karşılaştırma ancak aynı yön
        üzerinden anlamlıdır; aksi halde M ve S bakiyeleri toplanıp süzülmüş
        tek yönlü bakiyeyle kıyaslanırdı.

        FAZ1 Karar A ile tutarlı: aynı yön ve aynı bakiye kümesini taşıyan
        mükerrer satırlar TEK kez sayılır.
        """
        totals: dict[str, Decimal] = {}
        seen: set[tuple] = set()
        for r in rows:
            row_ms = effective_ms(r.ms)
            if ms and row_ms != ms:
                continue
            # Tutar DEĞER olarak anahtarlanır. str(Decimal) ile
            # "100.00" ve "100.0" farklı anahtar üretiyor ve aynı bakiye
            # iki kez toplanabiliyordu. Decimal değere göre hash'lenir.
            key = (
                row_ms,
                tuple(sorted(r.balances.items())),
            )
            if key in seen:
                continue
            seen.add(key)
            for raw_code, value in r.balances.items():
                _add(totals, _canonical_currency(raw_code), value)
        return totals

    @staticmethod
    def _changed_currencies(
        current: dict[str, Decimal],
        previous: dict[str, Decimal],
    ) -> list[str]:
        """İki bakiye kümesi arasında (kuruş hassasiyetinde) farklı olan kodlar."""
        changed: list[str] = []
        for currency in sorted(set(current) | set(previous)):
            a = _q(current.get(currency, Decimal("0")))
            b = _q(previous.get(currency, Decimal("0")))
            if a != b:
                changed.append(currency)
        return changed

    # -- uçtan uca ---------------------------------------------------------

    def build(
        self,
        fbl1h_path: str | Path | None,
        report_rows: Iterable[MailRow],
        run_id: Optional[str] = None,
        fbl5h_path: str | Path | None = None,
    ) -> list[CompanyPackageDraft]:
        """İki dosyayı yükle ve raporla birleştirilmiş taslakları döndür.

        Yalnızca biri verilirse diğer yönün segmenti boş üretilir ve ilgili
        firmalara "eksik dosya" uyarısı düşer.
        """
        vendor = (self.load(fbl1h_path, run_id=run_id) if fbl1h_path else None)
        customer = (self.load_customer(fbl5h_path, run_id=run_id)
                    if fbl5h_path else None)
        return self.merge(vendor, report_rows, fbl5h=customer)

    @staticmethod
    def missing_sources(
        report_rows: Iterable[MailRow],
        fbl1h: Optional[StatementLoadResult] = None,
        fbl5h: Optional[StatementLoadResult] = None,
    ) -> list[str]:
        """Rapordaki yönler için eksik olan kaynak dosyaları listele.

        UI bu listeyi "şu dosyaları da yükleyin" uyarısı olarak gösterir.
        """
        loaded = {
            StatementSource.VENDOR_FBL1H: fbl1h,
            StatementSource.CUSTOMER_FBL5H: fbl5h,
        }
        needed: set[StatementSource] = set()
        for r in report_rows:
            ms = effective_ms(r.ms)
            if ms:
                needed.add(_SOURCE_FOR_DIRECTION[ms])
        return [
            _SOURCE_LABEL[src]
            for src in (StatementSource.VENDOR_FBL1H,
                        StatementSource.CUSTOMER_FBL5H)
            if src in needed and loaded[src] is None
        ]
