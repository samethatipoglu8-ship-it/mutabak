"""Direct Line 3.0 istemcisi — Copilot Studio ajanına güvenli erişim.

GÜVENLİK MODELİ (Microsoft'un önerdiği akış)
    secret  →  /tokens/generate  →  token  →  conversation  →  activity

    Secret YALNIZCA servis tarafında durur ve tek bir yerde kullanılır:
    token üretimi. Konuşma boyunca kısa ömürlü token taşınır. Secret ya da
    token HİÇBİR log satırına, hata mesajına ya da istisna metnine girmez
    (bkz. ``_redact``). Tarayıcıya/istemciye hiçbir şey gönderilmez.

DAYANIKLILIK (uygulama "yanıt vermiyor" durumuna DÜŞMEZ)
    - bağlantı ve okuma zaman aşımı ayrı ayrı
    - yoklama (polling) için hem süre hem ADIM SAYISI sınırı → sonsuz döngü yok
    - yeniden deneme + üstel geri çekilme (retry / exponential backoff)
    - 429'da sunucunun ``Retry-After`` başlığına uyulur
    - ``should_cancel`` ile kooperatif iptal (mevcut worker kalıbıyla aynı)

Bu modül Qt bilmez, Outlook bilmez, dosya okumaz. Yalnızca HTTP konuşur.
"""

from __future__ import annotations

import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Optional
from urllib.parse import urlsplit

from loguru import logger

# Microsoft'un sabit Direct Line uç noktası. Kullanıcının main.py'de bir şey
# yazmasına gerek yoktur; yalnızca bölgesel/özel bir uç nokta gerekiyorsa
# yapılandırmadan değiştirilir.
DEFAULT_ENDPOINT = "https://directline.botframework.com/v3/directline"

# Secret yerine bırakılan yer tutucular — gerçek değer sanılmamalıdır.
PLACEHOLDER_TOKENS: frozenset[str] = frozenset({
    "BURAYA_DIRECT_LINE_SECRET_GELECEK",
    "BURAYA_DIRECT_LINE_ENDPOINT_GELECEK",
    "BURAYA_DIRECT_LINE_TOKEN_GELECEK",
    "CHANGE_ME", "TODO", "XXX",
})


def is_placeholder(value: Optional[str]) -> bool:
    """Değer doldurulmamış bir yer tutucu mu?"""
    if value is None:
        return True
    text = str(value).strip()
    return not text or text in PLACEHOLDER_TOKENS


# --- hata taksonomisi --------------------------------------------------------

class DirectLineError(RuntimeError):
    """Tüm Direct Line hatalarının ortak tabanı."""

    code = "DIRECT_LINE_ERROR"
    retryable = False

    def __init__(self, message: str, status: Optional[int] = None) -> None:
        super().__init__(message)
        self.status = status

    def __str__(self) -> str:  # pragma: no cover - biçimlendirme
        base = super().__str__()
        return f"{self.code}: {base}" if not base.startswith(self.code) else base


class DirectLineDisabledError(DirectLineError):
    """Direct Line kapalı ya da secret girilmemiş."""

    code = "DIRECT_LINE_DISABLED"


class DirectLineConfigurationError(DirectLineError):
    """Unsafe or malformed endpoint/configuration."""

    code = "DIRECT_LINE_BAD_CONFIG"


class DirectLineAuthError(DirectLineError):
    """401/403 — secret yanlış, süresi dolmuş ya da yetkisiz."""

    code = "DIRECT_LINE_AUTH_FAILED"


class DirectLineNotFoundError(DirectLineError):
    """404 — konuşma/uç nokta yok."""

    code = "DIRECT_LINE_NOT_FOUND"


class DirectLineRateLimitError(DirectLineError):
    """429 — istek sınırı. Beklenip tekrar denenir."""

    code = "DIRECT_LINE_RATE_LIMITED"
    retryable = True

    def __init__(self, message: str, status: Optional[int] = None,
                 retry_after: Optional[float] = None) -> None:
        super().__init__(message, status)
        self.retry_after = retry_after


class DirectLineServerError(DirectLineError):
    """5xx — sunucu hatası. Tekrar denenir."""

    code = "DIRECT_LINE_SERVER_ERROR"
    retryable = True


class DirectLineTimeoutError(DirectLineError):
    """Bağlantı/okuma/yoklama zaman aşımı. Tekrar denenir."""

    code = "DIRECT_LINE_TIMEOUT"
    retryable = True


class DirectLineConnectionError(DirectLineError):
    """Ağ hatası (DNS, TLS, kopma). Tekrar denenir."""

    code = "DIRECT_LINE_CONNECTION_FAILED"
    retryable = True


class DirectLineProtocolError(DirectLineError):
    """Cevap JSON değil / beklenen alanları taşımıyor."""

    code = "DIRECT_LINE_BAD_RESPONSE"


class DirectLineEmptyResponseError(DirectLineError):
    """Ajan bağlandı ama boş cevap verdi."""

    code = "DIRECT_LINE_EMPTY_RESPONSE"


class DirectLineCancelled(DirectLineError):
    """Kullanıcı iptal etti (kooperatif iptal)."""

    code = "DIRECT_LINE_CANCELLED"


class DirectLineClosedError(DirectLineError):
    """İstemci kapatılıyor / kapatıldı; yeni çağrı kabul edilmez.

    Kapanış başladıktan sonra istemci YENİ HTTP oturumu açmaz. Aksi hâlde
    ``close()`` bittikten sonra bile sürmekte olan bir ``ask()`` taze bir
    ``requests.Session()`` yaratıp istek/retry atmaya devam ediyordu:
    kapanış sırasında sızan oturum + uygulama kapanırken yaşayan ağ trafiği.
    TEKRAR DENENMEZ — kapanış kalıcı bir durumdur.
    """

    code = "DIRECT_LINE_CLOSED"


class DirectLineConversationError(DirectLineError):
    """Konuşma oluşturulamadı."""

    code = "DIRECT_LINE_CONVERSATION_FAILED"
    retryable = True


# --- yapılandırma ------------------------------------------------------------

@dataclass
class DirectLineConfig:
    """Direct Line çağrı ayarları. Secret DIŞARIDA tutulur, loglanmaz."""

    # ``repr=False`` — SECRET ASLA repr()'e GİRMEZ.
    #
    # Dataclass'ın varsayılan repr'i tüm alanları basar; f-string'e konan
    # ya da hata ayıklama amacıyla loglanan bir config nesnesi secret'ı
    # olduğu gibi diske yazıyordu. Bunu gizleyen tek test totolojikti
    # (``... or not hasattr(config, "redacted")`` — metot yoksa koşul her
    # zaman doğru), bu yüzden sızıntı yıllarca görünmedi.
    secret: str = field(default="", repr=False)
    endpoint: str = DEFAULT_ENDPOINT
    enabled: bool = True

    connect_timeout: float = 10.0
    read_timeout: float = 30.0
    poll_timeout: float = 90.0          # ajanın cevabı için toplam bekleme
    poll_interval: float = 1.0
    idle_polls_after_reply: int = 2     # JSON olmayan cevaptan sonra bekleme

    # İLK denemeden SONRAKİ tekrar sayısı: 3 → retry 1, retry 2, retry 3,
    # sonra AI_UNAVAILABLE. Toplam deneme = max_retries + 1.
    max_retries: int = 3
    backoff_base: float = 1.0
    backoff_max: float = 20.0

    user_id: str = "mutabakat-pro"
    locale: str = "tr-TR"

    @property
    def configured(self) -> bool:
        """Gerçek bir secret girilmiş mi?"""
        return not is_placeholder(self.secret)

    @property
    def usable(self) -> bool:
        if not self.enabled or not self.configured:
            return False
        try:
            self.base_url
        except DirectLineConfigurationError:
            return False
        return True

    @property
    def base_url(self) -> str:
        endpoint = (self.endpoint or "").strip()
        if is_placeholder(endpoint):
            endpoint = DEFAULT_ENDPOINT
        parsed = urlsplit(endpoint)
        if parsed.scheme.lower() != "https" or not parsed.netloc:
            raise DirectLineConfigurationError(
                "Direct Line endpoint geçerli bir HTTPS adresi olmalıdır; "
                "secret HTTP veya göreli bir adrese gönderilmez.")
        if parsed.username or parsed.password:
            raise DirectLineConfigurationError(
                "Direct Line endpoint kullanıcı adı/parola içeremez.")
        return endpoint.rstrip("/")

    def describe(self) -> dict[str, Any]:
        """Loglanabilir özet — secret ASLA yer almaz."""
        return {
            "endpoint": self.base_url,
            "enabled": self.enabled,
            "secret_configured": self.configured,
            "max_retries": self.max_retries,
            "poll_timeout": self.poll_timeout,
        }


@dataclass
class DirectLineReply:
    """Ajandan gelen ham cevap + çağrı ölçümleri (secret/token taşımaz)."""

    text: str = ""
    conversation_id: str = ""
    retries: int = 0
    duration_ms: int = 0
    activity_count: int = 0
    request_id: str = ""


class _Lifecycle:
    """İstemcinin yaşam döngüsü durumları (bkz. ``DirectLineClient``)."""

    OPEN = "OPEN"
    CLOSING = "CLOSING"
    CLOSED = "CLOSED"


def _redact(text: str, *secrets: Optional[str]) -> str:
    """Metindeki secret/token değerlerini maskele."""
    if not text:
        return ""
    out = str(text)
    for secret in secrets:
        if secret and len(str(secret)) >= 6:
            out = out.replace(str(secret), "***")
    return out


class DirectLineClient:
    """Copilot Studio ajanıyla tek turlu (soru → cevap) konuşma yapar.

    Her ``ask`` çağrısı YENİ bir konuşma açar: mailler birbirinin bağlamını
    kirletmesin ve uzun ömürlü bir konuşma zaman aşımına uğramasın diye.
    """

    def __init__(
        self,
        config: Optional[DirectLineConfig] = None,
        session: Optional[Any] = None,
        sleep: Optional[Callable[[float], None]] = None,
        clock: Optional[Callable[[], float]] = None,
    ) -> None:
        self._config = config or DirectLineConfig()
        self._session = session
        self._own_session = session is None
        self._sleep = sleep or time.sleep
        self._clock = clock or time.monotonic
        # Aynı istemciyi iki thread aynı anda kullanırsa konuşma durumları
        # birbirine karışır; tek seferde tek konuşma.
        self._lock = threading.Lock()
        # Oturum (requests.Session) için AYRI kilit. ``_lock`` tüm yeniden
        # deneme döngüsü boyunca tutulur (dakikalar sürebilir); close()
        # onu beklerse kapanış kilitlenir. Oturum kilidi yalnızca birkaç
        # komutluk kritik bölgeyi korur.
        self._session_lock = threading.Lock()
        # Session.close(), aktif request() tamamlanmadan aynı nesneyi kapatamaz.
        self._request_lock = threading.Lock()
        # Yaşam döngüsü: OPEN → CLOSING → CLOSED. ``_session_lock`` altında
        # okunur/yazılır. Oturumu None'lamak tek başına yetmiyordu: aktif bir
        # ask() sonraki adımda _get_session() çağırıp YENİ oturum yaratıyor,
        # böylece close() bittikten sonra istek atmaya devam ediyordu.
        self._state = _Lifecycle.OPEN

    @property
    def config(self) -> DirectLineConfig:
        return self._config

    # -- oturum ------------------------------------------------------------

    @property
    def closed(self) -> bool:
        """Kapanış başladı mı? (CLOSING ya da CLOSED)"""
        with self._session_lock:
            return self._state is not _Lifecycle.OPEN

    def _ensure_open(self) -> None:
        """Kapanış başlamışsa anlamlı bir hata ver (kilit DIŞINDA çağrılır)."""
        if self.closed:
            raise DirectLineClosedError(
                "Direct Line istemcisi kapatıldı; yeni çağrı kabul edilmiyor.")

    def _get_session(self):
        import requests  # yerel import: test/CI ortamı ağ katmanını yüklemesin

        with self._session_lock:
            # Kapanış başladıktan sonra YENİ oturum yaratmak yasak: yoksa
            # close() biter, ardından aktif ask() taze bir oturum açıp
            # istek/retry atmaya devam ederdi.
            if self._state is not _Lifecycle.OPEN:
                raise DirectLineClosedError(
                    "Direct Line istemcisi kapatıldı; yeni oturum açılmaz.")
            if self._session is None:
                self._session = requests.Session()
            return self._session

    def close(self) -> None:
        """İstemciyi kapat — başka thread ask() içindeyken de güvenli.

        SÖZLEŞME
            - Kapanış başladıktan sonra yeni oturum YARATILMAZ; sürmekte olan
              ``ask()`` bir sonraki adımda ``DirectLineClosedError`` alır.
            - Aktif request yarıda socket'i çekilerek bozulmaz: oturum
              ``_request_lock`` altında kapatılır, yani devam eden çağrının
              tamamlanması beklenir.
            - İdempotenttir; ikinci çağrı sessizce döner.
            - Dışarıdan verilen oturumun SAHİBİ biz değiliz: kapatılmaz, ama
              istemci yine kapanmış sayılır.
            - ``_lock`` (tüm retry döngüsü boyunca tutulur) BEKLENMEZ →
              kapanış kilitlenmez.
        """
        with self._session_lock:
            if self._state is _Lifecycle.CLOSED:
                return
            self._state = _Lifecycle.CLOSING
            session, self._session = self._session, None
            own = self._own_session
        try:
            # Dış oturum bizim değil → kapatmayız (sahiplik korunur).
            if session is not None and own:
                with self._request_lock:
                    try:
                        session.close()
                    except Exception:  # noqa: BLE001 - kapatma akışı bozmasın
                        pass
        finally:
            with self._session_lock:
                self._state = _Lifecycle.CLOSED

    # -- düşük seviye HTTP --------------------------------------------------

    def _request(self, method: str, url: str, token: Optional[str] = None,
                 payload: Optional[dict] = None,
                 params: Optional[dict] = None) -> dict[str, Any]:
        """Tek HTTP çağrısı; durum kodunu anlamlı istisnaya çevirir."""
        headers = {"Content-Type": "application/json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        timeout = (self._config.connect_timeout, self._config.read_timeout)
        try:
            with self._request_lock:
                # Acquire the close/request guard before obtaining the session:
                # close() cannot invalidate it in the gap between these steps.
                session = self._get_session()
                response = session.request(method, url, headers=headers,
                                           json=payload, params=params,
                                           timeout=timeout)
        except DirectLineError:
            # Kendi taksonomimiz olduğu gibi yükselir. Aksi hâlde kapanış
            # (DIRECT_LINE_CLOSED) "bağlantı hatası" diye maskeleniyor ve
            # retryable sayılıp boşuna tekrar deneniyordu.
            raise
        except Exception as exc:  # noqa: BLE001 - requests istisna ailesi geniş
            name = type(exc).__name__
            message = _redact(str(exc), self._config.secret, token)
            if "Timeout" in name:
                raise DirectLineTimeoutError(
                    f"{method} {self._safe_url(url)} zaman aşımı: {message}") from exc
            raise DirectLineConnectionError(
                f"{method} {self._safe_url(url)} bağlantı hatası "
                f"({name}): {message}") from exc

        status = getattr(response, "status_code", 0)
        if status in (401, 403):
            raise DirectLineAuthError(
                "Direct Line secret geçersiz ya da yetkisiz "
                f"(HTTP {status}). DIRECT_LINE_SECRET ortam değişkenini "
                "veya güvenli secret deposu ayarını kontrol edin.", status)
        if status == 404:
            raise DirectLineNotFoundError(
                f"Direct Line kaynağı bulunamadı (HTTP 404): "
                f"{self._safe_url(url)}", status)
        if status == 408:
            raise DirectLineTimeoutError(
                "Direct Line isteği sunucuda zaman aşımına uğradı (HTTP 408).",
                status)
        if status == 429:
            raise DirectLineRateLimitError(
                "Direct Line istek sınırı aşıldı (HTTP 429).", status,
                _retry_after(response))
        if status >= 500:
            raise DirectLineServerError(
                f"Direct Line sunucu hatası (HTTP {status}).", status)
        if status >= 400:
            raise DirectLineProtocolError(
                f"Direct Line beklenmeyen durum kodu: HTTP {status}.", status)

        try:
            data = response.json()
        except Exception as exc:  # noqa: BLE001 - JSON değilse net hata
            raise DirectLineProtocolError(
                "Direct Line cevabı JSON değil.") from exc
        if data is None:
            raise DirectLineProtocolError("Direct Line cevabı boş.")
        if not isinstance(data, dict):
            raise DirectLineProtocolError(
                f"Direct Line cevabı sözlük değil: {type(data).__name__}")
        return data

    @staticmethod
    def _safe_url(url: str) -> str:
        """Log/hata metni için URL — sorgu dizesi (token taşıyabilir) atılır."""
        return str(url).split("?", 1)[0]

    # -- Direct Line adımları ----------------------------------------------

    def _generate_token(self) -> str:
        """Secret ile kısa ömürlü konuşma token'ı üret."""
        data = self._request(
            "POST", f"{self._config.base_url}/tokens/generate",
            token=self._config.secret,
            payload={"user": {"id": self._config.user_id}},
        )
        token = data.get("token")
        if not token or not isinstance(token, str):
            raise DirectLineProtocolError(
                "Direct Line token cevabında 'token' alanı yok.")
        return token

    def _start_conversation(self, token: str) -> tuple[str, str]:
        """Konuşma başlat; (conversation_id, kullanılacak token) döndür."""
        data = self._request("POST", f"{self._config.base_url}/conversations",
                             token=token)
        conversation_id = data.get("conversationId")
        if not conversation_id or not isinstance(conversation_id, str):
            raise DirectLineConversationError(
                "Direct Line konuşma cevabında 'conversationId' yok.")
        return conversation_id, (data.get("token") or token)

    def _post_activity(self, conversation_id: str, token: str,
                       message: str) -> None:
        activity = {
            "type": "message",
            "from": {"id": self._config.user_id},
            "text": message,
            "locale": self._config.locale,
        }
        self._request(
            "POST",
            f"{self._config.base_url}/conversations/{conversation_id}/activities",
            token=token, payload=activity)

    def _poll_reply(self, conversation_id: str, token: str,
                    should_cancel: Optional[Callable[[], bool]]) -> tuple[str, int]:
        """Ajanın cevabını bekle. (metin, görülen aktivite sayısı) döndürür.

        Yoklama İKİ sınırla korunur: süre (poll_timeout) ve adım sayısı.
        Saat geri giderse ya da sunucu sürekli boş cevap verirse bile döngü
        biter — uygulama asla kilitlenmez.
        """
        config = self._config
        deadline = self._clock() + config.poll_timeout
        interval = max(0.05, config.poll_interval)
        max_polls = int(config.poll_timeout / interval) + 5
        watermark: Optional[str] = None
        activity_count = 0
        fallback_text = ""
        idle_after_reply = 0
        saw_empty_bot_message = False

        for _ in range(max_polls):
            if should_cancel is not None and should_cancel():
                raise DirectLineCancelled("Kullanıcı iptal etti.")
            if self._clock() > deadline:
                break

            params = {"watermark": watermark} if watermark else None
            data = self._request(
                "GET",
                f"{config.base_url}/conversations/{conversation_id}/activities",
                token=token, params=params)

            new_watermark = data.get("watermark")
            if new_watermark:
                watermark = str(new_watermark)

            activities = data.get("activities")
            if activities is None:
                activities = []
            if not isinstance(activities, list):
                raise DirectLineProtocolError(
                    "Direct Line 'activities' alanı liste değil.")

            for activity in activities:
                if not isinstance(activity, dict):
                    continue
                activity_count += 1
                if activity.get("type") != "message":
                    continue
                sender = (activity.get("from") or {})
                if str(sender.get("id", "")) == config.user_id:
                    continue
                text = activity.get("text") or ""
                if not text.strip():
                    text = _attachment_text(activity)
                if not text.strip():
                    # Ajan konuştu ama içerik yok: bunu zaman aşımıyla
                    # karıştırmayalım, ayrı bir hata olarak raporlanır.
                    saw_empty_bot_message = True
                    continue
                if "{" in text:
                    return text, activity_count
                # JSON olmayan bir cevap (selamlama olabilir): asıl cevabı
                # biraz daha bekle, ama sonsuza kadar değil.
                fallback_text = text

            if fallback_text:
                idle_after_reply += 1
                if idle_after_reply > config.idle_polls_after_reply:
                    return fallback_text, activity_count

            self._sleep(interval)

        if fallback_text:
            return fallback_text, activity_count
        if saw_empty_bot_message:
            raise DirectLineEmptyResponseError(
                "Ajan cevap verdi ama içerik boştu.")
        raise DirectLineTimeoutError(
            f"Ajan {config.poll_timeout:.0f} sn içinde cevap vermedi.")

    # -- genel API ----------------------------------------------------------

    def ask(self, message: str, request_id: str = "",
            should_cancel: Optional[Callable[[], bool]] = None) -> DirectLineReply:
        """Ajana bir mesaj gönder ve METİN cevabını döndür.

        Tüm tur (token → konuşma → gönderim → yoklama) tek bir deneme birimidir;
        geçici hatalarda baştan denenir. Kimlik hataları (401/403) TEKRAR
        DENENMEZ — yanlış secret her denemede yanlıştır.
        """
        config = self._config
        request_id = request_id or uuid.uuid4().hex[:12]

        # Kapalı istemcide ask() anlamlı istisna üretir (sessizce ağa çıkmaz).
        self._ensure_open()

        if not config.enabled:
            raise DirectLineDisabledError(
                "Direct Line kapalı (DIRECT_LINE_ENABLED = False).")
        if not config.configured:
            raise DirectLineDisabledError(
                "Direct Line secret girilmemiş. DIRECT_LINE_SECRET ortam "
                "değişkenini veya güvenli secret deposu ayarını yapın.")
        # Fail before the secret-bearing token request if endpoint is unsafe.
        config.base_url

        started = self._clock()
        attempts = max(1, config.max_retries + 1)   # ilk deneme + tekrarlar
        last_error: Optional[DirectLineError] = None

        with self._lock:
            for attempt in range(1, attempts + 1):
                conversation_started = False
                conversation_id = ""
                try:
                    if should_cancel is not None and should_cancel():
                        raise DirectLineCancelled("Kullanıcı iptal etti.")
                    # Retry döngüsü kapanışa saygı duyar: kapanış sırasında
                    # yeni bir tur başlatmaz.
                    self._ensure_open()

                    token = self._generate_token()
                    conversation_id, token = self._start_conversation(token)
                    conversation_started = True
                    self._post_activity(conversation_id, token, message)
                    text, activity_count = self._poll_reply(
                        conversation_id, token, should_cancel)

                    if not text.strip():
                        raise DirectLineEmptyResponseError(
                            "Ajan boş cevap döndürdü.")

                    duration = int((self._clock() - started) * 1000)
                    logger.info(
                        f"[direct-line] request_id={request_id} "
                        f"status=OK retry={attempt - 1} duration_ms={duration} "
                        f"activities={activity_count}")
                    return DirectLineReply(
                        text=text, conversation_id=conversation_id,
                        retries=attempt - 1, duration_ms=duration,
                        activity_count=activity_count, request_id=request_id)

                except DirectLineError as exc:
                    last_error = exc
                    retry = self._should_retry(exc, conversation_started)
                    logger.warning(
                        f"[direct-line] request_id={request_id} "
                        f"attempt={attempt}/{attempts} status={exc.code} "
                        f"retry={'yes' if retry and attempt < attempts else 'no'} "
                        f"detail={_redact(str(exc), config.secret)}")
                    if not retry or attempt >= attempts:
                        break
                    self._wait(self._backoff(attempt, exc), should_cancel)

        duration = int((self._clock() - started) * 1000)
        if last_error is None:  # pragma: no cover - döngü ya döner ya hata bırakır
            raise DirectLineError(
                "Direct Line çağrısı sonuçsuz bitti (beklenmeyen durum).")
        logger.error(
            f"[direct-line] request_id={request_id} status={last_error.code} "
            f"duration_ms={duration} — vazgeçildi.")
        raise last_error

    @staticmethod
    def _should_retry(exc: DirectLineError, conversation_started: bool) -> bool:
        if isinstance(exc, (DirectLineAuthError, DirectLineDisabledError,
                            DirectLineCancelled, DirectLineClosedError)):
            return False
        if isinstance(exc, DirectLineNotFoundError):
            # Konuşma açıldıktan sonraki 404 = konuşma düştü; yenisi açılabilir.
            return conversation_started
        return bool(exc.retryable)

    def _wait(self, delay: float,
              should_cancel: Optional[Callable[[], bool]]) -> None:
        """Geri çekilme beklemesi — İPTAL EDİLEBİLİR.

        20 saniyelik bir bekleme tek parça uyunursa kullanıcının "İptal"i
        20 saniye geç çalışır. Bekleme küçük dilimlere bölünür.
        """
        # Kapanış başlamışsa geri çekilme beklemesine hiç girilmez: uygulama
        # kapanırken 20 saniye boşa beklenmesin.
        self._ensure_open()
        if should_cancel is None:
            self._sleep(delay)
            return
        remaining = delay
        step = 0.5
        while remaining > 0:
            if should_cancel():
                raise DirectLineCancelled("Kullanıcı iptal etti.")
            self._ensure_open()
            dilim = min(step, remaining)
            self._sleep(dilim)
            # Uyunan kadar düşülür. (Toplam bekleme "remaining -= step"
            # ile de AYNIdır — son dilim zaten kısaltılıyor — ama böylece
            # remaining negatife düşmez ve niyet okunur kalır.)
            remaining -= dilim

    def _backoff(self, attempt: int, exc: DirectLineError) -> float:
        """Üstel geri çekilme; 429'da sunucunun istediği süreye uyulur."""
        delay = min(self._config.backoff_max,
                    self._config.backoff_base * (2 ** (attempt - 1)))
        retry_after = getattr(exc, "retry_after", None)
        if retry_after:
            try:
                delay = max(delay, min(float(retry_after),
                                       self._config.backoff_max))
            except (TypeError, ValueError):
                pass
        return delay


def _retry_after(response: Any) -> Optional[float]:
    """429 cevabındaki ``Retry-After`` başlığını saniyeye çevir."""
    try:
        headers = getattr(response, "headers", None) or {}
        value = headers.get("Retry-After") or headers.get("retry-after")
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _attachment_text(activity: dict) -> str:
    """Bot cevabı ``attachments`` içinde JSON döndürdüyse metnini çıkar."""
    import json as _json

    attachments = activity.get("attachments")
    if not isinstance(attachments, list):
        return ""
    for attachment in attachments:
        if not isinstance(attachment, dict):
            continue
        content = attachment.get("content")
        if isinstance(content, dict):
            try:
                return _json.dumps(content, ensure_ascii=False)
            except (TypeError, ValueError):
                continue
        if isinstance(content, str) and content.strip():
            return content
    return ""
