"""FAZ 6 (Aşama 5) — deterministic, explainable role scoring.

Her skor bir ``ScoreReason`` listesiyle AÇIKLANIR; opak/sihirli skor YOK.
ML/LLM YOK. Eşikler bu dosyada MERKEZİLEŞTİRİLMİŞ ve belgelendirilmiştir.

Bu modül ``app.services.column_mapper``'ın BÜYÜK, çok-dilli alias
sözlüğünü KASITLI OLARAK TEKRARLAMAZ — burada küçük, bağımsız bir alias
ipucu kümesi tutulur (header eşleşmesi SADECE bir BONUS'tur, ana kanıt
içerik profilidir). Bu bağımsızlık, ``column_mapper.py``'nin sözlüğü
değişirse bu modülün SESSİZCE bozulmamasını, ve bu modülün ``column_mapper.
py``'yi YANLIŞLIKLA etkilememesini garanti eder.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from pydantic import BaseModel, Field

from .profiling import ColumnProfile, PrimitiveType
from .roles import ROLE_STATUS, RoleImplementationStatus, SemanticRole

if TYPE_CHECKING:
    from .inference import SourceProfile

# ---------------------------------------------------------------------------
# Merkezi eşikler (belgelenmiş; "magic number" yok)
# ---------------------------------------------------------------------------

#: Bu skorun ALTINDAKİ bir aday hiç ÜRETİLMEZ (gürültü elenir).
MIN_CANDIDATE_SCORE = 0.35

#: Header birebir alias eşleşmesi bonusu (ana kanıt içerik profilidir).
_HEADER_EXACT_BONUS = 1.0
_HEADER_CONTAINS_BONUS = 0.6

#: Bilinen bir ``SourceProfile`` (ör. GENERIC_TR_CARI) bu başlığı AÇIKÇA bu
#: role bağlıyorsa eklenen ek güven (ana kanıtın ÜZERİNE, onu EZMEZ).
_KNOWN_PROFILE_BONUS = 0.15

#: Komşu kolon bağlamı bonusu (ör. DEBIT skorlanan kolonun yanında CREDIT
#: alias'lı bir başlık varsa, çift-kolon borç/alacak deseni doğrulanır).
_NEIGHBOR_CONTEXT_BONUS = 0.05

_ALIAS_HINTS: dict[SemanticRole, frozenset[str]] = {
    SemanticRole.TRANSACTION_DATE: frozenset({
        "tarih", "belgetarihi", "faturatarihi", "islemtarihi", "date",
        "invoicedate", "documentdate", "transactiondate",
    }),
    SemanticRole.POSTING_DATE: frozenset({
        "kayittarihi", "muhasebetarihi", "postingdate", "glposting", "girsitarihi",
    }),
    SemanticRole.DUE_DATE: frozenset({
        "vade", "vadetarihi", "duedate", "maturity", "fecha vencimiento",
    }),
    SemanticRole.DOCUMENT_NUMBER: frozenset({
        "faturano", "belgeno", "referans", "invoiceno", "invoicenumber",
        "documentno", "documentnumber", "reference",
    }),
    SemanticRole.EXTERNAL_DOCUMENT_NUMBER: frozenset({
        "haricibelgeno", "externaldocumentno", "muhatapbelgeno", "karsibelgeno",
    }),
    SemanticRole.REFERENCE: frozenset({
        "fisno", "dekontno", "serino", "sirano", "voucherno", "makbuzno",
    }),
    SemanticRole.DESCRIPTION: frozenset({
        "aciklama", "izahat", "description", "text", "comment", "memo", "notes",
    }),
    SemanticRole.DOCUMENT_TYPE: frozenset({
        "belgeturu", "fisturu", "documenttype", "transactiontype", "type",
    }),
    SemanticRole.COUNTERPARTY_CODE: frozenset({
        "carikodu", "hesapkodu", "account", "accountcode", "vendorcode",
        "customercode", "musterino",
    }),
    SemanticRole.COUNTERPARTY_NAME: frozenset({
        "cariunvan", "cariad", "ad", "unvan", "name", "vendorname", "customername",
    }),
    SemanticRole.DEBIT: frozenset({"borc", "borctutari", "debit", "dare", "soll"}),
    SemanticRole.CREDIT: frozenset({"alacak", "alacaktutari", "credit", "avere", "haben"}),
    SemanticRole.SIGNED_AMOUNT: frozenset({"tutar", "amount", "meblag", "net"}),
    SemanticRole.DOCUMENT_AMOUNT: frozenset({"tutar", "amount", "meblag", "net"}),
    SemanticRole.BALANCE: frozenset({"bakiye", "balance", "saldo", "kalan"}),
    SemanticRole.DOCUMENT_CURRENCY: frozenset({
        "parabirimi", "doviz", "currency", "curr", "pb", "devise",
    }),
}


class ScoreReason(BaseModel):
    """Bir skor bileşeninin AÇIKLAMASI. Kullanıcı talimatı Aşama 5: her
    aday ``reasons/evidence`` taşımalı, opak skor YASAK."""

    code: str
    weight: float
    detail: str


class RoleCandidate(BaseModel):
    role: SemanticRole
    column_index: int
    header_raw: Optional[str] = None
    score: float
    reasons: list[ScoreReason] = Field(default_factory=list)


def _header_score(profile: ColumnProfile, aliases: frozenset[str]) -> tuple[float, Optional[ScoreReason]]:
    n = profile.header_normalized
    if not n:
        return 0.0, None
    if n in aliases:
        return _HEADER_EXACT_BONUS, ScoreReason(
            code="header_alias_match", weight=_HEADER_EXACT_BONUS,
            detail=f"header {profile.header_raw!r} birebir alias eşleşmesi",
        )
    for a in aliases:
        if len(a) > 3 and a in n:
            return _HEADER_CONTAINS_BONUS, ScoreReason(
                code="header_alias_match", weight=_HEADER_CONTAINS_BONUS,
                detail=f"header {profile.header_raw!r} alias {a!r} içeriyor",
            )
    return 0.0, None


def _known_profile_score(
    profile: ColumnProfile, role: SemanticRole, profile_hint: Optional["SourceProfile"],
) -> tuple[float, Optional[ScoreReason]]:
    if profile_hint is None:
        return 0.0, None
    aliases = profile_hint.header_aliases.get(role, frozenset())
    if profile.header_normalized in aliases:
        return _KNOWN_PROFILE_BONUS, ScoreReason(
            code="known_source_profile_hint", weight=_KNOWN_PROFILE_BONUS,
            detail=f"{profile_hint.name} profili bu başlığı {role.value} ile eşlemiş",
        )
    return 0.0, None


def _neighbor_context_score(
    profile: ColumnProfile, companion_aliases: frozenset[str],
) -> tuple[float, Optional[ScoreReason]]:
    for h in profile.neighboring_headers:
        n = "".join(ch for ch in h.lower() if ch.isalnum())
        if n in companion_aliases or any(len(a) > 3 and a in n for a in companion_aliases):
            return _NEIGHBOR_CONTEXT_BONUS, ScoreReason(
                code="neighbor_context", weight=_NEIGHBOR_CONTEXT_BONUS,
                detail=f"komşu başlık {h!r} eşlik eden rolü doğruluyor",
            )
    return 0.0, None


def _clip(score: float) -> float:
    return max(0.0, min(1.0, score))


def _score_date_role(
    profile: ColumnProfile, role: SemanticRole, profile_hint: Optional["SourceProfile"],
) -> Optional[RoleCandidate]:
    if profile.date_ratio < 0.3:
        return None
    reasons: list[ScoreReason] = []
    aliases = _ALIAS_HINTS[role]
    header_s, header_reason = _header_score(profile, aliases)
    if header_reason:
        reasons.append(header_reason)
    known_s, known_reason = _known_profile_score(profile, role, profile_hint)
    if known_reason:
        reasons.append(known_reason)
    reasons.append(ScoreReason(
        code="date_content_ratio", weight=0.55,
        detail=f"date_ratio={profile.date_ratio:.2f}",
    ))
    score = _clip(0.30 * header_s + 0.55 * min(1.0, profile.date_ratio) + known_s)
    if score < MIN_CANDIDATE_SCORE:
        return None
    return RoleCandidate(role=role, column_index=profile.index, header_raw=profile.header_raw,
                         score=score, reasons=reasons)


def _score_identifier_role(
    profile: ColumnProfile, role: SemanticRole, profile_hint: Optional["SourceProfile"],
) -> Optional[RoleCandidate]:
    if profile.inferred_primitive_type == PrimitiveType.NUMERIC and profile.date_ratio < 0.1:
        # Salt sayısal ama tarih/metin değilse bile belge-no olabilir
        # (ör. "4500492000"); aşağıdaki identifier_like_ratio zaten bunu
        # kapsıyor (regex alfasayısal kod kabul eder).
        pass
    if profile.identifier_like_ratio < 0.4 and profile.text_ratio < 0.4:
        return None
    reasons: list[ScoreReason] = []
    aliases = _ALIAS_HINTS[role]
    header_s, header_reason = _header_score(profile, aliases)
    if header_reason:
        reasons.append(header_reason)
    known_s, known_reason = _known_profile_score(profile, role, profile_hint)
    if known_reason:
        reasons.append(known_reason)
    reasons.append(ScoreReason(
        code="identifier_pattern", weight=0.45,
        detail=f"identifier_like_ratio={profile.identifier_like_ratio:.2f}, "
               f"unique_ratio={profile.unique_ratio:.2f}",
    ))
    score = _clip(
        0.35 * header_s
        + 0.45 * profile.identifier_like_ratio
        + 0.15 * profile.unique_ratio
        + known_s
    )
    if score < MIN_CANDIDATE_SCORE:
        return None
    return RoleCandidate(role=role, column_index=profile.index, header_raw=profile.header_raw,
                         score=score, reasons=reasons)


def _score_text_role(
    profile: ColumnProfile, role: SemanticRole, profile_hint: Optional["SourceProfile"],
) -> Optional[RoleCandidate]:
    if profile.text_ratio < 0.4:
        return None
    reasons: list[ScoreReason] = []
    aliases = _ALIAS_HINTS[role]
    header_s, header_reason = _header_score(profile, aliases)
    if header_reason:
        reasons.append(header_reason)
    known_s, known_reason = _known_profile_score(profile, role, profile_hint)
    if known_reason:
        reasons.append(known_reason)
    reasons.append(ScoreReason(
        code="text_content_ratio", weight=0.5,
        detail=f"text_ratio={profile.text_ratio:.2f}",
    ))
    score = _clip(0.40 * header_s + 0.50 * profile.text_ratio + known_s)
    if score < MIN_CANDIDATE_SCORE:
        return None
    return RoleCandidate(role=role, column_index=profile.index, header_raw=profile.header_raw,
                         score=score, reasons=reasons)


def _score_counterparty_code(
    profile: ColumnProfile, profile_hint: Optional["SourceProfile"],
) -> Optional[RoleCandidate]:
    """``COUNTERPARTY_CODE`` için ``_score_identifier_role``'dan AYRI bir
    skor fonksiyonu: cari/vendor kodu TİPİK OLARAK TEKRARLANIR (aynı
    müşteri birden fazla satırda görünür). Tam-benzersiz (``unique_ratio``
    ~1.0) bir kolon, header/profil ipucu YOKSA, muhtemelen bir BELGE NO'dur
    — cari kod DEĞİL. Bu ayrım olmadan ``DOCUMENT_NUMBER`` ve
    ``COUNTERPARTY_CODE`` birbirinden ayırt edilemezdi (bkz. doc 20 §Açık
    sorular — bu, test #13'ün doğrudan motivasyonu)."""
    if profile.identifier_like_ratio < 0.4 and profile.text_ratio < 0.4:
        return None
    reasons: list[ScoreReason] = []
    header_s, header_reason = _header_score(profile, _ALIAS_HINTS[SemanticRole.COUNTERPARTY_CODE])
    if header_reason:
        reasons.append(header_reason)
    known_s, known_reason = _known_profile_score(profile, SemanticRole.COUNTERPARTY_CODE, profile_hint)
    if known_reason:
        reasons.append(known_reason)
    repetition_signal = 1.0 - profile.unique_ratio
    reasons.append(ScoreReason(
        code="identifier_pattern", weight=0.35,
        detail=f"identifier_like_ratio={profile.identifier_like_ratio:.2f}, "
               f"repetition_signal={repetition_signal:.2f}",
    ))
    score = _clip(0.45 * header_s + 0.35 * profile.identifier_like_ratio + 0.20 * repetition_signal + known_s)
    if header_s == 0.0 and known_s == 0.0 and repetition_signal < 0.3:
        # Hiçbir alias/profil ipucu yok VE kolon neredeyse tamamen
        # benzersiz: bu bir cari kod değil, muhtemelen bir belge no'dur.
        return None
    if score < MIN_CANDIDATE_SCORE:
        return None
    return RoleCandidate(role=SemanticRole.COUNTERPARTY_CODE, column_index=profile.index,
                         header_raw=profile.header_raw, score=score, reasons=reasons)


def _score_debit_or_credit(
    profile: ColumnProfile, role: SemanticRole, profile_hint: Optional["SourceProfile"],
) -> Optional[RoleCandidate]:
    if profile.numeric_ratio < 0.5:
        return None
    reasons: list[ScoreReason] = []
    aliases = _ALIAS_HINTS[role]
    header_s, header_reason = _header_score(profile, aliases)
    if header_reason:
        reasons.append(header_reason)
    known_s, known_reason = _known_profile_score(profile, role, profile_hint)
    if known_reason:
        reasons.append(known_reason)
    companion = SemanticRole.CREDIT if role is SemanticRole.DEBIT else SemanticRole.DEBIT
    neighbor_s, neighbor_reason = _neighbor_context_score(profile, _ALIAS_HINTS[companion])
    if neighbor_reason:
        reasons.append(neighbor_reason)
    reasons.append(ScoreReason(
        code="numeric_content_ratio", weight=0.30,
        detail=f"numeric_ratio={profile.numeric_ratio:.2f}",
    ))
    # Çift-kolon borç/alacak şemalarında bu kolonlar TİPİK OLARAK yarı-boştur
    # (bir satırda ya borç ya alacak dolu). Tam dolu (non_null_ratio yüksek)
    # bir sayısal kolon, daha çok tek-kolon imzalı tutar adayıdır — ama bu
    # BAŞLI BAŞINA header alias'ı EZMEZ, küçük bir ek sinyal.
    sparsity_bonus = 0.10 if 0.15 <= profile.non_null_ratio <= 0.85 else 0.0
    if sparsity_bonus:
        reasons.append(ScoreReason(
            code="numeric_content_ratio", weight=sparsity_bonus,
            detail=f"non_null_ratio={profile.non_null_ratio:.2f} (çift-kolon şeması için tipik seyreklik)",
        ))
    score = _clip(0.55 * header_s + 0.30 * profile.numeric_ratio + sparsity_bonus + known_s + neighbor_s)
    # Header ipucu YOKSA (header_s==0) ve rol-özel alias hiç eşleşmediyse,
    # salt "sayısal kolon" kanıtı DEBIT/CREDIT iddiası için YETERSİZDİR
    # (herhangi bir tutar kolonu bu testi geçebilirdi) — kullanıcı talimatı
    # Aşama 13 test #3: "numeric column not mistaken for amount purely by type".
    if header_s == 0.0 and known_s == 0.0:
        return None
    if score < MIN_CANDIDATE_SCORE:
        return None
    return RoleCandidate(role=role, column_index=profile.index, header_raw=profile.header_raw,
                         score=score, reasons=reasons)


def _score_balance(
    profile: ColumnProfile, profile_hint: Optional["SourceProfile"],
) -> Optional[RoleCandidate]:
    if profile.numeric_ratio < 0.5:
        return None
    reasons: list[ScoreReason] = []
    header_s, header_reason = _header_score(profile, _ALIAS_HINTS[SemanticRole.BALANCE])
    if header_reason:
        reasons.append(header_reason)
    known_s, known_reason = _known_profile_score(profile, SemanticRole.BALANCE, profile_hint)
    if known_reason:
        reasons.append(known_reason)
    reasons.append(ScoreReason(
        code="balance_monotonicity", weight=0.45,
        detail=f"monotonic_score={profile.monotonic_score:.2f}",
    ))
    score = _clip(0.35 * header_s + 0.45 * profile.monotonic_score + 0.10 * profile.numeric_ratio + known_s)
    if header_s == 0.0 and profile.monotonic_score < 0.75:
        return None
    if score < MIN_CANDIDATE_SCORE:
        return None
    return RoleCandidate(role=SemanticRole.BALANCE, column_index=profile.index,
                         header_raw=profile.header_raw, score=score, reasons=reasons)


def _score_amount(
    profile: ColumnProfile, role: SemanticRole, profile_hint: Optional["SourceProfile"],
) -> Optional[RoleCandidate]:
    if profile.numeric_ratio < 0.5:
        return None
    reasons: list[ScoreReason] = []
    header_s, header_reason = _header_score(profile, _ALIAS_HINTS[role])
    if header_reason:
        reasons.append(header_reason)
    known_s, known_reason = _known_profile_score(profile, role, profile_hint)
    if known_reason:
        reasons.append(known_reason)
    reasons.append(ScoreReason(
        code="numeric_content_ratio", weight=0.35,
        detail=f"numeric_ratio={profile.numeric_ratio:.2f}, non_null_ratio={profile.non_null_ratio:.2f}",
    ))
    # Bakiye-benzeri (yüksek monotonicity) bir kolon TUTAR adayı DEĞİLDİR —
    # yürüyen bakiye, işlem tutarı değil (doc 16 §3 ile aynı ilke, BAĞIMSIZ
    # olarak burada da uygulanır).
    if profile.monotonic_score > 0.75:
        return None
    density_bonus = 0.15 if profile.non_null_ratio >= 0.85 else 0.0
    score = _clip(0.50 * header_s + 0.35 * profile.numeric_ratio + density_bonus + known_s)
    if header_s == 0.0 and known_s == 0.0:
        return None
    if score < MIN_CANDIDATE_SCORE:
        return None
    return RoleCandidate(role=role, column_index=profile.index, header_raw=profile.header_raw,
                         score=score, reasons=reasons)


def _score_currency(
    profile: ColumnProfile, profile_hint: Optional["SourceProfile"],
) -> Optional[RoleCandidate]:
    if profile.currency_code_ratio < 0.4 and profile.header_normalized not in _ALIAS_HINTS[SemanticRole.DOCUMENT_CURRENCY]:
        return None
    reasons: list[ScoreReason] = []
    header_s, header_reason = _header_score(profile, _ALIAS_HINTS[SemanticRole.DOCUMENT_CURRENCY])
    if header_reason:
        reasons.append(header_reason)
    known_s, known_reason = _known_profile_score(profile, SemanticRole.DOCUMENT_CURRENCY, profile_hint)
    if known_reason:
        reasons.append(known_reason)
    reasons.append(ScoreReason(
        code="currency_code_pattern", weight=0.50,
        detail=f"currency_code_ratio={profile.currency_code_ratio:.2f}",
    ))
    score = _clip(0.35 * header_s + 0.50 * profile.currency_code_ratio + known_s)
    if score < MIN_CANDIDATE_SCORE:
        return None
    return RoleCandidate(role=SemanticRole.DOCUMENT_CURRENCY, column_index=profile.index,
                         header_raw=profile.header_raw, score=score, reasons=reasons)


#: Bu fazda GERÇEKTEN skorlanan roller (ROLE_STATUS ile TUTARLI olmalı;
#: test_faz6 bunu doğrular).
IMPLEMENTED_ROLES: frozenset[SemanticRole] = frozenset(
    role for role, (status, _) in ROLE_STATUS.items()
    if status is RoleImplementationStatus.IMPLEMENT_NOW
)


def score_column(
    profile: ColumnProfile, *, profile_hint: Optional["SourceProfile"] = None,
) -> list[RoleCandidate]:
    """Bir ``ColumnProfile`` için TÜM IMPLEMENT_NOW rollerine aday üret.

    Döner: skora göre AZALAN sıralı ``RoleCandidate`` listesi (boş liste =
    hiçbir rol için ``MIN_CANDIDATE_SCORE`` eşiği geçilmedi).
    """
    candidates: list[RoleCandidate] = []
    for role in (SemanticRole.TRANSACTION_DATE, SemanticRole.POSTING_DATE, SemanticRole.DUE_DATE):
        c = _score_date_role(profile, role, profile_hint)
        if c:
            candidates.append(c)
    for role in (SemanticRole.DOCUMENT_NUMBER, SemanticRole.EXTERNAL_DOCUMENT_NUMBER, SemanticRole.REFERENCE):
        c = _score_identifier_role(profile, role, profile_hint)
        if c:
            candidates.append(c)
    for role in (SemanticRole.DESCRIPTION, SemanticRole.DOCUMENT_TYPE, SemanticRole.COUNTERPARTY_NAME):
        c = _score_text_role(profile, role, profile_hint)
        if c:
            candidates.append(c)
    c = _score_counterparty_code(profile, profile_hint)
    if c:
        candidates.append(c)
    for role in (SemanticRole.DEBIT, SemanticRole.CREDIT):
        c = _score_debit_or_credit(profile, role, profile_hint)
        if c:
            candidates.append(c)
    c = _score_balance(profile, profile_hint)
    if c:
        candidates.append(c)
    for role in (SemanticRole.SIGNED_AMOUNT, SemanticRole.DOCUMENT_AMOUNT):
        c = _score_amount(profile, role, profile_hint)
        if c:
            candidates.append(c)
    c = _score_currency(profile, profile_hint)
    if c:
        candidates.append(c)
    candidates.sort(key=lambda rc: (-rc.score, rc.role.value))
    return candidates
