"""Gönderim öncesi muhafazakâr SMTP adres doğrulaması."""

from __future__ import annotations

import re

_DOMAIN_LABEL = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?$")
_LOCAL_FORBIDDEN = frozenset('()<>[]:;,@"\\')


def is_valid_email(address: object) -> bool:
    """Açıkça hatalı/başlık enjeksiyonlu adresleri reddet.

    Display-name biçimi bilinçli olarak kabul edilmez; Excel alanının yalnızca
    SMTP adresi taşıması beklenir. Unicode alan adları IDNA ile doğrulanır.
    """
    if not isinstance(address, str):
        return False
    value = address.strip()
    if not value or len(value) > 254 or value.count("@") != 1:
        return False
    if any(ch.isspace() or ord(ch) < 32 or ord(ch) == 127 for ch in value):
        return False
    local, domain = value.rsplit("@", 1)
    if (not local or len(local) > 64 or local.startswith(".")
            or local.endswith(".") or ".." in local
            or any(ch in _LOCAL_FORBIDDEN for ch in local)):
        return False
    try:
        ascii_domain = domain.encode("idna").decode("ascii")
    except UnicodeError:
        return False
    if not ascii_domain or len(ascii_domain) > 253 or ascii_domain.endswith("."):
        return False
    labels = ascii_domain.split(".")
    return all(_DOMAIN_LABEL.fullmatch(label) for label in labels)
