"""File loaders for TOFAŞ and firma statements.

Deterministic parsing into normalized records. Both loaders now keep *all*
candidate reference values per row (since the correct reference column varies
by firm), plus a primary amount. The TOFAŞ loader detects the SAP yellow total
row and filters by main account (320*/323*). PDF loading is supported for firma
statements; scanned PDFs fall back to an optional injected OCR hook - the only
place AI may ever be involved.
"""

from __future__ import annotations

import csv
import re
from decimal import Decimal
from pathlib import Path
from typing import Callable, Optional

import pandas as pd

from app.models.domain import FirmaRecord, TofasRecord
from app.services.column_mapper import map_firma_columns, map_tofas_columns
from app.services.customer_accounts import normalize_account
from app.services.errors import DataValidationError, MappingError
from app.services.totals import is_noninvoice_ref, is_opening_row, is_total_row
from app.utils.file_safety import UnsafeInputError, validate_input_file
from app.utils.normalization import (
    clean_currency,
    clean_string,
    normalize_amount,
    normalize_date,
    normalize_reference,
    try_normalize_amount,
)

_EXTRACTION_TABULAR = "deterministic_tabular"
_EXTRACTION_PDF = "deterministic_pdf"


def _strict_amount(
    value: object,
    *,
    path: Path,
    row_index: int,
    column_name: object,
) -> Decimal:
    """Parse a mapped monetary cell without turning corrupt text into zero.

    Empty cells remain legitimate zero values (``try_normalize_amount``'s
    documented behaviour). A non-empty/unreadable value is different: if it
    were coerced to zero, two corrupt rows with the same reference could be
    reported as a financial match. Fail closed and identify the data row.
    """
    parsed = try_normalize_amount(value)
    if parsed is not None:
        return parsed
    raw = clean_string(value) or repr(value)
    if len(raw) > 80:
        raw = raw[:77] + "..."
    raise DataValidationError(
        f"{path.name} dosyasında geçersiz tutar: veri satırı "
        f"{row_index + 1}, kolon '{clean_string(column_name) or column_name}', "
        f"değer {raw!r}. Bu hücre sıfır kabul edilmedi; kaynağı düzeltip "
        "yeniden deneyin."
    )

# Çok dilli başlık-satırı anahtar kökleri (normalize edilmiş, alt-dize eşleşmesi).
# Başlık satırı sayfanın ilk satırında OLMAYABİLİR (üstte firma/başlık bloğu:
# FRANCE r2, İTALYAV3 r14, BARSAN r2, Overdue r1). Türkçe-only anahtar listesi
# İngilizce/İtalyanca/İspanyolca/Fransızca/Almanca SAP+ERP başlıklarını kaçırıyordu.
# Bu köklerden en çok içeren satır başlık kabul edilir (bkz. _detect_header_idx).
_HEADER_KEYWORDS: frozenset[str] = frozenset({
    # tutar / borç-alacak / bakiye
    "amount", "tutar", "importo", "montant", "importe", "valor", "valore",
    "betrag", "kwota", "value", "borc", "alacak", "debit", "credit", "dare",
    "avere", "soll", "haben", "debito", "credito", "saldo", "solde", "bakiye",
    "balance", "meblag",
    # belge / fatura / referans
    "invoice", "fattura", "factura", "facture", "fatura", "faktura", "belge",
    "documento", "dokument", "document", "reference", "referans", "riferimento",
    "referencia", "referenz", "evrak", "assignment", "num", "fis",
    # tarih / vade
    "date", "tarih", "data", "fecha", "datum", "vade", "scadenza", "echeance",
    "vencimiento", "faellig", "due", "posting",
    # taraf / cari / para birimi / açıklama
    "hesap", "account", "konto", "conto", "cliente", "fornitore", "vendor",
    "supplier", "lieferant", "name", "unvan", "currency", "divisa", "doviz",
    "waluta", "aciklama", "testo", "descrizione", "comment", "text", "type",
    "tipo", "tip",
})


_HDR_TRANS = str.maketrans("çğıöşü", "cgiosu")


def _row_header_score(cells) -> int:
    """Bir satırdaki METİN hücrelerinden kaçının bilinen bir başlık kökü
    içerdiğini say. Salt sözlük/alt-dize araması — AI yok."""
    score = 0
    for cell in cells:
        if cell is None:
            continue
        try:
            if pd.isna(cell):
                continue
        except (TypeError, ValueError):
            pass
        text = str(cell).strip().lower()
        if not text:
            continue
        n = re.sub(r"[^a-z0-9]", "", text.translate(_HDR_TRANS))
        if not n or n.isdigit():
            continue
        if any(kw in n for kw in _HEADER_KEYWORDS):
            score += 1
    return score


def _detect_header_idx(df_temp) -> int:
    """Başlık satırının indeksini çok dilli skorlama ile bul (deterministik).

    En yüksek skorlu satır (≥2 farklı başlık kökü) başlıktır; beraberlikte EN
    ERKEN satır seçilir. Hiçbir satır ≥2 skor almazsa 0'a düşer (önceki güvenli
    davranış). Başlık satırı sayfanın ilk satırında olmayabilir.
    """
    best_idx, best_score = 0, 0
    for idx, row in df_temp.iterrows():
        score = _row_header_score(row.tolist())
        if score > best_score:
            best_score, best_idx = score, idx
    return best_idx if best_score >= 2 else 0


def _detect_header_idx_rows(rows: list[list[object]], limit: int = 25) -> int:
    """`_detect_header_idx` ile aynı skorlama, ama liste-satırlar için (PDF).

    PDF çıktısında tablo üstünde firma/başlık bloğu olabilir (ör. 'Cari Kodu :'
    satırı). Excel yolundaki çok dilli başlık tespitini PDF'e de uygular."""
    best_idx, best_score = 0, 0
    for idx, row in enumerate(rows[:limit]):
        score = _row_header_score(row if isinstance(row, list) else list(row))
        if score > best_score:
            best_score, best_idx = score, idx
    return best_idx if best_score >= 2 else 0


def _pick_data_sheet(xl, sheet_names: list[str]) -> str:
    """Çok-sayfalı workbook'ta ASIL veri sayfasını deterministik seç.

    Bazı dışa-aktarımlarda ilk/aktif sayfa bir ÖZET/PIVOT sayfasıdır (ör.
    'PIVOT TABLE' + 'OVERVIEW'); asıl kalem verisi başka sayfadadır. Her
    sayfanın en güçlü başlık-satır skorunu ve veri satırı sayısını hesaplar;
    (başlık skoru, satır sayısı) en yüksek olanı seçer — beraberlikte sayfa
    sırası korunur. Salt yapısal ölçüm — AI yok.
    """
    best_name = sheet_names[0]
    best_key = (-1, -1)
    for sn in sheet_names:
        try:
            probe = pd.read_excel(xl, sheet_name=sn, header=None, nrows=25)
        except Exception:
            continue
        max_score = 0
        for _, row in probe.iterrows():
            s = _row_header_score(row.tolist())
            if s > max_score:
                max_score = s
        try:
            n_rows = int(xl.book[sn].max_row) if hasattr(xl, "book") else len(probe)
        except Exception:
            n_rows = len(probe)
        key = (max_score, n_rows)
        if key > best_key:
            best_key, best_name = key, sn
    return best_name


class UnsupportedFileError(Exception):
    pass


def _read_any(path: Path) -> tuple[list[object], list[list[object]]]:
    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xls"}:
        try:
            # ``with``: ExcelFile kapatılmazsa dosya TANITICISI açık kalır.
            # Windows'ta bunun iki somut sonucu vardı:
            #   1. Okunan dosya silinemez/üzerine yazılamaz olur — geçici
            #      ekstre dosyaları %TEMP%'te kalıyordu (finansal veri diskte).
            #   2. Uzun süre açık kalan uygulamada kullanıcının kendi Excel
            #      dosyası kilitli kalır; sonuç yazımı "dosya kullanımda"
            #      hatasına düşerdi.
            with pd.ExcelFile(path) as xl:
                sheet = (xl.sheet_names[0] if len(xl.sheet_names) == 1
                         else _pick_data_sheet(xl, list(xl.sheet_names)))

                # Sonra başlık satırını tespit et (çok dilli, skorlamalı)
                df_temp = pd.read_excel(xl, sheet_name=sheet, header=None,
                                        nrows=25)
                header_idx = _detect_header_idx(df_temp)

                df = pd.read_excel(xl, sheet_name=sheet, header=header_idx)

            # NOT: Açılış/devir satırları burada ELENMEZ. Yükleyici döngüsü
            # bunları is_opening_row ile tanıyıp toplam bakiye kontrolü için
            # ayrı toplar; kalem eşleştirmesine almaz. Böylece 'DEVREDEN' değeri
            # de yakalanabilir (df seviyesinde atılırsa opening bakiye kaybolur).

            # Boş satırları tamamen temizle
            df = df.dropna(how='all')
            
            # Kolon isimlerini string yap
            headers = [str(c) if not pd.isna(c) else "" for c in df.columns.tolist()]
            
            # Veri satırlarını listeye çevir (NaN'ları None yap)
            rows = []
            for _, row in df.iterrows():
                rows.append([None if pd.isna(val) else val for val in row.tolist()])
                
            return headers, rows
            
        except Exception:
            from openpyxl import load_workbook
            wb = load_workbook(path, read_only=True, data_only=True)
            # try/finally: okuma ortasında hata olursa kitap kapanmadan
            # kalıyordu. read_only kitap kaynak dosyanın tanıtıcısını AÇIK
            # tutar; Windows'ta bu, kullanıcının dosyayı kaydetmesini/
            # silmesini engelleyebilir.
            try:
                ws = wb.active
                all_rows = [list(r) for r in ws.iter_rows(values_only=True)]
            finally:
                wb.close()
            if not all_rows:
                return [], []
            return all_rows[0], all_rows[1:]
            
    elif suffix == ".csv":
        with path.open("r", encoding="utf-8-sig", newline="") as fh:
            sample = fh.read(4096)
            fh.seek(0)
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=";,\t|")
            except csv.Error:
                dialect = csv.excel
                dialect.delimiter = ";" if sample.count(";") > sample.count(",") else ","
            all_rows = [list(r) for r in csv.reader(fh, dialect)]
    elif suffix == ".txt":
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        delim = "\t" if lines and "\t" in lines[0] else (
            ";" if lines and ";" in lines[0] else ",")
        all_rows = [line.split(delim) for line in lines if line.strip()]
    else:
        raise UnsupportedFileError(f"Desteklenmeyen dosya türü: {suffix}")
        
    if not all_rows:
        return [], []
    return all_rows[0], all_rows[1:]


#: PDF tablo çıkarma stratejileri — SIRA ÖNEMLİDİR.
#
# NEDEN BİRDEN ÇOK STRATEJİ
#     pdfplumber'ın varsayılan (çizgi tabanlı) çıkarımı, tablo kenarlıkları
#     çizilmemiş ekstrelerde başlık satırının TAMAMINI tek hücreye çökertir
#     (ör. "İŞLEM TARİHİ AÇIKLAMA VADE TARİHİ BORÇ ALACAK" tek string).
#     Böyle bir başlıkta hiçbir kolon tanınamaz ve dosya "referans kolonu
#     yok" diye reddedilir — oysa veri oradadır. Metin/boşluk hizasına
#     bakan stratejiler bu dosyalarda kolonları doğru ayırır.
#
# NEDEN "İLK UYAN KAZANIR" (en yüksek skor DEĞİL)
#     Varsayılan strateji listenin BAŞINDADIR ve kullanılabilir bir başlık
#     verdiği anda seçilir. Böylece BUGÜN OKUNABİLEN her dosya birebir
#     aynı şekilde okunmaya devam eder; yeni stratejiler yalnızca bugün
#     BAŞARISIZ olan dosyalarda devreye girer. Sıra sabit olduğu için
#     sonuç deterministiktir: aynı dosya her zaman aynı stratejiyle okunur.
_PDF_TABLE_STRATEGIES: tuple[Optional[dict], ...] = (
    None,                                                       # varsayılan (çizgi)
    {"vertical_strategy": "text", "horizontal_strategy": "lines"},
    {"vertical_strategy": "text", "horizontal_strategy": "text"},
    {"vertical_strategy": "lines", "horizontal_strategy": "text"},
)


def _pdf_rows_with(pdf, settings: Optional[dict]) -> list[list[object]]:
    """Tüm sayfaları tek strateji ile oku."""
    rows: list[list[object]] = []
    for page in pdf.pages:
        try:
            tables = (page.extract_tables(settings) if settings
                      else page.extract_tables()) or []
        except Exception:  # noqa: BLE001 - strateji bu sayfada geçersiz olabilir
            tables = []
        for table in tables:
            for r in table:
                if r is not None:
                    rows.append(list(r))
        if not tables and settings is None:
            # Varsayılan stratejide tablo yoksa kelime/konum hattına düş
            # (mevcut davranış korunur).
            rows.extend(_pdf_words_to_rows(page))
    return rows


def _pdf_header_usable(header: list[object]) -> bool:
    """Bu başlık satırı mutabakat için YETERLİ mi?

    Motorun gerçekten ihtiyaç duyduğu ikili: bir referans/belge no kolonu
    VE bir tutar kaynağı (tutar ya da borç/alacak). Biri eksikse dosya
    zaten reddedilecektir; bu yüzden strateji "işe yaradı" sayılmaz.
    """
    try:
        roles = map_firma_columns(header)
    except Exception:  # noqa: BLE001
        return False
    if not roles.get("reference"):
        return False
    return bool(roles.get("amount") or roles.get("debit")
                or roles.get("credit"))


def _pdf_metin_ornegi(path: Path) -> str:
    """PDF'in İLK sayfasının metni (belge türü ipucu için).

    Yalnızca hata yolunda çağrılır. Belge türünü ele veren ifadeler
    ("ORDER FORM", "FAKTURA / RECHNUNG") tablo başlığında değil sayfa
    METNİNDE bulunur; ayrıştırılmış satırlara bakmak yetmiyordu.
    """
    try:
        import pdfplumber

        with pdfplumber.open(path) as pdf:
            if not pdf.pages:
                return ""
            return (pdf.pages[0].extract_text() or "")[:4000]
    except Exception:  # noqa: BLE001 - ipucu üretimi asla çökertmemeli
        return ""


#: SAP FBL çıktısına ÖZGÜ alanlar. Karşı tarafın kendi ekstresinde bu
#: başlıklar bulunmaz; ikisi birden varsa dosya bir SAP çıktısıdır.
_SAP_IMZA_ALANLARI = ("main_account", "belge_turu")


def prefix_filter_applies(rows: list[list[object]], main_idx: Optional[int],
                          prefixes) -> bool:
    """Hesap öneki filtresi bu dosyada UYGULANMALI mı?

    Kural (kullanıcı kararı): satırların YARIDAN fazlası seçilen önekle
    başlıyorsa filtre uygulanır; aksi hâlde dosya o modun dosyası değildir
    ve filtre TÜM satırları eleyeceği için hiç uygulanmaz.

    TEK KAYNAK: hem ``TofasLoader.load`` hem ``peek_belge_turleri`` bunu
    kullanır. İki yerde ayrı ayrı yazılırsa, belge türü listesi ile
    mutabakata giren satırlar sessizce birbirinden ayrışabilirdi.
    """
    if main_idx is None or not prefixes:
        return False
    match_cnt = total_cnt = 0
    for row in rows:
        if _is_blank(row):
            continue
        acc = clean_string(_cell(row, main_idx))
        if not acc:
            continue
        total_cnt += 1
        if any(acc.startswith(p) for p in prefixes):
            match_cnt += 1
    return total_cnt > 0 and match_cnt > total_cnt / 2


def sap_header_score(headers: list[object]) -> float:
    """Başlık satırı ne kadar SAP FBL çıktısına benziyor? 0.0 – 1.0

    Dosyaların TERS yuvaya konmasını yakalamak için kullanılır
    (bkz. reconciliation_service._dosyalar_ters_mi). Ek dosya okuması
    yapmaz: yükleyicinin zaten elinde olan başlık satırına bakar.
    """
    try:
        mapping, _ = map_tofas_columns(list(headers))
    except Exception:  # noqa: BLE001 - ölçüm asla çökertmemeli
        return 0.0
    bulunan = sum(1 for alan in _SAP_IMZA_ALANLARI
                  if mapping.get(alan) is not None)
    return bulunan / len(_SAP_IMZA_ALANLARI)


# Mutabakat SONUÇ kitabının detay sayfalarının imzası. Bu başlıkları
# TAŞIYAN bir dosya ekstre değildir: UYGULAMANIN KENDİ ÇIKTISIDIR.
#
# NEDEN GEREKLİ — ölçülen senaryo
#     Sonuç dosyası (``<ad>_mutabakat.xlsx``) kaynak ekstrenin YANINDA ya da
#     aynı çıktı klasöründe, benzer adla durur. Yüzlerce firmalık bir dönemde
#     yanlış dosyayı seçmek çok kolaydır. Seçildiğinde yükleyici onu sessizce
#     ekstre olarak OKUYORDU: "Fatura No (Firma)" referans, "Firma Tutar"
#     tutar sanılıyor; "Sadece TOFAŞ'ta" satırlarında firma tutarı boş olduğu
#     için tutar 0 okunuyor ve mutabakat ÇÖP VERİ üzerinde çalışıyordu —
#     hiçbir hata ya da uyarı olmadan.
#
# Bu başlıklar ``result_writer._COLUMNS`` ile AYNI olmalıdır; eşleşmeyi
# ``tests/test_wrong_file_guard.py`` kilitler (yeniden adlandırma bu
# korumayı sessizce devre dışı bırakamaz).
_SONUC_IMZA_BASLIKLARI: tuple[str, ...] = (
    "fatura no (firma)",
    "fatura no (tofaş)",
)


def looks_like_result_workbook(headers: list[object]) -> bool:
    """Başlık satırı, uygulamanın KENDİ sonuç kitabına mı ait?

    Ek dosya okuması yapmaz; yükleyicinin elindeki başlık satırına bakar.

    Türkçe büyük harf İ/I, ``str.lower()`` ile beklenen harfe düşmez
    ("FİRMA".lower() noktalı i üretir, "FIRMA".lower() ise "firma"). Dosya
    elle düzenlenip başlıklar büyük harfe çevrilmiş olabileceği için bu iki
    harf karşılaştırmadan ÖNCE sadeleştirilir.
    """
    def _katla(text: str) -> str:
        return (text.strip()
                .replace("İ", "i").replace("I", "ı")
                .lower()
                .replace("ı", "i"))

    folded = {_katla(str(h or "")) for h in headers}
    hedef = {_katla(imza) for imza in _SONUC_IMZA_BASLIKLARI}
    return hedef <= folded


def _belge_turu_ipucu(headers: list[object],
                      rows: list[list[object]],
                      path: Optional[Path] = None) -> str:
    """Dosya ekstre değilse kullanıcıya gösterilecek EK açıklama.

    YALNIZCA hata yolunda çağrılır: dosya zaten reddedilmiştir, burada
    sadece "neden" daha anlaşılır hâle getirilir. Hiçbir dosyanın
    okunmasını engellemez ya da sağlamaz (bkz. app/services/document_type).
    """
    try:
        from app.services.document_type import (
            detect_document_type,
            explain_document_type,
        )

        ornekler: list[object] = list(headers)
        for satir in rows[:5]:
            ornekler.extend(satir)
        if path is not None and str(path).lower().endswith(".pdf"):
            ornekler.append(_pdf_metin_ornegi(path))
        return explain_document_type(detect_document_type(ornekler)) or ""
    except Exception:  # noqa: BLE001 - açıklama üretimi asla çökertmemeli
        return ""


def _read_pdf(path: Path, ocr_callback) -> tuple[list[object], list[list[object]]]:
    try:
        import pdfplumber
    except ImportError as exc:
        raise UnsupportedFileError(
            "PDF okumak için 'pdfplumber' kütüphanesi gerekli. "
        ) from exc

    ilk_rows: list[list[object]] = []
    secilen: list[list[object]] = []
    with pdfplumber.open(path) as pdf:
        for sira, settings in enumerate(_PDF_TABLE_STRATEGIES):
            rows = _pdf_rows_with(pdf, settings)
            if sira == 0:
                ilk_rows = rows          # geri düşüş için varsayılan sonucu sakla
            if not rows:
                continue
            hidx = _detect_header_idx_rows(rows)
            if _pdf_header_usable(rows[hidx]):
                secilen = rows
                break

    rows = secilen or ilk_rows
    if not rows and ocr_callback is not None:
        rows = ocr_callback(path)
    if not rows:
        raise ValueError("PDF içinde tablo bulunamadı.")
    # Tablo üstünde firma/başlık bloğu olabilir (ör. 'Cari Kodu :' satırı).
    # Excel yolundaki çok dilli başlık tespitini burada da uygula: gerçek
    # başlık satırını bul, öncesini at.
    hidx = _detect_header_idx_rows(rows)
    return rows[hidx], rows[hidx + 1:]


def _pdf_words_to_rows(page) -> list[list[object]]:
    words = page.extract_words(use_text_flow=False) or []
    if not words:
        return []

    lines: list[list[dict]] = []
    for w in sorted(words, key=lambda w: (round(w["top"] / 3), w["x0"])):
        key = round(w["top"] / 3)
        if lines and lines[-1] and round(lines[-1][0]["top"] / 3) == key:
            lines[-1].append(w)
        else:
            lines.append([w])
    if not lines:
        return []

    header = sorted(lines[0], key=lambda w: w["x0"])
    col_starts = _cluster_column_starts(header)
    if len(col_starts) < 2:
        return [[w["text"] for w in sorted(ln, key=lambda w: w["x0"])] for ln in lines]

    rows: list[list[object]] = []
    for ln in lines:
        cells = [""] * len(col_starts)
        for w in sorted(ln, key=lambda w: w["x0"]):
            ci = _which_column(w["x0"], col_starts)
            cells[ci] = (cells[ci] + " " + w["text"]).strip()
        rows.append(cells)
    return rows


def _cluster_column_starts(header_words: list[dict]) -> list[float]:
    starts: list[float] = []
    prev_end: Optional[float] = None
    for w in header_words:
        if prev_end is None or (w["x0"] - prev_end) > 18:
            starts.append(w["x0"])
        prev_end = w["x1"]
    return starts


def _which_column(x: float, col_starts: list[float]) -> int:
    ci = 0
    for i, cs in enumerate(col_starts):
        if x >= cs - 5:
            ci = i
        else:
            break
    return ci


def _is_blank(row: list[object]) -> bool:
    return row is None or all(c is None or str(c).strip() == "" for c in row)


def _cell(row: list[object], idx: Optional[int]) -> object:
    if idx is None or idx >= len(row):
        return None
    return row[idx]


# B/A (Borç/Alacak) göstergesi değerleri → işaret. Salt sözlük; AI yok.
_BA_CREDIT_TOKENS: frozenset[str] = frozenset({
    "a", "al", "alacak", "credit", "cr", "c", "haben", "h", "avere",
})
_BA_DEBIT_TOKENS: frozenset[str] = frozenset({
    "b", "bo", "borc", "borç", "debit", "dr", "d", "soll", "s", "dare",
})


def _apply_ba_sign(magnitude: Decimal, indicator: object) -> Decimal:
    """B/A göstergesine göre tutarın işaretini belirle.

    'A'/Alacak → negatif, 'B'/Borç → pozitif. Gösterge okunamıyorsa ham
    değeri (işaretiyle) olduğu gibi bırak. Büyüklük her zaman korunur.
    """
    text = clean_string(indicator)
    if text is None:
        return magnitude
    key = text.strip().lower()
    key = key.translate(str.maketrans("çı", "ci")).replace(" ", "")
    mag = magnitude.copy_abs()
    if key in _BA_CREDIT_TOKENS:
        return -mag
    if key in _BA_DEBIT_TOKENS:
        return mag
    return magnitude


# Açıklama/metin içine gömülü sipariş/belge no çıkarımı (madde 7, EK aday).
# Yerli ekstrede "SİPARİŞ NO:4500435648" gibi 10 haneli 45xx sipariş numarası
# açıklama hücresinde geçebilir. Bunlar EN DÜŞÜK öncelikli referans adayıdır;
# mevcut fatura/belge no önceliğini BOZMAZ (loader'da sona eklenir).
# Salt regex; AI yok.
_COMMENT_ORDER_RE = re.compile(r"\b(45\d{8})\b")


def _extract_comment_refs(comment: object) -> list[str]:
    """Açıklama metninden 10 haneli 45xx sipariş no'larını EK referans adayı
    olarak çıkar (normalize edilmiş). Bulunmazsa boş liste."""
    text = clean_string(comment)
    if text is None:
        return []
    out: list[str] = []
    for m in _COMMENT_ORDER_RE.findall(text):
        norm = normalize_reference(m)
        if norm and norm not in out:
            out.append(norm)
    return out


class TofasLoader:
    def __init__(self, account_prefixes: Optional[tuple[str, ...]] = ("320", "323"),
                 ocr_callback: Optional[Callable] = None) -> None:
        self.account_prefixes = account_prefixes
        self._ocr_callback = ocr_callback
        # Açılış/devir satırlarının işaretli toplamı (kalem eşleştirmesine
        # girmez; yalnızca toplam bakiye kontrolü için son yüklemede saklanır).
        self.opening_balance: Decimal = Decimal("0")
        self.prefix_filter_active = False
        self.off_prefix_referenced_rows = 0

    def load(self, path: str | Path) -> tuple[list[TofasRecord], Optional[Decimal]]:
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Dosya bulunamadı: {path}")
        try:
            validate_input_file(path)
        except UnsafeInputError as exc:
            raise DataValidationError(str(exc)) from exc

        if path.suffix.lower() == ".pdf":
            headers, rows = _read_pdf(path, self._ocr_callback)
            method = _EXTRACTION_PDF
        else:
            headers, rows = _read_any(path)
            method = _EXTRACTION_TABULAR

        # TOFAŞ yuvasına da uygulamanın KENDİ sonuç kitabı konabilir
        # (dosyalar aynı klasörde, benzer adla durur). Sessizce okunmaz.
        if looks_like_result_workbook(headers):
            raise DataValidationError(
                "Seçilen dosya bir TOFAŞ EKSTRESİ değil, bu uygulamanın "
                "ürettiği MUTABAKAT SONUCU dosyasıdır "
                f"({path.name}).\n\n"
                "Lütfen SAP'ten aldığınız ekstreyi seçin. Sonuç dosyaları "
                "genellikle '_mutabakat.xlsx' ile biter."
            )

        mapping, ref_indexes = map_tofas_columns(headers)
        # Dosyanın SAP imzası (ters yuva tespiti için; bkz. sap_header_score).
        self.sap_header_score = sap_header_score(headers)

        # SAP FBL şablonu birebir çözülemezse (ör. LOGO/Mikro tarzı bir "bizim
        # taraf" ekstresi: ANA DÖVİZ BORÇ / ORJİNAL DÖVİZ TUTAR / SERİ / SIRA /
        # BELGE NO), firma tarafıyla AYNI zengin/token-tabanlı tanıyıcıya düş.
        # Böylece TOFAŞ yuvasına SAP dışı bir format da konsa okunabilir.
        gen_ref_idxs: list[int] = []
        gen_amount_idx = gen_debit_idx = gen_credit_idx = None
        gen_balance_idx = gen_cur_idx = gen_date_idx = None
        if "amount" not in mapping or not ref_indexes:
            roles = map_firma_columns(headers)
            gen_ref_idxs = roles.get("reference", [])
            gen_amount_idx = roles["amount"][0] if roles.get("amount") else None
            gen_debit_idx = roles["debit"][0] if roles.get("debit") else None
            gen_credit_idx = roles["credit"][0] if roles.get("credit") else None
            gen_balance_idx = roles["balance"][0] if roles.get("balance") else None
            gen_cur_idx = roles["currency"][0] if roles.get("currency") else None
            gen_date_idx = roles["inv_date"][0] if roles.get("inv_date") else None

        # Etkin kolonlar: SAP birebir eşleşme önce; yoksa genel tanıyıcı.
        eff_ref_indexes = ref_indexes if ref_indexes else gen_ref_idxs
        sap_amount_idx = mapping.get("amount")
        # Yürüyen bakiye (running balance) tutar kaynağı SAYILMAZ. Kümülatif
        # bakiye satırın işlem tutarı DEĞİLDİR; onu tutar diye kullanmak her
        # satıra o ana kadarki toplamı yazar ve mutabakatı baştan sona yanlış
        # çalıştırır. Tek kaynak bakiyeyse aşağıda AÇIK hata verilir.
        has_amount_source = (
            sap_amount_idx is not None
            or gen_amount_idx is not None
            or gen_debit_idx is not None
            or gen_credit_idx is not None
        )

        # Sessiz başarısızlık yerine açık hata: hâlâ gerekli kolonlar yoksa
        # kullanıcıya NE bulunamadığını söyle (silent mapping failure = tehlike).
        missing: list[str] = []
        if not has_amount_source:
            if gen_balance_idx is not None:
                # Kullanıcı "kolon var ama tanınmadı" sanmasın: bulunan
                # kolonun NEDEN kullanılamadığı söylenir.
                missing.append(
                    "Tutar (veya Borç/Alacak) — dosyada yalnızca yürüyen "
                    "bakiye kolonu var; kümülatif bakiye satır tutarı olarak "
                    "KULLANILAMAZ")
            else:
                missing.append("Tutar (veya Borç/Alacak)")
        if not eff_ref_indexes:
            missing.append("Referans / Belge no")
        if missing:
            raise MappingError(
                "TOFAŞ ekstresi okunamadı: gerekli kolonlar bulunamadı.",
                file=str(path),
                found_columns=[str(h) for h in headers],
                missing=missing,
            )

        def tofas_row_amount(row: list[object], row_index: int) -> Decimal:
            """Öncelik: SAP tutar → genel tutar → (Borç-Alacak).

            Yürüyen bakiye BİLEREK dışarıda bırakılmıştır (bkz. yukarıdaki
            has_amount_source notu).
            """
            if sap_amount_idx is not None:
                return _strict_amount(
                    _cell(row, sap_amount_idx), path=path, row_index=row_index,
                    column_name=headers[sap_amount_idx])
            if gen_amount_idx is not None:
                val = _strict_amount(
                    _cell(row, gen_amount_idx), path=path, row_index=row_index,
                    column_name=headers[gen_amount_idx])
                if val != Decimal("0") or (gen_debit_idx is None and gen_credit_idx is None):
                    return val
            if gen_debit_idx is not None or gen_credit_idx is not None:
                borc = (_strict_amount(
                    _cell(row, gen_debit_idx), path=path, row_index=row_index,
                    column_name=headers[gen_debit_idx])
                    if gen_debit_idx is not None else Decimal("0"))
                alacak = (_strict_amount(
                    _cell(row, gen_credit_idx), path=path, row_index=row_index,
                    column_name=headers[gen_credit_idx])
                    if gen_credit_idx is not None else Decimal("0"))
                return borc.copy_abs() - alacak.copy_abs()
            # Bakiye kolonuna DÜŞÜLMEZ: tek kaynak bakiyeyse yükleme
            # yukarıda MappingError ile durdurulmuştur.
            return Decimal("0")

        records: list[TofasRecord] = []
        sap_total: Optional[Decimal] = None
        self.opening_balance = Decimal("0")
        self.off_prefix_referenced_rows = 0

        main_idx = mapping.get("main_account")
        apply_prefix_filter = prefix_filter_applies(
            rows, main_idx, self.account_prefixes)
        self.prefix_filter_active = apply_prefix_filter

        for i, row in enumerate(rows):
            if _is_blank(row):
                continue

            # Açılış/devir satırı: kalem eşleştirmesine ALINMAZ; işaretli tutarı
            # toplam bakiye kontrolü için ayrı toplanır (kullanıcı kararı).
            if is_opening_row(row):
                self.opening_balance += tofas_row_amount(row, i)
                continue

            # Fatura olmayan referans (Denkleştirme/Ödeme placeholder): referans
            # hücresi gerçek belge no yerine bir anahtar kelimeyse (ör.
            # "DENKLEŞTİRME"), satır karşılaştırmaya alınmaz (kullanıcı kararı).
            raw_refs = [clean_string(_cell(row, idx)) for idx in eff_ref_indexes]
            raw_refs = [r for r in raw_refs if r]
            if raw_refs and all(is_noninvoice_ref(r) for r in raw_refs):
                continue

            refs = [
                normalize_reference(_cell(row, idx))
                for idx in eff_ref_indexes
            ] if eff_ref_indexes else []
            refs = [r for r in refs if r]

            # KOD ALANLARINDA FLOAT ARTIĞI TEMİZLENİR.
            #     Excel sayısal hücreleri pandas üzerinden "2000405.0" gibi
            #     gelir. clean_string bu eki atmadığı için firma kodu
            #     "2000405.0" olarak taşınıyor; sonuç Excel'ine, arayüz
            #     tablosuna ve gönderim snapshot'ına böyle yazılıyordu.
            #     Kod alanları kanonik olmalı ki kod bazlı eşleşmeler ve
            #     denetim kaydı tutarlı kalsın.
            firma_kodu = normalize_account(_cell(row, mapping.get("firma_kodu")))
            amount = tofas_row_amount(row, i)
            main_account = normalize_account(_cell(row, mapping.get("main_account")))

            # Dip toplam (SAP sarı satır) tespiti — explicit + yapısal.
            # Explicit: hücrede "TOPLAM/TOTAL/..." geçiyorsa; yapısal: referansı
            # ve hesabı olmayan ama tutarı olan bir satır (SAP genel toplamı).
            # main_account varsa (ör. "Kur Farkı" gerçek muhasebe satırı) toplam
            # sanma.
            if amount != Decimal("0") and (
                is_total_row(row)
                or (not refs and firma_kodu is None and main_account is None)
            ):
                sap_total = amount
                continue

            # Ana-hesap prefiks filtresi (mod-bazlı). Kullanıcı kararı (madde 6):
            # eşleştirme hesap türüne DEĞİL, fatura/belge no'ya dayanır. Bu yüzden
            # prefikse uymayan bir satır bile GERÇEK bir referans taşıyorsa
            # (2590/1980/2260 gibi yan hesaplarda görülen fatura no'lu satırlar)
            # ELENMEZ; yalnızca referanssız + prefiks-dışı satırlar elenir
            # (referanssızsa zaten eşleşemez). Kod içi varsayılan davranış
            # değişmez; sadece referanslı satırlara muafiyet eklenir.
            if apply_prefix_filter and main_account is not None:
                is_allowed_prefix = any(
                    main_account.startswith(p) for p in self.account_prefixes)
                if refs and not is_allowed_prefix:
                    self.off_prefix_referenced_rows += 1
                if not refs and not is_allowed_prefix:
                    continue

            primary_ref = refs[0] if refs else None
            
            if primary_ref is None and amount == Decimal("0"):
                continue
                
            records.append(TofasRecord(
                row_index=i,
                fiscal_year=clean_string(_cell(row, mapping.get("fiscal_year"))),
                main_account=main_account,
                firma_kodu=firma_kodu,
                satici_ad=clean_string(_cell(row, mapping.get("satici_ad"))),
                reference=primary_ref,
                reference_raw=clean_string(_cell(row, eff_ref_indexes[0])) if eff_ref_indexes else None,
                all_references=refs,
                belge_turu=clean_string(_cell(row, mapping.get("belge_turu"))),
                belge_tarihi=normalize_date(_cell(row, mapping.get("belge_tarihi")))
                    if mapping.get("belge_tarihi") is not None
                    else normalize_date(_cell(row, gen_date_idx)),
                kayit_tarihi=normalize_date(_cell(row, mapping.get("kayit_tarihi"))),
                giris_tarihi=normalize_date(_cell(row, mapping.get("giris_tarihi"))),
                net_vade=normalize_date(_cell(row, mapping.get("net_vade"))),
                amount=amount,
                currency=clean_currency(_cell(row, mapping.get("currency")))
                    if mapping.get("currency") is not None
                    else clean_currency(_cell(row, gen_cur_idx)),
                metin=clean_string(_cell(row, mapping.get("metin"))),
                source_file=str(path),
                source_row=i,
                extraction_method=method,
            ))
        return records, sap_total


# --- Paralel para birimi sütunları -----------------------------------------
#
# SORUN (gerçek veriden)
#     Bazı ekstreler tutarı İKİ KEZ verir: bir kez yerel para biriminde
#     (Borç(TL) / Alacak(TL)), bir kez işlem/belge para biriminde
#     (Borç(İşlem Dövizi) / Alacak(İşlem Dövizi)) — yanında da bir
#     "İşlem Dövizi" kolonu (USD/EUR).
#
#     Motor tutarı İLK adaydan (TL) alıyor, para birimini ise döviz
#     kolonundan (USD) okuyordu. Sonuç: 35.446,86 TL'lik satır "35.446,86
#     USD" diye kaydediliyordu. Gerçek değer 742,80 USD. TOFAŞ tarafı
#     belge para biriminde tutulduğu için her satır "tutar farklı"
#     görünüyordu — tek bir dosyada 26 SAHTE fark.
#
# KURAL
#     Tutar ile para birimi ETİKETİ aynı kaynaktan gelmelidir. Yerel ve
#     belge-döviz sütunları birlikte varsa BELGE DÖVİZİ sütunu seçilir;
#     böylece etiket ile değer tutarlı olur. Bu, mevcut
#     ``_REPORTING_MARKERS`` ilkesinin (raporlama tutarı gerçek işlem
#     tutarı değildir) aynısıdır.
#
#     Dosya tamamen TL ise iki sütun aynı değeri taşır; seçim zararsızdır.

#: Yerel/raporlama para birimi sütunu işaretleri (normalize edilmiş).
_YEREL_PB_ISARET = ("anadoviz", "ulusalpara", "yerelpara", "localcurrency",
                    "raporpara", "raporlamapara")

#: Belge/işlem para birimi sütunu işaretleri.
_BELGE_PB_ISARET = ("islemdoviz", "belgedoviz", "belgeparabirimi",
                    "orjinaldoviz", "orijinaldoviz", "documentcurrency",
                    "transactioncurrency", "doccurrency", "islempara")


def _pb_sinifi(header: object) -> str:
    """Başlık hangi para birimi ailesine ait? 'yerel' | 'belge' | ''."""
    n = re.sub(r"[^a-z0-9]", "",
               str(header).strip().lower().translate(_HDR_TRANS))
    if not n:
        return ""
    if any(m in n for m in _BELGE_PB_ISARET):
        return "belge"
    if any(m in n for m in _YEREL_PB_ISARET):
        return "yerel"
    # "Borç(TL)" / "Alacak(TRY)" gibi ek olarak yazılmış yerel para birimi.
    if n.endswith("tl") or n.endswith("try") or n.endswith("tlmiktar"):
        return "yerel"
    return ""


def _kolon_dolu(rows: list[list[object]], idx: Optional[int],
                ornek: int = 60) -> bool:
    """Sütunda gerçekten değer var mı? (sıfırdan farklı en az bir satır)

    Belge-döviz sütunu boş bırakılmış bir dosyada ona geçmek TÜM tutarları
    sıfırlardı; bu yüzden geçiş yalnızca sütun DOLUYSA yapılır.
    """
    if idx is None:
        return False
    for row in rows[:ornek]:
        if normalize_amount(_cell(row, idx)) != Decimal("0"):
            return True
    return False


def _belge_dovizi_tercih_et(headers: list[object], rows: list[list[object]],
                            adaylar: list[int],
                            secili: Optional[int]) -> Optional[int]:
    """Seçili sütun YEREL para birimindeyse, dolu bir BELGE dövizi sütununa geç."""
    if secili is None or len(adaylar) < 2:
        return secili
    if _pb_sinifi(headers[secili] if secili < len(headers) else "") != "yerel":
        return secili
    for aday in adaylar:
        if aday == secili:
            continue
        if aday >= len(headers):
            continue
        if _pb_sinifi(headers[aday]) == "belge" and _kolon_dolu(rows, aday):
            return aday
    return secili


class FirmaLoader:
    def __init__(self, ocr_callback: Optional[Callable] = None,
                 balance_delta: bool = False) -> None:
        self._ocr_callback = ocr_callback
        # Bakiye-delta OPT-IN: yalnızca yürüyen bakiye kolonu olan ekstrelerde,
        # işlem tutarını ardışık bakiye farkından türet. Varsayılan KAPALI —
        # "Bakiye" kolonu her ekstrede yürüyen bakiye olmayabilir (bazı sistemde
        # satır-bazlı açık tutar); gerçek veriyle doğrulanana kadar güvenli
        # varsayılan, bakiyeyi son-çare ham tutar olarak bırakmaktır.
        self._balance_delta = bool(balance_delta)
        # Açılış/devir satırlarının işaretli toplamı (kalem eşleştirmesine
        # girmez; toplam bakiye kontrolü için son yüklemede saklanır).
        self.opening_balance: Decimal = Decimal("0")

    def load(self, path: str | Path) -> tuple[list[FirmaRecord], Optional[Decimal]]:
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Dosya bulunamadı: {path}")
        try:
            validate_input_file(path)
        except UnsafeInputError as exc:
            raise DataValidationError(str(exc)) from exc

        if path.suffix.lower() == ".pdf":
            headers, rows = _read_pdf(path, self._ocr_callback)
            method = _EXTRACTION_PDF
        else:
            headers, rows = _read_any(path)
            method = _EXTRACTION_TABULAR

        # Firma yuvasına UYGULAMANIN KENDİ SONUÇ KİTABI konmuş olabilir.
        # Bu sessizce okunursa mutabakat çöp veri üzerinde çalışır; o yüzden
        # tahmin yürütülmez, net bir hata verilir.
        if looks_like_result_workbook(headers):
            raise DataValidationError(
                "Seçilen dosya bir FİRMA EKSTRESİ değil, bu uygulamanın "
                "ürettiği MUTABAKAT SONUCU dosyasıdır "
                f"({path.name}).\n\n"
                "Lütfen firmanın gönderdiği ekstreyi seçin. Sonuç dosyaları "
                "genellikle '_mutabakat.xlsx' ile biter."
            )

        roles = map_firma_columns(headers)
        # Firma yuvasına SAP dosyası konmuş olabilir; imzayı ölç
        # (bkz. sap_header_score). Ek dosya okuması yapmaz.
        self.sap_header_score = sap_header_score(headers)
        ref_idxs = roles.get("reference", [])
        amt_idxs = roles.get("amount", [])
        debit_idxs = roles.get("debit", [])
        credit_idxs = roles.get("credit", [])
        balance_idxs = roles.get("balance", [])
        ba_idxs = roles.get("ba_indicator", [])

        inv_date_idx = roles["inv_date"][0] if roles.get("inv_date") else None
        due_date_idx = roles["due_date"][0] if roles.get("due_date") else None
        account_idx = roles["account"][0] if roles.get("account") else None
        name_idx = roles["name"][0] if roles.get("name") else None
        comment_idx = roles["comment"][0] if roles.get("comment") else None
        currency_idx = roles["currency"][0] if roles.get("currency") else None
        amount_idx = amt_idxs[0] if amt_idxs else None
        debit_idx = debit_idxs[0] if debit_idxs else None
        credit_idx = credit_idxs[0] if credit_idxs else None
        balance_idx = balance_idxs[0] if balance_idxs else None

        # Tutar ile para birimi ETİKETİ aynı kaynaktan gelmeli
        # (bkz. _belge_dovizi_tercih_et). Yalnızca para birimi kolonu
        # VARKEN devreye girer: tek para birimli ekstrede seçimi
        # değiştirmenin bir anlamı yoktur.
        if currency_idx is not None:
            yeni_debit = _belge_dovizi_tercih_et(headers, rows, debit_idxs,
                                                 debit_idx)
            yeni_credit = _belge_dovizi_tercih_et(headers, rows, credit_idxs,
                                                  credit_idx)
            # Borç ve Alacak BİRLİKTE değişir. Yalnızca birini çevirmek
            # iki farklı para biriminden borç/alacak toplamak demektir.
            if debit_idx is not None and credit_idx is not None:
                if yeni_debit != debit_idx and yeni_credit != credit_idx:
                    debit_idx, credit_idx = yeni_debit, yeni_credit
            else:
                debit_idx, credit_idx = yeni_debit, yeni_credit
            amount_idx = _belge_dovizi_tercih_et(headers, rows, amt_idxs,
                                                 amount_idx)
        # B/A göstergesi YALNIZCA ayrı Borç/Alacak kolonu YOKKEN devreye girer.
        # Ayrı Borç/Alacak varsa mevcut debit-credit işaret mantığı önceliklidir
        # (kullanıcı kararı); B/A kolonu bu durumda salt teyit amaçlıdır.
        ba_idx = (
            ba_idxs[0]
            if (ba_idxs and debit_idx is None and credit_idx is None)
            else None
        )

        # Sessiz başarısızlık yerine açık hata. Referans kolonu ya da HERHANGİ bir
        # tutar kaynağı (tutar / borç / alacak / bakiye) yoksa, dosyayı okuyamadık.
        missing: list[str] = []
        if not ref_idxs:
            missing.append("Referans / Fatura no")
        has_amount_source = (
            amount_idx is not None
            or debit_idx is not None
            or credit_idx is not None
            or balance_idx is not None
        )
        if not has_amount_source:
            missing.append("Tutar (veya Borç/Alacak)")
        if missing:
            ipucu = _belge_turu_ipucu(headers, rows, path)
            mesaj = "Firma ekstresi okunamadı: gerekli kolonlar bulunamadı."
            if ipucu:
                mesaj = ipucu + "\n\n" + mesaj
            raise MappingError(
                mesaj,
                file=str(path),
                found_columns=[str(h) for h in headers],
                missing=missing,
            )

        def row_amount(row: list[object], row_index: int) -> tuple[Decimal, str]:
            """Satırın işlem tutarını ve KAYNAĞINI döndür.

            Öncelik: (1) gerçek tutar kolonu, (2) Borç-Alacak (çift kolon
            muhasebe), (3) son çare olarak yürüyen bakiye. amount ile
            debit/credit KESİNLİKLE ayrıdır; bir Borç/Bakiye kolonu asla sessizce
            "tutar" sanılmaz.
            """
            if amount_idx is not None:
                val = _strict_amount(
                    _cell(row, amount_idx), path=path, row_index=row_index,
                    column_name=headers[amount_idx])
                if val != Decimal("0") or (debit_idx is None and credit_idx is None):
                    # B/A göstergesi aktifse tutarın işaretini ondan türet:
                    # 'A'/Alacak → negatif, 'B'/Borç → pozitif. Değer büyüklüğü
                    # korunur; gösterge okunamazsa ham işaret bırakılır.
                    if ba_idx is not None:
                        return _apply_ba_sign(val, _cell(row, ba_idx)), "amount+ba"
                    return val, "amount"
            if debit_idx is not None or credit_idx is not None:
                borc = (_strict_amount(
                    _cell(row, debit_idx), path=path, row_index=row_index,
                    column_name=headers[debit_idx])
                    if debit_idx is not None else Decimal("0"))
                alacak = (_strict_amount(
                    _cell(row, credit_idx), path=path, row_index=row_index,
                    column_name=headers[credit_idx])
                    if credit_idx is not None else Decimal("0"))
                return borc.copy_abs() - alacak.copy_abs(), "debit-credit"
            if balance_idx is not None:
                return (_strict_amount(
                    _cell(row, balance_idx), path=path, row_index=row_index,
                    column_name=headers[balance_idx]), "balance")
            return Decimal("0"), "amount"

        # Bakiye-delta modu: tek tutar kaynağı YÜRÜYEN BAKİYE ise (gerçek işlem
        # tutarı ya da borç/alacak kolonu yok), her satırın işlem tutarını ardışık
        # bakiye farkından türet. amount / borç / alacak varsa bu mod KAPALI kalır.
        balance_only = (
            self._balance_delta
            and amount_idx is None and debit_idx is None
            and credit_idx is None and balance_idx is not None
        )
        prev_balance: Optional[Decimal] = None

        records: list[FirmaRecord] = []
        declared_total: Optional[Decimal] = None
        self.opening_balance = Decimal("0")

        for i, row in enumerate(rows):
            if _is_blank(row):
                continue

            # Açılış/devir satırı: kalem eşleştirmesine ALINMAZ; toplam bakiye
            # kontrolü için işaretli tutarı ayrı toplanır (kullanıcı kararı).
            # 'Hesaplar arası virman' gerçek işlem sayılır, burada yakalanmaz.
            if is_opening_row(row):
                opening_amt, _ = row_amount(row, i)
                self.opening_balance += opening_amt
                # Açılış/devir bakiyesi: delta modunda başlangıç noktası olur.
                if balance_only:
                    prev_balance = _strict_amount(
                        _cell(row, balance_idx), path=path, row_index=i,
                        column_name=headers[balance_idx])
                continue

            # Fatura olmayan referans (Denkleştirme/Ödeme placeholder): satır
            # karşılaştırmaya alınmaz (kullanıcı kararı).
            raw_refs = [clean_string(_cell(row, idx)) for idx in ref_idxs]
            raw_refs = [r for r in raw_refs if r]
            if raw_refs and all(is_noninvoice_ref(r) for r in raw_refs):
                continue

            all_refs = [normalize_reference(_cell(row, idx)) for idx in ref_idxs]
            all_refs = [r for r in all_refs if r]
            amount, amount_source = row_amount(row, i)

            # Madde 7: Açıklama içine gömülü sipariş no (45xxxxxxxx) EK referans
            # adayı olarak SONA eklenir — mevcut fatura/belge no önceliğini
            # bozmadan (en düşük öncelik). Kolon-bazlı referans varsa birincil
            # o kalır; yoksa sipariş no birincil aday olur.
            comment_refs = _extract_comment_refs(_cell(row, comment_idx))
            for cr in comment_refs:
                if cr not in all_refs:
                    all_refs.append(cr)

            # Dip toplam satırını AÇIKÇA tanı (referans yokluğu tek başına yeterli
            # değil; "Kur Farkı" gibi gerçek satırlar da referanssız olabilir).
            if amount != Decimal("0") and is_total_row(row):
                declared_total = amount
                continue
            if not all_refs:
                continue

            # Bakiye-delta: işlem tutarı = bu satırın bakiyesi − önceki bakiye.
            if balance_only:
                cur_balance = amount  # row_amount balance kolonunu döndürmüştü
                base = prev_balance if prev_balance is not None else Decimal("0")
                amount = cur_balance - base
                prev_balance = cur_balance
                amount_source = "balance-delta"

            records.append(FirmaRecord(
                row_index=i,
                account=clean_string(_cell(row, account_idx)),
                name=clean_string(_cell(row, name_idx)),
                reference=all_refs[0],
                reference_raw=clean_string(_cell(row, ref_idxs[0])),
                all_references=all_refs,
                inv_date=normalize_date(_cell(row, inv_date_idx)),
                due_date=normalize_date(_cell(row, due_date_idx)),
                amount=amount,
                currency=clean_currency(_cell(row, currency_idx)),
                comment=clean_string(_cell(row, comment_idx)),
                source_file=str(path),
                source_row=i,
                amount_source=amount_source,
                extraction_method=method,
            ))
        return records, declared_total
