"""Ekstre satırının İŞLEM TÜRÜNÜ sınıflandır (deterministik, salt sözlük).

NEDEN GEREKLİ
    Gerçek bir FBL1H çıktısında (15.601 satır) ölçüldü:

        kur farkı : 220 satır
        iade      : 208 satır
        virman    : 233 satır
        mahsup    :  24 satır

    Bunlar sıradan fatura değildir. Karşı tarafın ekstresinde çoğu zaman
    bulunmazlar ya da farklı işaretle bulunurlar; kullanıcı "bu 220 satır
    neden fark olarak çıktı?" sorusunun cevabını göremiyordu.

TASARIM İLKESİ — SINIFLANDIRIR, DIŞLAMAZ
    Bu modül hiçbir satırı eşleştirmeden ÇIKARMAZ ve hiçbir tutarı
    değiştirmez. Yalnızca satırı etiketler.

    Kur farkı satırlarını "karşı tarafta yok, boşuna fark üretiyor" diye
    dışlamak CAZİPTİR ama YANLIŞTIR: karşı tarafta olmayan satır tam da
    farkın kendisidir. Dışlamak farkı yok etmez, yalnızca GİZLER — ve
    rapor "mutabık" görünürken gerçek tutarsız kalır. Doğru davranış,
    farkı görünür kılıp nedenini söylemektir.

    Aynı gerekçe avans ve iade için de geçerlidir.
"""

from __future__ import annotations

from typing import Optional

#: Sınıf kodları
INVOICE = "INVOICE"              # sıradan fatura / mal-hizmet hareketi
CREDIT_NOTE = "CREDIT_NOTE"      # iade faturası / credit note
FX_DIFFERENCE = "FX_DIFFERENCE"  # kur farkı
ADVANCE = "ADVANCE"              # avans
TRANSFER = "TRANSFER"            # virman / mahsup / denkleştirme
PAYMENT = "PAYMENT"              # tahsilat / ödeme / havale
UNKNOWN = ""

#: Anahtar kelimeler — normalize edilmiş (küçük harf, Türkçe harfler sade).
#: Sıra ÖNEMLİDİR: "kur farkı iadesi" gibi bileşik metinlerde daha ayırt
#: edici olan önce denenir.
_KURALLAR: tuple[tuple[str, tuple[str, ...]], ...] = (
    (FX_DIFFERENCE, ("kurfarki", "kurfark", "kurdegerleme", "exchangediff",
                     "exchangerate", "fxdiff", "kambiyo")),
    (ADVANCE, ("avans", "avansodeme", "sasavansi", "advance", "anzahlung",
               "acconto", "prepayment")),
    (TRANSFER, ("virman", "mahsup", "denklestirme", "denklesme", "aktarma",
                "transfer", "umbuchung", "clearing")),
    (CREDIT_NOTE, ("iade", "iadefaturasi", "satisiade", "toptansatisiade",
                   "creditnote", "gutschrift", "notadicredito", "abono",
                   "avoir", "returninvoice")),
    (PAYMENT, ("tahsilat", "odeme", "havale", "gelenhavale", "eft",
               "payment", "zahlung", "incasso", "cobro")),
)

_TRANS = str.maketrans("çğıöşüâî", "cgiosuai")


def _norm(value: object) -> str:
    if value is None:
        return ""
    text = str(value)
    for a, b in (("İ", "i"), ("I", "i"), ("Ş", "s"), ("Ç", "c"),
                 ("Ğ", "g"), ("Ö", "o"), ("Ü", "u")):
        text = text.replace(a, b)
    text = text.lower().translate(_TRANS)
    return "".join(ch for ch in text if ch.isalnum())


def classify_row(text: object = None, belge_turu: object = None,
                 reference: object = None) -> str:
    """Satırın işlem türü. Emin değilse ``INVOICE`` (varsayılan güvenli).

    ``text`` genelde SAP "Metin" ya da firma "Açıklama" alanıdır; asıl
    ayırt edici bilgi oradadır. ``belge_turu`` ve ``reference`` ek
    ipuçlarıdır.

    DİKKAT — bu fonksiyonun döndürdüğü ``INVOICE`` İKİ FARKLI anlama
    gelebilir: "gerçekten fatura" ya da "hiçbir anahtar kelime eşleşmedi,
    güvenli varsayılana düşüldü". Bu ayrımın önemli olduğu yerlerde (FAZ 4
    P0 güvenlik kapısı gibi) :func:`classify_row_with_confidence` kullanın.
    """
    return classify_row_with_confidence(text, belge_turu, reference)[0]


def classify_row_with_confidence(
    text: object = None, belge_turu: object = None, reference: object = None,
) -> tuple[str, bool]:
    """``classify_row`` ile AYNI etiket, AMA ayrıca bir GÜVEN bayrağı.

    Döner: ``(etiket, confirmed)``. ``confirmed=True`` yalnızca gerçek bir
    anahtar kelime eşleştiğinde; ``confirmed=False`` hem boş girdide hem de
    eşleşmeyen girdide (ikisi de ``INVOICE`` döner ama hiçbiri "bu satır
    gerçekten fatura" demez — yalnızca "bu konuda hiç kanıt yok" demektir).

    FAZ 4 (P0 güvenlik kapısı, docs/claude-audit/17 §1.3/§4): ekonomik olay
    çelişkisi tespiti SADECE ``confirmed=True`` olan sinyalleri "gerçek"
    sayar; aksi hâlde ``row_classifier``'ın her zaman var olan ``INVOICE``
    varsayılanı, rekabet eden her satırı yanlışlıkla "çelişkili" ilan ederdi.
    """
    birlesik = " ".join(_norm(v) for v in (text, reference, belge_turu) if v)
    if not birlesik:
        return INVOICE, False
    for sinif, anahtarlar in _KURALLAR:
        if any(a in birlesik for a in anahtarlar):
            return sinif, True
    return INVOICE, False


#: Kullanıcıya gösterilecek Türkçe adlar.
_ETIKET = {
    CREDIT_NOTE: "iade / credit note",
    FX_DIFFERENCE: "kur farkı",
    ADVANCE: "avans",
    TRANSFER: "virman / mahsup",
    PAYMENT: "tahsilat / ödeme",
}


def classify_records(records) -> dict[str, int]:
    """Kayıt listesini sınıflandır: sınıf -> adet (INVOICE hariç)."""
    sayim: dict[str, int] = {}
    for rec in records:
        sinif = classify_row(
            text=getattr(rec, "metin", None) or getattr(rec, "comment", None),
            belge_turu=getattr(rec, "belge_turu", None),
            reference=getattr(rec, "reference_raw", None),
        )
        if sinif and sinif != INVOICE:
            sayim[sinif] = sayim.get(sinif, 0) + 1
    return sayim


def describe_classes(sayim: dict[str, int]) -> Optional[str]:
    """Sayımı kullanıcıya gösterilecek tek satıra çevir; boşsa None.

    Amaç FARKI AÇIKLAMAK: "bu satırlar neden karşı tarafta yok?"
    sorusunun cevabı. Hiçbir satır dışlanmaz.
    """
    if not sayim:
        return None
    parcalar = [
        f"{adet} {_ETIKET.get(sinif, sinif)}"
        for sinif, adet in sorted(sayim.items(), key=lambda x: -x[1])
    ]
    return (
        "Fatura dışı hareketler: " + ", ".join(parcalar)
        + ". Bu satırlar eşleştirmeden ÇIKARILMAZ; karşı tarafın "
          "ekstresinde bulunmuyorlarsa farkın kaynağı olabilirler."
    )
