"""Aksiyon/hatırlatma gönderiminin GÜVENLİ yürütülmesi (§2).

KORUNAN ÜÇ KURAL
    1. ``Send()`` sonrası hata SEND_UNKNOWN'dır. Mail gitmiş OLABİLİR;
       FAILED sayılıp otomatik yeniden gönderilirse firma ikinci maili
       alır ve bu geri alınamaz.
    2. Çözülmemiş bir SEND_UNKNOWN varken AYNI vaka + AYNI aksiyon için
       yeni gönderim YAPILMAZ. Kullanıcıya Gönderilmiş Öğeler'i kontrol
       etmesi söylenir.
    3. Aynı iş İKİ KEZ çalışmaz: her deneme benzersiz ``attempt_id``
       taşır ve vaka bazlı kilit alınır (çift tıklama tek mail üretir).

Kimlikler her başarılı gönderimde vakaya yazılır ki bir sonraki mail
İLK mutabakat mailini değil EN SON gönderdiğimiz maili cevaplasın.
"""

from __future__ import annotations

import threading
import uuid
from dataclasses import dataclass
from typing import Any, Optional

from loguru import logger

from app.services.case_actions import (
    STATUS_DRAFTED,
    STATUS_SEND_UNKNOWN,
    STATUS_SENT,
    STATUS_WAITING,
    ActionItem,
    actions_of,
    upsert_action,
)
from app.services.reply_target import record_outbound, resolve_target

#: Vaka bazlı kilitler — çift tıklama/eşzamanlı gönderim koruması.
_LOCKS: dict[str, threading.Lock] = {}
_LOCKS_GUARD = threading.Lock()


def case_lock(case_id: str) -> threading.Lock:
    with _LOCKS_GUARD:
        kilit = _LOCKS.get(case_id)
        if kilit is None:
            kilit = threading.Lock()
            _LOCKS[case_id] = kilit
        return kilit


def new_attempt_id() -> str:
    return uuid.uuid4().hex[:16]


@dataclass
class SendGuard:
    """Gönderim yapılabilir mi? Yapılamazsa NEDEN?"""

    allowed: bool = True
    reason: str = ""


def check_can_send(case: Any, action_type: str) -> SendGuard:
    """Çözülmemiş SEND_UNKNOWN varsa aynı aksiyonu tekrar GÖNDERME."""
    bekleyen = str(getattr(case, "pending_unknown_action", "") or "")
    if bekleyen and bekleyen == action_type:
        zaman = str(getattr(case, "pending_unknown_at", "") or "")
        return SendGuard(False, (
            "Bu vaka için önceki gönderimin sonucu BELİRSİZ"
            + (f" ({zaman})" if zaman else "")
            + ". Mail gönderilmiş OLABİLİR; Gönderilmiş Öğeler kontrol "
              "edilmeli. Mükerrer mail riskine karşı yeni gönderim "
              "yapılmadı."))
    return SendGuard(True)


@dataclass
class MailContext:
    """Gönderilen mailin DENETİM için gereken bağlamı (§8).

    Mail GÖVDESİNİN TAMAMI audit kaydına YAZILMAZ: gövde finansal ve
    ticari bilgi taşır. Yalnızca kısa bir kesit ve içerik özeti (hash)
    saklanır; gerekirse eşleştirme bunlarla yapılır.
    """

    subject: str = ""
    body_hash: str = ""
    body_snippet: str = ""
    recipients: str = ""
    cc: str = ""
    attachment_count: int = 0
    attachment_hashes: list = None          # type: ignore[assignment]
    target_entry_id: str = ""
    target_message_id: str = ""

    def __post_init__(self) -> None:
        if self.attachment_hashes is None:
            self.attachment_hashes = []


def mail_context(subject: str = "", body: str = "", recipients: str = "",
                 cc: str = "", attachments: Optional[list] = None,
                 target_entry_id: str = "",
                 target_message_id: str = "") -> MailContext:
    """Gövdeyi ÖZETLEYEREK denetim bağlamı üret."""
    import hashlib

    govde = body or ""
    ekler = list(attachments or [])
    hashler = []
    for yol in ekler:
        try:
            with open(yol, "rb") as fh:
                hashler.append(hashlib.sha256(fh.read()).hexdigest()[:16])
        except OSError:
            hashler.append("")
    return MailContext(
        subject=subject,
        body_hash=hashlib.sha256(govde.encode("utf-8", "replace")).hexdigest()[:16],
        body_snippet=" ".join(govde.split())[:120],
        recipients=recipients, cc=cc,
        attachment_count=len(ekler), attachment_hashes=hashler,
        target_entry_id=target_entry_id, target_message_id=target_message_id,
    )


def verify_send_identity(result: Any, folder=None) -> bool:
    """Gönderilen tek mailin kimliklerini Gönderilmiş Öğeler'den yenile.

    Gönderim anında okunan ``entry_id`` TASLAĞA aittir ve öğe Gönderilmiş
    Öğeler'e taşınınca geçersizleşir; ``message_id`` ise çoğu zaman henüz
    doğmamıştır. Kimlikler doğrulanmazsa bir sonraki hatırlatma yanlış ya da
    eski bir zincire bağlanabilir.

    Döner: kimlik doğrulanabildiyse ``True``. Outlook yoksa / COM hata
    verirse sessizce ``False`` döner — gönderim ETKİLENMEZ.
    """
    if not (getattr(result, "sent", False) or getattr(result, "unknown", False)):
        return False
    try:
        from app.mailing.outlook_client import (
            identity_key,
            resolve_sent_identity,
        )

        kimlikler = resolve_sent_identity([result], folder)
        kimlik = kimlikler.get(identity_key(result))
    except Exception as exc:  # noqa: BLE001 - doğrulama maili bozmaz
        logger.debug(f"[gönderim] kimlik doğrulanamadı: {exc}")
        return False
    if kimlik is None:
        return False
    for alan in ("entry_id", "message_id", "conversation_id"):
        deger = getattr(kimlik, alan, "")
        if deger:
            try:
                setattr(result, alan, deger)
            except Exception:  # noqa: BLE001 - donmuş nesne olabilir
                return False
    return True


def apply_result(case: Any, action: ActionItem, result: Any,
                 action_type: str, context: Optional[MailContext] = None) -> str:
    """Gönderim sonucunu vakaya ve aksiyona işle. Dönen değer: durum.

    Geçmiş SİLİNMEZ; her sonuç timeline'a ve mail_events'e yazılır.
    """
    from app.services.incoming_cases import _now

    durum = str(getattr(result, "status", "") or "")
    zaman = _now()

    # KİMLİK ÖNCE DOĞRULANIR, SONRA ZİNCİRE YAZILIR: doğrulanmamış bir
    # EntryID zincire girerse sonraki hatırlatma onu hedefler.
    dogrulandi = False
    if durum in ("SENT", "SEND_UNKNOWN"):
        dogrulandi = verify_send_identity(result)

    if durum == "SENT":
        # ZİNCİRİN DEVAMI: yeni kimlikler kaydedilir.
        record_outbound(case, result, action_type, now=zaman)
        if str(getattr(case, "pending_unknown_action", "") or "") in (
                "", action_type):
            case.pending_unknown_action = ""
            case.pending_unknown_at = ""
        # BİR TALEBİN GÖNDERİLMESİ İŞİN BİTTİĞİ ANLAMINA GELMEZ:
        # firma cevaplayana kadar aksiyon AÇIK kalır.
        from app.services.case_actions import AWAITS_RESPONSE

        action.status = (STATUS_WAITING if action_type in AWAITS_RESPONSE
                         else STATUS_SENT)
        action.sent_at = zaman
        action.related_outbound_message_id = str(
            getattr(result, "message_id", "") or "")
        if action_type == "REMIND_FOR_REPLY":
            try:
                case.reminder_count = int(
                    getattr(case, "reminder_count", 0) or 0) + 1
            except (TypeError, ValueError):
                case.reminder_count = 1
            case.last_reminder_at = zaman
        # GERÇEK MAİL KONUSU kaydedilir. Eskiden buraya ``user_note``
        # yazılıyordu — o bir kullanıcı notudur, mailin konusu değil;
        # denetim kaydı yanlış bilgi taşıyordu.
        ctx = context or MailContext()
        actual_recipients = str(getattr(result, "recipients", "") or "")
        actual_cc = str(getattr(result, "cc", "") or "")
        case.add_mail_event(
            "OUT",
            mail_id=str(getattr(result, "message_id", "") or ""),
            subject=ctx.subject or str(getattr(case, "subject", "") or ""),
            sender=actual_recipients or ctx.recipients,
            occurred_at=zaman,
            snippet=ctx.body_snippet,
            attachment_count=ctx.attachment_count,
            attachment_hashes=list(ctx.attachment_hashes or []),
            reply_type=action_type)
        case.add_event(
            f"{action_type}_SENT", "Aksiyon maili gönderildi",
            detail=(f"attempt={action.attempt_id} "
                    f"hedef={ctx.target_entry_id or ctx.target_message_id or '-'} "
                    f"yeni={getattr(result, 'entry_id', '') or '-'} "
                    f"alıcı={actual_recipients or ctx.recipients or '-'} "
                    f"cc={actual_cc or ctx.cc or '-'} "
                    f"ek={ctx.attachment_count} govde_hash={ctx.body_hash} "
                    f"kimlik_dogrulandi={'evet' if dogrulandi else 'hayır'}"))

    elif durum == "SEND_UNKNOWN":
        # KİMLİKLER YİNE KAYDEDİLİR: mail gitmiş olabilir, elde ne varsa
        # saklanır ki Gönderilmiş Öğeler'den doğrulanabilsin.
        record_outbound(case, result, action_type, now=zaman)
        case.pending_unknown_action = action_type
        case.pending_unknown_at = zaman
        action.status = STATUS_SEND_UNKNOWN
        case.add_event(f"{action_type}_SEND_UNKNOWN",
                       "Gönderim sonucu BELİRSİZ — mail gitmiş olabilir",
                       detail=str(getattr(result, "reason", ""))[:300])

    elif durum == "DRAFTED":
        # TASLAK GÖNDERİLMİŞ MAİL DEĞİLDİR.
        #
        # Eskiden burada record_outbound çağrılıyordu: hiç gönderilmemiş
        # bir Outlook taslağı last_outbound_* alanlarına yazılıyordu.
        # Kullanıcı taslağı kapatır ya da silerse bir sonraki hatırlatma
        # GÖNDERİLMEMİŞ bir mailin üzerinden ilerliyordu.
        #
        # Taslağın kimliği AYRI alanlarda saklanır; zincir ancak taslak
        # Gönderilmiş Öğeler'de doğrulandığında ilerler
        # (bkz. confirm_draft_sent).
        entry = str(getattr(result, "entry_id", "") or "")
        if entry:
            case.last_draft_entry_id = entry
        conv = str(getattr(result, "conversation_id", "") or "")
        if conv:
            case.last_draft_conversation_id = conv
        case.last_draft_at = zaman
        case.last_draft_action = action_type
        # Aksiyon AÇIK kalır: kullanıcı taslağı silerse iş bitmiş sayılmaz.
        action.status = STATUS_DRAFTED
        case.add_event(f"{action_type}_DRAFTED",
                       "Taslak açıldı; GÖNDERİLMEDİ, zincir ilerlemedi")

    else:
        # Send() ÖNCESİ kesin hata: ortada gönderilmiş mail YOKTUR,
        # tekrar denemek güvenlidir.
        from app.services.case_actions import STATUS_FAILED_PRE_SEND

        action.status = STATUS_FAILED_PRE_SEND
        case.add_event(f"{action_type}_FAILED", "Aksiyon maili gönderilemedi",
                       detail=str(getattr(result, "reason", ""))[:300])

    upsert_action(case, action)
    # DENETİM: her gönderim (ve gönderim denemesi) kullanıcı adıyla kalıcı
    # günlüğe yazılır. Vakanın kendi timeline'ı silinmez ama vakaya bağlıdır;
    # denetim günlüğü VAKADAN BAĞIMSIZ ve salt eklenirdir.
    _audit_send(case, action_type, durum, result, context)
    return durum


def _audit_send(case: Any, action_type: str, durum: str, result: Any,
                context: Optional[MailContext]) -> None:
    """Gönderim sonucunu kurumsal denetim günlüğüne yaz (best-effort)."""
    try:
        from app.services.action_audit import ACTION_MAIL_SENT, ActionAuditLog
        from app.services.authz import current_user

        ctx = context or MailContext()
        ActionAuditLog().record(
            ACTION_MAIL_SENT,
            user=current_user(),
            target=str(getattr(case, "case_id", "") or ""),
            company_code=str(getattr(case, "company_code", "") or ""),
            period=str(getattr(case, "period", "") or ""),
            new_value=f"{action_type}:{durum}",
            detail=(f"alıcı={getattr(result, 'recipients', '') or ctx.recipients} "
                    f"konu={ctx.subject} "
                    f"entry={getattr(result, 'entry_id', '') or '-'}"),
        )
    except Exception:  # noqa: BLE001 - denetim gönderimi etkilemez
        pass


def build_request(case: Any, mail: Any, action_type: str):
    """Vakanın SON giden mailini hedefleyen ReplyRequest üret.

    Hedef bulunamazsa ``None`` döner ve ÇAĞIRAN YENİ MAİL AÇMAZ.
    """
    from app.mailing.outlook_client import ReplyRequest

    hedef = resolve_target(case)
    if not hedef.ready:
        return None, hedef

    return ReplyRequest(
        body=str(getattr(mail, "body", "") or ""),
        # ENTRY_ID ARTIK GERÇEKTEN AKTARILIYOR: en güçlü hedefleyici
        # arayüzden hiç geçirilmiyordu (bkz. §1).
        entry_id=hedef.entry_id,
        message_id=hedef.message_id,
        conversation_id=hedef.conversation_id,
        attachments=list(getattr(mail, "attachments", None) or []),
        code=str(getattr(case, "company_code", "") or ""),
        # §3 — zincirden bulunan öğe GERÇEK OUTLOOK VERİSİYLE doğrulanır.
        expected_recipients=[
            a.strip() for a in
            str(getattr(case, "recipients", "") or "").replace(",", ";").split(";")
            if a.strip()],
        period=str(getattr(case, "period", "") or ""),
        expected_subject=str(getattr(case, "subject", "") or ""),
    ), hedef


# ---------------------------------------------------------------------------
# Taslak doğrulama (§2)
# ---------------------------------------------------------------------------

def confirm_draft_sent(case: Any, *, entry_id: str = "",
                       sent_entry_id: str = "",
                       message_id: str = "",
                       conversation_id: str = "") -> bool:
    """Açılan taslak GERÇEKTEN gönderilmiş mi? Doğrulandıysa zinciri ilerlet.

    Kullanıcı taslağı Outlook'tan gönderdiğinde öğe Gönderilmiş Öğeler'e
    taşınır. Bu doğrulandığında — ve YALNIZCA o zaman — taslak kimlikleri
    ``last_outbound_*`` alanlarına yükseltilir; aksi hâlde bir sonraki
    hatırlatma gönderilmemiş bir taslağı hedeflerdi.

    Taslak silinmişse hiçbir şey değişmez: aksiyon AÇIK kalır.
    """
    from app.services.incoming_cases import _now

    taslak = str(getattr(case, "last_draft_entry_id", "") or "")
    if not taslak:
        return False
    # ``entry_id`` doğrulanan KAYNAK taslağın kimliğidir. Outlook taslağı
    # Gönderilmiş Öğeler'e taşırken EntryID'yi değiştirebildiği için yeni
    # kimlik ayrıca ``sent_entry_id`` ile taşınır.
    if entry_id and entry_id != taslak:
        return False
    if not (entry_id and (sent_entry_id or message_id)):
        return False

    zaman = _now()
    case.last_outbound_entry_id = sent_entry_id or entry_id
    if message_id:
        case.last_outbound_message_id = message_id
    if conversation_id or getattr(case, "last_draft_conversation_id", ""):
        case.last_outbound_conversation_id = (
            conversation_id or case.last_draft_conversation_id)
    if not str(getattr(case, "initial_outbound_entry_id", "") or ""):
        case.initial_outbound_entry_id = sent_entry_id or entry_id
    if message_id and not str(
            getattr(case, "initial_outbound_message_id", "") or ""):
        case.initial_outbound_message_id = message_id

    tur = str(getattr(case, "last_draft_action", "") or "")
    case.last_outbound_at = zaman
    case.last_outbound_kind = tur
    if tur == "REMIND_FOR_REPLY":
        try:
            case.reminder_count = int(
                getattr(case, "reminder_count", 0) or 0) + 1
        except (TypeError, ValueError):
            case.reminder_count = 1
        case.last_reminder_at = zaman

    # Taslak artık gönderilmiş: taslak alanları temizlenir.
    case.last_draft_entry_id = ""
    case.last_draft_conversation_id = ""
    case.last_draft_action = ""

    # İlgili aksiyon DRAFTED -> WAITING_RESPONSE.
    for aksiyon in actions_of(case):
        if aksiyon.status == STATUS_DRAFTED and aksiyon.action_type == tur:
            aksiyon.status = STATUS_WAITING
            aksiyon.sent_at = zaman
            upsert_action(case, aksiyon)
            break

    case.add_mail_event("OUT", mail_id=message_id or sent_entry_id or entry_id,
                        occurred_at=zaman, reply_type=tur)
    case.add_event(f"{tur}_DRAFT_CONFIRMED",
                   "Taslak Gönderilmiş Öğeler'de doğrulandı; zincir ilerledi")
    return True


def resolve_send_unknown(case: Any, verify: Any) -> str:
    """Belirsiz kalan gönderimi Outlook doğrulamasıyla ÇÖZ.

    ÜRETİM ETKİSİ
        ``pending_unknown_action`` yalnızca BAŞARILI bir gönderimle
        temizleniyordu; o gönderim de ``check_can_send`` tarafından
        engelleniyordu. Tek bir ağ kesintisi, o vaka + o aksiyon için
        hatırlatmayı KALICI olarak kilitliyordu. Kullanıcının belirsizliği
        çözebileceği bir yol yoktu.

    Karar YALNIZCA Outlook'un söylediğine dayanır; tahmin yürütülmez:

      * ``SENT``     → mail gerçekten gitmiş: aksiyon WAITING_RESPONSE
                       (cevap bekleyen türse) ya da SENT olur, kilit açılır.
      * ``NOT_SENT`` → mail gitmemiş: aksiyon OPEN'a döner, kilit açılır;
                       tekrar göndermek GÜVENLİDİR.
      * ``UNKNOWN``  → hiçbir şey değişmez. Belirsizlik korunur; mükerrer
                       mail riski varken kilidi açmak yanlış olur.

    Dönen değer: uygulanan yeni durum ya da "" (değişiklik yok).
    """
    from app.services.case_actions import (
        AWAITS_RESPONSE,
        STATUS_OPEN,
        STATUS_SEND_UNKNOWN,
    )
    from app.services.incoming_cases import _now

    bekleyen = str(getattr(case, "pending_unknown_action", "") or "")
    if not bekleyen:
        return ""
    durum = str(getattr(verify, "status", "") or "")
    if durum not in ("SENT", "NOT_SENT"):
        return ""

    zaman = _now()
    hedef = ""
    for aksiyon in actions_of(case):
        if (aksiyon.status != STATUS_SEND_UNKNOWN
                or aksiyon.action_type != bekleyen):
            continue
        if durum == "SENT":
            hedef = (STATUS_WAITING if bekleyen in AWAITS_RESPONSE
                     else STATUS_SENT)
            aksiyon.sent_at = aksiyon.sent_at or zaman
            mid = str(getattr(verify, "message_id", "") or "")
            if mid:
                aksiyon.related_outbound_message_id = mid
        else:
            hedef = STATUS_OPEN
        aksiyon.status = hedef
        aksiyon.user_note = (
            (aksiyon.user_note + " | ") if aksiyon.user_note else ""
        ) + f"Outlook doğrulaması: {durum}"
        upsert_action(case, aksiyon)
        break

    if not hedef:
        return ""

    if durum == "SENT":
        # Kimlikler tamamlanır ki zincir EN SON gidenden devam etsin.
        record_outbound(case, verify, bekleyen, now=zaman)
    case.pending_unknown_action = ""
    case.pending_unknown_at = ""
    case.add_event(
        f"{bekleyen}_UNKNOWN_RESOLVED",
        ("Belirsiz gönderim Outlook'ta GÖNDERİLMİŞ olarak doğrulandı"
         if durum == "SENT" else
         "Belirsiz gönderim Outlook'ta GÖNDERİLMEMİŞ olarak doğrulandı; "
         "tekrar gönderim güvenli"),
        detail=str(getattr(verify, "reason", ""))[:300])
    return hedef
