"""İşlenmiş gelen mail kaydı — aynı mail İKİNCİ KEZ AI'ya gönderilmez.

NEDEN GEREKLİ
    Outlook aynı maili birden çok kez verebilir (senkronizasyon, klasör
    taşıma, kullanıcının "yeniden tara" demesi, iki pencerenin aynı anda
    çalışması). Her tekrar yeni bir Direct Line çağrısı demektir: para,
    zaman ve — daha kötüsü — aynı mail için iki farklı sonuç.

TASARIM (mail_log.py ile aynı ilkeler)
    - SQLite, kurulum gerektirmez, kullanıcı klasöründe durur.
    - Kayıt ASLA işi çökertmez: veritabanı yazılamazsa hata loglanır ve mail
      yine işlenir (sessiz veri kaybı yerine, en fazla mükerrer çağrı).
    - ``claim`` ATOMİKTİR: tek bir INSERT ile "bu maili ben aldım" denir.
      İki thread aynı anda denerse yalnızca biri kazanır.
    - Yarım kalan iş (uygulama kapandı) sonsuza kadar kilitlemez: eskimiş
      PROCESSING kayıtları ``stale_after`` sonrası devralınabilir.
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from loguru import logger

from app.incoming.models import ReconciliationResponse
from app.utils.paths import app_data_dir
from app.utils.sqlite import open_sqlite_connection

STATUS_PROCESSING = "PROCESSING"
STATUS_DONE = "DONE"
STATUS_FAILED = "FAILED"

# Yarım kalmış bir işin devralınabilmesi için geçmesi gereken süre.
DEFAULT_STALE_AFTER = timedelta(minutes=15)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(moment: datetime) -> str:
    return moment.isoformat(timespec="seconds")


@dataclass
class ClaimResult:
    """``claim`` sonucu.

    granted=True  → işleme devam et (AI çağrısı serbest).
    granted=False → başka biri işledi/işliyor; ``cached`` doluysa onu kullan.
    """

    granted: bool
    cached: Optional[ReconciliationResponse] = None
    status: str = ""
    reason: str = ""

    @property
    def duplicate(self) -> bool:
        return not self.granted


class ProcessedMailStore:
    """Gelen maillerin işlenme durumunu tutan kalıcı depo."""

    def __init__(self, path: str | Path | None = None,
                 stale_after: timedelta = DEFAULT_STALE_AFTER) -> None:
        if path is None:
            base = app_data_dir()
            base.mkdir(parents=True, exist_ok=True)
            path = base / "incoming_mail.db"
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._stale_after = stale_after
        self._degraded = False
        self._ensure_schema()

    @property
    def path(self) -> Path:
        return self._path

    @property
    def degraded(self) -> bool:
        """Veritabanı kullanılamıyor mu? (mükerrer koruma kapalı demektir)"""
        return self._degraded

    def _connect(self) -> sqlite3.Connection:
        return open_sqlite_connection(self._path, isolation_level=None)

    @contextmanager
    def _session(self):
        """Bağlantı aç, işlemi tamamla ve BAĞLANTIYI KAPAT.

        ``with sqlite3.connect(...) as conn`` yalnızca commit/rollback yapar;
        bağlantıyı KAPATMAZ. Kapanış çöp toplayıcıya kalınca yük altında
        dosya tanıtıcıları birikiyordu.
        """
        conn = self._connect()
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _ensure_schema(self) -> None:
        try:
            with self._session() as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS processed_mails (
                        fingerprint  TEXT PRIMARY KEY,
                        message_id   TEXT,
                        status       TEXT NOT NULL,
                        company_code TEXT,
                        subject      TEXT,
                        result       TEXT,
                        claimed_at   TEXT NOT NULL,
                        updated_at   TEXT NOT NULL
                    )
                """)
                conn.execute("""
                    CREATE INDEX IF NOT EXISTS ix_processed_mails_status
                    ON processed_mails (status, updated_at)
                """)
        except sqlite3.Error as exc:  # pragma: no cover - ortam bağımlı
            self._degraded = True
            logger.error(f"Gelen mail kaydı şeması kurulamadı: {exc}")

    # -- sahiplenme --------------------------------------------------------

    def claim(self, fingerprint: str, message_id: str = "",
              subject: str = "") -> ClaimResult:
        """Bu maili işleme hakkını al (atomik).

        Aynı parmak izi daha önce TAMAMLANDIYSA önbellekteki sonuç döner ve
        yeni bir AI çağrısı YAPILMAZ.
        """
        if not fingerprint:
            return ClaimResult(True, reason="parmak izi yok")

        now = _now()
        try:
            with self._session() as conn:
                try:
                    conn.execute(
                        "INSERT INTO processed_mails (fingerprint, message_id, "
                        "status, subject, claimed_at, updated_at) "
                        "VALUES (?,?,?,?,?,?)",
                        (fingerprint, message_id, STATUS_PROCESSING, subject,
                         _iso(now), _iso(now)),
                    )
                    return ClaimResult(True, status=STATUS_PROCESSING)
                except sqlite3.IntegrityError:
                    pass  # kayıt zaten var → durumuna bak

                row = conn.execute(
                    "SELECT status, result, claimed_at FROM processed_mails "
                    "WHERE fingerprint = ?", (fingerprint,)).fetchone()
                if row is None:  # pragma: no cover - yarış durumu
                    return ClaimResult(True, reason="kayıt kayboldu")

                status, result_json, claimed_at = row[0], row[1], row[2]

                if status == STATUS_DONE:
                    cached = self._decode(result_json)
                    if cached is not None:
                        cached.from_cache = True
                    return ClaimResult(False, cached, status,
                                       "bu mail daha önce işlendi")

                if status == STATUS_PROCESSING and not self._is_stale(claimed_at, now):
                    return ClaimResult(False, None, status,
                                       "mail şu anda başka bir işlem tarafından "
                                       "işleniyor")

                # FAILED ya da eskimiş PROCESSING → devral.
                # Devralma ATOMİK olmalı: iki thread aynı eskimiş kaydı
                # görebilir. UPDATE'i okunan (status, claimed_at) çiftine
                # bağlayıp rowcount ile yalnızca bir thread'in kazandığını
                # doğruluyoruz. "IS" operatörü NULL claimed_at için de çalışır.
                cur = conn.execute(
                    "UPDATE processed_mails SET status = ?, claimed_at = ?, "
                    "updated_at = ? WHERE fingerprint = ? AND status IS ? "
                    "AND claimed_at IS ?",
                    (STATUS_PROCESSING, _iso(now), _iso(now), fingerprint,
                     status, claimed_at))
                if cur.rowcount != 1:
                    # Başka bir thread bizden önce devraldı.
                    return ClaimResult(False, None, STATUS_PROCESSING,
                                       "mail şu anda başka bir işlem tarafından "
                                       "işleniyor")
                return ClaimResult(True, None, status, "önceki deneme tamamlanmamış")
        except sqlite3.Error as exc:  # pragma: no cover
            self._degraded = True
            logger.error(f"Gelen mail kaydı okunamadı ({fingerprint[:12]}…): {exc}")
            # Kayıt tutulamıyorsa iş DURMAZ; en fazla mükerrer çağrı olur.
            return ClaimResult(True, reason=f"kayıt hatası: {exc}")

    def _is_stale(self, claimed_at: Optional[str], now: datetime) -> bool:
        if not claimed_at:
            return True
        try:
            moment = datetime.fromisoformat(claimed_at)
        except ValueError:
            return True
        if moment.tzinfo is None:
            moment = moment.replace(tzinfo=timezone.utc)
        return (now - moment) > self._stale_after

    # -- sonuç yazma -------------------------------------------------------

    def complete(self, fingerprint: str,
                 response: ReconciliationResponse) -> bool:
        """İşlemi tamamlandı olarak işaretle ve sonucu sakla."""
        if not fingerprint:
            return False
        now = _iso(_now())
        try:
            payload = json.dumps(response.to_dict(), ensure_ascii=False)
        except (TypeError, ValueError) as exc:  # pragma: no cover
            logger.error(f"Sonuç JSON'a çevrilemedi: {exc}")
            payload = "{}"
        try:
            with self._session() as conn:
                conn.execute(
                    "INSERT INTO processed_mails (fingerprint, message_id, "
                    "status, company_code, subject, result, claimed_at, updated_at) "
                    "VALUES (?,?,?,?,?,?,?,?) "
                    "ON CONFLICT(fingerprint) DO UPDATE SET "
                    "status=excluded.status, company_code=excluded.company_code, "
                    "result=excluded.result, updated_at=excluded.updated_at",
                    (fingerprint, response.message_id, STATUS_DONE,
                     response.company_code or "", response.subject,
                     payload, now, now))
            return True
        except sqlite3.Error as exc:  # pragma: no cover
            self._degraded = True
            logger.error(f"Gelen mail sonucu yazılamadı: {exc}")
            return False

    def fail(self, fingerprint: str, reason: str = "") -> bool:
        """İşlemi başarısız işaretle (sonraki denemede yeniden işlenebilir)."""
        if not fingerprint:
            return False
        now = _iso(_now())
        try:
            with self._session() as conn:
                conn.execute(
                    "INSERT INTO processed_mails (fingerprint, status, "
                    "subject, result, claimed_at, updated_at) "
                    "VALUES (?,?,?,?,?,?) "
                    "ON CONFLICT(fingerprint) DO UPDATE SET "
                    "status=excluded.status, updated_at=excluded.updated_at",
                    (fingerprint, STATUS_FAILED, "",
                     json.dumps({"error": reason}, ensure_ascii=False),
                     now, now))
            return True
        except sqlite3.Error as exc:  # pragma: no cover
            self._degraded = True
            logger.error(f"Gelen mail hata kaydı yazılamadı: {exc}")
            return False

    # -- okuma -------------------------------------------------------------

    def get(self, fingerprint: str) -> Optional[ReconciliationResponse]:
        """Tamamlanmış sonucu getir (yoksa None)."""
        try:
            with self._session() as conn:
                row = conn.execute(
                    "SELECT result FROM processed_mails "
                    "WHERE fingerprint = ? AND status = ?",
                    (fingerprint, STATUS_DONE)).fetchone()
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"Gelen mail sonucu okunamadı: {exc}")
            return None
        if row is None:
            return None
        cached = self._decode(row[0])
        if cached is not None:
            cached.from_cache = True
        return cached

    def status_of(self, fingerprint: str) -> str:
        try:
            with self._session() as conn:
                row = conn.execute(
                    "SELECT status FROM processed_mails WHERE fingerprint = ?",
                    (fingerprint,)).fetchone()
        except sqlite3.Error:  # pragma: no cover
            return ""
        return row[0] if row else ""

    def count(self, status: Optional[str] = None) -> int:
        sql = "SELECT COUNT(*) FROM processed_mails"
        params: tuple = ()
        if status:
            sql += " WHERE status = ?"
            params = (status,)
        try:
            with self._session() as conn:
                row = conn.execute(sql, params).fetchone()
            return int(row[0]) if row else 0
        except sqlite3.Error:  # pragma: no cover
            return 0

    @staticmethod
    def _decode(payload: Optional[str]) -> Optional[ReconciliationResponse]:
        if not payload:
            return None
        try:
            data = json.loads(payload)
        except (TypeError, ValueError):
            return None
        if not isinstance(data, dict) or "reply_type" not in data:
            return None
        try:
            return ReconciliationResponse.from_dict(data)
        except Exception as exc:  # noqa: BLE001 - bozuk önbellek çökertmesin
            logger.warning(f"Önbellekteki sonuç okunamadı: {exc}")
            return None
