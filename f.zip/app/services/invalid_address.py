"""Teslim edilemeyen adresin VAKA tarafındaki sonuçları.

NEDEN AYRI MODÜL
    ``AddressRegistry`` bir ADRESİN durumunu tutar; bu modül o durumun
    VAKAYA ne yaptığını tanımlar:

      * Firma kaydı ``GEÇERSİZ_ADRES`` durumuna alınır.
      * Aynı adrese hatırlatma gönderimi DURDURULUR.
      * Yeni iletişim adresi girilmeden vaka KAPATILAMAZ.

    Üçü de tek bir yerde tanımlıdır; arayüz, hatırlatma üreteci ve dönüş
    tarayıcısı aynı kuralı çağırır. Kural iki yere kopyalanırsa biri
    güncellenip diğeri unutulur ve kullanılmayan adrese ay boyunca
    hatırlatma gider.

TASARIM
    Saf mantık: SQLite/Qt/COM bilmez, istisna fırlatmaz.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Iterable

#: Firma kaydının teslim edilemeyen adres durumu.
GECERSIZ_ADRES = "GECERSIZ_ADRES"
#: Kullanıcı yeni adres girdi; vaka yeniden işletilebilir.
ADRES_DUZELTILDI = "ADRES_DUZELTILDI"

_EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+$")


def is_valid_address(address: str) -> bool:
    """Biçimsel olarak gönderilebilir bir e-posta adresi mi?"""
    return bool(_EMAIL_RE.match((address or "").strip().strip("<>")))


def normalize(address: str) -> str:
    return (address or "").strip().strip("<>").lower()


@dataclass(frozen=True)
class AddressDecision:
    """Bir NDR'nin vakaya ve adres defterine yansıması."""

    #: Adres kalıcı olarak kullanılamaz mı (hatırlatma DURSUN mu)?
    block: bool = False
    #: Adres "kullanılmıyor" sınıfında mı (yanlış/kapatılmış)?
    unused: bool = False
    address: str = ""
    reason: str = ""

    @property
    def case_status(self) -> str:
        return GECERSIZ_ADRES if self.block else ""


def decide(failure: Any) -> AddressDecision:
    """``DeliveryFailureInfo``dan adres kararını çıkar.

    Geçici (4.x.x) hata adresi KAPATMAZ: sunucu yeniden deneyecektir ve
    geçici bir doluluk yüzünden firmayı takipten düşürmek, gerçekten
    ulaşılabilir bir firmayı kaybetmek demektir.
    """
    if failure is None or not getattr(failure, "is_failure", False):
        return AddressDecision()
    adres = normalize(getattr(failure, "failed_recipient", "") or "")
    kalici = bool(getattr(failure, "permanent", False))
    kullanilmiyor = bool(getattr(failure, "address_unused", False))
    try:
        gerekce = failure.describe()
    except Exception:  # noqa: BLE001 - gerekçe üretilemezse ham nedene düş
        gerekce = str(getattr(failure, "reason", "") or "")
    return AddressDecision(block=kalici, unused=kullanilmiyor,
                           address=adres, reason=gerekce)


def apply_to_case(case: Any, decision: AddressDecision) -> bool:
    """Kararı vakaya işle. Döner: vaka değişti mi?

    Geçmiş SİLİNMEZ: durum değişikliği vakanın timeline'ına yazılır.
    """
    if case is None or not decision.block:
        return False
    onceki = str(getattr(case, "address_status", "") or "")
    case.address_status = GECERSIZ_ADRES
    if decision.address:
        case.invalid_address = decision.address
    case.address_failure_reason = decision.reason[:500]
    # Girilen yeni adres de patladıysa düzeltme geçersizdir.
    if (decision.address
            and normalize(getattr(case, "replacement_address", "") or "")
            == decision.address):
        case.replacement_address = ""
    if onceki != GECERSIZ_ADRES:
        try:
            case.add_event("ADDRESS_INVALID",
                           "Mail teslim edilemedi; adres geçersiz sayıldı",
                           old_value=onceki, new_value=GECERSIZ_ADRES,
                           detail=decision.reason[:300])
        except Exception:  # noqa: BLE001 - olay yazılamazsa durum yine geçerli
            pass
    return True


def record_in_registry(registry: Any, decision: AddressDecision, *,
                       company_code: str = "") -> bool:
    """Kararı adres defterine yaz. Defter yoksa/yazılamazsa False."""
    if registry is None or not decision.address:
        return False
    try:
        if decision.unused:
            registry.mark_unused(decision.address, reason=decision.reason,
                                 company_code=company_code)
        else:
            registry.record_failure(decision.address,
                                    permanent=decision.block,
                                    reason=decision.reason,
                                    company_code=company_code)
        return True
    except Exception:  # noqa: BLE001 - defter hatası taramayı durdurmaz
        return False


def set_replacement_address(case: Any, address: str, *, user: str = "",
                            registry: Any = None, reason: str = "") -> str:
    """Vakaya YENİ iletişim adresi gir.

    Döner: boş metin (başarılı) ya da engel gerekçesi. Adres biçimsel olarak
    geçersizse ya da hâlâ engelli bir adres verilmişse KABUL EDİLMEZ —
    kullanıcı "düzelttim" sanıp vakayı kapatmasın.
    """
    yeni = normalize(address)
    if not is_valid_address(yeni):
        return "Geçerli bir e-posta adresi girin."
    if yeni == normalize(getattr(case, "invalid_address", "") or ""):
        return "Yeni adres, teslim edilemeyen adresle aynı olamaz."
    if registry is not None:
        try:
            engel = registry.blocked_reason(yeni)
        except Exception:  # noqa: BLE001
            engel = ""
        if engel:
            return f"Bu adres de teslimatı engellenmiş: {engel}"
    onceki = str(getattr(case, "replacement_address", "") or "") or str(
        getattr(case, "invalid_address", "") or "")
    case.replacement_address = yeni
    case.address_status = ADRES_DUZELTILDI
    try:
        case.add_event("ADDRESS_REPLACED", "Yeni iletişim adresi girildi",
                       old_value=onceki, new_value=yeni, user=user,
                       detail=reason[:300])
    except Exception:  # noqa: BLE001
        pass
    # DENETİM: adres değişikliği kullanıcı adıyla kalıcı günlüğe yazılır.
    _audit("ADDRESS_CHANGED", user=user,
           target=str(getattr(case, "case_id", "") or ""),
           company_code=str(getattr(case, "company_code", "") or ""),
           old_value=onceki, new_value=yeni, reason=reason)
    return ""


def _audit(action: str, **kwargs) -> None:
    """Denetim kaydı yaz; günlük yoksa iş DURMAZ."""
    try:
        from app.services.action_audit import ActionAuditLog

        ActionAuditLog().record(action, **kwargs)
    except Exception:  # noqa: BLE001 - denetim adres düzeltmeyi engellemez
        pass


def blocked(case: Any, registry: Any = None) -> str:
    """Bu vakaya mail/hatırlatma gitmesini engelleyen gerekçe (yoksa "").

    İki bağımsız kaynak sorgulanır: vakanın kendi durumu ve adres defteri.
    Defter, aynı adresi kullanan BAŞKA bir vakadan öğrenilmiş engeli de
    bilir; vakanın kendi alanı ise defter okunamasa bile korumayı sürdürür.
    """
    durum = str(getattr(case, "address_status", "") or "")
    if durum == GECERSIZ_ADRES:
        adres = str(getattr(case, "invalid_address", "") or "")
        gerekce = str(getattr(case, "address_failure_reason", "") or "")
        return (f"Adres teslimata kapalı ({adres or 'bilinmiyor'}): "
                f"{gerekce or 'mail teslim edilemedi'}. Yeni iletişim adresi "
                "girilmeden hatırlatma gönderilmez.")
    if registry is not None:
        # Düzeltilmiş adres varsa ARTIK O adres hedeflenir; eski (patlamış)
        # adresin defterdeki kaydı yeni adresi engellememelidir.
        yeni = normalize(getattr(case, "replacement_address", "") or "")
        for adres in _case_addresses(case):
            if yeni and adres != yeni:
                continue
            try:
                gerekce = registry.blocked_reason(adres)
            except Exception:  # noqa: BLE001
                gerekce = ""
            if gerekce:
                return (f"Adres teslimata kapalı: {gerekce}. Yeni iletişim "
                        "adresi girilmeden hatırlatma gönderilmez.")
    return ""


def _case_addresses(case: Any) -> Iterable[str]:
    """Vakanın hedeflediği adresler (alıcı + CC + gönderen)."""
    ham = "; ".join(str(getattr(case, alan, "") or "")
                    for alan in ("recipients", "cc", "sender"))
    for parca in ham.replace(",", ";").split(";"):
        adres = normalize(parca)
        if "@" in adres:
            yield adres


def can_close(case: Any) -> tuple[bool, str]:
    """Vaka kapatılabilir mi? (kapatılabilir, engel gerekçesi)

    GEÇERSİZ_ADRES durumundaki bir vaka, yeni iletişim adresi GİRİLMEDEN
    kapatılamaz: kapatılırsa firma mutabakat mektubunu hiç görmemiş olduğu
    hâlde dosya kapanır.
    """
    if str(getattr(case, "address_status", "") or "") != GECERSIZ_ADRES:
        return True, ""
    if is_valid_address(str(getattr(case, "replacement_address", "") or "")):
        return True, ""
    return False, ("Bu firmanın adresi teslimata kapalı. Vaka, YENİ iletişim "
                   "adresi girilmeden kapatılamaz.")


def invalid_cases(cases: Iterable[Any]) -> list[Any]:
    """Adresi geçersiz olan vakalar (operasyon paneli / rapor için)."""
    return [c for c in cases or ()
            if str(getattr(c, "address_status", "") or "") == GECERSIZ_ADRES]
