"""Mutabakat Pro paketi."""

# Uygulama sürümü. Audit kaydına ve sonuç Excel'inin "Çalıştırma Parametreleri"
# bloğuna yazılır; böylece bir sonuç dosyası aylar sonra hangi program sürümüyle
# üretildiği belli olur. Davranışı etkileyen her değişiklikte artırın.
__version__ = "4.3.0"
APP_VERSION = __version__
