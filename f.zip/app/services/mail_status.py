"""Mutabakat mailinin yaşam döngüsü — durum modeli ve geçiş kuralları.

NEDEN
    "Gönderildi / gönderilemedi" ikilisi gerçeği anlatmıyor. Bir mail
    gönderilmiş ama teslim edilmemiş; teslim edilmiş ama cevaplanmamış;
    cevaplanmış ama ekstre gelmemiş; ekstre gelmiş ama mutabık olunmamış
    olabilir. Kullanıcı "bu firma nerede kaldı?" sorusunun cevabını tek bir
    alanda görebilmelidir.

TASARIM
    * Durumlar TEK yönlüdür: bir kayıt ileri gider, geriye dönmez (yeniden
      gönderim yeni bir dönem/deneme demektir).
    * Her geçiş DOĞRULANIR: geçersiz bir geçiş sessizce uygulanmaz, çünkü
      "REPLY_RECEIVED" durumundaki bir kaydın "WAITING"e düşmesi, kullanıcının
      cevabı kaybetmesi demektir.
    * Bu modül SQLite/Qt bilmez; saf mantıktır ve her yerden çağrılabilir.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional


class MailStatus(str, Enum):
    """Bir mutabakat mailinin bulunduğu aşama."""

    WAITING = "WAITING"                    # üretildi, henüz gönderilmedi
    SENDING = "SENDING"                    # gönderim sürüyor
    SENT = "SENT"                          # Outlook'a teslim edildi
    SEND_FAILED = "SEND_FAILED"            # gönderilemedi (bizim tarafta hata)
    DELIVERY_FAILED = "DELIVERY_FAILED"    # karşı sunucu kabul etmedi (NDR)
    AWAITING_REPLY = "AWAITING_REPLY"      # gitti, cevap bekleniyor
    AUTOMATIC_REPLY = "AUTOMATIC_REPLY"    # ofis dışı / otomatik yanıt geldi
    REPLY_RECEIVED = "REPLY_RECEIVED"      # gerçek müşteri cevabı geldi
    ATTACHMENT_RECEIVED = "ATTACHMENT_RECEIVED"   # cevapta ekstre/mektup var
    PROCESSING = "PROCESSING"              # ek işleniyor / motor çalışıyor
    RECONCILED = "RECONCILED"              # mutabık
    RECONCILIATION_DIFFERENCE = "RECONCILIATION_DIFFERENCE"   # fark var
    HUMAN_REVIEW = "HUMAN_REVIEW"          # insan bakmalı
    AI_FAILED = "AI_FAILED"                # AI katmanı sonuç veremedi
    UNKNOWN = "UNKNOWN"                    # sınıflandırılamadı

    @property
    def is_terminal(self) -> bool:
        """Kayıt bu durumda kapanmış sayılır mı?"""
        return self in _TERMINAL

    @property
    def needs_attention(self) -> bool:
        """Kullanıcının bakması gereken bir durum mu?"""
        return self in _ATTENTION


_TERMINAL = frozenset({
    MailStatus.RECONCILED,
    MailStatus.DELIVERY_FAILED,
    MailStatus.SEND_FAILED,
})

_ATTENTION = frozenset({
    MailStatus.SEND_FAILED,
    MailStatus.DELIVERY_FAILED,
    MailStatus.RECONCILIATION_DIFFERENCE,
    MailStatus.HUMAN_REVIEW,
    MailStatus.AI_FAILED,
    MailStatus.UNKNOWN,
})


# İzin verilen geçişler. Amaç ilerlemeyi korumak: gelmiş bir cevabı ya da
# tespit edilmiş bir teslim hatasını daha erken bir duruma düşürmemek.
_ALLOWED: dict[MailStatus, frozenset[MailStatus]] = {
    MailStatus.WAITING: frozenset({
        MailStatus.SENDING, MailStatus.SENT, MailStatus.SEND_FAILED,
        MailStatus.HUMAN_REVIEW, MailStatus.UNKNOWN,
    }),
    MailStatus.SENDING: frozenset({
        MailStatus.SENT, MailStatus.SEND_FAILED, MailStatus.HUMAN_REVIEW,
    }),
    MailStatus.SENT: frozenset({
        MailStatus.AWAITING_REPLY, MailStatus.DELIVERY_FAILED,
        MailStatus.AUTOMATIC_REPLY, MailStatus.REPLY_RECEIVED,
        MailStatus.HUMAN_REVIEW, MailStatus.UNKNOWN,
    }),
    MailStatus.AWAITING_REPLY: frozenset({
        MailStatus.DELIVERY_FAILED, MailStatus.AUTOMATIC_REPLY,
        MailStatus.REPLY_RECEIVED, MailStatus.HUMAN_REVIEW, MailStatus.UNKNOWN,
    }),
    # Otomatik yanıt son söz değildir: gerçek cevap sonradan gelebilir.
    MailStatus.AUTOMATIC_REPLY: frozenset({
        MailStatus.REPLY_RECEIVED, MailStatus.DELIVERY_FAILED,
        MailStatus.HUMAN_REVIEW, MailStatus.UNKNOWN,
    }),
    MailStatus.REPLY_RECEIVED: frozenset({
        MailStatus.ATTACHMENT_RECEIVED, MailStatus.PROCESSING,
        MailStatus.RECONCILED, MailStatus.RECONCILIATION_DIFFERENCE,
        MailStatus.HUMAN_REVIEW, MailStatus.AI_FAILED, MailStatus.UNKNOWN,
    }),
    MailStatus.ATTACHMENT_RECEIVED: frozenset({
        MailStatus.PROCESSING, MailStatus.RECONCILED,
        MailStatus.RECONCILIATION_DIFFERENCE, MailStatus.HUMAN_REVIEW,
        MailStatus.AI_FAILED, MailStatus.UNKNOWN,
    }),
    MailStatus.PROCESSING: frozenset({
        MailStatus.RECONCILED, MailStatus.RECONCILIATION_DIFFERENCE,
        MailStatus.HUMAN_REVIEW, MailStatus.AI_FAILED, MailStatus.UNKNOWN,
    }),
    MailStatus.RECONCILIATION_DIFFERENCE: frozenset({
        MailStatus.HUMAN_REVIEW, MailStatus.RECONCILED,
    }),
    MailStatus.AI_FAILED: frozenset({
        MailStatus.HUMAN_REVIEW, MailStatus.RECONCILED,
        MailStatus.RECONCILIATION_DIFFERENCE,
    }),
    MailStatus.HUMAN_REVIEW: frozenset({
        MailStatus.RECONCILED, MailStatus.RECONCILIATION_DIFFERENCE,
    }),
    MailStatus.UNKNOWN: frozenset(set(MailStatus) - {MailStatus.UNKNOWN}),
    MailStatus.SEND_FAILED: frozenset({
        # Yeniden denenirse baştan gönderilebilir.
        MailStatus.SENDING, MailStatus.SENT, MailStatus.WAITING,
    }),
    MailStatus.DELIVERY_FAILED: frozenset({
        # Adres düzeltilip yeniden gönderilebilir.
        MailStatus.WAITING, MailStatus.SENDING, MailStatus.SENT,
        MailStatus.HUMAN_REVIEW,
    }),
    MailStatus.RECONCILED: frozenset({MailStatus.HUMAN_REVIEW}),
}


def can_transition(current: MailStatus, target: MailStatus) -> bool:
    """``current`` durumundan ``target`` durumuna geçilebilir mi?"""
    if current is target:
        return True
    return target in _ALLOWED.get(current, frozenset())


class InvalidTransition(ValueError):
    """Geçersiz durum geçişi denendi (ilerleme geriye alınamaz)."""


@dataclass(frozen=True)
class StatusEvent:
    """Tek bir durum değişikliği — denetim izinin yapı taşı."""

    status: MailStatus
    at: str
    note: str = ""
    actor: str = ""            # "system" | "user" | "outlook" | "ai"

    def __str__(self) -> str:  # pragma: no cover - gösterim
        return f"{self.at} {self.status.value}" + (f" — {self.note}" if self.note else "")


@dataclass
class MailLifecycle:
    """Bir mutabakat mailinin durum geçmişi (§30 zaman çizelgesi).

    Geçmiş silinmez; her geçiş eklenir. Böylece "bu kayıt neden burada?"
    sorusu tarih tarih cevaplanabilir.
    """

    status: MailStatus = MailStatus.WAITING
    events: list[StatusEvent] = field(default_factory=list)

    def advance(self, target: MailStatus, note: str = "", actor: str = "system",
                at: Optional[str] = None, strict: bool = False) -> bool:
        """Durumu ilerlet. Geçersiz geçişte ``strict`` ise hata, değilse False.

        Geçersiz geçiş SESSİZCE uygulanmaz — kayıt olduğu yerde kalır ve
        çağıran taraf False görür.
        """
        if not can_transition(self.status, target):
            if strict:
                raise InvalidTransition(
                    f"{self.status.value} → {target.value} geçişine izin yok.")
            return False
        stamp = at or datetime.now(timezone.utc).isoformat(timespec="seconds")
        self.status = target
        self.events.append(StatusEvent(target, stamp, note, actor))
        return True

    def timeline(self) -> list[str]:
        """UI'da gösterilecek okunabilir zaman çizelgesi."""
        return [str(e) for e in self.events]
