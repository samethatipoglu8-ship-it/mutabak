"""Bağımsız mutabakat sonucu doğrulayıcısı (FAZ 7).

NE YAPAR
    ``validate_reconciliation_result(input_left, input_right,
    reconciliation_result, context)`` girdi listelerini (firma/TOFAŞ satırları)
    ve ``Reconciler.reconcile()``'ın ÜRETTİĞİ ``ReconciliationResult``'ı alır,
    bunları SALT-OKUNUR biçimde inceler ve bir ``ValidationReport`` döndürür.

NE YAPMAZ (kesin kurallar)
    * eşleşme ÜRETMEZ, SİLMEZ, durumunu/kuralını DEĞİŞTİRMEZ
    * aday SEÇMEZ, tutar/kayıt ONARMAZ
    * ``Reconciler``'ı import etmez, çağırmaz, sonucu yeniden hesaplamaz
    * girdi listelerini ya da ``reconciliation_result``'ı MUTE ETMEZ

Bu modül, Reconciler'ın ÜRETTİĞİ sonucun kendi iç tutarlılığını (bkz. aşağıdaki
kontrol listesi) ikinci, bağımsız bir gözle denetler — Reconciler'ın mantığının
BİR KISMINI tekrar etmez; yalnızca sonuç nesnesinin alanları arasındaki
YAPISAL/ARİTMETİK tutarlılığı, girdi listeleriyle karşılaştırarak kontrol eder.

Kontrol listesi (docs/claude-audit/21 "INDEPENDENT VALIDATOR IMPLEMENTATION
STATUS" bölümünde numaralandırıldığı gibi):
  1-4   çift tüketim (firma/TOFAŞ satırı birden fazla sonuç kovasında;
        bire-çok gruplar arası ya da grup-içi tekrar)
  5     kova dışlayıcılığı (bir satır hem "sadece X" hem "eşleşti" olamaz)
  6-7   girdi satırı korunumu (sessiz kaybolma/hayalet satır yok) ve sayım
        tutarlılığı
  8     kalan/tutar farkı tutarlılığı (kurus_farki yeniden hesaplanır)
  9     para birimi çelişkisi tutarlılığı
  10    kimlik (IDENTITY) BLOCK tutarlılığı
  11    ekonomik olay (ECONOMIC_EVENT) BLOCK/REVIEW tutarlılığı
  12    belirsizlik (ambiguous) metadata tutarlılığı
  13    CrossMatch üyelik/yapı tutarlılığı
  14    özet (Summary) sayaçları vs gerçek sonuç nesneleri

Bulgular (``Finding``) yalnızca MİNİMAL kanıt taşır (satır indeksi, kova adı,
sayı) — asla tam finansal satır (tutar, firma adı, referans metni) loglanmaz.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Any, Optional, Sequence

from app.models.domain import (
    FirmaRecord,
    MatchRule,
    ReconciliationResult,
    Side,
    TofasRecord,
)

__all__ = [
    "Finding",
    "ValidationCode",
    "ValidationReport",
    "ValidationSeverity",
    "validate_reconciliation_result",
]


class ValidationSeverity(str, Enum):
    ERROR = "ERROR"
    WARNING = "WARNING"
    INFO = "INFO"


class ValidationCode(str, Enum):
    DUPLICATE_CONSUMPTION = "DUPLICATE_CONSUMPTION"
    MISSING_SOURCE_ROW = "MISSING_SOURCE_ROW"
    BUCKET_CONFLICT = "BUCKET_CONFLICT"
    COUNT_MISMATCH = "COUNT_MISMATCH"
    AMOUNT_RESIDUAL = "AMOUNT_RESIDUAL"
    CURRENCY_CONFLICT = "CURRENCY_CONFLICT"
    IDENTITY_GATE_INCONSISTENCY = "IDENTITY_GATE_INCONSISTENCY"
    EVENT_GATE_INCONSISTENCY = "EVENT_GATE_INCONSISTENCY"
    AMBIGUITY_INCONSISTENCY = "AMBIGUITY_INCONSISTENCY"
    SUMMARY_MISMATCH = "SUMMARY_MISMATCH"
    #: Yukarıdaki listede yoktu (talimatta "examples" olarak işaretliydi) ama
    #: CrossMatch nesnesinin kendi alanları arasındaki yapısal çelişkiyi
    #: (ör. single_side=FIRMA iken many_firma dolu) ayrı bir koddan ayırmak
    #: tanıyı kolaylaştırıyor.
    CROSS_MATCH_INCONSISTENCY = "CROSS_MATCH_INCONSISTENCY"


@dataclass(frozen=True)
class Finding:
    """Tek bir doğrulama bulgusu — MİNİMAL kanıt taşır (tam satır değil)."""

    severity: ValidationSeverity
    code: ValidationCode
    message: str
    evidence: dict[str, Any] = field(default_factory=dict)


@dataclass
class ValidationReport:
    findings: list[Finding] = field(default_factory=list)

    @property
    def errors(self) -> list[Finding]:
        return [f for f in self.findings if f.severity == ValidationSeverity.ERROR]

    @property
    def warnings(self) -> list[Finding]:
        return [f for f in self.findings if f.severity == ValidationSeverity.WARNING]

    @property
    def infos(self) -> list[Finding]:
        return [f for f in self.findings if f.severity == ValidationSeverity.INFO]

    @property
    def ok(self) -> bool:
        """Hiçbir ERROR seviyeli bulgu yoksa True (WARNING/INFO olsa da)."""
        return not self.errors


# ---------------------------------------------------------------------------
# iç yardımcılar — kova-üyeliği haritaları (satır_index -> [kova_adı, ...])
# ---------------------------------------------------------------------------

_CONSUMED_BUCKETS = frozenset({
    "matched", "amount_mismatch", "identity_conflict",
    "economic_event_review", "currency_diff",
    "cross_match_one", "cross_match_many",
})


def _left_appearances(result: ReconciliationResult) -> dict[int, list[str]]:
    out: dict[int, list[str]] = defaultdict(list)
    for p in result.matched:
        out[p.firma.row_index].append("matched")
    for p in result.amount_mismatch:
        out[p.firma.row_index].append("amount_mismatch")
    for p in result.identity_conflict:
        out[p.firma.row_index].append("identity_conflict")
    for p in result.economic_event_review:
        out[p.firma.row_index].append("economic_event_review")
    for p in result.currency_diff:
        out[p.firma.row_index].append("currency_diff")
    for rec in result.only_firma:
        out[rec.row_index].append("only_firma")
    for cm in result.cross_matches:
        if cm.single_side == Side.FIRMA and cm.one_firma is not None:
            out[cm.one_firma.row_index].append("cross_match_one")
        for rec in cm.many_firma:
            out[rec.row_index].append("cross_match_many")
    return out


def _right_appearances(result: ReconciliationResult) -> dict[int, list[str]]:
    out: dict[int, list[str]] = defaultdict(list)
    for p in result.matched:
        out[p.tofas.row_index].append("matched")
    for p in result.amount_mismatch:
        out[p.tofas.row_index].append("amount_mismatch")
    for p in result.identity_conflict:
        out[p.tofas.row_index].append("identity_conflict")
    for p in result.economic_event_review:
        out[p.tofas.row_index].append("economic_event_review")
    for p in result.currency_diff:
        out[p.tofas.row_index].append("currency_diff")
    for rec in result.only_tofas:
        out[rec.row_index].append("only_tofas")
    for cm in result.cross_matches:
        if cm.single_side == Side.TOFAS and cm.one_tofas is not None:
            out[cm.one_tofas.row_index].append("cross_match_one")
        for rec in cm.many_tofas:
            out[rec.row_index].append("cross_match_many")
    return out


# ---------------------------------------------------------------------------
# kontrol 1-4: çift tüketim (aynı satır birden fazla kez TÜKETİLDİ mi?)
# ---------------------------------------------------------------------------

def _check_duplicate_consumption(
    appearances: dict[int, list[str]], side: str, report: ValidationReport,
) -> None:
    for row_idx, buckets in sorted(appearances.items()):
        consumed = [b for b in buckets if b in _CONSUMED_BUCKETS]
        if len(consumed) > 1:
            report.findings.append(Finding(
                severity=ValidationSeverity.ERROR,
                code=ValidationCode.DUPLICATE_CONSUMPTION,
                message=(
                    f"{side} satırı {row_idx} birden fazla sonuç kovasında "
                    f"tüketilmiş: {consumed}"),
                evidence={"side": side, "row_index": row_idx, "buckets": consumed},
            ))


# ---------------------------------------------------------------------------
# kontrol 5: kova dışlayıcılığı (aynı satır hem "sadece X" hem "tüketildi")
# ---------------------------------------------------------------------------

def _check_bucket_exclusivity(
    appearances: dict[int, list[str]], only_bucket: str, side: str,
    report: ValidationReport,
) -> None:
    for row_idx, buckets in sorted(appearances.items()):
        if only_bucket in buckets and any(b in _CONSUMED_BUCKETS for b in buckets):
            report.findings.append(Finding(
                severity=ValidationSeverity.ERROR,
                code=ValidationCode.BUCKET_CONFLICT,
                message=(
                    f"{side} satırı {row_idx} HEM '{only_bucket}' HEM de "
                    f"tüketilmiş kovalarda görünüyor: {buckets}"),
                evidence={"side": side, "row_index": row_idx, "buckets": buckets},
            ))


# ---------------------------------------------------------------------------
# kontrol 6-7: girdi satırı korunumu + sayım tutarlılığı
# ---------------------------------------------------------------------------

def _check_conservation_left(
    input_left: Sequence[FirmaRecord], appearances: dict[int, list[str]],
    report: ValidationReport,
) -> None:
    input_ids = {r.row_index for r in input_left}
    seen_ids = set(appearances.keys())
    for row_idx in sorted(input_ids - seen_ids):
        report.findings.append(Finding(
            severity=ValidationSeverity.ERROR,
            code=ValidationCode.MISSING_SOURCE_ROW,
            message=f"Firma satırı {row_idx} hiçbir sonuç kovasında görünmüyor",
            evidence={"side": "firma", "row_index": row_idx},
        ))
    for row_idx in sorted(seen_ids - input_ids):
        report.findings.append(Finding(
            severity=ValidationSeverity.ERROR,
            code=ValidationCode.COUNT_MISMATCH,
            message=(
                f"Firma satırı {row_idx} sonuçta var ama girdi listesinde yok"),
            evidence={"side": "firma", "row_index": row_idx},
        ))


def _check_conservation_right(
    input_right: Sequence[TofasRecord], result: ReconciliationResult,
    appearances: dict[int, list[str]], report: ValidationReport,
) -> None:
    excluded_codes = {str(c).strip() for c in result.excluded_belge_turu}
    active_ids = {
        r.row_index for r in input_right
        if (r.belge_turu or "").strip() not in excluded_codes
    }
    excluded_ids = {
        r.row_index for r in input_right
        if (r.belge_turu or "").strip() in excluded_codes
    }
    seen_ids = set(appearances.keys())

    for row_idx in sorted(active_ids - seen_ids):
        report.findings.append(Finding(
            severity=ValidationSeverity.ERROR,
            code=ValidationCode.MISSING_SOURCE_ROW,
            message=f"TOFAŞ satırı {row_idx} hiçbir sonuç kovasında görünmüyor",
            evidence={"side": "tofas", "row_index": row_idx},
        ))
    for row_idx in sorted(seen_ids & excluded_ids):
        report.findings.append(Finding(
            severity=ValidationSeverity.ERROR,
            code=ValidationCode.COUNT_MISMATCH,
            message=(
                f"TOFAŞ satırı {row_idx} belge türü dışlanmış olmasına rağmen "
                "sonuçta görünüyor"),
            evidence={"side": "tofas", "row_index": row_idx},
        ))
    for row_idx in sorted(seen_ids - active_ids - excluded_ids):
        report.findings.append(Finding(
            severity=ValidationSeverity.ERROR,
            code=ValidationCode.COUNT_MISMATCH,
            message=f"TOFAŞ satırı {row_idx} sonuçta var ama girdi listesinde yok",
            evidence={"side": "tofas", "row_index": row_idx},
        ))


# ---------------------------------------------------------------------------
# kontrol 14: özet sayaçları vs gerçek sonuç nesneleri (+ total_tofas/total_firma)
# ---------------------------------------------------------------------------

def _check_summary(
    input_left: Sequence[FirmaRecord], input_right: Sequence[TofasRecord],
    result: ReconciliationResult, report: ValidationReport,
) -> None:
    s = result.summary
    excluded_codes = {str(c).strip() for c in result.excluded_belge_turu}
    active_tofas_count = sum(
        1 for r in input_right if (r.belge_turu or "").strip() not in excluded_codes
    )
    checks = (
        ("matched", len(result.matched), s.matched),
        ("amount_diff", len(result.amount_mismatch), s.amount_diff),
        ("cross_matched", len(result.cross_matches), s.cross_matched),
        ("currency_diff", len(result.currency_diff), s.currency_diff),
        ("identity_conflict", len(result.identity_conflict), s.identity_conflict),
        ("economic_event_review", len(result.economic_event_review),
         s.economic_event_review),
        ("only_firma", len(result.only_firma), s.only_firma),
        ("only_tofas", len(result.only_tofas), s.only_tofas),
        ("total_firma", len(input_left), s.total_firma),
        ("total_tofas", active_tofas_count, s.total_tofas),
        ("ambiguous_matches",
         sum(1 for m in result.matched if m.ambiguous), s.ambiguous_matches),
    )
    for label, actual, reported in checks:
        if actual != reported:
            report.findings.append(Finding(
                severity=ValidationSeverity.ERROR,
                code=ValidationCode.SUMMARY_MISMATCH,
                message=(
                    f"Summary.{label} = {reported} bildiriyor ama gerçek "
                    f"değer {actual}"),
                evidence={"field": label, "reported": reported, "actual": actual},
            ))


# ---------------------------------------------------------------------------
# kontrol 8: kalan/tutar farkı tutarlılığı
# ---------------------------------------------------------------------------

def _cents(value: Decimal) -> int:
    from decimal import ROUND_HALF_UP
    return int(value.copy_abs().quantize(Decimal("0.01"), rounding=ROUND_HALF_UP) * 100)


def _check_amount_residual(
    result: ReconciliationResult, report: ValidationReport,
) -> None:
    for bucket_name, pairs in (
        ("matched", result.matched), ("amount_mismatch", result.amount_mismatch),
    ):
        for p in pairs:
            actual = (p.firma.amount.copy_abs() - p.tofas.amount.copy_abs()).copy_abs()
            if _cents(actual) != _cents(p.kurus_farki):
                report.findings.append(Finding(
                    severity=ValidationSeverity.ERROR,
                    code=ValidationCode.AMOUNT_RESIDUAL,
                    message=(
                        f"{bucket_name}: firma satırı {p.firma.row_index} / "
                        f"tofas satırı {p.tofas.row_index} için kayıtlı "
                        f"kurus_farki gerçek farktan sapıyor"),
                    evidence={
                        "bucket": bucket_name,
                        "firma_row_index": p.firma.row_index,
                        "tofas_row_index": p.tofas.row_index,
                        "reported_cents": _cents(p.kurus_farki),
                        "actual_cents": _cents(actual),
                    },
                ))

    for i, cm in enumerate(result.cross_matches):
        many = cm.many_tofas if cm.single_side == Side.FIRMA else cm.many_firma
        total_many = sum((m.amount.copy_abs() for m in many), Decimal("0"))
        one = cm.one_firma if cm.single_side == Side.FIRMA else cm.one_tofas
        total_one = one.amount.copy_abs() if one is not None else Decimal("0")
        actual_kurus = (total_one - total_many).copy_abs()
        mismatches = []
        if _cents(total_one) != _cents(cm.total_one):
            mismatches.append("total_one")
        if _cents(total_many) != _cents(cm.total_many):
            mismatches.append("total_many")
        if _cents(actual_kurus) != _cents(cm.kurus_farki):
            mismatches.append("kurus_farki")
        if mismatches:
            report.findings.append(Finding(
                severity=ValidationSeverity.ERROR,
                code=ValidationCode.AMOUNT_RESIDUAL,
                message=(
                    f"cross_matches[{i}] alanları ({', '.join(mismatches)}) "
                    "satırlardan yeniden hesaplananla uyuşmuyor"),
                evidence={
                    "cross_match_index": i,
                    "mismatched_fields": mismatches,
                },
            ))


# ---------------------------------------------------------------------------
# kontrol 9: para birimi çelişkisi tutarlılığı
# ---------------------------------------------------------------------------

def _check_currency_conflict(
    result: ReconciliationResult, report: ValidationReport,
) -> None:
    for i, p in enumerate(result.currency_diff):
        a = (p.firma.currency or "").strip().upper()
        b = (p.tofas.currency or "").strip().upper()
        if not a or not b or a == b:
            report.findings.append(Finding(
                severity=ValidationSeverity.ERROR,
                code=ValidationCode.CURRENCY_CONFLICT,
                message=(
                    f"currency_diff[{i}] (firma satırı {p.firma.row_index} / "
                    f"tofas satırı {p.tofas.row_index}) gerçek bir para "
                    "birimi çelişkisi göstermiyor (biri boş ya da ikisi aynı)"),
                evidence={
                    "index": i,
                    "firma_row_index": p.firma.row_index,
                    "tofas_row_index": p.tofas.row_index,
                },
            ))


# ---------------------------------------------------------------------------
# kontrol 10: kimlik (IDENTITY) BLOCK tutarlılığı
# ---------------------------------------------------------------------------

def _check_identity_gate(
    result: ReconciliationResult, report: ValidationReport,
) -> None:
    for i, p in enumerate(result.identity_conflict):
        fa = (p.firma.tax_id or "").strip()
        ta = (p.tofas.tax_id or "").strip()
        if not fa or not ta or fa == ta:
            report.findings.append(Finding(
                severity=ValidationSeverity.ERROR,
                code=ValidationCode.IDENTITY_GATE_INCONSISTENCY,
                message=(
                    f"identity_conflict[{i}] gerçek bir doğrulanmış kimlik "
                    "çelişkisi göstermiyor (biri boş ya da ikisi aynı)"),
                evidence={
                    "index": i,
                    "firma_row_index": p.firma.row_index,
                    "tofas_row_index": p.tofas.row_index,
                },
            ))

    for bucket_name, pairs in (
        ("matched", result.matched), ("amount_mismatch", result.amount_mismatch),
        ("economic_event_review", result.economic_event_review),
        ("currency_diff", result.currency_diff),
    ):
        for p in pairs:
            fa = (p.firma.tax_id or "").strip()
            ta = (p.tofas.tax_id or "").strip()
            if fa and ta and fa != ta:
                report.findings.append(Finding(
                    severity=ValidationSeverity.ERROR,
                    code=ValidationCode.IDENTITY_GATE_INCONSISTENCY,
                    message=(
                        f"{bucket_name}: firma satırı {p.firma.row_index} / "
                        f"tofas satırı {p.tofas.row_index} doğrulanmış kimlik "
                        "çelişkisi taşıyor ama identity_conflict'e BLOCK "
                        "edilmemiş"),
                    evidence={
                        "bucket": bucket_name,
                        "firma_row_index": p.firma.row_index,
                        "tofas_row_index": p.tofas.row_index,
                    },
                ))


# ---------------------------------------------------------------------------
# kontrol 11: ekonomik olay (ECONOMIC_EVENT) BLOCK/REVIEW tutarlılığı
#
# NOT: ``row_classifier`` ETİKETLERİ BURADA YENİDEN HESAPLANMAZ (bu,
# Reconciler'ın eşleştirme mantığının bir parçasını tekrar etmek olurdu).
# Yalnızca sonuç nesnesinin KENDİ alanlarının birbiriyle yapısal tutarlılığı
# denetlenir.
# ---------------------------------------------------------------------------

_REFERENCE_BASED_RULES = frozenset({MatchRule.REFERENCE_EXACT, MatchRule.REFERENCE_FUZZY})


def _check_event_gate(
    result: ReconciliationResult, report: ValidationReport,
) -> None:
    for i, p in enumerate(result.economic_event_review):
        problems = []
        if p.rule != MatchRule.ECONOMIC_EVENT_CONFLICT:
            problems.append("rule")
        if p.original_rule not in _REFERENCE_BASED_RULES:
            problems.append("original_rule")
        if problems:
            report.findings.append(Finding(
                severity=ValidationSeverity.ERROR,
                code=ValidationCode.EVENT_GATE_INCONSISTENCY,
                message=(
                    f"economic_event_review[{i}] alanları ({', '.join(problems)}) "
                    "beklenen yapıyla uyuşmuyor"),
                evidence={"index": i, "problems": problems},
            ))

    for bucket_name, pairs in (
        ("matched", result.matched), ("amount_mismatch", result.amount_mismatch),
        ("identity_conflict", result.identity_conflict),
        ("currency_diff", result.currency_diff),
    ):
        for p in pairs:
            if p.rule == MatchRule.ECONOMIC_EVENT_CONFLICT:
                report.findings.append(Finding(
                    severity=ValidationSeverity.ERROR,
                    code=ValidationCode.EVENT_GATE_INCONSISTENCY,
                    message=(
                        f"{bucket_name}: firma satırı {p.firma.row_index} / "
                        f"tofas satırı {p.tofas.row_index} "
                        "ECONOMIC_EVENT_CONFLICT kuralı taşıyor ama "
                        "economic_event_review'de değil"),
                    evidence={
                        "bucket": bucket_name,
                        "firma_row_index": p.firma.row_index,
                        "tofas_row_index": p.tofas.row_index,
                    },
                ))


# ---------------------------------------------------------------------------
# kontrol 12: belirsizlik (ambiguous) metadata tutarlılığı
# ---------------------------------------------------------------------------

def _check_ambiguity_metadata(
    result: ReconciliationResult, report: ValidationReport,
) -> None:
    for bucket_name, pairs in (
        ("matched", result.matched), ("amount_mismatch", result.amount_mismatch),
    ):
        for p in pairs:
            if p.ambiguous and not (p.ambiguous_reason or "").strip():
                report.findings.append(Finding(
                    severity=ValidationSeverity.ERROR,
                    code=ValidationCode.AMBIGUITY_INCONSISTENCY,
                    message=(
                        f"{bucket_name}: firma satırı {p.firma.row_index} / "
                        f"tofas satırı {p.tofas.row_index} ambiguous=True "
                        "ama gerekçe boş"),
                    evidence={
                        "bucket": bucket_name,
                        "firma_row_index": p.firma.row_index,
                        "tofas_row_index": p.tofas.row_index,
                    },
                ))
            elif not p.ambiguous and (p.ambiguous_reason or "").strip():
                report.findings.append(Finding(
                    severity=ValidationSeverity.ERROR,
                    code=ValidationCode.AMBIGUITY_INCONSISTENCY,
                    message=(
                        f"{bucket_name}: firma satırı {p.firma.row_index} / "
                        f"tofas satırı {p.tofas.row_index} ambiguous=False "
                        "ama eski bir gerekçe taşıyor"),
                    evidence={
                        "bucket": bucket_name,
                        "firma_row_index": p.firma.row_index,
                        "tofas_row_index": p.tofas.row_index,
                    },
                ))


# ---------------------------------------------------------------------------
# kontrol 13: CrossMatch üyelik/yapı tutarlılığı
# ---------------------------------------------------------------------------

def _check_cross_match_structure(
    result: ReconciliationResult, report: ValidationReport,
) -> None:
    for i, cm in enumerate(result.cross_matches):
        problems: list[str] = []
        if cm.single_side == Side.FIRMA:
            if cm.one_firma is None:
                problems.append("one_firma eksik")
            if cm.one_tofas is not None:
                problems.append("one_tofas dolu olmamalıydı")
            if cm.many_firma:
                problems.append("many_firma boş olmalıydı")
            if not cm.many_tofas:
                problems.append("many_tofas boş olmamalıydı")
            ids = [r.row_index for r in cm.many_tofas]
            if len(ids) != len(set(ids)):
                problems.append("many_tofas içinde tekrarlanan satır")
        elif cm.single_side == Side.TOFAS:
            if cm.one_tofas is None:
                problems.append("one_tofas eksik")
            if cm.one_firma is not None:
                problems.append("one_firma dolu olmamalıydı")
            if cm.many_tofas:
                problems.append("many_tofas boş olmalıydı")
            if not cm.many_firma:
                problems.append("many_firma boş olmamalıydı")
            ids = [r.row_index for r in cm.many_firma]
            if len(ids) != len(set(ids)):
                problems.append("many_firma içinde tekrarlanan satır")

        if problems:
            report.findings.append(Finding(
                severity=ValidationSeverity.ERROR,
                code=ValidationCode.CROSS_MATCH_INCONSISTENCY,
                message=f"cross_matches[{i}] yapısal olarak tutarsız: {problems}",
                evidence={"index": i, "problems": problems},
            ))


# ---------------------------------------------------------------------------
# genel giriş noktası
# ---------------------------------------------------------------------------

def validate_reconciliation_result(
    input_left: Sequence[FirmaRecord],
    input_right: Sequence[TofasRecord],
    reconciliation_result: ReconciliationResult,
    context: Optional[dict[str, Any]] = None,
) -> ValidationReport:
    """Üretilmiş bir ``ReconciliationResult``'ı SALT-OKUNUR denetle.

    ``context`` şu an kullanılmıyor (gelecekte, ör. ``amount_tolerance``
    geçmek için ayrılmıştır); verilirse okunur ama hiçbir alanı değiştirmez.
    """
    del context  # şu an kullanılmıyor — ayrılmış parametre
    report = ValidationReport()
    r = reconciliation_result

    left_app = _left_appearances(r)
    right_app = _right_appearances(r)

    _check_duplicate_consumption(left_app, "firma", report)
    _check_duplicate_consumption(right_app, "tofas", report)
    _check_bucket_exclusivity(left_app, "only_firma", "firma", report)
    _check_bucket_exclusivity(right_app, "only_tofas", "tofas", report)
    _check_conservation_left(input_left, left_app, report)
    _check_conservation_right(input_right, r, right_app, report)
    _check_summary(input_left, input_right, r, report)
    _check_amount_residual(r, report)
    _check_currency_conflict(r, report)
    _check_identity_gate(r, report)
    _check_event_gate(r, report)
    _check_ambiguity_metadata(r, report)
    _check_cross_match_structure(r, report)

    return report
