"""Gelen mutabakat maili hattının domain modelleri.

Model stili mevcut servis katmanıyla aynı: ``dataclass`` + ``str, Enum``
(bkz. ``app/services/company_statement_service.py``, ``app/services/mail_log.py``).
``app/models/domain.py`` içindeki Pydantic modellere DOKUNULMAZ; bu hat
onların üstüne ayrı bir katman olarak biner.

ÜÇ DEĞERLİ MANTIK (True / False / None)
    ``letter_signed``, ``letter_sealed``, ``letter_filled`` ve
    ``balance_accepted`` bilerek ``Optional[bool]``tur. ``None`` = "bilinmiyor".
    İmza/kaşe gibi alanlarda "emin değilim"i ``False`` diye yazmak, imzasız bir
    mektubu imzalı sanmak kadar tehlikelidir: ikisi de sessiz yanlış bilgidir.
    Bilinmeyen alan insana sorulur (``needs_human_review``).
"""

from __future__ import annotations

import hashlib
import threading
from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Any, Optional


class AttachmentKind(str, Enum):
    """Ekin ne olduğu. Dosya adına KÖRÜ KÖRÜNE güvenilmez; içerik de bakılır."""

    LETTER = "LETTER"          # mutabakat mektubu
    STATEMENT = "STATEMENT"    # ekstre / hesap dökümü
    OTHER = "OTHER"            # imza görseli, logo, alakasız belge…
    UNREADABLE = "UNREADABLE"  # bozuk/şifreli/okunamayan dosya
    #: BİZİM gönderdiğimiz dosyanın geri dönen kopyası (bayt bayt aynı).
    #: Outlook cevap verirken orijinal eki çoğu zaman geri yollar. Bu bir
    #: FİRMA BELGESİ DEĞİLDİR: mektup/ekstre sayılmaz, değerlendirilmez.
    ECHO = "ECHO"


class ReplyType(str, Enum):
    """Firmanın cevabının türü."""

    ACCEPTED = "ACCEPTED"
    REJECTED = "REJECTED"
    PARTIALLY_ACCEPTED = "PARTIALLY_ACCEPTED"
    REQUESTED_CORRECTION = "REQUESTED_CORRECTION"
    INFORMATION_ONLY = "INFORMATION_ONLY"
    UNKNOWN = "UNKNOWN"


class Direction(str, Enum):
    """Mutabakat yönü (mevcut sistemdeki M/S/X ile aynı anlam)."""

    M = "M"
    S = "S"
    X = "X"
    UNKNOWN = "UNKNOWN"


class AIReviewStatus(str, Enum):
    """AI katmanının bu mail için akıbeti."""

    NOT_CALLED = "NOT_CALLED"                  # Python yeterliydi, AI çağrılmadı
    ACCEPTED = "ACCEPTED"                      # AI çağrıldı, sonucu birleştirildi
    CONFLICT = "CONFLICT"                      # Python ve AI çelişti → insan
    DISABLED = "DISABLED"                      # Direct Line kapalı / secret yok
    AI_UNAVAILABLE = "AI_UNAVAILABLE"          # timeout / retry tükendi
    AI_INVALID_JSON = "AI_INVALID_JSON"        # cevap JSON değil / şema dışı
    AI_AUTH_FAILED = "DIRECT_LINE_AUTH_FAILED"  # secret yanlış/yetkisiz
    AI_ERROR = "AI_ERROR"                      # diğer Direct Line hataları


# İnsan incelemesi gerekçeleri — sabit kodlar, log ve UI için.
REVIEW_NO_COMPANY_CODE = "NO_COMPANY_CODE"
REVIEW_NO_COMPANY_NAME = "NO_COMPANY_NAME"
REVIEW_MULTIPLE_COMPANY_CODES = "MULTIPLE_COMPANY_CODES"
REVIEW_MULTIPLE_LETTERS = "MULTIPLE_LETTERS"
REVIEW_MULTIPLE_STATEMENTS = "MULTIPLE_STATEMENTS"
REVIEW_LETTER_UNCERTAIN = "LETTER_UNCERTAIN"
# Mektubun İÇERİĞİ hiç görülemedi (taranmış görüntü / okunamayan ek).
# Bu sistem AI'ya görüntü göndermez; imza/kaşe iddiası KABUL EDİLMEZ.
REVIEW_LETTER_NOT_SEEN = "LETTER_NOT_SEEN"
REVIEW_SIGNATURE_UNCERTAIN = "SIGNATURE_UNCERTAIN"
REVIEW_SEAL_UNCERTAIN = "SEAL_UNCERTAIN"
REVIEW_BALANCE_UNCERTAIN = "BALANCE_UNCERTAIN"
REVIEW_LOW_CONFIDENCE = "LOW_CONFIDENCE"
REVIEW_ATTACHMENT_UNREADABLE = "ATTACHMENT_UNREADABLE"
REVIEW_CONFLICT = "PYTHON_AI_CONFLICT"
REVIEW_AI_UNAVAILABLE = "AI_UNAVAILABLE"
REVIEW_AI_INVALID_JSON = "AI_INVALID_JSON"
REVIEW_AI_REQUESTED = "AI_REQUESTED_REVIEW"
REVIEW_REPLY_TYPE_UNKNOWN = "REPLY_TYPE_UNKNOWN"
REVIEW_PARSER_ERROR = "PARSER_ERROR"
REVIEW_CONDITIONAL_REPLY = "CONDITIONAL_REPLY"
REVIEW_PAYMENT_INSTRUCTION = "PAYMENT_INSTRUCTION_CHANGE"
# Bilgi amaçlı (tek başına insan incelemesi gerektirmez).
INFO_DUPLICATE_ATTACHMENT = "DUPLICATE_ATTACHMENT"


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


#: Belleğe alınacak en büyük ek boyutu. Daha büyüğü OKUNMAZ: 500 MB'lık
#: bir PDF'i belleğe almak süreci düşürür. Hem Outlook okuyucusu hem de
#: disk yolundan okuyan çıkarıcı AYNI sınırı uygular.
MAX_ATTACHMENT_BYTES = 25 * 1024 * 1024


#: Parmak izi hesaplamasını serileştiren kilit (bkz. IncomingMail.fingerprint).
_FINGERPRINT_LOCK = threading.Lock()


@dataclass
class IncomingAttachment:
    """Gelen mailin tek bir eki.

    İçerik ya ``content`` (bayt) ya da ``path`` üzerinden gelir; ikisi de
    boşsa ek OKUNAMAZ sayılır ve sessizce yok sayılmaz.
    """

    filename: str = ""
    content: bytes = b""
    path: Optional[str] = None

    # -- sınıflandırma -----------------------------------------------------
    kind: AttachmentKind = AttachmentKind.OTHER
    kind_confidence: float = 0.0
    kind_reason: str = ""

    # -- çıkarım -----------------------------------------------------------
    text: str = ""                                   # düz metin (PDF/Excel/txt)
    tables: list[list[list[str]]] = field(default_factory=list)  # sayfa → satır → hücre
    page_count: int = 0
    extracted_page_count: int = 0
    extraction_truncated: bool = False
    image_count: int = 0
    has_text_layer: Optional[bool] = None            # PDF'te metin katmanı var mı
    has_digital_signature: Optional[bool] = None     # PDF AcroForm /Sig alanı
    read_error: str = ""

    @property
    def extension(self) -> str:
        name = (self.filename or "").strip().lower()
        return name[name.rfind("."):] if "." in name else ""

    @property
    def size(self) -> int:
        return len(self.content)

    @property
    def readable(self) -> bool:
        """Ekten anlamlı bir şey çıkarılabildi mi?"""
        return not self.read_error and bool(self.text.strip() or self.tables)

    @property
    def sha256(self) -> str:
        """İçerik parmak izi (mükerrer ek tespiti; içerik yoksa ada düşer)."""
        if self.content:
            return _sha256(self.content)
        return _sha256((self.filename or "").encode("utf-8", "replace"))

    def summary(self) -> dict[str, Any]:
        """Log/AI yükü için kısa özet — BINARY İÇERİK TAŞIMAZ."""
        return {
            "filename": self.filename,
            "extension": self.extension,
            "size": self.size,
            "kind": self.kind.value,
            "kind_confidence": round(self.kind_confidence, 2),
            "page_count": self.page_count,
            "extracted_page_count": self.extracted_page_count,
            "extraction_truncated": self.extraction_truncated,
            "image_count": self.image_count,
            "has_text_layer": self.has_text_layer,
            "read_error": self.read_error,
        }


@dataclass
class IncomingMail:
    """Outlook'tan (ya da testte elle) gelen tek bir mail.

    Bu sınıf Outlook'a BAĞIMLI DEĞİLDİR: okuyucu katmanı COM nesnesini bu
    modele çevirir, hattın geri kalanı yalnızca bu modeli görür.
    """

    message_id: str = ""             # InternetMessageID (tercih edilen kimlik)
    entry_id: str = ""               # Outlook EntryID (yerel kimlik)
    subject: str = ""
    sender: str = ""                 # SMTP adresi
    sender_name: str = ""
    to: list[str] = field(default_factory=list)
    cc: list[str] = field(default_factory=list)
    body: str = ""
    received_at: Optional[datetime] = None
    attachments: list[IncomingAttachment] = field(default_factory=list)
    folder: str = ""

    # -- zincir kimlikleri (gelen cevabı GÖNDERDİĞİMİZ maile bağlar) --------
    # Konu satırı tek başına yeterli değildir: firma konuyu değiştirebilir,
    # iki dönem aynı konuyu taşıyabilir. Bu alanlar doluysa eşleştirme kesindir.
    conversation_id: str = ""        # Outlook ConversationID (zincir kimliği)
    in_reply_to: str = ""            # RFC 5322 In-Reply-To
    references: str = ""             # RFC 5322 References
    message_class: str = ""          # IPM.Note / REPORT.IPM.Note.NDR …

    # İlk erişimde hesaplanıp SABİTLENİR: ayrıştırma sırasında eklere metin
    # yazılır ve parmak izinin bu yüzden değişmesi, kayıt anahtarı ile sonuçtaki
    # anahtarın farklı olmasına yol açardı. (İçerik hash'i zaten değişmez;
    # önbellek ayrıca 25 MB'lık ekleri tekrar tekrar hashlemeyi de önler.)
    _fingerprint: Optional[str] = field(default=None, init=False, repr=False,
                                        compare=False)

    @property
    def fingerprint(self) -> str:
        """İdempotency anahtarı.

        InternetMessageID varsa o kullanılır (RFC 5322 Message-ID benzersizdir).
        Yoksa mailin değişmeyen parçalarından türetilir; böylece aynı mail
        iki kez işlenip İKİNCİ KEZ AI çağrısı yapılması engellenir.
        """
        # Hesaplama KİLİT ALTINDA: iki thread aynı maile aynı anda
        # eriştiğinde ikisi de hesaplıyordu. Ekler bu sırada değişirse iki
        # farklı parmak izi doğar ve mükerrer koruma delinir.
        # Kilit modül düzeyindedir: dataclass'a kilit alanı eklemek nesneyi
        # kopyalanamaz/pickle'lanamaz yapardı. Çekişme ihmal edilebilir —
        # ek içerik hash'leri zaten önceden hesaplanmıştır.
        if self._fingerprint is None:
            with _FINGERPRINT_LOCK:
                if self._fingerprint is None:
                    self._fingerprint = self._compute_fingerprint()
        return self._fingerprint

    def _compute_fingerprint(self) -> str:
        if self.message_id.strip():
            return "mid:" + _sha256(self.message_id.strip().encode("utf-8"))
        parts = [
            self.entry_id.strip(),
            self.subject.strip(),
            self.sender.strip().lower(),
            self.received_at.isoformat() if self.received_at else "",
            (self.body or "")[:2000],
        ]
        parts.extend(sorted(a.sha256 for a in self.attachments))
        return "raw:" + _sha256("|".join(parts).encode("utf-8", "replace"))

    @property
    def attachment_names(self) -> list[str]:
        return [a.filename for a in self.attachments]

    def attachments_of(self, kind: AttachmentKind) -> list[IncomingAttachment]:
        return [a for a in self.attachments if a.kind == kind]


@dataclass
class ParsedMailResult:
    """Deterministik Python parser'ın çıktısı (AI'dan ÖNCE)."""

    company_code: Optional[str] = None
    company_name: Optional[str] = None

    letter_present: bool = False
    statement_present: bool = False

    letter_filled: Optional[bool] = None
    letter_signed: Optional[bool] = None
    letter_sealed: Optional[bool] = None

    balance_present: bool = False
    balance_accepted: Optional[bool] = None

    reply_type: ReplyType = ReplyType.UNKNOWN
    period: Optional[str] = None                       # "2026-07"
    currencies: dict[str, Decimal] = field(default_factory=dict)
    direction: Direction = Direction.UNKNOWN

    confidence: float = 0.0
    needs_human_review: bool = True
    reasons: list[str] = field(default_factory=list)

    # -- izlenebilirlik ----------------------------------------------------
    evidence: dict[str, str] = field(default_factory=dict)
    letter_count: int = 0
    statement_count: int = 0
    unreadable_attachments: list[str] = field(default_factory=list)
    company_code_candidates: list[str] = field(default_factory=list)

    def add_reason(self, code: str) -> None:
        if code and code not in self.reasons:
            self.reasons.append(code)

    def is_confident(self, threshold: float) -> bool:
        """AI'ya gitmeden kabul edilebilir mi?"""
        return self.confidence >= threshold and not self.needs_human_review


@dataclass
class AIAnalysisResult:
    """Copilot Studio ajanının doğrulanmış çıktısı.

    Alanlar ``ParsedMailResult`` ile birebir aynı adları taşır ki birleştirme
    katmanı alan alan karşılaştırabilsin. ``status`` alanı AI'nın gerçekten
    cevap verip vermediğini söyler — cevap yoksa alanlar boş kalır ve
    ``needs_human_review`` True olur.
    """

    status: AIReviewStatus = AIReviewStatus.NOT_CALLED

    company_code: Optional[str] = None
    company_name: Optional[str] = None

    letter_present: Optional[bool] = None
    statement_present: Optional[bool] = None

    letter_filled: Optional[bool] = None
    letter_signed: Optional[bool] = None
    letter_sealed: Optional[bool] = None

    balance_present: Optional[bool] = None
    balance_accepted: Optional[bool] = None

    reply_type: ReplyType = ReplyType.UNKNOWN
    period: Optional[str] = None
    currencies: dict[str, Decimal] = field(default_factory=dict)
    direction: Direction = Direction.UNKNOWN

    confidence: float = 0.0
    needs_human_review: bool = True
    reason: Optional[str] = None

    # -- çağrı bilgileri (secret/token ASLA taşınmaz) ----------------------
    request_id: str = ""
    error_code: str = ""
    retries: int = 0
    duration_ms: int = 0
    schema_errors: list[str] = field(default_factory=list)

    @property
    def usable(self) -> bool:
        """Birleştirmeye girebilir mi?"""
        return self.status == AIReviewStatus.ACCEPTED


@dataclass(frozen=True)
class FieldConflict:
    """Python ve AI aynı alan için FARKLI değer söyledi.

    Çakışma sessizce çözülmez: Python'un değeri korunur, kayıt tutulur ve
    mail insan incelemesine düşer.
    """

    field_name: str
    python_value: str
    ai_value: str

    def __str__(self) -> str:  # pragma: no cover - yalnızca log/gösterim
        return (f"{self.field_name}: python={self.python_value!r} "
                f"ai={self.ai_value!r}")


@dataclass
class ReconciliationResponse:
    """Hattın NİHAİ sonucu — mevcut sistemin tüketeceği model."""

    company_code: Optional[str] = None
    company_name: Optional[str] = None

    letter_present: bool = False
    statement_present: bool = False

    letter_filled: Optional[bool] = None
    letter_signed: Optional[bool] = None
    letter_sealed: Optional[bool] = None

    balance_present: bool = False
    balance_accepted: Optional[bool] = None

    reply_type: ReplyType = ReplyType.UNKNOWN
    period: Optional[str] = None
    currencies: dict[str, Decimal] = field(default_factory=dict)
    direction: Direction = Direction.UNKNOWN

    confidence: float = 0.0
    needs_human_review: bool = True

    # -- izlenebilirlik ----------------------------------------------------
    review_status: AIReviewStatus = AIReviewStatus.NOT_CALLED
    conflicts: list[FieldConflict] = field(default_factory=list)
    reasons: list[str] = field(default_factory=list)
    message_id: str = ""
    fingerprint: str = ""
    subject: str = ""
    sender: str = ""
    ai_error: str = ""
    from_cache: bool = False
    duration_ms: int = 0

    def add_reason(self, code: str) -> None:
        if code and code not in self.reasons:
            self.reasons.append(code)

    @property
    def has_conflict(self) -> bool:
        return bool(self.conflicts)

    def to_dict(self) -> dict[str, Any]:
        """JSON'a yazılabilir sözlük (Decimal → str)."""
        return {
            "company_code": self.company_code,
            "company_name": self.company_name,
            "letter_present": self.letter_present,
            "statement_present": self.statement_present,
            "letter_filled": self.letter_filled,
            "letter_signed": self.letter_signed,
            "letter_sealed": self.letter_sealed,
            "balance_present": self.balance_present,
            "balance_accepted": self.balance_accepted,
            "reply_type": self.reply_type.value,
            "period": self.period,
            "currencies": {c: str(v) for c, v in self.currencies.items()},
            "direction": self.direction.value,
            "confidence": round(self.confidence, 4),
            "needs_human_review": self.needs_human_review,
            "review_status": self.review_status.value,
            "conflicts": [
                {"field": c.field_name, "python": c.python_value, "ai": c.ai_value}
                for c in self.conflicts
            ],
            "reasons": list(self.reasons),
            "message_id": self.message_id,
            "fingerprint": self.fingerprint,
            "subject": self.subject,
            "sender": self.sender,
            "ai_error": self.ai_error,
            "duration_ms": self.duration_ms,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ReconciliationResponse":
        """``to_dict`` çıktısından geri kur (idempotency önbelleği için)."""
        def _enum(enum_cls, value, default):
            try:
                return enum_cls(value)
            except (ValueError, TypeError):
                return default

        currencies: dict[str, Decimal] = {}
        for code, amount in (data.get("currencies") or {}).items():
            try:
                currencies[str(code)] = Decimal(str(amount))
            except Exception:  # noqa: BLE001 - bozuk önbellek çökertmesin
                continue

        conflicts = [
            FieldConflict(
                field_name=str(c.get("field", "")),
                python_value=str(c.get("python", "")),
                ai_value=str(c.get("ai", "")),
            )
            for c in (data.get("conflicts") or [])
            if isinstance(c, dict)
        ]

        return cls(
            company_code=data.get("company_code"),
            company_name=data.get("company_name"),
            letter_present=bool(data.get("letter_present", False)),
            statement_present=bool(data.get("statement_present", False)),
            letter_filled=data.get("letter_filled"),
            letter_signed=data.get("letter_signed"),
            letter_sealed=data.get("letter_sealed"),
            balance_present=bool(data.get("balance_present", False)),
            balance_accepted=data.get("balance_accepted"),
            reply_type=_enum(ReplyType, data.get("reply_type"), ReplyType.UNKNOWN),
            period=data.get("period"),
            currencies=currencies,
            direction=_enum(Direction, data.get("direction"), Direction.UNKNOWN),
            confidence=float(data.get("confidence") or 0.0),
            needs_human_review=bool(data.get("needs_human_review", True)),
            review_status=_enum(AIReviewStatus, data.get("review_status"),
                                AIReviewStatus.NOT_CALLED),
            conflicts=conflicts,
            reasons=list(data.get("reasons") or []),
            message_id=str(data.get("message_id") or ""),
            fingerprint=str(data.get("fingerprint") or ""),
            subject=str(data.get("subject") or ""),
            sender=str(data.get("sender") or ""),
            ai_error=str(data.get("ai_error") or ""),
            duration_ms=int(data.get("duration_ms") or 0),
        )
