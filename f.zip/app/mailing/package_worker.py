"""Firma paketi üretimi ve gönderimi için arka plan işçileri.

Excel + PDF üretimi ve Outlook gönderimi UI thread'inde çalışırsa uygulama
"yanıt vermiyor" durumuna düşer: 500 firma × (2 Excel + 2 PDF) ciddi bir iş
yüküdür. Bu işçiler mevcut ``app.ui.worker.run_in_thread`` kalıbını kullanır;
iletişim yalnızca Qt sinyalleriyle olur.

Outlook COM çağrıları ``pythoncom.CoInitialize()`` sarmalayıcısını kendi
içinde yaptığı için arka plan thread'inde güvenle çalışır.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from decimal import Decimal
from typing import TYPE_CHECKING, Iterable, Optional, Sequence

from loguru import logger
from PySide6.QtCore import QObject, Signal

from app.mailing.excel_loader import MailRow
from app.mailing.mail_builder import BuildConfig, normalize_code
from app.services import send_gate
from app.services.mail_log import MailLog, period_key

if TYPE_CHECKING:  # pragma: no cover - yalnızca tip denetimi için
    from app.services.company_package_service import CompanyMailPackage
    from app.services.reconciliation_letter_writer import LetterPeriod

# NOT: ekstre/mektup üreten servisler pandas, openpyxl, reportlab ve pypdf'i
# modül düzeyinde çeker (~1 sn). Bu modül gelen mail hattının da taban sınıfını
# (``CancellableWorker``) barındırdığı için o zincir TEMBEL bırakılır: ağır
# bağımlılıklar yalnızca gerçekten üretim/gönderim yapılırken yüklenir.


@dataclass
class SapBalanceResult:
    """SAP dosyalarından çıkarılan dip bakiyeler.

    ``balances``: firma kodu -> yön ("M"/"S"/"") -> para birimi -> tutar.
    ``missing_directions``: firma kodu -> kaynağı yüklenmemiş yönler.
    """

    balances: dict = field(default_factory=dict)
    missing_directions: dict = field(default_factory=dict)
    vendor_loaded: bool = False
    customer_loaded: bool = False
    company_count: int = 0
    #: Hiçbir firmaya bağlanamayan 120* hesabı -> satır sayısı.
    #: Bu satırlar TAHMİN EDİLMEZ ve hiçbir mektuba girmez; sayım
    #: kullanıcıya gösterilir ki eksik eşleme sessizce kaybolmasın.
    unmapped_customer_accounts: dict = field(default_factory=dict)
    # Hangi hesaplamaya ait olduğu. Ekran, eskimiş bir sonucun yenisini
    # ezmesini bu numarayla engeller. (Sinyale lambda BAĞLANMAZ: lambda'nın
    # alıcı nesnesi olmadığı için Qt çağrıyı worker thread'inde çalıştırır ve
    # arayüz başka thread'den kurcalanır.)
    token: int = 0

    def for_direction(self, code: str, ms: str) -> Optional[dict]:
        """Firmanın o yöndeki SAP bakiyesi (yoksa None — 0 İLE KARIŞTIRMA).

        ``None`` "SAP bu yönü söylemedi" demektir; boş sözlük ise "SAP baktı,
        hiç satır yok" demektir ve 0 olarak yazılabilir.
        """
        per_direction = self.balances.get(code)
        if per_direction is None:
            return None
        if ms in per_direction:
            return per_direction[ms]
        # Yön belirsiz satır ("") tek segmentli firmada o segmenti kullanır.
        if ms == "" and len(per_direction) == 1:
            return next(iter(per_direction.values()))
        return None


class CancellableWorker(QObject):
    """İptal edilebilir işçiler için ortak taban.

    İptal KOOPERATİFTİR: iş parçacığı zorla öldürülmez, döngü bir sonraki
    adımda kendisi durur. Böylece yarım yazılmış dosya ya da yarım gönderilmiş
    mail oluşmaz.
    """

    def __init__(self) -> None:
        super().__init__()
        self._cancel = threading.Event()

    def cancel(self) -> None:
        """UI thread'inden çağrılır; işçi bir sonraki adımda durur."""
        self._cancel.set()

    @property
    def cancelled(self) -> bool:
        return self._cancel.is_set()


class ReportLoadWorker(CancellableWorker):
    """Mutabakat raporu Excel'ini ARKA PLANDA okur.

    3000 satırlık bir dosyayı UI thread'inde açmak uygulamayı saniyelerce
    "yanıt vermiyor" durumunda bırakıyordu.
    """

    progress = Signal(str, int)
    finished = Signal(object)            # LoadResult
    failed = Signal(str)

    def __init__(self, path: str) -> None:
        super().__init__()
        self._path = path

    def run(self) -> None:
        try:
            from app.mailing.excel_loader import load_report

            self.progress.emit("Excel okunuyor…", 20)
            result = load_report(self._path)
            self.progress.emit(f"{len(result.rows)} satır yüklendi.", 100)
            self.finished.emit(result)
        except Exception as exc:  # noqa: BLE001 - hata UI'ya taşınsın
            self.failed.emit(str(exc))


class OutlookConnectionWorker(CancellableWorker):
    """Outlook bağlantısını ARKA PLANDA kurar.

    Kurumsal Exchange/online-arşiv profillerinde ilk Dispatch saniyeler
    sürebiliyor; UI thread'inde yapılırsa pencere donuk görünür.
    """

    progress = Signal(str, int)
    finished = Signal(object)            # OutlookAccount
    failed = Signal(str)

    def run(self) -> None:
        try:
            from app.mailing.outlook_client import get_default_account

            self.progress.emit("Outlook'a bağlanılıyor…", 30)
            account = get_default_account()
            self.progress.emit("Outlook bağlandı.", 100)
            self.finished.emit(account)
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))


class MailPreviewWorker(CancellableWorker):
    """Tek maili Outlook penceresinde açar (COM çağrısı arka planda).

    ``preview_mail`` kendi ``CoInitialize`` sarmalayıcısını yaptığı için
    arka plan thread'inde güvenlidir.
    """

    progress = Signal(str, int)
    finished = Signal(object)            # önizlenen taslak
    failed = Signal(str)

    def __init__(self, draft) -> None:
        super().__init__()
        self._draft = draft

    def run(self) -> None:
        try:
            from app.mailing.outlook_client import preview_mail

            self.progress.emit("Önizleme açılıyor…", 50)
            preview_mail(self._draft)
            self.progress.emit("Önizleme açıldı.", 100)
            self.finished.emit(self._draft)
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))


class DraftBuildWorker(CancellableWorker):
    """Mail taslaklarını ARKA PLANDA üretir (1/5/6 numaralı akışlar).

    NEDEN BU İŞÇİ VAR
        ``build_drafts`` düğmeye basıldığı anda UI thread'inde çalışıyordu.
        İki ağır yük taşıyor:

          1. firma başına satır gruplama + metin üretimi (saf CPU),
          2. HER ALICI ADRESİ için adres kayıt defteri sorgusu — her biri
             ayrı bir SQLite bağlantısı açıp kapatıyor.

        600 firmalı bir dönemde pencere saniyelerce "yanıt vermiyor"
        oluyordu: ilerleme çubuğu kıpırdamıyor, "Durdur" tıklanamıyordu.
        Sayfanın geri kalanı (önizleme, gönderim, SAP bakiyesi, paket
        üretimi) zaten arka plandaydı; yalnızca bu adım atlanmıştı.

        Taslak üretimi SALT OKUNUR bir işlemdir: mail göndermez, dosya
        yazmaz. Bu yüzden iptal edilmesi güvenlidir, yarım çıktı bırakmaz.
    """

    progress = Signal(str, int)
    finished = Signal(object)            # list[MailDraft]
    failed = Signal(str)

    def __init__(self, rows, config, only_codes=None,
                 address_registry=None) -> None:
        super().__init__()
        self._rows = list(rows or [])
        self._config = config
        self._only_codes = only_codes
        self._address_registry = address_registry

    def run(self) -> None:
        try:
            from app.mailing.mail_builder import build_drafts

            self.progress.emit("Mail taslakları hazırlanıyor…", 20)
            drafts = build_drafts(
                self._rows, self._config,
                only_codes=self._only_codes,
                address_registry=self._address_registry)
            if self.cancelled:
                # İptalde boş liste yayılır; sayfa bunu "gönderilecek mail
                # yok" gibi değil, iptal olarak ele alır (``cancelled``).
                self.progress.emit("İptal edildi.", 0)
                self.finished.emit([])
                return
            self.progress.emit(f"{len(drafts)} taslak hazır.", 100)
            self.finished.emit(drafts)
        except Exception as exc:  # noqa: BLE001 - arayüze bildir, çökme yok
            self.failed.emit(str(exc))


class SapBalanceWorker(CancellableWorker):
    """FBL1H/FBL5H bakiyelerini ARKA PLANDA hesaplar (ekran ve mail için).

    Kullanıcı kararı: **SAP verisi her zaman daha güvenilirdir.** Bu işçi,
    yüklenen SAP dosyalarından firma × para birimi dip bakiyesini çıkarır;
    ekran tablosu ve eksiz mail metni bu değerlerle güncellenir.

    Yön ayrımı DOSYADAN gelir: FBL5H → M, FBL1H → S/X. Bir yönün dosyası
    yüklenmemişse o yön GÜNCELLENMEZ (rapordaki değer korunur ve durum
    'Rapor' olarak işaretlenir) — eksik dosyayı 0 sanmak yanlış mektup
    üretirdi.
    """

    progress = Signal(str, int)
    finished = Signal(object)            # SapBalanceResult
    failed = Signal(str)

    def __init__(self, fbl1h_path: Optional[str], fbl5h_path: Optional[str],
                 report_rows: Sequence[MailRow], token: int = 0) -> None:
        super().__init__()
        self._fbl1h = fbl1h_path
        self._fbl5h = fbl5h_path
        self._rows = list(report_rows)
        self._token = token

    def run(self) -> None:
        try:
            from app.services.company_statement_service import (
                CompanyStatementService,
            )

            svc = CompanyStatementService()

            vendor = customer = None
            if self._fbl1h:
                self.progress.emit("FBL1H (satıcı) okunuyor…", 15)
                vendor = svc.load(self._fbl1h)
            if self.cancelled:
                self.finished.emit(SapBalanceResult(token=self._token))
                return
            if self._fbl5h:
                self.progress.emit("FBL5H (müşteri) okunuyor…", 45)
                customer = svc.load_customer(self._fbl5h)
            if self.cancelled:
                self.finished.emit(SapBalanceResult(token=self._token))
                return

            self.progress.emit("Bakiyeler hesaplanıyor…", 75)
            drafts = svc.merge(vendor, self._rows, fbl5h=customer)

            # Eşlenemeyen müşteri hesapları: hesaplanıyordu ama hiçbir yerde
            # gösterilmiyordu (bkz. unmapped_customer_warning).
            eslenemeyen: dict = {}
            for yukleme in (vendor, customer):
                for hesap, adet in getattr(
                        yukleme, "unmapped_customer_accounts", {}).items():
                    eslenemeyen[hesap] = eslenemeyen.get(hesap, 0) + adet

            balances: dict[str, dict[str, dict[str, Decimal]]] = {}
            missing: dict[str, list[str]] = {}
            for draft in drafts:
                per_direction: dict[str, dict[str, Decimal]] = {}
                for segment in draft.segments:
                    if segment.source_missing:
                        missing.setdefault(draft.company_code, []).append(
                            segment.ms or "?")
                        continue
                    per_direction[segment.ms] = dict(segment.balances)
                if per_direction:
                    balances[draft.company_code] = per_direction

            result = SapBalanceResult(
                balances=balances,
                missing_directions=missing,
                vendor_loaded=vendor is not None,
                customer_loaded=customer is not None,
                company_count=len(balances),
                unmapped_customer_accounts=eslenemeyen,
                token=self._token,
            )
            self.progress.emit(
                f"{result.company_count} firmanın bakiyesi SAP'tan güncellendi.",
                100)
            self.finished.emit(result)
        except Exception as exc:  # noqa: BLE001 - hata UI'ya taşınsın
            self.failed.emit(str(exc))


class PackageBuildWorker(CancellableWorker):
    """FBL1H + FBL5H okur, firma paketlerini (Excel + PDF) üretir."""

    progress = Signal(str, int)          # mesaj, yüzde
    finished = Signal(object)            # list[CompanyMailPackage]
    failed = Signal(str)
    cancelled_signal = Signal(object)    # iptalde üretilmiş paketler

    def __init__(
        self,
        fbl1h_path: Optional[str],
        fbl5h_path: Optional[str],
        report_rows: Sequence[MailRow],
        output_dir: str,
        period: LetterPeriod,
        config: Optional[BuildConfig] = None,
        only_codes: Optional[set[str]] = None,
    ) -> None:
        super().__init__()
        self._fbl1h = fbl1h_path
        self._fbl5h = fbl5h_path
        self._rows = list(report_rows)
        self._output_dir = output_dir
        self._period = period
        self._config = config
        self._only = only_codes

    def run(self) -> None:
        try:
            from app.services.company_package_service import (
                CompanyPackageService,
            )
            from app.services.company_statement_service import (
                CompanyStatementService,
            )

            svc = CompanyStatementService()

            vendor = customer = None
            if self._fbl1h:
                self.progress.emit("FBL1H (satıcı) okunuyor…", 5)
                vendor = svc.load(self._fbl1h)
            if self._fbl5h:
                self.progress.emit("FBL5H (müşteri) okunuyor…", 20)
                customer = svc.load_customer(self._fbl5h)

            # Bir müşteri hesabının sahibi belirsizse o bakiye hiçbir firmaya
            # yazılmaz. Uyarıyla devam etmek, eksik bakiyeli toplu mektup
            # üretme riskini taşır; dosya oluşturmadan önce güvenli şekilde
            # durduruyoruz.
            from app.services.customer_accounts import require_complete_customer_mapping

            unmapped: dict = {}
            for source in (vendor, customer):
                for account, count in getattr(
                        source, "unmapped_customer_accounts", {}).items():
                    unmapped[account] = unmapped.get(account, 0) + count
            require_complete_customer_mapping(unmapped)

            missing = svc.missing_sources(self._rows, vendor, customer)
            if missing:
                self.progress.emit(
                    "Eksik kaynak: " + ", ".join(missing), 25)

            self.progress.emit("Firmalar eşleştiriliyor…", 30)
            drafts = svc.merge(vendor, self._rows, fbl5h=customer)
            if self._only is not None:
                drafts = [d for d in drafts if d.company_code in self._only]

            packager = CompanyPackageService()
            packages: list = []
            total = len(drafts) or 1
            for i, draft in enumerate(drafts, start=1):
                # İptal, bir firmanın dosyaları YAZILMADAN önce kontrol edilir;
                # yarım kalmış Excel/PDF oluşmaz.
                if self.cancelled:
                    self.progress.emit(
                        f"İptal edildi — {len(packages)} firma üretilmişti.",
                        0)
                    self.finished.emit(packages)
                    return
                self.progress.emit(
                    f"{draft.company_code} — ekstre ve mektup üretiliyor "
                    f"({i}/{total})",
                    30 + int(65 * i / total),
                )
                packages.append(packager.build_one(
                    draft, self._output_dir, self._period, self._config))

            self.progress.emit("Paketler hazır.", 100)
            self.finished.emit(packages)
        except Exception as exc:  # noqa: BLE001 - hata UI'ya taşınsın, çökmesin
            self.failed.emit(str(exc))


class MailSendWorker(CancellableWorker):
    """Hazır mail taslaklarını (FAZ1 akışı: 1/5/6 numaralı butonlar) arka
    planda gönderir.

    Toplu gönderim UI thread'inde çalıştığında uygulama yüzlerce mail boyunca
    "yanıt vermiyor" durumuna düşüyordu; bu işçi o donmayı ortadan kaldırır.

    OTL-08 düzeltmesi: bu işçi artık "9) Ekli Mailleri Gönder" (bkz.
    ``PackageSendWorker``) ile AYNI gönderim kapısından geçer
    (``app/services/send_gate.py``) — write-ahead ``SENDING`` kaydı, crash
    sonrası kurtarma, aynı dönemde ikinci kez göndermeme. ``mail_log`` ve
    ``period`` verilmezse (geriye uyum: eski doğrudan çağrılar/testler)
    kuyruk YİNE açılır ve yazar, ama ``MailLog``'a kalıcı günlük yazımı ve
    "zaten gönderilmiş" filtrelemesi atlanır — ``PackageSendWorker``'ın
    dönemsiz çalıştırma sözleşmesiyle BİREBİR aynı davranış.
    """

    progress = Signal(str, int)
    finished = Signal(object)            # (gönderilen, atlananlar)
    failed = Signal(str)

    def __init__(self, drafts: Iterable, *,
                mail_log: Optional[MailLog] = None,
                period: str = "",
                send_queue=None,
                skip_already_sent: bool = True,
                run_id: Optional[str] = None,
                outgoing_smtp: str = "") -> None:
        super().__init__()
        self._drafts = list(drafts)
        # Kurumsal giden hesap (Settings.outgoing_mailbox_smtp); boşsa gerçek
        # gönderim fail-closed engellenir (bkz. outlook_client).
        self._outgoing_smtp = outgoing_smtp
        self._log = mail_log
        self._period = period
        self._queue = send_queue
        self._skip_already_sent = skip_already_sent
        self._run_id = run_id

    def run(self) -> None:
        try:
            from app.mailing.outlook_client import send_with_results
            from app.services.send_queue import QueueUnavailableError, SendQueue

            if not self._drafts:
                self.finished.emit((0, ["Gönderilecek mail yok."]))
                return

            log = self._log
            period = self._period or ""
            atlanan_kayitli: list[str] = []

            # KUYRUK ÖNCE, FAIL-CLOSED: kuyruk açılamıyor / okunamıyorsa
            # HİÇBİR mail gönderilmez (aynı sözleşme, bkz. PackageSendWorker).
            try:
                kuyruk = self._queue or SendQueue()
            except Exception as exc:  # noqa: BLE001
                self.failed.emit(
                    "Gönderim kuyruğu açılamadı; HİÇBİR mail gönderilmedi: "
                    f"{exc}")
                return
            try:
                send_gate.prepare_queue(kuyruk, log, period)
            except QueueUnavailableError as exc:
                self.failed.emit(str(exc))
                return

            # Zaten gönderilmiş firmaları çıkar: mükerrer mutabakat mektubu
            # karşı tarafta karışıklık yaratır ve geri alınamaz.
            drafts = self._drafts
            if log is not None and period and self._skip_already_sent:
                gonderilmis = log.no_resend_codes(period)
                if gonderilmis:
                    onceki = len(drafts)
                    drafts = [d for d in drafts if d.code not in gonderilmis]
                    atlanan = onceki - len(drafts)
                    if atlanan:
                        atlanan_kayitli.append(
                            f"{atlanan} firma bu dönemde ZATEN gönderilmiş, "
                            "tekrar gönderilmedi.")
                        self.progress.emit(
                            f"{atlanan} firma zaten gönderilmiş, atlandı.", 5)

            if not drafts:
                self.finished.emit(
                    (0, atlanan_kayitli or ["Gönderilecek mail yok."]))
                return

            toplam = len(drafts)
            self.progress.emit(f"{toplam} mail gönderiliyor…", 10)

            # KALICI KUYRUK: gönderim GUI döngüsünden değil, diske yazılmış
            # bir kuyruktan ilerler (bkz. PackageSendWorker ile aynı mantık).
            kuyruk_kimlikleri = send_gate.enqueue_drafts(
                kuyruk, drafts, period, run_id=self._run_id or "")

            engellenen: set[str] = set()
            zorla = (not self._skip_already_sent) or (not period)
            gonderim_oncesi = send_gate.make_before_send(
                kuyruk, kuyruk_kimlikleri, engellenen, force=zorla)
            sonuc_geldi = send_gate.make_result_sink(
                kuyruk, kuyruk_kimlikleri, engellenen)

            def ilerleme(i: int, total: int, code: str) -> None:
                self.progress.emit(f"{code} ({i}/{total})",
                                   10 + int(85 * i / total))

            results = send_with_results(
                drafts, on_progress=ilerleme,
                should_cancel=lambda: self.cancelled,
                on_result=sonuc_geldi,
                on_before_send=gonderim_oncesi,
                outgoing_smtp=self._outgoing_smtp)

            if log is not None and period:
                drafts_by_code = {d.code: d for d in drafts}
                send_gate.record_results(log, period, results,
                                         drafts_by_code, run_id=self._run_id)
                send_gate.verify_identities(log, period, results)
                send_gate.complete_missing_ids(log, period, results)

            sent = sum(1 for r in results if r.sent)
            belirsiz = [r for r in results if getattr(r, "unknown", False)]
            skipped = ([f"{r.code}: {r.reason}" for r in results if not r.sent]
                      + atlanan_kayitli)
            if belirsiz:
                # Kullanıcı bunu ÖZETTE görmeli: bu firmalara mail gitmiş
                # OLABİLİR ve sistem otomatik olarak tekrar göndermeyecek.
                skipped.insert(0, (
                    f"{len(belirsiz)} mailin sonucu BELİRSİZ (gitmiş olabilir). "
                    "Mükerrer mektup riskine karşı tekrar gönderilmedi; "
                    "Gönderilmiş Öğeler'den kontrol edin."))
            kalan = toplam - len(results)
            if kalan:
                skipped.append(
                    f"{kalan} mail İPTAL nedeniyle gönderilmedi. "
                    "Tekrar çalıştırdığınızda kaldığı yerden devam eder.")
            self.progress.emit(
                "İptal edildi." if self.cancelled else "Gönderim tamamlandı.",
                100)
            self.finished.emit((sent, skipped))
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))


class PackageSendWorker(CancellableWorker):
    """Hazır paketleri Outlook üzerinden gönderir ve HER SONUCU günlüğe yazar.

    Günlük iki işi yapar: aynı dönemde aynı firmaya ikinci kez gönderimi
    engeller ve yarıda kalan bir gönderimin kaldığı yerden sürdürülmesini
    sağlar (3000 firmada kritik).
    """

    progress = Signal(str, int)
    finished = Signal(object)            # (gönderilen, atlananlar)
    failed = Signal(str)

    def __init__(
        self,
        packages: Iterable[CompanyMailPackage],
        period: Optional[LetterPeriod] = None,
        mail_log: Optional[MailLog] = None,
        skip_already_sent: bool = True,
        run_id: Optional[str] = None,
        snapshot_store=None,
        fbl1h_path: Optional[str] = None,
        fbl5h_path: Optional[str] = None,
        send_queue=None,
        outgoing_smtp: str = "",
    ) -> None:
        super().__init__()
        self._packages = list(packages)
        # Kurumsal giden hesap (Settings.outgoing_mailbox_smtp); boşsa gerçek
        # gönderim fail-closed engellenir (bkz. outlook_client).
        self._outgoing_smtp = outgoing_smtp
        # Kalıcı gönderim kuyruğu (madde 6). Verilmezse ilk ihtiyaçta açılır.
        self._queue = send_queue
        self._period = period
        self._log = mail_log
        self._skip_already_sent = skip_already_sent
        self._run_id = run_id
        # Gönderim anının değişmez hafızası. Verilmezse snapshot alınmaz ve
        # gönderim normal çalışır (geriye dönük uyum) — ancak o gönderimin
        # cevabı sonradan yalnızca genel dosyayla karşılaştırılabilir.
        self._snapshots = snapshot_store
        self._fbl1h_path = fbl1h_path
        self._fbl5h_path = fbl5h_path

    def run(self) -> None:
        try:
            from app.mailing.outlook_client import send_with_results
            from app.services.company_package_service import (
                CompanyPackageService,
            )

            packages = {p.company_code: p for p in self._packages}
            drafts = CompanyPackageService.sendable(self._packages)

            log = self._log
            period = (period_key(self._period.year, self._period.month)
                      if self._period else "")
            atlanan_kayitli: list[str] = []

            # KUYRUK ÖNCE, FAIL-CLOSED: kuyruk açılamıyor / okunamıyorsa HİÇBİR
            # mail gönderilmez. Önceki çalıştırmada yarım kalan işler geri
            # alınır ve kuyruğun bildiği "gitti / gitmiş olabilir" bilgisi
            # tekrar-gönderim kapısına (MailLog) yansıtılır.
            kuyruk = self._kuyruk_hazirla(log, period)

            # Zaten gönderilmiş firmaları çıkar: mükerrer mutabakat mektubu
            # karşı tarafta karışıklık yaratır ve geri alınamaz.
            if log is not None and period and self._skip_already_sent:
                # SENT ∪ SEND_UNKNOWN: sonucu belirsiz kalan gönderim de
                # tekrar denenmez (mail gitmiş olabilir).
                gonderilmis = log.no_resend_codes(period)
                if gonderilmis:
                    onceki = len(drafts)
                    drafts = [d for d in drafts if d.code not in gonderilmis]
                    atlanan = onceki - len(drafts)
                    if atlanan:
                        atlanan_kayitli.append(
                            f"{atlanan} firma bu dönemde ZATEN gönderilmiş, "
                            "tekrar gönderilmedi.")
                        self.progress.emit(
                            f"{atlanan} firma zaten gönderilmiş, atlandı.", 5)

            if not drafts:
                self.finished.emit(
                    (0, atlanan_kayitli or ["Gönderilebilecek mail yok."]))
                return

            toplam = len(drafts)

            # GÖNDERİMDEN ÖNCE snapshot: mail çıktıktan sonra kaynak dosya
            # değişse/silinse bile "bu firmaya ne gönderildi?" sorusu
            # cevaplanabilir olmalı. Snapshot alınamazsa gönderim DURMAZ.
            self.progress.emit("Gönderim snapshot'ı alınıyor…", 8)
            snapshots = self._create_snapshots(
                [packages[d.code] for d in drafts if d.code in packages],
                period)

            # KALICI KUYRUK: gönderim GUI döngüsünden değil, diske yazılmış
            # bir kuyruktan ilerler. Uygulama ortada kapanırsa "hangisi
            # gitti?" bilgisi kaybolmaz ve kalınan yerden devam edilir.
            kuyruk_kimlikleri = self._kuyruga_al(kuyruk, drafts, packages,
                                                 period)

            self.progress.emit(f"{toplam} mail gönderiliyor…", 10)

            def ilerleme(i: int, total: int, code: str) -> None:
                self.progress.emit(f"{code} gönderildi ({i}/{total})",
                                   10 + int(85 * i / total))

            engellenen: set[str] = set()
            # Bilinçli "tekrar gönder" (skip_already_sent=False) ya da dönemsiz
            # çalıştırma (tekrar-kapısının kimliği yok): eski davranış korunur,
            # ama SENDING yazımı YİNE zorunludur.
            zorla = (not self._skip_already_sent) or (not period)

            # Paylaşılan gönderim kapısı (OTL-08): "9" ve "1/5/6" aynı
            # fonksiyonları çağırır, bkz. app/services/send_gate.py.
            gonderim_oncesi = send_gate.make_before_send(
                kuyruk, kuyruk_kimlikleri, engellenen, force=zorla)
            sonuc_geldi = send_gate.make_result_sink(
                kuyruk, kuyruk_kimlikleri, engellenen)

            results = send_with_results(
                drafts, on_progress=ilerleme,
                should_cancel=lambda: self.cancelled,
                on_result=sonuc_geldi,
                on_before_send=gonderim_oncesi,
                outgoing_smtp=self._outgoing_smtp)

            # Her sonuç ANINDA günlüğe yazılır; süreç yarıda kesilse bile
            # o ana kadar gidenler kayıtlıdır.
            # Snapshot, gönderim sonucuyla mühürlenir: kimlikler ve gerçek
            # gönderim zamanı yalnızca send_id ile yazılır (firma+dönem ile
            # DEĞİL) — aynı dönemdeki ikinci gönderim birincisini ezmez.
            self._seal_snapshots(snapshots, results)

            if log is not None and period:
                drafts_by_code = {d.code: d for d in drafts}
                meta_by_code = {
                    code: {"company_name": p.company_name,
                           "directions": list(p.directions)}
                    for code, p in packages.items()}
                # Paylaşılan gönderim kapısı (OTL-08): aynı fonksiyon "1/5/6"
                # tarafından da çağrılır, bkz. app/services/send_gate.py.
                send_gate.record_results(
                    log, period, results, drafts_by_code,
                    meta_by_code=meta_by_code, run_id=self._run_id,
                    snapshots=snapshots)

                # GÖNDERİM SONRASI KESİN DOĞRULAMA
                #
                # Gönderim anında okunan kimlikler TASLAĞA aittir: öğe
                # Gönderilmiş Öğeler'e taşınınca EntryID değişir,
                # InternetMessageID ise çoğu zaman henüz doğmamıştır. Bu
                # yüzden üç kimlik de gönderilmiş öğeden YENİDEN okunur ve
                # kaydedilir; hatırlatma böylece yanlış/eski bir zincire
                # bağlanamaz.
                self._dogrula_kimlikleri(log, period, results, snapshots,
                                         self._snapshots)

            sent = sum(1 for r in results if r.sent)
            belirsiz = [r for r in results if getattr(r, "unknown", False)]
            skipped = ([f"{r.code}: {r.reason}" for r in results if not r.sent]
                       + atlanan_kayitli)
            if belirsiz:
                # Kullanıcı bunu ÖZETTE görmeli: bu firmalara mail gitmiş
                # OLABİLİR ve sistem otomatik olarak tekrar göndermeyecek.
                skipped.insert(0, (
                    f"{len(belirsiz)} mailin sonucu BELİRSİZ (gitmiş olabilir). "
                    "Mükerrer mektup riskine karşı tekrar gönderilmedi; "
                    "Gönderilmiş Öğeler'den kontrol edin."))
            kalan = toplam - len(results)
            if kalan:
                skipped.append(
                    f"{kalan} mail İPTAL nedeniyle gönderilmedi. "
                    "Tekrar çalıştırdığınızda kaldığı yerden devam eder.")
            self.progress.emit(
                "İptal edildi." if self.cancelled else "Gönderim tamamlandı.",
                100)
            self.finished.emit((sent, skipped))
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))

    # -- kalıcı kuyruk ------------------------------------------------------

    def _kuyruk_hazirla(self, log, period: str):
        """Kuyruğu aç, yarım işleri geri al, kuyruk gerçeğini MailLog'a yansıt.

        FAIL-CLOSED: kuyruk açılamaz ya da kurtarma durumu okunamazsa
        ``QueueUnavailableError`` yükselir ve HİÇBİR mail gönderilmez.

        Kurtarma mantığı paylaşılan ``send_gate.prepare_queue``'dadır (OTL-08:
        "1/5/6" yolu da AYNI fonksiyonu çağırır).
        """
        from app.services.send_queue import QueueUnavailableError, SendQueue

        try:
            kuyruk = self._queue or SendQueue()
        except Exception as exc:  # noqa: BLE001
            raise QueueUnavailableError(
                f"Gönderim kuyruğu açılamadı; HİÇBİR mail gönderilmedi: {exc}"
            ) from exc
        meta_by_code = {p.company_code: {"company_name": p.company_name}
                        for p in self._packages}
        send_gate.prepare_queue(kuyruk, log, period, meta_by_code=meta_by_code)
        return kuyruk

    def _kuyruga_al(self, kuyruk, drafts, packages, period: str):
        """Gönderilecek taslakları kalıcı kuyruğa yaz (bkz.
        ``send_gate.enqueue_drafts`` — paylaşılan uygulama)."""
        return send_gate.enqueue_drafts(kuyruk, drafts, period,
                                        run_id=self._run_id or "")

    # -- snapshot ----------------------------------------------------------

    def _create_snapshots(self, packages: Sequence[CompanyMailPackage],
                          period: str) -> dict:
        """Gönderilecek her paket için PENDING snapshot üret.

        Döner: ``{firma_kodu: SentReconciliationSnapshot}``. Depo verilmemişse
        ya da bir firma için snapshot alınamazsa o firma sözlükte YER ALMAZ;
        gönderim yine yapılır ama bu durum loglanır (sessizce "alındı"
        denmez).
        """
        store = self._snapshots
        if store is None or not packages:
            return {}
        created: dict = {}
        for package in packages:
            draft = package.draft
            snapshot = store.create(
                company_code=package.company_code,
                company_name=package.company_name,
                period=period,
                run_id=self._run_id,
                responsible=getattr(draft, "responsible", "") if draft else "",
                recipients=list(draft.to) if draft else [],
                cc=list(draft.cc) if draft else [],
                subject=draft.subject if draft else "",
                body=draft.body if draft else "",
                locale=package.locale,
                directions=list(package.directions),
                fbl1h_path=self._fbl1h_path,
                fbl5h_path=self._fbl5h_path,
                attachments=list(package.attachments),
                records=getattr(package, "snapshot_records", None),
            )
            if snapshot is None:
                logger.error(
                    f"[snapshot] {package.company_code} için gönderim "
                    "snapshot'ı alınamadı; cevap sonradan yalnızca güncel "
                    "dosyayla karşılaştırılabilecek.")
                continue
            created[package.company_code] = snapshot
        return created

    def _seal_snapshots(self, snapshots: dict, results) -> None:
        """Gönderim sonucunu snapshot'a işle (yalnızca takip alanları)."""
        store = self._snapshots
        if store is None or not snapshots:
            return
        from app.services.send_snapshot import (
            SNAPSHOT_FAILED,
            SNAPSHOT_SENT,
            SNAPSHOT_SKIPPED,
            SNAPSHOT_UNKNOWN,
        )

        durum = {"SENT": SNAPSHOT_SENT, "FAILED": SNAPSHOT_FAILED,
                 "SEND_UNKNOWN": SNAPSHOT_UNKNOWN}
        for r in results:
            snapshot = snapshots.get(r.code)
            if snapshot is None:
                continue
            try:
                store.mark_sent(
                    snapshot.send_id,
                    status=durum.get(r.status, SNAPSHOT_SKIPPED),
                    message_id=getattr(r, "message_id", ""),
                    conversation_id=getattr(r, "conversation_id", ""),
                )
            except Exception as exc:  # noqa: BLE001 - kayıt maili bozmaz
                logger.warning(
                    f"[snapshot] {r.code} sonucu işlenemedi: {exc}")

    @staticmethod
    def _dogrula_kimlikleri(log, period: str, results,
                            snapshots: Optional[dict] = None,
                            store=None, folder=None) -> None:
        """Bkz. ``send_gate.verify_identities`` (paylaşılan uygulama; bu
        isim eski çağrı yerleri/testler için geriye uyumlu olarak kalır)."""
        send_gate.verify_identities(log, period, results,
                                    snapshots=snapshots, store=store,
                                    folder=folder)

    @staticmethod
    def _tamamla_eksik_kimlikler(log, period: str, results,
                                 snapshots: Optional[dict] = None,
                                 store=None) -> None:
        """Bkz. ``send_gate.complete_missing_ids`` (paylaşılan uygulama; bu
        isim eski çağrı yerleri/testler için geriye uyumlu olarak kalır)."""
        send_gate.complete_missing_ids(log, period, results,
                                       snapshots=snapshots, store=store)


def _mail_status_of(result) -> str:
    """Bkz. ``send_gate._mail_status_of`` (paylaşılan uygulama)."""
    return send_gate._mail_status_of(result)


def codes_of(rows: Iterable[MailRow]) -> set[str]:
    """Rapor satırlarındaki normalize firma kodları."""
    return {normalize_code(r.code_raw) for r in rows if normalize_code(r.code_raw)}
