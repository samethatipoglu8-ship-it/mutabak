"""Direct Line yapılandırmasının tek kaynağı (secret ASLA koda gömülmez).

ÇÖZÜMLEME SIRASI
    1. Açık çalışma-zamanı override'ı (yalnızca kontrollü entegrasyon/test)
    2. Ortam değişkenleri  (DIRECT_LINE_SECRET, DIRECT_LINE_ENDPOINT, …)
    3. Proje kökündeki ``.env`` dosyası (yalnızca yerel geliştirme)
    4. Kod içi güvenli varsayılanlar

Yer tutucu değerler ("BURAYA_DIRECT_LINE_SECRET_GELECEK") DOLU sayılmaz;
sistem "secret yok" der, uydurma bir değerle çağrı denemez.

``.env`` desteği harici bağımlılık kullanmaz (python-dotenv gerekmez).
"""

from __future__ import annotations

import os
import threading
from pathlib import Path
from typing import Any, Optional

from app.incoming.direct_line_client import (
    DEFAULT_ENDPOINT,
    DirectLineConfig,
    is_placeholder,
)
from app.utils.paths import resolved_env_path

ENV_SECRET = "DIRECT_LINE_SECRET"
ENV_ENDPOINT = "DIRECT_LINE_ENDPOINT"
ENV_ENABLED = "DIRECT_LINE_ENABLED"
ENV_POLL_TIMEOUT = "DIRECT_LINE_POLL_TIMEOUT"
ENV_MAX_RETRIES = "DIRECT_LINE_MAX_RETRIES"
ENV_USER_ID = "DIRECT_LINE_USER_ID"

# Paketlenmiş .exe yanında bir .env varsa ONU, yoksa gömülü (_internal veya
# geliştirme kökü) konumunu kullanır (bkz. mimari inceleme bulgusu).
DEFAULT_ENV_FILE = resolved_env_path()

_lock = threading.Lock()
_overrides: dict[str, Any] = {}
# .env önbelleği için AYRI kilit. ``_lock`` yeniden girişli değildir ve
# current_config() onu bırakmadan _lookup() çağıracak biçimde
# değiştirilirse aynı kilit kilitlenmeye yol açardı; önbellek durumu
# yalnızca load_env_file() içinde okunup yazıldığı için kendi kilidini alır.
_env_lock = threading.Lock()
_env_file_cache: Optional[dict[str, str]] = None
_env_file_path: Optional[Path] = None


def load_env_file(path: str | Path | None = None,
                  force: bool = False) -> dict[str, str]:
    """``.env`` dosyasını oku (KEY=VALUE). Dosya yoksa boş sözlük.

    Yorum satırları (#), tırnaklar ve ``export`` ön eki desteklenir. Dosya
    bir kez okunup önbelleklenir; ``force=True`` ile tazelenir.
    """
    global _env_file_cache, _env_file_path

    target = Path(path) if path else DEFAULT_ENV_FILE
    # Önbellek okuma/yazması KİLİT ALTINDA: iki thread aynı anda farklı
    # yollarla çağırırsa cache ile path birbirinden kopabiliyor ve
    # yanlış dosyanın değerleri dönebiliyordu.
    with _env_lock:
        if (not force and _env_file_cache is not None
                and _env_file_path == target):
            return dict(_env_file_cache)
        return dict(_read_env_file_locked(target))


def _read_env_file_locked(target: Path) -> dict[str, str]:
    """``.env`` içeriğini oku ve önbelleğe yaz. ``_env_lock`` TUTULUYOR olmalı."""
    global _env_file_cache, _env_file_path

    values: dict[str, str] = {}
    try:
        if target.is_file():
            for raw_line in target.read_text(encoding="utf-8").splitlines():
                line = raw_line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                if line.lower().startswith("export "):
                    line = line[7:].strip()
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip()
                # SATIR İÇİ YORUM: `SECRET=abc  # üretim anahtarı`
                # Yorum ayıklanmazsa secret'ın SONUNA yapışır ve kimlik
                # doğrulama sessizce başarısız olur. Yalnızca TIRNAKSIZ
                # değerlerde ayıklanır — tırnak içindeki '#' veriye aittir.
                if value[:1] not in ('"', "'") and "#" in value:
                    value = value.split("#", 1)[0].strip()
                value = value.strip('"').strip("'")
                if key:
                    values[key] = value
    except OSError:
        # .env okunamazsa yapılandırma çökmez; ortam değişkenlerine düşülür.
        values = {}

    _env_file_cache = values
    _env_file_path = target
    return values


def _lookup(name: str) -> Optional[str]:
    """Ortam değişkeni → .env sırasıyla ara."""
    value = os.environ.get(name)
    if value is not None and value.strip():
        return value.strip()
    file_value = load_env_file().get(name)
    if file_value is not None and file_value.strip():
        return file_value.strip()
    return None


def _as_bool(value: Any, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    token = str(value).strip().lower()
    if token in {"1", "true", "yes", "on", "evet", "acik", "açık"}:
        return True
    if token in {"0", "false", "no", "off", "hayir", "hayır", "kapali", "kapalı"}:
        return False
    return default


def _as_float(value: Any, default: float) -> float:
    try:
        return float(str(value).replace(",", "."))
    except (TypeError, ValueError):
        return default


def _as_int(value: Any, default: int) -> int:
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return default


def configure(secret: Optional[str] = None,
              endpoint: Optional[str] = None,
              enabled: Optional[bool] = None,
              **extra: Any) -> None:
    """Açık çalışma-zamanı override'larını uygula.

    Normal uygulama açılışı bu fonksiyona secret vermez; secret yalnızca
    ortam/.env zincirinden gelir. Yer tutucular yok sayılır; böylece test
    ve kontrollü entegrasyonlarda da sistem uydurma bir değerle çağrı
    denemez.
    """
    with _lock:
        if secret is not None and not is_placeholder(secret):
            _overrides["secret"] = str(secret).strip()
        if endpoint is not None and not is_placeholder(endpoint):
            _overrides["endpoint"] = str(endpoint).strip()
        if enabled is not None:
            _overrides["enabled"] = bool(enabled)
        for key, value in extra.items():
            if value is not None:
                _overrides[key] = value


def reset() -> None:
    """Test/yeniden yapılandırma için tüm override'ları temizle."""
    global _env_file_cache, _env_file_path
    with _lock:
        _overrides.clear()
        _env_file_cache = None
        _env_file_path = None


def current_config() -> DirectLineConfig:
    """Geçerli Direct Line yapılandırmasını üret (her çağrıda taze nesne)."""
    with _lock:
        overrides = dict(_overrides)

    secret = overrides.get("secret") or _lookup(ENV_SECRET) or ""
    if is_placeholder(secret):
        secret = ""

    endpoint = overrides.get("endpoint") or _lookup(ENV_ENDPOINT) or DEFAULT_ENDPOINT
    if is_placeholder(endpoint):
        endpoint = DEFAULT_ENDPOINT

    enabled = overrides.get("enabled")
    if enabled is None:
        enabled = _as_bool(_lookup(ENV_ENABLED), True)

    config = DirectLineConfig(
        secret=secret,
        endpoint=endpoint,
        enabled=bool(enabled),
    )

    poll_timeout = overrides.get("poll_timeout", _lookup(ENV_POLL_TIMEOUT))
    if poll_timeout is not None:
        config.poll_timeout = _as_float(poll_timeout, config.poll_timeout)

    max_retries = overrides.get("max_retries", _lookup(ENV_MAX_RETRIES))
    if max_retries is not None:
        config.max_retries = max(1, _as_int(max_retries, config.max_retries))

    user_id = overrides.get("user_id", _lookup(ENV_USER_ID))
    if user_id:
        config.user_id = str(user_id)

    for key in ("connect_timeout", "read_timeout", "poll_interval",
                "backoff_base", "backoff_max", "locale"):
        if key in overrides:
            setattr(config, key, overrides[key])

    return config


def status_line() -> str:
    """Kullanıcıya gösterilebilir tek satırlık durum (secret GÖSTERİLMEZ)."""
    config = current_config()
    if not config.enabled:
        return "Direct Line: KAPALI (DIRECT_LINE_ENABLED = False)"
    if not config.configured:
        return ("Direct Line: secret girilmemiş — AI fallback devre dışı, "
                "belirsiz mailler insan incelemesine düşer.")
    return f"Direct Line: hazır ({config.base_url})"
