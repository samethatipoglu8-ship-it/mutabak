"""FAZ 11 — fark bulunduğunda hazırlanan cevap maili (§12).

NE ZAMAN
    Ekstre karşılaştırmasında fark çıktığında robot, firmadan eksik/uyuşmayan
    belgeleri isteyen bir mail HAZIRLAR. Mail kendiliğinden GİTMEZ: kullanıcı
    önizler ve "Gönder" derse thread üzerinden Reply-All olarak iletilir.

DİL FİRMA KODUNDAN GELİR
    2 ile başlayan kod -> Türkçe, 4 ile başlayan kod -> İngilizce
    (mevcut ``classify_locale`` kuralı; yeni bir dil kuralı YAZILMAZ).
    Dil belirlenemiyorsa mail HAZIRLANMAZ — yanlış dilde bir fark talebi
    karşı tarafta karışıklık yaratır ve geri alınamaz.

TABLO UYDURULMAZ
    Fark tablosu yalnızca motorun ürettiği kayıtlardan doldurulur: firmanın
    ekstresinde olup bizim kayıtlarımızda bulunmayan satırlar. Tutar, tarih,
    belge no ve para birimi kaynaktan gelir; hiçbir alan tahmin edilmez.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Optional, Sequence

from app.mailing.mail_builder import classify_locale, fmt_amount_tr

# Tablo başlıkları (dil bazlı).
_HEADERS = {
    "tr": ("Belge / Fatura No", "Tarih", "Tutar", "Para Birimi", "Açıklama"),
    "en": ("Document / Invoice No", "Date", "Amount", "Currency", "Description"),
}

_INTRO = {
    "tr": ("Merhaba,\n\n"
           "Yapılan mutabakat kontrolünde aşağıdaki kayıtların TOFAŞ "
           "kayıtlarında bulunmadığı/uyuşmadığı tespit edilmiştir.\n\n"
           "Aşağıdaki fark oluşturan faturaları ve ilgili belgeleri "
           "paylaşabilir misiniz?\n"),
    "en": ("Dear,\n\n"
           "As a result of our reconciliation check, the below "
           "invoices/records appear to be missing or unmatched in our "
           "records.\n\n"
           "May you please share the below invoices and related documents?\n"),
}

_OUTRO = {
    "tr": "\nTeşekkürler,\nİyi çalışmalar.",
    "en": "\nKind regards,",
}

_TOTAL_LABEL = {"tr": "Toplam fark", "en": "Total difference"}
_NO_ROW = {
    "tr": ("(Fark oluşturan satırlar ekli ekstrede listelenmiştir; "
           "tutar farkı aşağıda özetlenmiştir.)"),
    "en": ("(The differing lines are listed in the attached statement; "
           "the amount difference is summarised below.)"),
}

# Tabloya en fazla kaç satır yazılır (mail okunabilir kalsın).
MAX_ROWS = 40


@dataclass
class DifferenceRow:
    """Fark tablosunun tek satırı — tamamı kaynaktan gelir."""

    reference: str = ""
    date: str = ""
    amount: Decimal = Decimal("0")
    currency: str = ""
    description: str = ""

    def cells(self) -> tuple[str, str, str, str, str]:
        return (self.reference or "—",
                self.date or "—",
                fmt_amount_tr(self.amount),
                self.currency or "—",
                (self.description or "")[:60])


@dataclass
class DifferenceMail:
    """Hazırlanan fark maili (henüz GÖNDERİLMEDİ)."""

    locale: str = ""
    subject: str = ""
    body: str = ""
    rows: list[DifferenceRow] = field(default_factory=list)
    total_difference: Decimal = Decimal("0")
    currency: str = ""
    truncated: int = 0
    blocked_reason: str = ""
    # Ekran tarafından doldurulur (gönderim için kimlik).
    case_id: str = ""
    company_code: str = ""
    company_name: str = ""
    conversation_id: str = ""
    message_id: str = ""
    attachments: list[str] = field(default_factory=list)

    @property
    def ready(self) -> bool:
        return not self.blocked_reason and bool(self.body.strip())


def reply_subject(original: str) -> str:
    """Thread üzerinden devam eden konu (RE: iki kez eklenmez)."""
    subject = (original or "").strip()
    if not subject:
        return "RE:"
    if subject[:3].upper() in ("RE:", "RE "):
        return subject
    return f"RE: {subject}"


def rows_from_result(engine_result: Any, limit: int = MAX_ROWS
                     ) -> tuple[list[DifferenceRow], int]:
    """Motor sonucundan «yalnız firmada olan» satırları çıkar.

    Bunlar firmanın bize gönderdiği ama bizim kayıtlarımızda bulunmayan
    kalemlerdir — fark talebinin konusu tam olarak budur.
    """
    if engine_result is None:
        return [], 0
    kayitlar = list(getattr(engine_result, "only_firma", []) or [])
    rows: list[DifferenceRow] = []
    for record in kayitlar[:limit]:
        tarih = getattr(record, "inv_date", None)
        rows.append(DifferenceRow(
            reference=str(getattr(record, "reference_raw", "")
                          or getattr(record, "reference", "") or ""),
            date=tarih.strftime("%d.%m.%Y") if tarih else "",
            amount=getattr(record, "amount", Decimal("0")) or Decimal("0"),
            currency=str(getattr(record, "currency", "") or ""),
            description=str(getattr(record, "comment", "") or ""),
        ))
    return rows, max(0, len(kayitlar) - len(rows))


def _table(rows: Sequence[DifferenceRow], locale: str) -> str:
    """Sabit genişlikli metin tablosu (mail istemcilerinde bozulmaz)."""
    headers = _HEADERS.get(locale, _HEADERS["en"])
    satirlar = [r.cells() for r in rows]
    genislik = [len(h) for h in headers]
    for cells in satirlar:
        for i, cell in enumerate(cells):
            genislik[i] = max(genislik[i], len(cell))

    def line(cells: Sequence[str]) -> str:
        return "  ".join(cell.ljust(genislik[i]) for i, cell in enumerate(cells))

    out = [line(headers), "  ".join("-" * w for w in genislik)]
    out.extend(line(cells) for cells in satirlar)
    return "\n".join(out)


def rows_from_dicts(rows: Sequence[dict], limit: int = MAX_ROWS
                    ) -> tuple[list[DifferenceRow], int]:
    """Kayıtlı özetten (JSON) fark satırlarını kur."""
    out: list[DifferenceRow] = []
    for row in list(rows or [])[:limit]:
        try:
            tutar = Decimal(str(row.get("amount") or "0"))
        except Exception:  # noqa: BLE001 - bozuk kayıt tabloyu düşürmez
            tutar = Decimal("0")
        out.append(DifferenceRow(
            reference=str(row.get("reference") or ""),
            date=str(row.get("date") or ""),
            amount=tutar,
            currency=str(row.get("currency") or ""),
            description=str(row.get("description") or ""),
        ))
    return out, max(0, len(rows or []) - len(out))


def build_difference_mail(
    *,
    company_code: str,
    original_subject: str,
    engine_result: Any = None,
    stored_rows: Optional[Sequence[dict]] = None,
    total_difference: Decimal = Decimal("0"),
    currency: str = "",
    limit: int = MAX_ROWS,
) -> DifferenceMail:
    """Fark talebi mailini hazırla (gönderme YOK)."""
    locale = classify_locale(company_code or "")
    mail = DifferenceMail(locale=locale,
                          subject=reply_subject(original_subject),
                          total_difference=total_difference or Decimal("0"),
                          currency=currency or "")

    if locale not in ("tr", "en"):
        mail.blocked_reason = (
            f"Firma kodu '{company_code}' 2/4 ile başlamıyor; mail dili "
            "belirlenemedi, fark maili hazırlanmadı.")
        return mail

    if stored_rows:
        rows, truncated = rows_from_dicts(stored_rows, limit)
    else:
        rows, truncated = rows_from_result(engine_result, limit)
    mail.rows = rows
    mail.truncated = truncated

    parcalar = [_INTRO[locale]]
    if rows:
        parcalar.append("\n" + _table(rows, locale) + "\n")
        if truncated:
            parcalar.append(
                f"… (+{truncated} " +
                ("satır daha)" if locale == "tr" else "more rows)") + "\n")
    else:
        parcalar.append("\n" + _NO_ROW[locale] + "\n")

    if mail.total_difference:
        parcalar.append(
            f"\n{_TOTAL_LABEL[locale]}: "
            f"{fmt_amount_tr(mail.total_difference)} {mail.currency}".rstrip()
            + "\n")
    parcalar.append(_OUTRO[locale])
    mail.body = "".join(parcalar)
    return mail


def build_from_comparison(case: Any, comparison: Any,
                          limit: int = MAX_ROWS) -> DifferenceMail:
    """Karşılaştırma sonucundan doğrudan fark maili üret."""
    statement = getattr(comparison, "statement", None)
    analysis = getattr(statement, "analysis", None) if statement else None
    kayitli = (getattr(case, "statement_result", None) or {}).get(
        "only_firma_rows")
    return build_difference_mail(
        company_code=getattr(case, "company_code", ""),
        original_subject=getattr(case, "subject", ""),
        engine_result=getattr(statement, "engine_result", None),
        stored_rows=kayitli,
        total_difference=getattr(analysis, "difference", Decimal("0"))
        if analysis else Decimal("0"),
        currency=getattr(analysis, "currency", "") if analysis else "",
        limit=limit,
    )
