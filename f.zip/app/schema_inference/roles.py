"""FAZ 6 — generic semantic role taxonomy for schema inference.

Bu roller YALNIZCA ``app.schema_inference`` içinde ADAY üretimi/skorlama için
kullanılır. Hiçbiri ``app.core.reconciler`` matching kararına BAĞLANMADI ve
bu fazda bağlanmayacak (bkz. doc 20 §"Backward compatibility").
"""

from __future__ import annotations

from enum import Enum


class SemanticRole(str, Enum):
    TRANSACTION_DATE = "transaction_date"
    POSTING_DATE = "posting_date"
    DUE_DATE = "due_date"
    DOCUMENT_NUMBER = "document_number"
    EXTERNAL_DOCUMENT_NUMBER = "external_document_number"
    REFERENCE = "reference"
    DESCRIPTION = "description"
    DOCUMENT_TYPE = "document_type"
    COUNTERPARTY_CODE = "counterparty_code"
    COUNTERPARTY_NAME = "counterparty_name"
    COUNTERPARTY_TAX_ID = "counterparty_tax_id"
    DEBIT = "debit"
    CREDIT = "credit"
    SIGNED_AMOUNT = "signed_amount"
    BALANCE = "balance"
    DOCUMENT_AMOUNT = "document_amount"
    DOCUMENT_CURRENCY = "document_currency"
    LOCAL_CURRENCY_AMOUNT = "local_currency_amount"
    LOCAL_CURRENCY = "local_currency"
    GROSS_AMOUNT = "gross_amount"
    NET_AMOUNT = "net_amount"
    WITHHOLDING_AMOUNT = "withholding_amount"
    OPEN_AMOUNT = "open_amount"
    IS_OPEN = "is_open"
    CLEARING_REFERENCE = "clearing_reference"
    CLEARING_DATE = "clearing_date"
    SPECIAL_GL_INDICATOR = "special_gl_indicator"
    ADVANCE_INDICATOR = "advance_indicator"
    OPENING_BALANCE_INDICATOR = "opening_balance_indicator"


class RoleImplementationStatus(str, Enum):
    #: Bu fazda gerçek bir skorlama fonksiyonu VAR (dormant, advisory).
    IMPLEMENT_NOW = "implement_now"
    #: Tasarlandı, kod YOK.
    DESIGN_ONLY = "design_only"
    #: Gerçek bir ERP export örneği görülmeden güvenle skorlanamaz/anlamlandırılamaz.
    NEEDS_REAL_SAMPLE = "needs_real_sample"
    #: Alanın VARLIĞI sorun değil; nasıl YORUMLANACAĞI/kullanılacağı finans kararı gerektirir.
    FINANCE_DECISION_REQUIRED = "finance_decision_required"
    #: Kalıcı yasak DEĞİL — bugünkü FAZ 2 karakterizasyon testi nedeniyle
    #: ertelendi (doc 19 §21, bu fazın kullanıcı talimatıyla NETLEŞTİRİLDİ).
    DEFERRED_MIGRATION_CANDIDATE = "deferred_migration_candidate"


#: Her rolün bu fazdaki durumu + kısa gerekçe. Rapor §7'de de kullanılır.
ROLE_STATUS: dict[SemanticRole, tuple[RoleImplementationStatus, str]] = {
    SemanticRole.TRANSACTION_DATE: (
        RoleImplementationStatus.IMPLEMENT_NOW,
        "column_mapper.py'deki inv_date/belge_tarihi eşdeğeri; içerik+alias skorlaması güvenli",
    ),
    SemanticRole.POSTING_DATE: (
        RoleImplementationStatus.IMPLEMENT_NOW,
        "kayit_tarihi eşdeğeri; TRANSACTION_DATE ile aynı kolonu paylaşmaması assignment'ta garanti edilir",
    ),
    SemanticRole.DUE_DATE: (
        RoleImplementationStatus.IMPLEMENT_NOW,
        "due_date/net_vade eşdeğeri",
    ),
    SemanticRole.DOCUMENT_NUMBER: (
        RoleImplementationStatus.IMPLEMENT_NOW,
        "reference eşdeğeri; zaten geniş bir alias sözlüğü var (column_mapper.py)",
    ),
    SemanticRole.EXTERNAL_DOCUMENT_NUMBER: (
        RoleImplementationStatus.IMPLEMENT_NOW,
        "ikincil referans adayı (ör. 'BelgeNo2'); alternatives olarak tutulur, zorla tek seçilmez",
    ),
    SemanticRole.REFERENCE: (
        RoleImplementationStatus.IMPLEMENT_NOW,
        "genel referans-benzeri kolon havuzu (fiş/dekont/seri-sıra vb.)",
    ),
    SemanticRole.DESCRIPTION: (
        RoleImplementationStatus.IMPLEMENT_NOW,
        "comment/metin eşdeğeri",
    ),
    SemanticRole.DOCUMENT_TYPE: (
        RoleImplementationStatus.IMPLEMENT_NOW,
        "belge_turu eşdeğeri; row_classifier'dan BAĞIMSIZ, salt kolon profili/alias",
    ),
    SemanticRole.COUNTERPARTY_CODE: (
        RoleImplementationStatus.IMPLEMENT_NOW,
        "account/firma_kodu eşdeğeri; identity KANITI SAYILMAZ (doc 17 §3, doc 19 §12)",
    ),
    SemanticRole.COUNTERPARTY_NAME: (
        RoleImplementationStatus.IMPLEMENT_NOW,
        "name/satici_ad eşdeğeri",
    ),
    SemanticRole.COUNTERPARTY_TAX_ID: (
        RoleImplementationStatus.NEEDS_REAL_SAMPLE,
        "VKN/TCKN kolonu hiçbir gerçek dosyada doğrulanmadı (doc 19 §12); uydurma YASAK",
    ),
    SemanticRole.DEBIT: (
        RoleImplementationStatus.IMPLEMENT_NOW,
        "debit rolü eşdeğeri; işaret anlamı (pozitif/negatif) ATANMAZ, salt kolon tespiti",
    ),
    SemanticRole.CREDIT: (
        RoleImplementationStatus.IMPLEMENT_NOW,
        "credit rolü eşdeğeri; işaret anlamı ATANMAZ",
    ),
    SemanticRole.SIGNED_AMOUNT: (
        RoleImplementationStatus.IMPLEMENT_NOW,
        "amount rolü eşdeğeri (tek-kolon imzalı tutar adayı)",
    ),
    SemanticRole.BALANCE: (
        RoleImplementationStatus.IMPLEMENT_NOW,
        "balance rolü eşdeğeri; monotonic_score ana sinyal",
    ),
    SemanticRole.DOCUMENT_AMOUNT: (
        RoleImplementationStatus.IMPLEMENT_NOW,
        "SIGNED_AMOUNT ile AYNI kolon-profili skorunu paylaşır (hangi kolonun 'TUTAR' olduğu "
        "mekanik tespiti IMPLEMENT_NOW); belge-dövizi mi yerel-döviz mi olduğu ayrımı "
        "NEEDS_REAL_SAMPLE'dır (bkz. LOCAL_CURRENCY_AMOUNT)",
    ),
    SemanticRole.DOCUMENT_CURRENCY: (
        RoleImplementationStatus.IMPLEMENT_NOW,
        "currency rolü eşdeğeri",
    ),
    SemanticRole.LOCAL_CURRENCY_AMOUNT: (
        RoleImplementationStatus.NEEDS_REAL_SAMPLE,
        "doc 19 §14 dormant alanı; HANGİ kolonun yerel-döviz olduğu gerçek örnekle doğrulanmalı",
    ),
    SemanticRole.LOCAL_CURRENCY: (
        RoleImplementationStatus.NEEDS_REAL_SAMPLE,
        "aynı gerekçe",
    ),
    SemanticRole.GROSS_AMOUNT: (
        RoleImplementationStatus.FINANCE_DECISION_REQUIRED,
        "brüt/net karşılaştırma TABANI finans kararı gerektirir (doc 19 §26)",
    ),
    SemanticRole.NET_AMOUNT: (
        RoleImplementationStatus.FINANCE_DECISION_REQUIRED,
        "aynı gerekçe",
    ),
    SemanticRole.WITHHOLDING_AMOUNT: (
        RoleImplementationStatus.FINANCE_DECISION_REQUIRED,
        "stopaj hesaplama/karşılaştırma POLİTİKASI finans kararı gerektirir",
    ),
    SemanticRole.OPEN_AMOUNT: (
        RoleImplementationStatus.DEFERRED_MIGRATION_CANDIDATE,
        "doc 19 §21 — kalıcı yasak DEĞİL; Faz 2'nin test_O karakterizasyonu nedeniyle "
        "bu fazda da ertelendi (bu faz kullanıcı talimatıyla NETLEŞTİRİLDİ)",
    ),
    SemanticRole.IS_OPEN: (
        RoleImplementationStatus.DEFERRED_MIGRATION_CANDIDATE,
        "aynı gerekçe",
    ),
    SemanticRole.CLEARING_REFERENCE: (
        RoleImplementationStatus.DEFERRED_MIGRATION_CANDIDATE,
        "aynı gerekçe",
    ),
    SemanticRole.CLEARING_DATE: (
        RoleImplementationStatus.DEFERRED_MIGRATION_CANDIDATE,
        "aynı gerekçe",
    ),
    SemanticRole.SPECIAL_GL_INDICATOR: (
        RoleImplementationStatus.NEEDS_REAL_SAMPLE,
        "UMSKZ-benzeri kod anlamı ERP'ye özgü; gerçek örnek + doküman olmadan uydurulamaz",
    ),
    SemanticRole.ADVANCE_INDICATOR: (
        RoleImplementationStatus.DESIGN_ONLY,
        "metin-tabanlı tahmin zaten row_classifier.py'de var (ayrı mekanizma); ayrı bir "
        "KOLON-seviyesi gösterge nadiren bulunur, bu fazda skorlanmadı",
    ),
    SemanticRole.OPENING_BALANCE_INDICATOR: (
        RoleImplementationStatus.DESIGN_ONLY,
        "mevcut mimaride açılış satırı zaten loader seviyesinde ELENİYOR, kayıt bile olmuyor "
        "(doc 19 §11.5) — kolon-seviyesi bir gösterge farklı bir kavram, bu fazda skorlanmadı",
    ),
}
