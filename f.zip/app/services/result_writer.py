"""Mutabakat sonucunu BAĞIMSIZ bir Excel kitabına yazar (üç sayfa).

NEDEN KAYNAK DOSYAYA EKLENMİYOR (değişiklik)
    Sonuç eskiden kullanıcının seçtiği TOFAŞ ekstresinin İÇİNE bir sayfa
    olarak ekleniyordu. Bu üç ayrı sorun üretiyordu:

    1. ÖLÇEK. Koca bir FBL1H kitabını ``load_workbook`` ile açıp yeniden
       kaydetmek, 15.601 satırlık gerçekçi bir kaynakta firma başına
       ~11,7 sn sürüyordu; bağımsız kitap ~0,04 sn. Dönem başına yüzlerce
       (ve artan sayıda) firma çalıştırıldığında bu, saatlerle dakikalar
       arasındaki farktır. Disk tarafında da her firma için kaynağın tam
       kopyası tutuluyordu.
    2. SADAKAT. openpyxl bir Excel dosyasını tam sadakatle yeniden yazamaz:
       grafik, pivot, koşullu biçimlendirme, veri doğrulama kaybolabilir.
       Kullanıcının ORİJİNAL ekstresi bu riski taşımamalıdır.
    3. MAKRO. ``.xlsm`` kaynakta ``keep_vba`` yönetmek zorunluydu; tek bir
       hata kullanıcının makrolarını kalıcı olarak siliyordu.

    Artık kaynak dosya hiç AÇILMAZ. İzlenebilirlik kaybolmaz: özet sayfası
    TOFAŞ dosya adını, SHA-256'sını ve satır sayısını zaten taşır.

SAYFALAR — her biri farklı bir soruya hizmet eder
    "Mutabakat Özeti"  tek ekran: oran, fark, dip toplam, veri kalitesi,
                       çalıştırma parametreleri. Yüksekliği değişkendir.
    "Farklar"          GÜNLÜK ÇALIŞMA SAYFASI. Başlık DAİMA 1. satırdadır
                       (250+ dosyada aynı makro/pivot kurulabilsin),
                       AutoFilter açıktır, yalnız istisnaları taşır ve
                       bloklara ayrılmıştır. Her bloğun sonunda ara toplam.
    "Tüm Satırlar"     eşleşenler dahil tam liste; kanıt ve denetim için.

TUTARLAR VE TARİHLER GERÇEK TİPTEDİR
    Eskiden her hücre ``str()`` ile metne çevriliyordu; ``safe_excel_value``
    eksili tutarları formül sanıp başına kesme işareti koyuyordu
    (``'-22542009.59``). Sonuç: kolon toplanamıyor, sıralanamıyor, sayı
    filtresi çalışmıyordu — mutabakatta yapılan ilk işler. Artık ``Decimal``
    ve ``date`` nesneleri olduğu gibi yazılır, biçim hücreye uygulanır.
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from pathlib import Path
from typing import Optional

from app.models.domain import ReconciliationResult
from app.services.excel_style import (
    BLUE,
    DARK_RED,
    DATE_FORMAT,
    GREEN,
    HEADER_FILL,
    LIGHT_ORANGE,
    MONEY_FORMAT,
    ORANGE,
    PURPLE,
    RED,
    WARN_FONT,
    YELLOW,
)
from app.utils.excel import safe_excel_value

# Geriye dönük uyumluluk: ``statement_writer`` bu adı import ediyordu.
_HEADER = HEADER_FILL

# "Çalıştırma parametreleri" bloğunda tercih edilen görüntüleme sırası.
_PARAM_ORDER = (
    "Program Sürümü", "Kural Sürümü", "Çalıştırma Tarihi",
    "Firma Modu", "Şirket",
    "TOFAŞ Dosyası", "TOFAŞ SHA-256", "TOFAŞ Satır Sayısı",
    "Firma Dosyası", "Firma SHA-256", "Firma Satır Sayısı",
    "Tutar Toleransı", "Tarih Toleransı (gün)",
    "Bire-Çok Eşleşme", "Bire-Çok Havuz Sınırı", "Bire-Çok Alt-Küme Sınırı",
)

# -- Detay tablosu şeması ---------------------------------------------------
# İKİ detay sayfası AYNI şemayı kullanır: "Farklar" ve "Tüm Satırlar". Böylece
# kullanıcı tek bir kolon düzeni öğrenir ve iki sayfa arasında kopyalama
# yapabilir.
#
# "Fatura No" kolonları başa yakın durur: kullanıcının en sık ihtiyacı
# "hangi faturalar tutmuyor" sorusudur ve bu kolon kopyalanıp satın alma /
# firma yazışmasına doğrudan yapıştırılır.
_COLUMNS: tuple[tuple[str, int], ...] = (
    ("Blok", 20),
    ("Fatura No (Firma)", 22),
    ("Fatura No (TOFAŞ)", 22),
    ("Belge Tarihi", 13),
    ("Vade", 13),
    ("Firma Tutar", 16),
    ("TOFAŞ Tutar", 16),
    ("Fark", 16),
    ("Para Birimi", 11),
    ("Eşleşme Kuralı", 20),
    ("Uyarı", 24),
    ("Firma Hesap", 14),
    ("TOFAŞ Hesap", 14),
    ("Açıklama", 40),
)
_MONEY_COLS = (6, 7, 8)
_DATE_COLS = (4, 5)
_FARK_COL = 8

_ZERO = Decimal("0")


def _warn_text(isaret: bool, para_birimi: bool) -> str:
    """Satır uyarılarını tek hücrede topla (boşsa boş kalır)."""
    parts = []
    if isaret:
        parts.append("Aynı işaret!")
    if para_birimi:
        parts.append("Para birimi bilinmiyor!")
    return " · ".join(parts)


def _amt(value: Optional[Decimal]) -> Decimal:
    """Tutar; eksik taraf SIFIR sayılır."""
    return value if value is not None else _ZERO


def _fark(firma: Optional[Decimal], tofas: Optional[Decimal]) -> Decimal:
    """Satır farkı — İŞARETLİ toplam olarak hesaplanır.

    İŞ KURALI: TOFAŞ'ta faturalar EKSİLİ, firmada artılı tutulur. Dolayısıyla
    tutan bir çiftte ``firma + TOFAŞ = 0``'dır ve fark doğrudan okunur:

        eşleşti        firma 100, TOFAŞ -100  ->  0
        tutar farkı    firma 100, TOFAŞ  -95  ->  5   (firma 5 fazla gösteriyor)
        sadece firmada firma 100, TOFAŞ    0  ->  100 (bizde hiç yok)
        sadece TOFAŞ   firma   0, TOFAŞ -100  -> -100 (firma göstermiyor)

    Mutlak değerle (``|firma| - |TOFAŞ|``) hesaplamak yerine işaretli toplam
    seçildi: iade/düzeltme satırları her iki tarafta da ters işaretli olabilir
    ve mutlak değer bu bilgiyi yok ederek farkı OLDUĞUNDAN BÜYÜK gösterir.

    İşaretler ters olması gerekirken aynıysa (ör. ikisi de artılı) fark iki
    katı görünür; o satır zaten "Aynı işaret!" uyarısı taşır.
    """
    return _amt(firma) + _amt(tofas)


class ResultWriter:
    """Mutabakat sonucunu bağımsız bir Excel kitabına yazar."""

    SHEET_SUMMARY = "Mutabakat Özeti"
    SHEET_DIFF = "Farklar"
    SHEET_ALL = "Tüm Satırlar"

    #: Geriye dönük ad (eski kod/testler bu sabiti arıyordu).
    SHEET_NAME = SHEET_SUMMARY

    #: Sonuç dosyasının adı kaynak dosyadan bu ek ile türetilir.
    SUFFIX = "_mutabakat"

    def target_for(self, tofas_path: str | Path) -> Path:
        """Kaynak ekstrenin YANINA yazılacak sonuç dosyasının yolu.

        Kaynak dosya hiç açılmaz; yalnızca adı kullanılır. Hedef daima
        ``.xlsx``'tir — bağımsız kitapta makro yoktur, dolayısıyla ``.xlsm``
        üretmek için bir neden de yoktur.
        """
        path = Path(tofas_path)
        return path.with_name(f"{path.stem}{self.SUFFIX}.xlsx")

    def write(self, tofas_path: str | Path, result: ReconciliationResult,
              *, target: str | Path | None = None) -> Path:
        """Sonuç kitabını yaz ve yazılan yolu döndür.

        ``target`` verilirse AYNEN kullanılır (``output_location.result_target``
        zaten benzersiz ve doğru adı üretir). Verilmezse kaynağın yanına
        ``<ad>_mutabakat.xlsx`` yazılır. Hedefin adından "bu zaten bir sonuç
        yolu mu?" diye sezgi yürütmek, ``ad_mutabakat (2)`` gibi benzersizlik
        eklerinde yanlış sonuç veriyordu; bu yüzden niyet açıkça taşınır.
        """
        from openpyxl import Workbook

        target = Path(target) if target is not None else self.target_for(tofas_path)

        wb = Workbook()
        wb.remove(wb.active)  # varsayılan boş sayfayı kaldır
        try:
            self._write_summary_sheet(wb, result)
            self._write_difference_sheet(wb, result)
            self._write_all_rows_sheet(wb, result)
            self._atomic_save(wb, target)
        finally:
            self._release_workbook(wb)
        return target

    # -- Sayfa 1: özet ------------------------------------------------------

    def _write_summary_sheet(self, wb, result: ReconciliationResult) -> None:
        from openpyxl.styles import Font

        ws = wb.create_sheet(self.SHEET_SUMMARY)
        bold = Font(bold=True)
        warn = Font(bold=True, color=WARN_FONT)
        s = result.summary
        row = 1

        ws.cell(row=row, column=1, value="MUTABAKAT ÖZETİ").font = bold
        row += 1

        # (etiket, değer, para_mi) — sayımlar int, tutarlar Decimal kalır.
        rows: list[tuple[str, object, bool]] = [
            ("Mutabakat No (RUN-ID)", s.run_id or "-", False),
            ("Firma kayıt sayısı", s.total_firma, False),
            ("TOFAŞ kayıt sayısı (aktif)", s.total_tofas, False),
            ("Eşleşen", s.matched, False),
            ("Tutar farkı", s.amount_diff, False),
            ("Bire-çok eşleşme (grup)", s.cross_matched, False),
            ("Para birimi farkı (eşleşme değil)", s.currency_diff, False),
            ("Kimlik çelişkisi (eşleşme değil, BLOCK)", s.identity_conflict, False),
            ("Ekonomik olay çelişkisi (eşleşme değil, REVIEW)",
             s.economic_event_review, False),
            ("Belirsiz eşleşme (matched içinde, incelenmeli)",
             s.ambiguous_matches, False),
            ("Sadece firmada (TOFAŞ'ta yok)", s.only_firma, False),
            ("Sadece TOFAŞ'ta (firmada yok)", s.only_tofas, False),
            ("Firma dip toplam", s.firma_diptoplam, True),
            ("TOFAŞ dip toplam (hesaplanan)", s.tofas_diptoplam_hesap, True),
            ("TOFAŞ dip toplam (SAP sarı satır)",
             s.tofas_diptoplam_sap if s.tofas_diptoplam_sap is not None else "-",
             s.tofas_diptoplam_sap is not None),
            ("Fark (|firma| - |TOFAŞ|)", s.fark, True),
        ]
        for label, value, is_money in rows:
            ws.cell(row=row, column=1, value=label)
            cell = ws.cell(row=row, column=2, value=safe_excel_value(value))
            if is_money:
                cell.number_format = MONEY_FORMAT
            row += 1

        if s.diptoplam_uyari:
            ws.cell(row=row, column=1, value=s.diptoplam_uyari).font = warn
            row += 1
        if result.excluded_belge_turu:
            ws.cell(row=row, column=1, value="Hariç tutulan belge türleri")
            ws.cell(row=row, column=2,
                    value=", ".join(result.excluded_belge_turu))
            row += 1

        if result.data_quality:
            row += 1
            ws.cell(row=row, column=1, value="VERİ KALİTESİ UYARILARI").font = warn
            row += 1
            for line in result.data_quality:
                ws.cell(row=row, column=1, value=safe_excel_value(line))
                row += 1

        # Tekrar üretilebilirlik: dosya aylar sonra tek başına açıldığında
        # "bu sonuç hangi ayarlarla, hangi girdiden üretildi?" cevaplanabilsin.
        # Kaynak dosya artık kopyalanmadığı için bu blok İZLENEBİLİRLİĞİN
        # TEK TAŞIYICISIDIR: dosya adı + SHA-256 + satır sayısı burada durur.
        if s.parameters:
            row += 1
            ws.cell(row=row, column=1, value="ÇALIŞTIRMA PARAMETRELERİ").font = bold
            row += 1
            seen = set()
            for label in _PARAM_ORDER:
                if label in s.parameters:
                    ws.cell(row=row, column=1, value=label)
                    ws.cell(row=row, column=2,
                            value=safe_excel_value(s.parameters[label]))
                    seen.add(label)
                    row += 1
            for label in sorted(k for k in s.parameters if k not in seen):
                ws.cell(row=row, column=1, value=label)
                ws.cell(row=row, column=2,
                        value=safe_excel_value(s.parameters[label]))
                row += 1

        ws.column_dimensions["A"].width = 34
        ws.column_dimensions["B"].width = 46

    # -- Satır üretimi (iki detay sayfası için ORTAK) -----------------------

    def _matched_rows(self, result: ReconciliationResult, label: str,
                      pairs) -> list[tuple[list, str, Decimal]]:
        out = []
        fill = GREEN if label == "Eşleşti" else YELLOW
        for p in pairs:
            fark = _fark(p.firma.amount, p.tofas.amount)
            out.append(([
                label,
                p.firma.reference_raw or p.firma.reference or "",
                p.tofas.reference_raw or p.tofas.reference or "",
                p.firma.inv_date or p.tofas.belge_tarihi,
                p.firma.due_date or p.tofas.net_vade,
                p.firma.amount, p.tofas.amount, fark,
                p.firma.currency or p.tofas.currency or "",
                p.rule.value,
                _warn_text(p.isaret_uyari, p.para_birimi_uyari),
                p.firma.account or "",
                p.tofas.main_account or p.tofas.firma_kodu or "",
                p.firma.comment or p.tofas.metin or "",
            ], fill, fark))
        return out

    def _currency_rows(self, result: ReconciliationResult
                       ) -> list[tuple[list, str, Decimal]]:
        """Aynı fatura no, FARKLI para birimi.

        Fark hücresi BİLEREK BOŞ bırakılır ve blok toplamına 0 katkı verir:
        farklı para birimindeki iki tutarı çıkarmak anlamsız bir sayı üretir
        ve o sayı toplanırsa dönem farkını yanlış gösterir. Para birimi
        kolonu iki tarafın bildirdiğini birlikte taşır (``EUR ↔ USD``), çünkü
        muhasebecinin ilk sorusu "hangisi hangisini söylüyor?"dur.
        """
        out = []
        for p in result.currency_diff:
            fb = (p.firma.currency or "?").strip().upper()
            tb = (p.tofas.currency or "?").strip().upper()
            out.append(([
                "Para birimi farkı",
                p.firma.reference_raw or p.firma.reference or "",
                p.tofas.reference_raw or p.tofas.reference or "",
                p.firma.inv_date or p.tofas.belge_tarihi,
                p.firma.due_date or p.tofas.net_vade,
                p.firma.amount, p.tofas.amount, None,
                f"{fb} ↔ {tb}",
                p.rule.value,
                "Para birimi çelişiyor — fark hesaplanamaz",
                p.firma.account or "",
                p.tofas.main_account or p.tofas.firma_kodu or "",
                p.firma.comment or p.tofas.metin or "",
            ], ORANGE, _ZERO))
        return out

    def _identity_conflict_rows(self, result: ReconciliationResult
                               ) -> list[tuple[list, str, Decimal]]:
        """FAZ 4 (P0 güvenlik kapısı) — doğrulanmış kimlik çelişkisi.

        ``_currency_rows`` ile BİREBİR aynı ilke: mutabık SAYILMAZ, fark
        hesaplanmaz (iki tarafın tutarını karşılaştırmak bu durumda
        anlamsızdır — asıl mesele kimliğin kendisidir), kalem kaybolmaz.
        """
        out = []
        for p in result.identity_conflict:
            out.append(([
                "Kimlik çelişkisi — BLOCK",
                p.firma.reference_raw or p.firma.reference or "",
                p.tofas.reference_raw or p.tofas.reference or "",
                p.firma.inv_date or p.tofas.belge_tarihi,
                p.firma.due_date or p.tofas.net_vade,
                p.firma.amount, p.tofas.amount, None,
                f"VKN {p.firma.tax_id} ↔ {p.tofas.tax_id}",
                (p.original_rule.value if p.original_rule else p.rule.value),
                "Doğrulanmış kimlik çelişkisi — otomatik eşleşme engellendi",
                p.firma.account or "",
                p.tofas.main_account or p.tofas.firma_kodu or "",
                p.firma.comment or p.tofas.metin or "",
            ], DARK_RED, _ZERO))
        return out

    def _economic_event_review_rows(self, result: ReconciliationResult
                                    ) -> list[tuple[list, str, Decimal]]:
        """FAZ 4 (P0 güvenlik kapısı) — doğrulanmış ekonomik olay çelişkisi.

        Mutabık SAYILMAZ; insan incelemesi gerekir. Fark BİLEREK boş
        bırakılır: rekabet eden adaylardan HANGİSİNİN doğru eşleşme olduğu
        henüz belirsizdir, bu yüzden bir "tutar farkı" sayısı üretmek
        yanıltıcı olur.
        """
        out = []
        for p in result.economic_event_review:
            out.append(([
                "Ekonomik olay çelişkisi — REVIEW",
                p.firma.reference_raw or p.firma.reference or "",
                p.tofas.reference_raw or p.tofas.reference or "",
                p.firma.inv_date or p.tofas.belge_tarihi,
                p.firma.due_date or p.tofas.net_vade,
                p.firma.amount, p.tofas.amount, None,
                p.firma.currency or p.tofas.currency or "",
                (p.original_rule.value if p.original_rule else p.rule.value),
                ("Rekabet eden bir aday çelişen bir ekonomik olay türü "
                 "taşıyor (örn. fatura/iade/avans) — otomatik eşleşme "
                 "yapılmadı, elle doğrulayın"),
                p.firma.account or "",
                p.tofas.main_account or p.tofas.firma_kodu or "",
                p.firma.comment or p.tofas.metin or "",
            ], LIGHT_ORANGE, _ZERO))
        return out

    def _cross_rows(self, result: ReconciliationResult
                    ) -> list[tuple[list, str, Decimal]]:
        out = []
        for cm in result.cross_matches:
            if cm.single_side.value == "FIRMA":
                firma_ref = cm.one_firma.reference_raw or cm.one_firma.reference or ""
                tofas_ref = ", ".join(
                    (m.reference_raw or m.reference or "") for m in cm.many_tofas)
                firma_amount, tofas_amount = cm.total_one, cm.total_many
                acc_f = cm.one_firma.account or ""
                acc_t = ", ".join(
                    (m.main_account or m.firma_kodu or "") for m in cm.many_tofas)
                note = f"1 firma faturası ↔ {len(cm.many_tofas)} TOFAŞ satırı"
                currency = cm.one_firma.currency or ""
            else:
                firma_ref = ", ".join(
                    (m.reference_raw or m.reference or "") for m in cm.many_firma)
                tofas_ref = cm.one_tofas.reference_raw or cm.one_tofas.reference or ""
                firma_amount, tofas_amount = cm.total_many, cm.total_one
                acc_f = ", ".join((m.account or "") for m in cm.many_firma)
                acc_t = cm.one_tofas.main_account or cm.one_tofas.firma_kodu or ""
                note = f"{len(cm.many_firma)} firma satırı ↔ 1 TOFAŞ faturası"
                currency = cm.one_tofas.currency or ""
            fark = _fark(firma_amount, tofas_amount)
            out.append(([
                "Bire-çok", firma_ref, tofas_ref, None, None,
                firma_amount, tofas_amount, fark,
                currency, cm.rule.value,
                _warn_text(False, cm.para_birimi_uyari),
                acc_f, acc_t, note,
            ], PURPLE, fark))
        return out

    def _only_firma_rows(self, result: ReconciliationResult
                         ) -> list[tuple[list, str, Decimal]]:
        out = []
        for rec in result.only_firma:
            # TOFAŞ tarafı yok: fark, risk altındaki tutarın tamamıdır.
            fark = _fark(rec.amount, None)
            out.append(([
                "Sadece firmada", rec.reference_raw or rec.reference or "", "",
                rec.inv_date, rec.due_date,
                rec.amount, None, fark,
                rec.currency or "", "", "",
                rec.account or "", "", rec.comment or "",
            ], RED, fark))
        return out

    def _only_tofas_rows(self, result: ReconciliationResult
                         ) -> list[tuple[list, str, Decimal]]:
        out = []
        for rec in result.only_tofas:
            # Firma tarafı yok: TOFAŞ tutarı eksili olduğu için fark da
            # eksilidir — yön bilgisi korunur.
            fark = _fark(None, rec.amount)
            out.append(([
                "Sadece TOFAŞ'ta", "", rec.reference_raw or rec.reference or "",
                rec.belge_tarihi, rec.net_vade,
                None, rec.amount, fark,
                rec.currency or "", "", "",
                "", rec.main_account or rec.firma_kodu or "", rec.metin or "",
            ], BLUE, fark))
        return out

    # -- Sayfa 2: Farklar ---------------------------------------------------

    def _write_difference_sheet(self, wb, result: ReconciliationResult) -> None:
        """İstisnalar, muhasebe aksiyonu sırasına göre bloklanmış.

        Blok sırası KASITLIDIR — en çok aksiyon gerektiren en üstte:
          1. Sadece firmada  → fatura bize gelmemiş/girilmemiş (satın almaya sor)
          2. Sadece TOFAŞ'ta → firma işlememiş / iade (firmaya sor)
          3. Tutar farkı     → fatura no tuttu, tutar tutmadı (kalem incele)
          4. Bire-çok        → konsolide/kısmi; çoğu meşru, doğrulanır
        """
        from openpyxl.styles import Font

        ws = wb.create_sheet(self.SHEET_DIFF)
        bold = Font(bold=True)

        self._put_header(ws, row=1)
        row = 2

        blocks = (
            ("SADECE FİRMADA — fatura TOFAŞ'ta yok", self._only_firma_rows(result)),
            ("SADECE TOFAŞ'TA — firma göstermiyor", self._only_tofas_rows(result)),
            ("TUTAR FARKI — referans tuttu, tutar tutmadı",
             self._matched_rows(result, "Tutar farkı", result.amount_mismatch)),
            ("PARA BİRİMİ FARKI — aynı fatura, farklı döviz",
             self._currency_rows(result)),
            ("KİMLİK ÇELİŞKİSİ — doğrulanmış kimlikler farklı (BLOCK)",
             self._identity_conflict_rows(result)),
            ("EKONOMİK OLAY ÇELİŞKİSİ — fatura/iade/avans karışıklığı riski (REVIEW)",
             self._economic_event_review_rows(result)),
            ("BİRE-ÇOK — konsolide / kısmi eşleşme", self._cross_rows(result)),
        )

        genel = _ZERO
        yazilan = 0
        for title, rows in blocks:
            if not rows:
                continue
            ws.cell(row=row, column=1, value=f"{title}  ({len(rows)} satır)").font = bold
            row += 1
            blok_toplam = _ZERO
            for values, fill, fark in rows:
                self._put_row(ws, row, values, fill)
                blok_toplam += fark
                row += 1
            ws.cell(row=row, column=1, value="Blok toplamı").font = bold
            cell = ws.cell(row=row, column=_FARK_COL, value=blok_toplam)
            cell.number_format = MONEY_FORMAT
            cell.font = bold
            row += 2
            genel += blok_toplam
            yazilan += len(rows)

        if yazilan:
            ws.cell(row=row, column=1,
                    value=f"LİSTELENEN {yazilan} İSTİSNANIN FARK TOPLAMI").font = bold
            cell = ws.cell(row=row, column=_FARK_COL, value=genel)
            cell.number_format = MONEY_FORMAT
            cell.font = bold
            row += 2
            # DÜRÜSTLÜK NOTU: Bu toplam, özet sayfasındaki "Fark" ile AYNI
            # SAYI DEĞİLDİR ve öyle olduğu varsayılmamalıdır. Özetteki fark
            # iki tarafın DİP TOPLAMLARININ karşılaştırmasıdır; oraya hariç
            # tutulan belge türleri ve açılış/devir satırları da girer,
            # buraya girmez. Altı golden vakada ikisinin ayrıştığı ölçüldü;
            # bu yüzden iki sayı aynı adı TAŞIMAZ.
            ws.cell(
                row=row, column=1,
                value=("Not: Bu toplam yalnızca YUKARIDA LİSTELENEN satırları "
                       "kapsar. Özet sayfasındaki 'Fark' ise iki tarafın dip "
                       "toplamlarını karşılaştırır (hariç tutulan belge "
                       "türleri ve açılış/devir satırları dahil), bu yüzden "
                       "iki sayı farklı olabilir."))
        else:
            ws.cell(row=row, column=1,
                    value="Fark yok — tüm kalemler eşleşti.").font = bold

        self._finish_detail_sheet(ws, header_row=1, last_row=row)

    # -- Sayfa 3: Tüm Satırlar ----------------------------------------------

    def _write_all_rows_sheet(self, wb, result: ReconciliationResult) -> None:
        """Eşleşenler dahil tam liste — kanıt ve denetim için."""
        ws = wb.create_sheet(self.SHEET_ALL)
        self._put_header(ws, row=1)
        row = 2
        for group in (
            self._matched_rows(result, "Eşleşti", result.matched),
            self._matched_rows(result, "Tutar farkı", result.amount_mismatch),
            self._currency_rows(result),
            self._identity_conflict_rows(result),
            self._economic_event_review_rows(result),
            self._cross_rows(result),
            self._only_firma_rows(result),
            self._only_tofas_rows(result),
        ):
            for values, fill, _fark in group:
                self._put_row(ws, row, values, fill)
                row += 1
        self._finish_detail_sheet(ws, header_row=1, last_row=row - 1)

    # -- Ortak yazım yardımcıları -------------------------------------------

    @staticmethod
    def _put_header(ws, row: int) -> None:
        from openpyxl.styles import Font, PatternFill

        white_bold = Font(bold=True, color="FFFFFFFF")
        fill = PatternFill("solid", fgColor=HEADER_FILL)
        for col, (title, _width) in enumerate(_COLUMNS, start=1):
            cell = ws.cell(row=row, column=col, value=title)
            cell.font = white_bold
            cell.fill = fill

    @staticmethod
    def _put_row(ws, row: int, values: list, fill_color: str) -> None:
        """Tek satır yaz: tutar/tarih GERÇEK TİP, biçim hücrede."""
        from openpyxl.styles import Alignment, PatternFill

        fill = PatternFill("solid", fgColor=fill_color)
        right = Alignment(horizontal="right")
        for col, value in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col, value=safe_excel_value(value))
            cell.fill = fill
            if col in _MONEY_COLS:
                cell.number_format = MONEY_FORMAT
                cell.alignment = right
            elif col in _DATE_COLS and isinstance(value, date):
                cell.number_format = DATE_FORMAT

    @staticmethod
    def _finish_detail_sheet(ws, header_row: int, last_row: int) -> None:
        """Kolon genişlikleri + donmuş başlık + AutoFilter.

        AutoFilter OLMADAN 250+ dosyada "sadece firmada olanları göster"
        denemezdi; bu, kullanıcının en sık yaptığı işlemdir.
        """
        from openpyxl.utils import get_column_letter

        for i, (_title, width) in enumerate(_COLUMNS, start=1):
            ws.column_dimensions[get_column_letter(i)].width = width
        ws.freeze_panes = ws.cell(row=header_row + 1, column=1)
        son = get_column_letter(len(_COLUMNS))
        # Filtre en az bir veri satırı varsa anlamlıdır.
        if last_row > header_row:
            ws.auto_filter.ref = f"A{header_row}:{son}{last_row}"

    @staticmethod
    def _release_workbook(wb) -> None:
        """Çalışma kitabının TÜM kaynaklarını bırak (``vba_archive`` dahil).

        ``Workbook.close()`` yalnızca ``_archive``i kapatır. ``keep_vba=True``
        ile açılan kitapta openpyxl ayrıca
        ``wb.vba_archive = ZipFile(BytesIO(), 'a')`` tutar ve BUNU HİÇ
        KAPATMAZ. Kaydetme sırasında altındaki BytesIO kapandığı için nesne
        çöp toplandığında ``ZipFile.__del__`` → ``fp.seek()``

            ValueError: I/O operation on closed file

        hatasını "unraisable exception" olarak üretiyordu.

        Bu yazıcı artık yalnızca SIFIRDAN kitap üretir (vba_archive yoktur),
        ama yardımcı ``statement_writer`` ile paylaşıldığı ve kitabı biz
        açtığımız için bırakmak da bizim işimizdir.
        """
        archive = getattr(wb, "vba_archive", None)
        if archive is not None:
            try:
                archive.close()
            except (ValueError, OSError):
                pass
            finally:
                try:
                    wb.vba_archive = None
                except AttributeError:  # pragma: no cover - savunma
                    pass
        wb.close()

    @classmethod
    def _atomic_save(cls, wb, target: Path) -> None:
        """Çalışma kitabını ATOMİK yaz: önce geçici dosya, sonra yer değiştir.

        Doğrudan ``wb.save(target)`` çağrılırsa, yazma ortasında bir hata
        olursa (disk dolu, dosya kilitli, süreç öldürüldü) hedef dosya yarım
        yazılmış halde kalır. Bu yüzden aynı klasördeki geçici bir dosyaya
        yazılır ve yalnızca yazma tamamen başarılı olursa ``os.replace`` ile
        (aynı birim üzerinde atomik) hedefin üzerine alınır.

        GEÇİCİ DOSYANIN UZANTISI HEDEFLE AYNIDIR
            Makro içeren bir kitabı ``.xlsx`` uzantılı geçici dosyaya yazmak
            openpyxl'i "bu bir makrolu kitap değil" varsayımına itebilir.
            (``statement_writer`` bu yardımcıyı paylaşır.)

        YEDEK ARTIK ALINMIYOR — NEDEN
            Eskiden değiştirmeden önce hedefin bir kopyası alınıyordu, çünkü
            hedef KULLANICININ ORİJİNAL ekstresiydi ve openpyxl bir Excel
            dosyasını tam sadakatle yeniden yazamaz. Artık hedef daima
            UYGULAMANIN ÜRETTİĞİ bir dosyadır: kaynak ekstreye hiç
            dokunulmaz, ve üzerine yazılan şey yeniden çalıştırmayla birebir
            geri üretilebilir. Yüzlerce firmalık bir dönemde her çalıştırmada
            bir yedek bırakmak, korumadığı bir veri için klasörü ikiye
            katlardı. ``output_location.result_target`` ayrıca her çalıştırma
            için benzersiz bir ad rezerve eder.
        """
        import os
        import tempfile

        target = Path(target)
        suffix = target.suffix or ".xlsx"
        fd, tmp_name = tempfile.mkstemp(
            dir=str(target.parent), prefix=f".{target.stem}.", suffix=f".tmp{suffix}"
        )
        os.close(fd)
        tmp_path = Path(tmp_name)
        try:
            wb.save(tmp_path)
            os.replace(tmp_path, target)
        except BaseException:
            # Hedef dosyaya HİÇ dokunulmadı; geçici dosyayı temizle ve yükselt.
            try:
                tmp_path.unlink(missing_ok=True)
            except OSError:  # pragma: no cover - temizlik hatası yutulur
                pass
            raise
