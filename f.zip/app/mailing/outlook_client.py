"""Outlook istemcisi — kullanıcının çalışan Gümrük Dekont uygulamasıyla
BİREBİR AYNI yapı.

Gümrük uygulamasındaki kalıp aynen korunmuştur:
  - Modül seviyesinde:  try: import pythoncom, win32com.client  / except: None
  - Sabit:              MAIL_ITEM_CLASS = 43
  - Her Outlook işlemi: pythoncom.CoInitialize() ... try/finally ...
                        pythoncom.CoUninitialize()
  - Bağlantı:           win32com.client.Dispatch("Outlook.Application")
                        .GetNamespace("MAPI")
  - Kurulu değilse:     RuntimeError("pywin32 kurulu değil. CMD: ...")

Bu ortam (Linux) Outlook içermez; modül seviyesindeki import except ile
yakalanır ve None kalır. Fonksiyonlar çağrıldığında net RuntimeError verir,
çökme olmaz.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

from loguru import logger

from app.mailing.mail_builder import MailDraft

# --- Gümrük uygulamasıyla birebir aynı modül-seviyesi import ------------------
try:
    import pythoncom
    import win32com.client
except Exception:
    pythoncom = None
    win32com = None

# Outlook MailItem sınıf sabiti (gümrük kodundaki MAIL_ITEM_CLASS = 43 ile aynı).
MAIL_ITEM_CLASS = 43
# Yeni mail oluşturmak için CreateItem argümanı (olMailItem = 0).
OL_MAIL_ITEM = 0
# Gönderilmiş Öğeler klasörü (eksik Message-ID'leri sonradan tamamlamak için).
OL_FOLDER_SENT_ITEMS = 5
# Gelen Kutusu (zincirdeki son cevabı bulmak için).
OL_FOLDER_INBOX = 6
# Giden Kutusu / Taslaklar: bir öğenin NEREDE durduğu, gönderilip
# gönderilmediğinin kanıtıdır (bkz. verify_sent).
OL_FOLDER_OUTBOX = 4
OL_FOLDER_DRAFTS = 16
# InternetMessageID MAPI etiketi — gelen cevabı bu maile bağlayan kimlik.
PR_INTERNET_MESSAGE_ID = "http://schemas.microsoft.com/mapi/proptag/0x1035001F"


def _outlook_send_block(namespace) -> str:
    """Gönderimden önce Outlook'un çevrimiçi olduğunu kanıtla.

    ``NameSpace.Offline`` Exchange profillerinde Outlook'un sunucuya bağlı
    olup olmadığını bildirir. Bu uygulama yalnız yönetilen kurumsal Exchange
    posta kutusundan toplu mutabakat gönderebildiği için özellik okunamıyorsa
    ya da boolean olmayan bir değer dönüyorsa gönderime izin verilmez.

    Bu kapı özellikle ``Work Offline`` durumunda ``Send()`` çağrısının Giden
    Kutusu'na öğe bırakıp daha sonra beklenmedik bir anda teslim etmesini
    engeller. Önizleme açmak gönderim değildir; bu kontrol yalnız gerçek
    ``Send()`` yollarında uygulanır.
    """
    try:
        offline = namespace.Offline
    except Exception as exc:  # noqa: BLE001 - belirsizlikte gönderme
        return (
            "Outlook çevrimiçi durumu doğrulanamadı "
            f"({exc}); güvenlik gereği gönderim yapılmadı.")
    if type(offline) is not bool:
        return (
            "Outlook çevrimiçi durumu geçerli bir Exchange bilgisi vermedi; "
            "güvenlik gereği gönderim yapılmadı.")
    if offline:
        return (
            "Outlook 'Work Offline' modunda; mail Giden Kutusu'nda bekleyip "
            "sonradan teslim olabileceği için gönderim yapılmadı.")
    return ""


def _outgoing_account(namespace, outgoing_smtp: str):
    """Gerçek gönderim için yapılandırılmış kurumsal ``Account``'u çöz.

    Dönüş ``(account, engel)``: başarıda ``engel`` boştur; aksi hâlde
    ``account`` ``None`` ve ``engel`` anlaşılır bir gerekçedir.

    Eşleşme YALNIZ ``namespace.Accounts`` üzerinde ``SmtpAddress`` alanına
    büyük/küçük harf duyarsız TAM eşleşmedir. Görünen ad, varsayılan hesap ya
    da Store adıyla tahmin yapılmaz. Paylaşımlı kurumsal posta kutusu
    Outlook'ta gerçek bir ``Account`` olarak tanımlı olmalıdır. Okunamayan
    herhangi bir hesap adresi de engeller: tekillik kanıtlanamaz.
    """
    smtp = (outgoing_smtp or "").strip()
    if not smtp:
        return None, (
            "Kurumsal giden posta kutusu SMTP ayarı (outgoing_mailbox_smtp) "
            "boş; güvenlik gereği gönderim yapılmadı.")
    try:
        accounts = list(namespace.Accounts)
    except Exception as exc:  # noqa: BLE001 - belirsizlikte gönderme
        return None, (
            f"Outlook hesap listesi okunamadı ({exc}); güvenlik gereği "
            "gönderim yapılmadı.")
    target = smtp.lower()
    matches = []
    for account in accounts:
        try:
            address = account.SmtpAddress
        except Exception:  # noqa: BLE001
            address = None
        if not isinstance(address, str):
            return None, (
                "Bir Outlook hesabının SMTP adresi okunamadı; yapılandırılmış "
                f"'{smtp}' hesabının tekil olduğu doğrulanamadığı için "
                "gönderim yapılmadı.")
        if address.strip().lower() == target:
            matches.append(account)
    if not matches:
        return None, (
            f"Yapılandırılmış kurumsal giden SMTP '{smtp}' Outlook "
            "hesapları arasında bulunamadı; gönderim yapılmadı.")
    if len(matches) > 1:
        return None, (
            f"'{smtp}' SMTP adresine birden fazla Outlook hesabı uyuyor; "
            "hangisinin kullanılacağı belirsiz, gönderim yapılmadı.")
    return matches[0], ""


def _safe(getter, default=""):
    """COM özelliği okunamazsa varsayılana düş (okuyucu tarafıyla aynı kalıp)."""
    try:
        value = getter()
    except Exception:  # noqa: BLE001 - COM her özellikte patlayabilir
        return default
    return default if value is None else value


@dataclass
class OutlookAccount:
    display_name: str = ""
    smtp_address: str = ""


def _require_com():
    """Gümrük kodundaki guard ile birebir aynı kontrol."""
    if pythoncom is None or win32com is None:
        raise RuntimeError(
            "pywin32 kurulu değil. CMD: python -m pip install pywin32"
        )


def get_default_account() -> OutlookAccount:
    """Outlook'a bağlanır. Gümrük uygulamasıyla BİREBİR aynı: yalnızca Dispatch
    + GetNamespace yapılır; hesap bilgisi (Accounts/SmtpAddress) OKUNMAZ.

    Not: ns.Accounts / SmtpAddress erişimi kurumsal Exchange/online-arşiv
    profillerinde sunucuya gidip saniyelerce sürebiliyordu; bağlantı yavaşlığının
    tek sebebi buydu. From, gönderim sırasında Outlook'un varsayılan hesabıyla
    otomatik dolar; adresi burada okumaya gerek yok.
    """
    _require_com()
    pythoncom.CoInitialize()
    try:
        # Gümrükteki collect_folders() ile aynı çağrı; sadece bağlantıyı doğrular.
        win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
        return OutlookAccount()  # boş; ekranda "bağlı ✓" gösterilir
    finally:
        pythoncom.CoUninitialize()


def attach_files(mail, draft: MailDraft) -> List[str]:
    """Taslaktaki dosyaları maile ekler; eklenemeyenlerin gerekçesini döndürür.

    Var olmayan bir dosya sessizce atlanmaz: gerekçe listeye yazılır, çünkü
    eksik ekli bir mutabakat maili karşı tarafa yanlış bilgi verir.
    """
    problems: List[str] = []
    for path in draft.attachments:
        try:
            if not Path(path).is_file():
                problems.append(f"{draft.code}: ek dosya bulunamadı — {path}")
                continue
            mail.Attachments.Add(str(Path(path).resolve()))
        except Exception as exc:  # noqa: BLE001 - COM hatası maili çökertmesin
            problems.append(f"{draft.code}: ek eklenemedi ({path}) — {exc}")
    return problems


def preview_mail(draft: MailDraft) -> None:
    """Tek maili göndermeden Outlook penceresinde açar (Display).

    Gümrük kodundaki COM kalıbıyla birebir aynı; ekler de iliştirilir.
    """
    _require_com()
    pythoncom.CoInitialize()
    try:
        app = win32com.client.Dispatch("Outlook.Application")
        mail = app.CreateItem(OL_MAIL_ITEM)
        mail.To = "; ".join(draft.to)
        if draft.cc:
            mail.CC = "; ".join(draft.cc)
        mail.Subject = draft.subject
        mail.Body = draft.body
        attach_files(mail, draft)
        mail.Display(False)
    finally:
        pythoncom.CoUninitialize()


# -- gönderim durum makinesi ---------------------------------------------------
#
# NEDEN "UNKNOWN" AYRI BİR DURUM
#     ``mail.Send()`` bir COM istisnası fırlattığında mailin GİTMEDİĞİ
#     ANLAMINA GELMEZ. Outlook öğeyi giden kutusuna almış, Exchange'e
#     teslim etmiş ve istisna sonraki bir adımda (örneğin özellik okuma ya
#     da profil hatası) oluşmuş olabilir. Bu sonucu "FAILED" sayıp yeniden
#     denemek, firmaya İKİNCİ bir mutabakat mektubu göndermek demektir ve
#     geri alınamaz.
#
#     Bu yüzden belirsiz sonuç ``SEND_UNKNOWN`` olarak işaretlenir:
#       * otomatik yeniden gönderim YAPILMAZ,
#       * Gönderilmiş Öğeler üzerinden doğrulama denenir,
#       * çözülemezse kayıt insan incelemesine düşer.
STATUS_SENT = "SENT"                    # gönderim ONAYLANDI
STATUS_FAILED = "FAILED"                # gönderim KESİN başarısız (mail oluşmadı)
STATUS_SKIPPED = "SKIPPED"              # kasıtlı atlandı
STATUS_UNKNOWN = "SEND_UNKNOWN"         # gitmiş OLABİLİR — tekrar gönderME
STATUS_DRAFTED = "DRAFTED"              # taslak açıldı; gönderim kullanıcıda

# Send() ÇAĞRILMADAN önce oluşan hatalar kesin başarısızlıktır: ortada
# gönderilmiş bir mail yoktur, tekrar denemek güvenlidir.
_PRE_SEND_FAILURE = STATUS_FAILED


@dataclass
class SendResult:
    """Tek bir taslağın gönderim sonucu.

    Toplu gönderimde yalnızca "kaç tane gitti" bilgisi yetmiyordu: 3000 mailin
    ortasında hata olunca hangi firmaya gittiği bilinemiyor, baştan başlamak
    bazı firmalara İKİNCİ kez mektup gönderiyordu. Bu yüzden her taslak için
    ayrı sonuç döndürülür ve günlüğe yazılır.
    """

    code: str
    status: str                     # SENT | FAILED | SKIPPED | SEND_UNKNOWN
    reason: str = ""

    # -- takip kimlikleri (gelen cevabı BU maile bağlamak için) -------------
    # Konu satırı tek başına yeterli değildir. Bu kimlikler mail günlüğüne
    # yazılır; firmanın cevabı geldiğinde In-Reply-To / ConversationID
    # üzerinden doğru mutabakata KESİN olarak bağlanır.
    message_id: str = ""            # InternetMessageID (aktarımdan sonra oluşur)
    conversation_id: str = ""       # zincir kimliği (kayıtta oluşur)
    entry_id: str = ""              # yerel Outlook kimliği (Gönderilmiş Öğeler)
    recipients: str = ""             # Reply-All'in gerçek To alanı
    cc: str = ""                     # Reply-All'in gerçek CC alanı
    subject: str = ""                # taşınmış öğeyi yeniden bulma kanıtı

    @property
    def sent(self) -> bool:
        return self.status == STATUS_SENT

    @property
    def unknown(self) -> bool:
        """Gitmiş OLABİLİR — otomatik tekrar gönderim YASAK."""
        return self.status == STATUS_UNKNOWN

    @property
    def safe_to_retry(self) -> bool:
        """Bu firmaya yeniden göndermek güvenli mi?

        Yalnızca KESİN başarısızlıkta güvenlidir. Belirsiz sonuçta yeniden
        göndermek mükerrer mutabakat mektubu üretir.
        """
        return self.status == STATUS_FAILED


def _read_property(mail, tag: str) -> str:
    """MAPI özelliğini oku; okunamazsa boş döndür (COM her an patlayabilir)."""
    try:
        value = mail.PropertyAccessor.GetProperty(tag)
    except Exception:  # noqa: BLE001 - özellik yoksa/erişilemezse sorun değil
        return ""
    return "" if value is None else str(value)


def _capture_ids_and_send(mail) -> dict:
    """Maili gönder ve takip kimliklerini yakala.

    NEDEN KAYDEDİP GÖNDERİYORUZ
        Outlook ``ConversationID``yi ancak öğe KAYDEDİLDİĞİNDE üretir. Bu
        kimlik olmadan firmanın cevabı yalnızca "gönderen + konu" gibi zayıf
        bir ipucuyla bağlanabiliyordu; konu değişirse cevap kaybolurdu.

        ``InternetMessageID`` ise aktarım katmanında oluşur ve genelde
        gönderimden ÖNCE boştur. Gönderimden sonra okunmaya çalışılır; yine
        boşsa Gönderilmiş Öğeler üzerinden sonradan tamamlanabilir
        (bkz. ``resolve_sent_message_ids``).

    Kimlik okunamazsa gönderim YİNE YAPILIR — takip bilgisi mailden önemli
    değildir. Kaydetme sonrası hata olursa taslak Taslaklar klasöründe
    kalmasın diye silinmeye çalışılır.
    """
    ids = {"message_id": "", "conversation_id": "", "entry_id": "",
           "status": STATUS_SENT, "reason": ""}
    try:
        mail.Save()
        ids["conversation_id"] = str(_safe(lambda: mail.ConversationID, ""))
        ids["entry_id"] = str(_safe(lambda: mail.EntryID, ""))
    except Exception:  # noqa: BLE001 - kaydedilemezse kimliksiz devam
        pass

    try:
        mail.Send()
    except Exception as exc:  # noqa: BLE001
        # BURASI KRİTİK.
        #
        # ``Send()`` istisnası "mail gitmedi" DEMEK DEĞİLDİR. Öğe giden
        # kutusuna alınmış ve teslim edilmiş olabilir. Eskiden burada iki
        # tehlikeli şey yapılıyordu:
        #
        #   1) ``mail.Delete()`` — GÖNDERİLMİŞ olabilecek bir öğeyi siler ve
        #      Gönderilmiş Öğeler'den doğrulama şansını da yok eder.
        #   2) Sonucu FAILED sayma — çağıran taraf yeniden gönderir ve firma
        #      İKİNCİ mutabakat mektubunu alır (geri alınamaz).
        #
        # Artık öğe SİLİNMEZ ve sonuç SEND_UNKNOWN'dır: doğrulama denenir,
        # çözülemezse kayıt insan incelemesine düşer.
        ids["status"] = STATUS_UNKNOWN
        ids["reason"] = (
            f"Send() hata verdi ({exc}). Mail GÖNDERİLMİŞ OLABİLİR; "
            "mükerrer mektup riskine karşı otomatik tekrar gönderim "
            "yapılmadı. Gönderilmiş Öğeler kontrol edilmeli.")
        # Kimlikler doğrulama için hâlâ değerlidir; okumayı dene.
        ids["message_id"] = _read_property(mail, PR_INTERNET_MESSAGE_ID)
        if not ids["conversation_id"]:
            ids["conversation_id"] = str(_safe(lambda: mail.ConversationID, ""))
        return ids

    # Gönderimden sonra öğe genelde Gönderilmiş Öğeler'e taşınır ve bu referans
    # geçersizleşebilir; bu yüzden okuma DENENİR, başarısızlığı sorun değildir.
    ids["message_id"] = _read_property(mail, PR_INTERNET_MESSAGE_ID)
    if not ids["conversation_id"]:
        ids["conversation_id"] = str(_safe(lambda: mail.ConversationID, ""))
    return ids


def confirm_in_sent_items(entry_id: str, folder=None) -> bool:
    """Belirsiz kalan bir gönderim Gönderilmiş Öğeler'de var mı?

    ``True``  → mail GERÇEKTEN gitti (SEND_UNKNOWN → SENT'e yükseltilebilir).
    ``False`` → doğrulanamadı. Bu "gitmedi" DEMEK DEĞİLDİR; öğe henüz
                senkronize olmamış, başka klasöre taşınmış ya da Exchange
                gecikmiş olabilir. Bu yüzden ``False`` asla otomatik yeniden
                gönderime gerekçe yapılmaz.
    """
    if not entry_id:
        return False
    owns_com = folder is None
    if owns_com:
        _require_com()
        pythoncom.CoInitialize()
    try:
        if folder is None:
            namespace = win32com.client.Dispatch(
                "Outlook.Application").GetNamespace("MAPI")
            folder = namespace.GetDefaultFolder(OL_FOLDER_SENT_ITEMS)
        try:
            item = folder.Session.GetItemFromID(entry_id)
        except Exception:  # noqa: BLE001 - öğe yok/erişilemiyor
            return False
        # ÖĞENİN VAR OLMASI GÖNDERİLDİĞİ ANLAMINA GELMEZ.
        #
        # ``Session.GetItemFromID`` öğeyi MAĞAZADAN getirir, klasörden
        # değil: Taslaklar'da bekleyen bir mail de bulunur ve eskiden
        # "gönderildi" sayılıyordu. Gönderilmemiş bir taslak üzerinden
        # zincir ilerletilirse sonraki hatırlatma firmanın hiç görmediği
        # bir mailin üstüne yazılır.
        return item is not None and _is_sent_item(item, folder)
    finally:
        if owns_com:
            pythoncom.CoUninitialize()


def _is_sent_item(item, sent_folder=None) -> bool:
    """Öğe GERÇEKTEN gönderilmiş mi? (taslak değil)

    İki bağımsız kanıt aranır; biri okunamazsa diğeri karar verir:
      * ``Sent`` özelliği — Outlook öğe gönderildiğinde True yapar,
      * öğenin bulunduğu klasör Gönderilmiş Öğeler mi.

    Hiçbiri okunamıyorsa ``False`` döner: belirsizlikte "gönderildi"
    varsayılmaz.
    """
    gonderildi = _safe(lambda: item.Sent, None)
    if gonderildi is True:
        return True
    if gonderildi is False:
        return False
    try:
        parent_id = str(_safe(lambda: item.Parent.EntryID, "") or "")
        hedef_id = str(_safe(lambda: sent_folder.EntryID, "") or "")
    except Exception:  # noqa: BLE001
        return False
    return bool(parent_id and hedef_id and parent_id == hedef_id)


@dataclass(frozen=True)
class SentIdentity:
    """Gönderilmiş öğeden YENİDEN OKUNAN takip kimlikleri.

    NEDEN YENİDEN OKUNUR
        Gönderim anındaki kimlikler eksik ya da geçicidir:

          * ``EntryID`` taslağa aittir. Öğe Gönderilmiş Öğeler'e TAŞINDIĞINDA
            değişir; eski kimlikle yapılan "Reply-All" ya hiç öğe bulamaz ya
            da (mağaza yeniden kullanmışsa) BAŞKA bir öğeye düşer.
          * ``InternetMessageID`` aktarım katmanında doğar; gönderimden önce
            çoğu zaman BOŞTUR.
          * ``ConversationID`` kayıtta doğar ama öğe taşınırken okunamamış
            olabilir.

        Bu üçü gönderilmiş öğeden birlikte okunursa, hatırlatma zincirinin
        yanlış/eski bir maile bağlanma ihtimali ortadan kalkar.
    """

    entry_id: str = ""
    message_id: str = ""
    conversation_id: str = ""
    #: Öğe Gönderilmiş Öğeler'de BULUNDU ve gerçekten gönderilmiş.
    verified: bool = False


def identity_key(entry) -> str:
    """Bir gönderim sonucunun kimlik sözlüğündeki anahtarı.

    Öncelik gönderim anındaki ``entry_id``dir. Yoksa firma kodu + konu
    kullanılır; iki alan da boşsa kayıt eşleştirilemez ve atlanır.
    """
    entry_id = str(getattr(entry, "entry_id", "") or "")
    if entry_id:
        return entry_id
    code = str(getattr(entry, "code", "") or "")
    subject = str(getattr(entry, "subject", "") or "")
    return f"{code}|{subject}" if (code or subject) else ""


def resolve_sent_identity(entries, folder=None) -> dict:
    """Gönderilmiş Öğeler'den EntryID + Message-ID + ConversationID oku.

    Döner: ``{identity_key(entry): SentIdentity}``. Öğesi bulunamayan kayıt
    sözlüğe HİÇ girmez — "bulunamadı" ile "boş kimlik" karıştırılmaz.

    BEST-EFFORT: COM hatası gönderimi etkilemez, yalnızca kimlik tamamlanmaz.
    """
    wanted = [e for e in entries
              if (getattr(e, "sent", False)
                  or getattr(e, "status", "") == STATUS_UNKNOWN)
              and identity_key(e)]
    if not wanted:
        return {}

    owns_com = folder is None
    if owns_com:
        _require_com()
        pythoncom.CoInitialize()
    resolved: dict = {}
    try:
        if folder is None:
            namespace = win32com.client.Dispatch(
                "Outlook.Application").GetNamespace("MAPI")
            folder = namespace.GetDefaultFolder(OL_FOLDER_SENT_ITEMS)
        for entry in wanted:
            item = None
            eski_id = str(getattr(entry, "entry_id", "") or "")
            if eski_id:
                try:
                    item = folder.Session.GetItemFromID(eski_id)
                except Exception:  # noqa: BLE001 - öğe taşınmış/silinmiş
                    item = None
            # Öğe bulunsa bile GÖNDERİLMİŞ olduğu doğrulanmalıdır: Taslaklar'da
            # duran bir öğe üzerinden zincir ilerletilirse sonraki hatırlatma
            # firmanın HİÇ GÖRMEDİĞİ bir mailin altına düşer.
            if item is None or not _is_sent_item(item, folder):
                item = _unique_sent_item_by_fingerprint(folder, entry)
            if item is None or not _is_sent_item(item, folder):
                continue
            resolved[identity_key(entry)] = SentIdentity(
                entry_id=str(_safe(lambda: item.EntryID, "") or ""),
                message_id=_read_property(item, PR_INTERNET_MESSAGE_ID),
                conversation_id=str(_safe(lambda: item.ConversationID, "") or ""),
                verified=True,
            )
    except Exception as exc:  # noqa: BLE001 - kimlik tamamlama maili bozmaz
        logger.warning(f"[outlook] gönderilmiş öğe kimlikleri okunamadı: {exc}")
    finally:
        if owns_com:
            pythoncom.CoUninitialize()
    return resolved


def resolve_sent_message_ids(entries, folder=None) -> dict:
    """Gönderilmiş Öğeler'den eksik ``InternetMessageID``leri tamamla.

    Gönderim anında Message-ID çoğu zaman henüz oluşmamıştır. Bu yardımcı,
    ``entry_id`` bilinen kayıtlar için Gönderilmiş Öğeler'deki asıl öğeyi bulup
    kimliği okur. Döner: ``{entry_id: message_id}``.

    ``folder`` verilmezse Outlook'un Gönderilmiş Öğeler klasörü kullanılır;
    testlerde sahte bir klasör verilebilir.
    """
    wanted = [e for e in entries if getattr(e, "entry_id", "")
              and not getattr(e, "message_id", "")]
    if not wanted:
        return {}

    owns_com = folder is None
    if owns_com:
        _require_com()
        pythoncom.CoInitialize()
    resolved: dict = {}
    try:
        if folder is None:
            namespace = win32com.client.Dispatch(
                "Outlook.Application").GetNamespace("MAPI")
            folder = namespace.GetDefaultFolder(OL_FOLDER_SENT_ITEMS)
        for entry in wanted:
            try:
                item = folder.Session.GetItemFromID(entry.entry_id)
            except Exception:  # noqa: BLE001 - öğe taşınmış/silinmiş olabilir
                item = _unique_sent_item_by_fingerprint(folder, entry)
            if item is None:
                continue
            message_id = _read_property(item, PR_INTERNET_MESSAGE_ID)
            if message_id:
                resolved[entry.entry_id] = message_id
    finally:
        if owns_com:
            pythoncom.CoUninitialize()
    return resolved


def _unique_sent_item_by_fingerprint(folder, entry):
    """Eski EntryID sonrası konu+alıcıyla TEK gönderilmiş öğeyi bul."""
    subject = str(getattr(entry, "subject", "") or "").strip()
    recipients = {
        a.strip().lower()
        for a in str(getattr(entry, "recipients", "") or "")
        .replace(",", ";").split(";") if "@" in a
    }
    if not subject or not recipients:
        return None
    try:
        items = folder.Items
        try:
            items.Sort("[SentOn]", True)
        except Exception:  # noqa: BLE001
            pass
        matches = []
        for i in range(1, min(int(_safe(lambda: items.Count, 0)), 200) + 1):
            candidate = items.Item(i)
            if str(_safe(lambda c=candidate: c.Subject, "") or "").strip() != subject:
                continue
            if not (_item_recipients(candidate) & recipients):
                continue
            if _is_sent_item(candidate, folder):
                matches.append(candidate)
                if len(matches) > 1:
                    return None
        return matches[0] if len(matches) == 1 else None
    except Exception:  # noqa: BLE001
        return None


def _before_send_block(on_before_send, code: str) -> str:
    """``on_before_send`` kapısı. FAIL-CLOSED.

    Döner: ``""`` -> gönderilebilir; dolu metin -> GÖNDERİLMEZ ve gerekçesi.
    Kanca ``False`` dönerse ya da istisna verirse mail gönderilmez: gönderim
    öncesi kalıcı kayıt yazılamadıysa, süreç ``Send()`` sırasında ölürse
    "gitti mi?" bilgisi kaybolur ve yeniden başlatmada mükerrer mektup çıkar.
    """
    if on_before_send is None:
        return ""
    try:
        izin = on_before_send(code)
    except Exception as exc:  # noqa: BLE001 - kapı hatası = GÖNDERME
        return ("gönderim öncesi kayıt yazılamadı "
                f"({exc}); mükerrer mektup riskine karşı gönderilmedi.")
    if izin is False:
        return ("gönderim öncesi kayıt alınamadı veya bu gönderim zaten "
                "kayıtlı; mükerrer mektup riskine karşı gönderilmedi.")
    return ""


def send_with_results(drafts: List[MailDraft],
                      skip_unsendable: bool = True,
                      on_progress=None,
                      should_cancel=None,
                      on_result=None,
                      on_before_send=None,
                      *,
                      outgoing_smtp: str = "") -> List[SendResult]:
    """Taslakları gönderir ve HER BİRİ için ayrı sonuç döndürür.

    Gümrük kodundaki COM kalıbı korunur: tek CoInitialize/CoUninitialize
    sarmalayıcısı içinde tüm öğeler işlenir.

    ``on_progress(index, total, code)`` verilirse her mailden sonra çağrılır.
    ``should_cancel()`` True dönerse, o ana kadarki sonuçlarla ÇIKILIR —
    gönderilmiş mailler geri alınmaz, gönderilmemişler hiç denenmez. Kayıt
    günlüğü sayesinde kalınan yerden devam edilebilir.

    ``on_before_send(code)`` (isteğe bağlı) ``Send()`` ÇAĞRILMADAN hemen önce
    çağrılır ve gönderim öncesi kalıcı kaydı (write-ahead) yazar. ``False``
    dönerse ya da istisna verirse o firmaya mail GÖNDERİLMEZ (SKIPPED).
    Verilmezse davranış eskisiyle aynıdır.

    ``outgoing_smtp`` AÇIK bağımlılıktır (Settings.outgoing_mailbox_smtp):
    gönderim yalnız bu SMTP'ye sahip tek Outlook ``Account`` ile yapılır ve
    her öğeye ``SendUsingAccount`` atanır. Boş/okunamayan/eşleşmeyen/çoklu
    eşleşme durumunda HİÇBİR öğe oluşturulmaz (``CreateItem``/``Save``/
    ``Send`` çağrılmaz), her taslak SKIPPED döner.
    """
    _require_com()
    results: List[SendResult] = []
    total = len(drafts)
    pythoncom.CoInitialize()
    try:
        app = win32com.client.Dispatch("Outlook.Application")
        namespace = app.GetNamespace("MAPI")
        offline_block = _outlook_send_block(namespace)
        send_account = None
        if not offline_block:
            send_account, offline_block = _outgoing_account(
                namespace, outgoing_smtp)
        for i, d in enumerate(drafts, start=1):
            # İptal kontrolü mail GÖNDERİLMEDEN önce yapılır: yarım gönderilmiş
            # bir mail diye bir şey olmasın.
            if should_cancel is not None and should_cancel():
                break
            if d.invalid_recipients:
                results.append(SendResult(
                    d.code, STATUS_SKIPPED,
                    "geçersiz e-posta adresi: " + ", ".join(d.invalid_recipients)))
            elif skip_unsendable and not d.sendable:
                # Gerekçe taslağın kendisinden gelir: hangi firmanın NEDEN
                # atlandığı tek bir yerde tanımlıdır (MailDraft.skip_reason).
                reason = d.skip_reason or "gönderilemez taslak, atlandı."
                if d.needs_confirmation:
                    reason += (" Göndermek için firmayı seçip tek tek "
                               "gönderin.")
                results.append(SendResult(d.code, "SKIPPED", reason))
            elif offline_block:
                results.append(SendResult(d.code, STATUS_SKIPPED, offline_block))
            else:
                try:
                    mail = app.CreateItem(OL_MAIL_ITEM)
                    # Hesap, başka hiçbir alandan ÖNCE atanır; atanamazsa
                    # istisna Send()'den önce düşer ve mail gitmez.
                    mail.SendUsingAccount = send_account
                    mail.To = "; ".join(d.to)
                    if d.cc:
                        mail.CC = "; ".join(d.cc)
                    mail.Subject = d.subject
                    mail.Body = d.body

                    # Ek dosyalar: biri bile eksikse mail GÖNDERİLMEZ. Eksik
                    # ekli bir mutabakat maili karşı tarafa yanlış bilgi verir
                    # ve geri alınamaz.
                    problems = attach_files(mail, d)
                    if problems:
                        results.append(SendResult(
                            d.code, STATUS_SKIPPED,
                            "ekler tamamlanamadı: " + "; ".join(problems)))
                    elif (engel := _before_send_block(on_before_send, d.code)):
                        results.append(SendResult(d.code, STATUS_SKIPPED, engel))
                    else:
                        ids = _capture_ids_and_send(mail)
                        results.append(SendResult(
                            d.code, ids.get("status", STATUS_SENT),
                            reason=ids.get("reason", ""),
                            message_id=ids.get("message_id", ""),
                            conversation_id=ids.get("conversation_id", ""),
                            entry_id=ids.get("entry_id", ""),
                            recipients="; ".join(d.to),
                            cc="; ".join(d.cc), subject=d.subject))
                except Exception as e:  # noqa: BLE001
                    # Buraya YALNIZCA Send() ÇAĞRILMADAN önceki adımlar
                    # (CreateItem, alan atama, ek iliştirme) düşer. Ortada
                    # gönderilmiş bir mail yoktur; tekrar denemek güvenlidir.
                    results.append(SendResult(d.code, _PRE_SEND_FAILURE,
                                              f"gönderim hazırlanamadı — {e}"))
            # SONUÇ ANINDA BİLDİRİLİR: kalıcı kuyruk her mailden hemen sonra
            # güncellensin diye. Parti sonunda toplu yazmak, uygulama ortada
            # kapandığında "hangisi gitti?" bilgisini kaybettirirdi.
            if on_result is not None and results:
                try:
                    on_result(results[-1])
                except Exception as exc:  # noqa: BLE001 - kayıt maili bozmaz
                    logger.warning(f"[outlook] sonuç bildirilemedi: {exc}")
            if on_progress is not None:
                try:
                    on_progress(i, total, d.code)
                except Exception:  # noqa: BLE001 - ilerleme bildirimi kritik değil
                    pass
    finally:
        pythoncom.CoUninitialize()
    return results


def send_all_mails(drafts: List[MailDraft],
                   skip_unsendable: bool = True,
                   *, outgoing_smtp: str = "") -> tuple[int, List[str]]:
    """Tüm taslakları gönderir (geriye dönük uyumlu özet biçim).

    Dönüş: (gönderilen sayısı, atlanan/başarısızların gerekçe listesi).
    Ayrıntılı sonuç için ``send_with_results`` kullanın.
    """
    results = send_with_results(drafts, skip_unsendable=skip_unsendable,
                                outgoing_smtp=outgoing_smtp)
    sent = sum(1 for r in results if r.sent)
    skipped = [f"{r.code}: {r.reason}" for r in results if not r.sent]
    return sent, skipped


# --- UI'nin beklediği ince sarmalayıcı sınıf ---------------------------------
# (mailing_page.py OutlookClient() bekliyor; iç yapı yukarıdaki gümrük-birebir
#  fonksiyonları çağırır. Böylece hem UI değişmez hem yapı gümrükle aynı olur.)
class OutlookUnavailable(RuntimeError):
    """Geriye dönük uyum için; _require_com RuntimeError fırlatır."""


class OutlookClient:
    def __init__(self) -> None:
        self._account = OutlookAccount()

    def connect(self) -> OutlookAccount:
        self._account = get_default_account()
        return self._account

    def preview(self, draft: MailDraft) -> None:
        preview_mail(draft)

    def send_one(self, draft: MailDraft, *, outgoing_smtp: str = "") -> None:
        send_all_mails([draft], outgoing_smtp=outgoing_smtp)

    def send_all(self, drafts: List[MailDraft],
                 skip_unsendable: bool = True,
                 *, outgoing_smtp: str = "") -> tuple[int, List[str]]:
        return send_all_mails(drafts, skip_unsendable=skip_unsendable,
                              outgoing_smtp=outgoing_smtp)

# ---------------------------------------------------------------------------
# FAZ 11 — thread üzerinden cevap (Reply-All)
# ---------------------------------------------------------------------------

@dataclass
class ReplyRequest:
    """Var olan bir mail zincirine verilecek cevap.

    Hatırlatma ve fark talebi YENİ MAİL DEĞİLDİR: firma aynı konu altında
    kendi cevabını görebilmelidir. Bu yüzden zincirdeki öğe bulunur ve
    ``ReplyAll`` ile devam edilir — konu, alıcılar ve geçmiş korunur.
    """

    body: str
    conversation_id: str = ""
    message_id: str = ""
    entry_id: str = ""
    attachments: List[str] = field(default_factory=list)
    extra_recipients: List[str] = field(default_factory=list)
    code: str = ""

    # -- DOĞRULAMA VERİSİ (§3) ---------------------------------------------
    # ConversationID TEKİL DEĞİLDİR. Zincirden bulunan öğenin gerçekten bu
    # vakaya ait olduğu, GERÇEK OUTLOOK ÖĞESİ üzerinden doğrulanır: alıcı
    # adresleri kesişiyor mu, konu firma kodunu/dönemi taşıyor mu.
    # Doğrulanamayan bir zincire cevap YAZILMAZ.
    expected_recipients: List[str] = field(default_factory=list)
    period: str = ""
    expected_subject: str = ""

    @property
    def has_target(self) -> bool:
        return bool(self.conversation_id or self.message_id or self.entry_id)


def _dasl_quote(value: str) -> str:
    """DASL/Jet sorgusunda tek tırnak içine konacak değeri güvenli hâle getir.

    NEDEN GEREKLİ
        ``message_id`` KARŞI TARAFTAN gelir (mailin RFC 5322 başlığı). İçinde
        tek tırnak olan bir değer doğrudan sorguya eklenirse sorgu kırılır ve
        yanlış öğe bulunabilir: Reply-All YANLIŞ mail zincirine yazılır ve
        bir firmanın mutabakat verisi başka firmaya gider.

    Jet/DASL'de tek tırnak İKİYE KATLANARAK kaçırılır. Satır sonu gibi
    denetim karakterleri sorguda anlamsızdır ve temizlenir.
    """
    text = str(value or "")
    text = "".join(ch for ch in text if ch >= " " and ch != "")
    return text.replace("'", "''")


#: PR_SMTP_ADDRESS — Exchange alıcısının gerçek SMTP karşılığı.
PR_SMTP_ADDRESS = "http://schemas.microsoft.com/mapi/proptag/0x39FE001F"


def _smtp_of(recipient) -> str:
    """Exchange/X500 alıcısının SMTP adresi; çözülemezse boş."""
    adres = str(_safe(
        lambda: recipient.PropertyAccessor.GetProperty(PR_SMTP_ADDRESS),
        "") or "").strip().lower()
    if "@" in adres:
        return adres
    return str(_safe(
        lambda: recipient.AddressEntry.GetExchangeUser().PrimarySmtpAddress,
        "") or "").strip().lower()


def _item_recipients(item) -> set:
    """Öğenin alıcı SMTP adresleri (küçük harf). Okunamazsa boş küme."""
    out = set()
    for alan in ("To", "CC"):
        metin = str(_safe(lambda a=alan: getattr(item, a), "") or "")
        for parca in metin.replace(",", ";").split(";"):
            adres = parca.strip().lower()
            if "@" in adres:
                out.add(adres)
    try:
        alicilar = item.Recipients
        for i in range(1, int(_safe(lambda: alicilar.Count, 0)) + 1):
            r = alicilar.Item(i)
            adres = str(_safe(lambda: r.Address, "") or "").strip().lower()
            if "@" not in adres:
                # EXCHANGE/X500 ADRESİ (/O=.../CN=RECIPIENTS/CN=...).
                # SMTP karşılığı çözülmezse kurum içi alıcılar denetimde
                # görünmez ve alıcı doğrulaması sessizce zayıflar.
                adres = _smtp_of(r)
            if "@" in adres:
                out.add(adres)
    except Exception:  # noqa: BLE001 - alıcı listesi okunamayabilir
        pass
    return out


def _own_smtp_addresses(namespace) -> set[str]:
    """Açık Outlook profilindeki hesapların doğrulanabilen SMTP adresleri."""
    out: set[str] = set()
    try:
        accounts = namespace.Accounts
        for i in range(1, int(_safe(lambda: accounts.Count, 0)) + 1):
            account = accounts.Item(i)
            address = str(_safe(lambda: account.SmtpAddress, "") or "").strip().lower()
            if "@" in address:
                out.add(address)
    except Exception:  # noqa: BLE001 - hesap koleksiyonu sağlayıcıya bağlıdır
        pass
    return out


def _remove_own_recipients(reply, namespace) -> list[str]:
    """Reply-All'ın eklediği kendi hesaplarımızı alıcı listesinden çıkar."""
    own = _own_smtp_addresses(namespace)
    removed: list[str] = []
    if not own:
        return removed
    try:
        recipients = reply.Recipients
        # Silme sırasında indeksler kaydığı için sondan başa ilerlenir.
        for i in range(int(_safe(lambda: recipients.Count, 0)), 0, -1):
            recipient = recipients.Item(i)
            address = str(_safe(lambda: recipient.Address, "") or "").strip().lower()
            if "@" not in address:
                address = _smtp_of(recipient)
            if address in own:
                recipient.Delete()
                removed.append(address)
    except Exception:  # noqa: BLE001 - doğrulanamıyorsa mevcut alıcılar korunur
        return removed
    return removed


_MONTHS = {
    "january": 1, "ocak": 1, "february": 2, "şubat": 2, "subat": 2,
    "march": 3, "mart": 3, "april": 4, "nisan": 4, "may": 5,
    "mayıs": 5, "mayis": 5, "june": 6, "haziran": 6, "july": 7,
    "temmuz": 7, "august": 8, "ağustos": 8, "agustos": 8,
    "september": 9, "eylül": 9, "eylul": 9, "october": 10, "ekim": 10,
    "november": 11, "kasım": 11, "kasim": 11, "december": 12,
    "aralık": 12, "aralik": 12,
}


def _subject_periods(subject: str) -> set[str]:
    """Konu içindeki açık yıl-ay işaretlerini ``YYYY-MM`` biçimine çevir."""
    text = str(subject or "").lower()
    out = set(re.findall(r"\b(20\d{2}-(?:0[1-9]|1[0-2]))\b", text))
    for day, month, year in re.findall(
            r"\b([0-3]?\d)[./-](0?[1-9]|1[0-2])[./-](20\d{2})\b", text):
        out.add(f"{year}-{int(month):02d}")
    for name, month in _MONTHS.items():
        for year in re.findall(rf"\b{re.escape(name)}\s+(20\d{{2}})\b", text):
            out.add(f"{year}-{month:02d}")
        for year in re.findall(rf"\b(20\d{{2}})\s+{re.escape(name)}\b", text):
            out.add(f"{year}-{month:02d}")
    return out


def _subject_key(subject: str) -> str:
    text = re.sub(r"^(?:(?:re|fw|fwd)\s*:\s*)+", "", str(subject or ""),
                  flags=re.IGNORECASE)
    return " ".join(text.casefold().split())


def verify_item(item, request: "ReplyRequest") -> tuple:
    """Bulunan öğe GERÇEKTEN bu vakaya mı ait? (uygun_mu, gerekçe)

    Vaka alanlarının dolu olması KANIT DEĞİLDİR; kanıt, Outlook'taki
    öğenin kendisinden gelmelidir:

      * alıcı adresleri vakanın alıcılarıyla KESİŞMELİ, ya da
      * konu firma kodunu (ve varsa dönemi) taşımalı.

    Hiçbiri doğrulanamazsa zincir REDDEDİLİR — aynı ConversationID
    altında başka bir firmanın yazışması olabilir.
    """
    konu = str(_safe(lambda: item.Subject, "") or "")
    beklenen = {a.strip().lower() for a in request.expected_recipients
                if a and "@" in a}
    gercek = _item_recipients(item)

    donemler = _subject_periods(konu)
    if request.period and donemler and request.period not in donemler:
        return False, "zincirdeki mail farklı bir döneme ait görünüyor"

    if beklenen and gercek:
        if beklenen & gercek:
            return True, "alıcı eşleşti"
        return False, (
            "zincirdeki mailin alıcıları vakanın alıcılarıyla EŞLEŞMİYOR "
            "(aynı konuşmada başka bir firma olabilir)")

    if request.expected_subject and (
            _subject_key(request.expected_subject) == _subject_key(konu)):
        return True, "konu birebir eşleşti"

    if request.code and re.search(
            rf"(?<!\d){re.escape(request.code)}(?!\d)", konu):
        return True, "konu firma kodunu taşıyor"

    return False, (
        "zincirdeki mail bu vakaya ait olduğu DOĞRULANAMADI "
        "(alıcı ya da firma kodu eşleşmesi bulunamadı)")


def _verified_conversation_item(items, request: "ReplyRequest"):
    """Conversation zincirindeki DOĞRULANMIŞ en yeni öğeyi seç.

    ``Find`` yalnızca ilk eşleşmeyi verir ve o, Gelen Kutusu'ndaki
    rastgele bir mesaj olabilir. Burada adaylar sırayla gezilir, her biri
    doğrulanır; farklı firmalara ait çelişkili adaylar bulunursa hiçbiri
    seçilmez (belirsizlikte gönderim YAPILMAZ).
    """
    try:
        items.Sort("[ReceivedTime]", True)      # en yeni önce
    except Exception:  # noqa: BLE001
        pass
    sorgu = "[ConversationID] = '" + _dasl_quote(request.conversation_id) + "'"
    try:
        aday = items.Find(sorgu)
    except Exception:  # noqa: BLE001 - sağlayıcı desteklemiyor olabilir
        return None, "conversation sorgusu çalıştırılamadı"

    dogrulanan = []
    reddedilen = 0
    while aday is not None:
        uygun, _gerekce = verify_item(aday, request)
        if uygun:
            dogrulanan.append(aday)
        else:
            reddedilen += 1
        try:
            aday = items.FindNext()
        except Exception:  # noqa: BLE001
            break

    if dogrulanan:
        if len(dogrulanan) == 1:
            return dogrulanan[0], "doğrulanmış conversation öğesi"
        # Aynı zincirdeki normal Reply-All öğeleri aynı kanonik konuya
        # sahiptir. Farklı konular aynı ConversationID altında birleşmişse
        # ve beklenen konu bunları tekilleştiremiyorsa yanlış dönem/vaka
        # riski nedeniyle gönderim engellenir.
        beklenen_konu = _subject_key(request.expected_subject)
        if beklenen_konu:
            eslesen = [a for a in dogrulanan
                       if _subject_key(_safe(lambda x=a: x.Subject, ""))
                       == beklenen_konu]
            if eslesen:
                return eslesen[0], "beklenen konuyla doğrulanmış conversation öğesi"
        konu_anahtarlari = {
            _subject_key(_safe(lambda x=a: x.Subject, "")) for a in dogrulanan
        }
        if len(konu_anahtarlari) == 1:
            return dogrulanan[0], "aynı konulu doğrulanmış en yeni conversation öğesi"
        return None, "conversation içinde birden fazla farklı konu/vaka adayı var"
    if reddedilen:
        return None, (f"{reddedilen} conversation adayının hiçbiri bu vakaya "
                      "ait olduğu doğrulanamadı")
    return None, "conversation zincirinde öğe bulunamadı"


def _find_thread_item(namespace, request: "ReplyRequest"):
    """Cevaplanacak öğeyi bul: EntryID > Message-ID > ConversationID.

    En güçlü kimlikten zayıfa doğru gidilir. Hiçbiri bulunamazsa None döner
    ve çağıran taraf YENİ MAİL AÇMAZ — sessizce yanlış yere cevap yazmaktansa
    kullanıcıya "zincir bulunamadı" demek doğrudur.
    """
    must_verify = bool(request.expected_recipients or request.expected_subject
                       or request.period)

    if request.entry_id:
        try:
            item = namespace.GetItemFromID(request.entry_id)
            if item is not None:
                if not must_verify:
                    return item
                uygun, _gerekce = verify_item(item, request)
                if uygun:
                    return item
        except Exception:  # noqa: BLE001 - kimlik eskimiş olabilir
            pass

    # GÖNDERİLMİŞ ÖĞELER ÖNCE ARANIR.
    #
    # Aradığımız şey "zincirdeki son mesaj" değil, BİZİM gönderdiğimiz son
    # maildir. Gelen Kutusu önce taranınca firmanın cevabı seçilebiliyor ve
    # hatırlatma yanlış öğenin üzerine kuruluyordu.
    for folder_id in (OL_FOLDER_SENT_ITEMS, OL_FOLDER_INBOX):
        try:
            folder = namespace.GetDefaultFolder(folder_id)
            items = folder.Items
        except Exception:  # noqa: BLE001
            continue

        if request.message_id:
            try:
                found = items.Find(
                    "@SQL=\"http://schemas.microsoft.com/mapi/proptag/"
                    "0x1035001F\" = '"
                    + _dasl_quote(request.message_id) + "'")
                if found is not None:
                    if not must_verify:
                        return found
                    uygun, _gerekce = verify_item(found, request)
                    if uygun:
                        return found
            except Exception:  # noqa: BLE001 - sağlayıcı bu sorguyu desteklemeyebilir
                pass

        if request.conversation_id:
            found, _gerekce = _verified_conversation_item(items, request)
            if found is not None:
                return found
    return None


def reply_all(request: "ReplyRequest", send: bool = False,
              *, outgoing_smtp: str = "") -> "SendResult":
    """Zincire Reply-All ile cevap yaz; ``send=False`` ise yalnızca AÇAR.

    Varsayılan davranış GÖNDERMEMEKtir: kullanıcı metni görmeden fark talebi
    ya da hatırlatma gitmemelidir.

    ``send=True`` iken ``outgoing_smtp`` (Settings.outgoing_mailbox_smtp)
    ZORUNLUDUR: yalnız bu SMTP'ye sahip tek Outlook ``Account`` ile gönderilir
    ve cevaba ``SendUsingAccount`` atanır. Engel varsa ``ReplyAll``/``Save``/
    ``Send`` çağrılmaz. Önizleme (``send=False``) bu kapıya tabi değildir.
    """
    _require_com()
    if not request.has_target:
        return SendResult(request.code, "FAILED",
                          "cevaplanacak mail zinciri bilinmiyor "
                          "(conversation/message/entry id yok)")

    pythoncom.CoInitialize()
    try:
        namespace = win32com.client.Dispatch(
            "Outlook.Application").GetNamespace("MAPI")
        send_account = None
        if send:
            send_block = _outlook_send_block(namespace)
            if not send_block:
                send_account, send_block = _outgoing_account(
                    namespace, outgoing_smtp)
            if send_block:
                return SendResult(request.code, STATUS_SKIPPED, send_block)
        original = _find_thread_item(namespace, request)
        if original is None:
            return SendResult(request.code, "FAILED",
                              "mail zinciri Outlook'ta bulunamadı; "
                              "yeni mail AÇILMADI")

        reply = original.ReplyAll()
        if send:
            # Gönderim hesabı başka hiçbir alandan ÖNCE atanır; atanamazsa
            # istisna Send()'den önce düşer (dış except → FAILED, mail gitmez).
            reply.SendUsingAccount = send_account
        # Robotun metni, Outlook'un ürettiği alıntı gövdesinin ÜSTÜNE yazılır;
        # geçmiş yazışma silinmez.
        try:
            reply.Body = (request.body + chr(10) * 2
                          + str(_safe(lambda: reply.Body, "")))
        except Exception:  # noqa: BLE001
            reply.Body = request.body

        for address in request.extra_recipients:
            if address and address not in str(_safe(lambda: reply.CC, "")):
                reply.CC = (str(_safe(lambda: reply.CC, "")) + "; "
                            + address).strip("; ")

        _remove_own_recipients(reply, namespace)

        actual_to = str(_safe(lambda: reply.To, "") or "")
        actual_cc = str(_safe(lambda: reply.CC, "") or "")

        eksik: List[str] = []
        for path in request.attachments:
            try:
                if not Path(path).is_file():
                    eksik.append(f"ek bulunamadı — {path}")
                    continue
                reply.Attachments.Add(str(Path(path).resolve()))
            except Exception as exc:  # noqa: BLE001
                eksik.append(f"ek eklenemedi ({path}) — {exc}")
        if eksik:
            # Eksik ekli bir fark talebi karşı tarafa yanlış bilgi verir.
            return SendResult(request.code, "SKIPPED",
                              "ekler tamamlanamadı: " + "; ".join(eksik))

        if send:
            # KİMLİK YAKALAMA + SEND_UNKNOWN mantığı ilk gönderimle AYNI
            # koddan gelir (_capture_ids_and_send): önce Save() —
            # ConversationID/EntryID ancak kayıtta doğar — sonra Send(),
            # ardından InternetMessageID okunur.
            #
            # BU KİMLİKLER ZİNCİRİN DEVAMI İÇİN ZORUNLUDUR: bir sonraki
            # hatırlatma İLK mutabakat mailini değil, EN SON gönderdiğimiz
            # maili cevaplamalıdır. Kimlikler döndürülmezse zincir ilk
            # maile çakılı kalır.
            ids = _capture_ids_and_send(reply)
            return SendResult(
                request.code, ids["status"], ids.get("reason", ""),
                message_id=ids.get("message_id", ""),
                conversation_id=ids.get("conversation_id", ""),
                entry_id=ids.get("entry_id", ""),
                recipients=actual_to, cc=actual_cc,
                subject=str(_safe(lambda: original.Subject, "") or ""),
            )

        # ÖNİZLEME: gönderilmez ama taslak KAYDEDİLİR ki EntryID doğsun;
        # kullanıcı Outlook'tan gönderirse zincir yine takip edilebilir.
        entry_id = conversation_id = ""
        try:
            reply.Save()
            conversation_id = str(_safe(lambda: reply.ConversationID, ""))
            entry_id = str(_safe(lambda: reply.EntryID, ""))
        except Exception:  # noqa: BLE001 - kaydedilemezse önizleme yine açılır
            pass
        reply.Display(False)
        return SendResult(request.code, STATUS_DRAFTED,
                          "önizleme açıldı; gönderim kullanıcıya bırakıldı",
                          conversation_id=conversation_id, entry_id=entry_id,
                          recipients=actual_to, cc=actual_cc)
    except Exception as exc:  # noqa: BLE001 - COM hatası uygulamayı düşürmez
        return SendResult(request.code, "FAILED", f"cevap hatası — {exc}")
    finally:
        pythoncom.CoUninitialize()


# ---------------------------------------------------------------------------
# Taslak / belirsiz gönderim doğrulaması (§2, §3)
# ---------------------------------------------------------------------------

@dataclass
class VerifyResult:
    """Bir taslağın ya da belirsiz gönderimin Outlook'taki gerçek durumu.

    ``status`` üç değerden biridir:
      * ``SENT``      — öğe Gönderilmiş Öğeler'de ve gönderilmiş; zincir
                        güvenle ilerletilebilir.
      * ``NOT_SENT``  — gönderilmediği KANITLI: ``Sent`` açıkça ``False`` VE
                        öğe Taslaklar klasöründe. Başka hiçbir durum
                        ``NOT_SENT`` değildir.
      * ``UNKNOWN``   — öğe bulunamadı, Giden Kutusu'nda bekliyor (yolda
                        olabilir), başka bir klasörde ya da durumu
                        okunamıyor. Bu "gitmedi" DEMEK DEĞİLDİR; bu yüzden
                        asla yeniden gönderim gerekçesi yapılmaz.

    ``location``: öğenin bulunduğu klasör (``DRAFTS``/``OUTBOX``/``SENT``/
    ``OTHER``) ya da okunamadıysa boş.
    """

    status: str = "UNKNOWN"
    entry_id: str = ""
    message_id: str = ""
    conversation_id: str = ""
    reason: str = ""
    location: str = ""


def _item_location(item, namespace) -> str:
    """Öğenin bulunduğu klasör: DRAFTS / OUTBOX / SENT / OTHER; okunamazsa ''."""
    parent_id = str(_safe(lambda: item.Parent.EntryID, "") or "")
    if not parent_id:
        return ""
    for ad, kod in (("DRAFTS", OL_FOLDER_DRAFTS), ("OUTBOX", OL_FOLDER_OUTBOX),
                    ("SENT", OL_FOLDER_SENT_ITEMS)):
        klasor_id = str(_safe(
            lambda kod=kod: namespace.GetDefaultFolder(kod).EntryID, "") or "")
        if klasor_id and klasor_id == parent_id:
            return ad
    return "OTHER"


def verify_sent(entry_id: str = "", message_id: str = "",
                namespace=None) -> "VerifyResult":
    """Kimliği bilinen öğenin gönderilip gönderilmediğini Outlook'a SOR.

    COM ÇAĞIRIR: UI thread'inde çalıştırılmaz, worker'dan çağrılır.

    Taslak Outlook'tan elle gönderilirse öğe Taslaklar'dan Gönderilmiş
    Öğeler'e taşınır ve EntryID DEĞİŞEBİLİR. Bu yüzden EntryID
    bulunamazsa ``message_id`` ile Gönderilmiş Öğeler ayrıca taranır ve
    bulunan YENİ EntryID döndürülür.
    """
    owns_com = namespace is None
    if owns_com:
        _require_com()
        pythoncom.CoInitialize()
    try:
        if namespace is None:
            namespace = win32com.client.Dispatch(
                "Outlook.Application").GetNamespace("MAPI")
        try:
            sent_folder = namespace.GetDefaultFolder(OL_FOLDER_SENT_ITEMS)
        except Exception:  # noqa: BLE001
            sent_folder = None

        bekleyen_neden = ""
        bekleyen_konum = ""
        if entry_id:
            item = _safe(lambda: namespace.GetItemFromID(entry_id), None)
            if item is not None:
                if _is_sent_item(item, sent_folder):
                    return VerifyResult(
                        "SENT", entry_id=str(_safe(lambda: item.EntryID, "")
                                             or entry_id),
                        message_id=_read_property(item, PR_INTERNET_MESSAGE_ID),
                        conversation_id=str(
                            _safe(lambda: item.ConversationID, "") or ""),
                        reason="öğe Gönderilmiş Öğeler'de doğrulandı",
                        location="SENT")
                # "Gönderilmedi" YALNIZCA pozitif kanıtla: Sent açıkça False
                # VE öğe Taslaklar'da. Giden Kutusu'ndaki öğe de Sent=False
                # görünür ama yolda olabilir (çevrimdışı/önbellekli modda
                # dakikalarca bekler); onu "gitmedi" saymak mükerrer
                # mektuba yol açar.
                konum = _item_location(item, namespace)
                sent_false = _safe(lambda: item.Sent, None) is False
                if sent_false and konum == "DRAFTS":
                    return VerifyResult(
                        "NOT_SENT", entry_id=entry_id,
                        reason="öğe Taslaklar klasöründe ve gönderilmemiş",
                        location="DRAFTS")
                bekleyen_konum = konum
                if konum == "OUTBOX":
                    bekleyen_neden = (
                        "öğe Giden Kutusu'nda bekliyor; gönderimi sürüyor "
                        "olabilir (gitmedi DEĞİL)")
                else:
                    bekleyen_neden = (
                        "öğenin gönderilmediği KANITLANAMADI "
                        f"(konum: {konum or 'okunamadı'}, "
                        "Sent durumu taslak kanıtı vermiyor)")

        # EntryID geçersiz (öğe taşınmış): Message-ID ile SENT klASÖRÜNDE ara.
        if message_id and sent_folder is not None:
            bulunan = _safe(lambda: sent_folder.Items.Find(
                "@SQL=\"" + PR_INTERNET_MESSAGE_ID + "\" = '"
                + _dasl_quote(message_id) + "'"), None)
            if bulunan is not None:
                return VerifyResult(
                    "SENT",
                    entry_id=str(_safe(lambda: bulunan.EntryID, "") or ""),
                    message_id=message_id,
                    conversation_id=str(
                        _safe(lambda: bulunan.ConversationID, "") or ""),
                    reason="Message-ID Gönderilmiş Öğeler'de bulundu "
                           "(EntryID değişmiş)")

        return VerifyResult(
            "UNKNOWN", entry_id=entry_id, message_id=message_id,
            reason=bekleyen_neden or (
                "öğe Outlook'ta bulunamadı; gönderilmediği ANLAMINA "
                "GELMEZ (senkronizasyon gecikmiş ya da öğe taşınmış "
                "olabilir)"),
            location=bekleyen_konum)
    except Exception as exc:  # noqa: BLE001 - COM hatası uygulamayı düşürmez
        return VerifyResult("UNKNOWN", reason=f"doğrulama hatası — {exc}")
    finally:
        if owns_com:
            pythoncom.CoUninitialize()
