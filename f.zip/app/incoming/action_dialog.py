"""Vaka bazlı "Aksiyon Al" merkezi (§4).

Kullanıcı gelen maili ve ekstreyi inceledikten sonra bu pencereden tek
bir yerde: durumu görür, sistemin ÖNERDİĞİ aksiyonu görür, gerekirse
değiştirir, mail metnini düzenler ve kontrollü biçimde gönderir.

GÜVENLİ VARSAYILAN: TASLAK
    Pencere açıldığında hiçbir şey gönderilmez. "Outlook Taslağını Aç"
    varsayılan eylemdir; doğrudan gönderim ayrı bir düğme ve ayrı bir
    onay ister. Yanlış bir talebin firmaya gitmesi geri alınamaz.

COM UI THREAD'İNDE ÇALIŞMAZ
    Gönderim/taslak açma işi çağıran sayfaya (worker'a) devredilir; bu
    pencere yalnızca kullanıcının kararını toplar.
"""

from __future__ import annotations

from typing import Any

from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
)

from app.services import case_actions as ca
from app.services.action_mail import build_action_mail
from app.services.action_send import check_can_send
from app.services.reply_target import resolve_target

#: Kullanıcının seçebileceği aksiyonlar (öneri motoru sırasıyla aynı).
_SECILEBILIR = (
    ca.REMIND_FOR_REPLY,
    ca.REQUEST_STATEMENT,
    ca.REQUEST_SIMPLIFIED_STATEMENT,
    ca.REQUEST_MISSING_INVOICES,
    ca.REQUEST_READABLE_DOCUMENTS,
    ca.REQUEST_CORRECT_PERIOD,
    ca.REQUEST_DIFFERENCE_EXPLANATION,
    ca.REQUEST_CORRECTED_STATEMENT,
    ca.RESOLVE_CONTRADICTION,
    ca.FIX_DELIVERY_ADDRESS,
    ca.RECOMPARE,
    ca.INTERNAL_REVIEW,
    ca.CLOSE_CASE,
)

#: Kullanıcının seçtiği sonuç.
RESULT_CANCEL = ""
RESULT_DRAFT = "DRAFT"
RESULT_SEND = "SEND"
RESULT_RECOMPARE = "RECOMPARE"
RESULT_RESOLVE = "RESOLVE"


def _txt(value: Any, default: str = "—") -> str:
    text = "" if value is None else str(value).strip()
    return text or default


def _rows(case: Any, key: str) -> list[dict]:
    sonuc = getattr(case, "statement_result", None) or {}
    out: list[dict] = []
    for r in (sonuc.get(key) or []):
        if not isinstance(r, dict):
            continue
        out.append({
            "reference": r.get("reference") or r.get("ref"),
            "date": r.get("date") or r.get("inv_date"),
            "amount": r.get("amount"),
            "currency": r.get("currency"),
            "description": r.get("description") or r.get("comment"),
        })
    return out


def difference_rows(case: Any, action_type: str = "") -> dict:
    """Aksiyona göre DOĞRU YÖNÜN satırları.

    YÖN KARIŞTIRILAMAZ (§5):
      * REQUEST_MISSING_INVOICES     -> yalnız only_firma_rows
        (firmada var, bizde yok -> fatura İSTE)
      * REQUEST_CORRECTED_STATEMENT  -> yalnız only_tofas_rows
        (bizde var, firmada yok -> fatura BİZDE, istenmez)
      * REQUEST_DIFFERENCE_EXPLANATION -> İKİSİ AYRI başlıkla

    Eski kayıtlarda satır ayrıntısı yoksa boş döner; tablo UYDURULMAZ.
    """
    firma = _rows(case, "only_firma_rows")
    tofas = _rows(case, "only_tofas_rows")
    if action_type == ca.REQUEST_MISSING_INVOICES:
        return {"only_firma": firma}
    if action_type == ca.REQUEST_CORRECTED_STATEMENT:
        return {"only_tofas": tofas}
    if action_type == ca.REQUEST_DIFFERENCE_EXPLANATION:
        return {"only_firma": firma, "only_tofas": tofas}
    return {}


class ActionDialog(QDialog):
    """Tek vaka için aksiyon seçme + mail düzenleme penceresi."""

    def __init__(self, case: Any, parent=None) -> None:
        super().__init__(parent)
        self._case = case
        self._result = RESULT_CANCEL
        self.setWindowTitle("Aksiyon Al")
        self.setMinimumWidth(720)

        self._suggestion = ca.suggest_action(case)
        self._target = resolve_target(case)

        root = QVBoxLayout(self)
        root.addWidget(self._ozet_kutusu())
        root.addWidget(self._aksiyon_kutusu())
        root.addWidget(self._mail_kutusu(), 1)
        root.addLayout(self._dugmeler())

        self._aksiyon_degisti()

    # -- bölümler ----------------------------------------------------------

    def _ozet_kutusu(self) -> QGroupBox:
        case = self._case
        kutu = QGroupBox("Vaka durumu")
        form = QFormLayout(kutu)
        form.addRow("Firma:", QLabel(
            f"{_txt(case.company_code)} — {_txt(case.company_name)}"))
        form.addRow("Dönem:", QLabel(_txt(case.period)))
        form.addRow("Son gelen mail:", QLabel(
            f"{_txt(case.last_reply_date)} · {_txt(case.latest_reply_subject)}"))
        form.addRow("Son giden mail:", QLabel(
            f"{_txt(case.last_outbound_at)} · "
            f"{_txt(case.last_outbound_kind)}"))
        form.addRow("Body kararı:", QLabel(_txt(case.body_decision)))
        form.addRow("Ekstre kararı:", QLabel(_txt(case.statement_decision)))
        form.addRow("Finansal fark:", QLabel(
            f"{_txt(case.financial_difference)} "
            f"{_txt(case.difference_currency, '')}".strip()))

        okunamayan = [str((e or {}).get("name") or "?")
                      for e in (case.incoming_attachments or [])
                      if (e or {}).get("read_error")]
        form.addRow("Okunamayan ek:", QLabel(
            ", ".join(okunamayan) if okunamayan else "—"))

        self.lbl_hedef = QLabel(
            f"{self._target.source}" if self._target.ready
            else f"⚠ {self._target.blocked_reason}")
        self.lbl_hedef.setWordWrap(True)
        form.addRow("Cevaplanacak mail:", self.lbl_hedef)
        return kutu

    def _aksiyon_kutusu(self) -> QGroupBox:
        kutu = QGroupBox("Aksiyon")
        lay = QVBoxLayout(kutu)

        oneri = QLabel(
            f"Sistem önerisi: <b>{self._suggestion.label}</b><br>"
            f"{self._suggestion.explanation}")
        oneri.setWordWrap(True)
        lay.addWidget(oneri)

        satir = QHBoxLayout()
        satir.addWidget(QLabel("Uygulanacak aksiyon:"))
        self.combo = QComboBox()
        for tur in _SECILEBILIR:
            self.combo.addItem(ca.ACTION_LABELS.get(tur, tur), tur)
        idx = self.combo.findData(self._suggestion.action_type)
        self.combo.setCurrentIndex(idx if idx >= 0 else 0)
        self.combo.currentIndexChanged.connect(self._aksiyon_degisti)
        satir.addWidget(self.combo, 1)
        lay.addLayout(satir)
        return kutu

    def _mail_kutusu(self) -> QGroupBox:
        kutu = QGroupBox("Mail (düzenlenebilir)")
        lay = QVBoxLayout(kutu)

        form = QFormLayout()
        # ALICI SALT OKUNUR (§4).
        #
        # Reply-All'da alıcılar Outlook'un ZİNCİRDEN ürettiği listeden
        # gelir. Bu alan düzenlenebilir bırakılırsa kullanıcı yazdığı
        # adresin uygulandığını sanır — oysa hiçbir yere aktarılmıyordu.
        # Yanlış bir düzenlenebilir alan sunmaktansa gerçeği göstermek
        # doğrudur.
        self.edit_to = QLineEdit(_txt(self._case.recipients, ""))
        self.edit_to.setReadOnly(True)
        self.edit_to.setToolTip(
            "Alıcılar Outlook zincirinden alınır; buradan değiştirilemez.")
        form.addRow("Alıcı (zincirden):", self.edit_to)
        form.addRow("", QLabel(
            "Alıcılar Outlook zincirinden alınır. Ek adres gerekiyorsa "
            "aşağıdaki alanı kullanın."))

        # EK ALICI: mevcut alıcıyı DEĞİŞTİRMEZ, üzerine ekler.
        self.edit_extra = QLineEdit()
        self.edit_extra.setPlaceholderText(
            "ek1@firma.com; ek2@firma.com   (noktalı virgülle ayırın)")
        form.addRow("Ek alıcı (CC):", self.edit_extra)
        lay.addLayout(form)

        self.edit_body = QPlainTextEdit()
        lay.addWidget(self.edit_body, 1)

        self.lbl_engel = QLabel("")
        self.lbl_engel.setWordWrap(True)
        self.lbl_engel.setStyleSheet("color:#c62828;font-weight:600;")
        lay.addWidget(self.lbl_engel)
        return kutu

    def _dugmeler(self) -> QHBoxLayout:
        satir = QHBoxLayout()
        self.btn_recompare = QPushButton("Tekrar Karşılaştır")
        self.btn_recompare.clicked.connect(
            lambda: self._bitir(RESULT_RECOMPARE))
        satir.addWidget(self.btn_recompare)

        self.btn_resolve = QPushButton("Aksiyonu Tamamlandı İşaretle")
        self.btn_resolve.clicked.connect(lambda: self._bitir(RESULT_RESOLVE))
        satir.addWidget(self.btn_resolve)

        satir.addStretch(1)

        # VARSAYILAN GÜVENLİ EYLEM: taslak.
        self.btn_draft = QPushButton("Outlook Taslağını Aç")
        self.btn_draft.setDefault(True)
        self.btn_draft.clicked.connect(lambda: self._bitir(RESULT_DRAFT))
        satir.addWidget(self.btn_draft)

        self.btn_send = QPushButton("Gönder")
        self.btn_send.clicked.connect(self._gonder_onayi)
        satir.addWidget(self.btn_send)

        iptal = QPushButton("Kapat")
        iptal.clicked.connect(self.reject)
        satir.addWidget(iptal)
        return satir

    # -- davranış ----------------------------------------------------------

    def selected_action(self) -> str:
        return self.combo.currentData() or ca.INTERNAL_REVIEW

    def _aksiyon_degisti(self) -> None:
        """Seçilen aksiyona göre mail metnini yeniden üret."""
        tur = self.selected_action()
        mail = build_action_mail(self._case, tur,
                                 rows=difference_rows(self._case, tur))
        self._mail = mail

        engeller = []
        if mail.blocked_reason:
            engeller.append(mail.blocked_reason)
        if tur not in ca.INTERNAL_ACTIONS and not self._target.ready:
            engeller.append(self._target.blocked_reason)
        guard = check_can_send(self._case, tur)
        if not guard.allowed:
            engeller.append(guard.reason)

        self.edit_body.setPlainText(mail.body)
        self.lbl_engel.setText("\n".join(engeller))
        gonderilebilir = not engeller
        self.btn_send.setEnabled(gonderilebilir)
        self.btn_draft.setEnabled(gonderilebilir)

    def _gonder_onayi(self) -> None:
        """DOĞRUDAN GÖNDERİM AYRI ONAY İSTER."""
        tur = self.selected_action()
        cevap = QMessageBox.question(
            self, "Gönderimi onayla",
            f"'{ca.ACTION_LABELS.get(tur, tur)}' maili "
            f"{_txt(self._case.company_code)} firmasına GÖNDERİLECEK.\n\n"
            "Bu işlem geri alınamaz. Devam edilsin mi?")
        if cevap == QMessageBox.Yes:
            self._bitir(RESULT_SEND)

    def _bitir(self, sonuc: str) -> None:
        self._result = sonuc
        self.accept()

    # -- çağıranın okuduğu -------------------------------------------------

    @property
    def result_action(self) -> str:
        return self._result

    def mail_payload(self) -> dict:
        """Kullanıcının düzenlediği son hâl."""
        return {
            "action_type": self.selected_action(),
            "body": self.edit_body.toPlainText(),
            # Yalnızca GÖSTERİM içindir; gönderime uygulanmaz (salt okunur).
            "recipients": self.edit_to.text().strip(),
            # GERÇEKTEN uygulanan tek alıcı müdahalesi.
            "extra_recipients": self.edit_extra.text().strip(),
            "attachments": list(getattr(self._mail, "attachments", []) or []),
        }
