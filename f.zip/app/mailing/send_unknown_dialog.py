"""Belirsiz (SEND_UNKNOWN) gönderimler için karar ekranı.

Bu pencere YALNIZCA kullanıcının kararını toplar; tüm kurallar
``app.services.send_unknown_resolution`` içindedir (yetki, zorunlu gerekçe,
audit, geçiş tablosu, kanıt kuralları). Pencere HİÇBİR mail göndermez.

ÜÇ KARAR
    * Gönderilmiş olarak doğrula  -> kalıcı; firmaya bu dönem tekrar gitmez.
    * Gönderilmediğini doğrula ve yeniden gönderime aç -> Send() ÇAĞRILMAZ;
      yalnız engel kalkar, firma bir sonraki MANUEL gönderimde gider.
    * İncelemede bırak -> durum değişmez (engelli kalır).

KANIT
    Kayıtlı kimlikler (Message-ID / EntryID), kuyruk durumu ve istenirse
    Outlook kontrolü gösterilir. Sistem kendi başına "gönderildi" varsaymaz.
    Outlook kontrolü COM kullanır; UI thread'inde DEĞİL, worker thread'inde çalışır.
"""

from __future__ import annotations

import sqlite3
from typing import Any, Callable, Optional

from loguru import logger
from PySide6.QtCore import QObject, QThread, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from app.services import authz
from app.services import send_unknown_resolution as sur
from app.services.mail_log import (
    DECISION_REOPENED,
    DECISION_UNDER_REVIEW,
    DECISION_VERIFIED_SENT,
    MailLog,
)
from app.services.send_queue import QueueUnavailableError, SendQueue

_KARAR_ADI = {
    DECISION_VERIFIED_SENT: "Gönderilmiş olarak doğrula",
    DECISION_REOPENED: "Gönderilmediğini doğrula ve yeniden gönderime aç",
    DECISION_UNDER_REVIEW: "İncelemede bırak",
}

_ONAY_METNI = {
    DECISION_VERIFIED_SENT: (
        "{kod} için bu belirsiz gönderim 'GÖNDERİLMİŞ' olarak kaydedilecek.\n\n"
        "Bu karar KALICIDIR: firmaya bu dönem için yeniden mail gönderilmez.\n"
        "Bu işlem mail GÖNDERMEZ.\n\nDevam edilsin mi?"),
    DECISION_REOPENED: (
        "{kod} için 'GÖNDERİLMEDİ' kaydedilecek ve firma yeniden gönderime "
        "açılacak.\n\nBu işlem mail GÖNDERMEZ. Firma, bu dönem için bir "
        "sonraki MANUEL gönderimde gidecek.\n\nDevam edilsin mi?"),
    DECISION_UNDER_REVIEW: (
        "{kod} incelemede bırakılacak. Durum DEĞİŞMEZ: firma engelli kalır "
        "ve otomatik gönderilmez.\n\nDevam edilsin mi?"),
}


_RISK_METNI = (
    "{kod}: {uyari}.\n\nOutlook bu mailin gitmediğini DOĞRULAMADI. Yeniden "
    "gönderime açarsanız firma, bir sonraki manuel gönderimde aynı dönem için "
    "İKİNCİ kez mektup alabilir; bu geri alınamaz.\n\nYine de yeniden "
    "gönderime açılsın mı?")

#: Çalışan Outlook-kontrol thread'leri. Pencere kapansa bile bitene kadar canlı
#: tutulur (çalışan bir QThread'in yok edilmesi çökmeye yol açar).
_LIVE_THREADS: set = set()


def format_detail(detail: sur.UnknownDetail) -> str:
    """Karar ekranındaki kanıt metni (saf işlev; GUI gerektirmez)."""
    d, kanit = detail.state, detail.evidence
    satirlar: list[str] = []
    durum = d.state + (" — İNCELEMEDE" if d.under_review else "")
    satirlar.append(f"Durum: {durum}")
    satirlar.append(f"Kanıt seviyesi: {kanit.level}")
    if kanit.level == sur.EVIDENCE_MISSING:
        satirlar.append(
            "  Kayıtlı Message-ID/EntryID yok. Sistem 'gönderildi' ya da "
            "'gönderilmedi' VARSAYMAZ; kanıtsız karar için açık onay gerekir.")
    satirlar.append(
        f"Yeniden gönderime açma için kanıt durumu: {kanit.status}")
    if kanit.status == sur.STATUS_EV_UNKNOWN:
        satirlar.append(f"  UYARI: {sur.DUPLICATE_RISK_WARNING}. Açmak için "
                        "ikinci bir açık onay gerekir.")
    elif kanit.status == sur.STATUS_EV_SENT:
        satirlar.append("  Gönderildiği görülüyor: yeniden gönderime açılamaz.")
    else:
        satirlar.append("  Outlook gönderilmediğini doğruladı.")

    satirlar.append("\n-- Gönderim günlüğü (MailLog) --")
    m = kanit.mail_log
    if m:
        for ad, anahtar in (("Zaman", "sent_at"), ("Durum", "status"),
                            ("Alıcı", "recipients"), ("Konu", "subject"),
                            ("Gerekçe", "reason"), ("Message-ID", "message_id"),
                            ("EntryID", "entry_id"),
                            ("ConversationID", "conversation_id")):
            satirlar.append(f"  {ad}: {m.get(anahtar) or '—'}")
    else:
        satirlar.append("  (kayıt yok)")

    satirlar.append("\n-- Gönderim kuyruğu --")
    if kanit.queue is None:
        satirlar.append(f"  OKUNAMADI: {kanit.queue_error or 'bilinmeyen hata'}")
    elif not kanit.queue:
        satirlar.append("  (kayıt yok)")
    for q in kanit.queue or []:
        satirlar.append(
            f"  {q['status']} · deneme {q['attempts']} · {q['updated_at']} · "
            f"Message-ID {q['message_id'] or '—'} · EntryID {q['entry_id'] or '—'}")

    satirlar.append("\n-- Outlook kontrolü (bu pencerede çalıştırılan) --")
    o = kanit.outlook
    if o:
        satirlar.append(f"  Sonuç: {o['status']} · konum: {o['location'] or '—'}")
        if o["reason"]:
            satirlar.append(f"  {o['reason']}")
        if o["status"] == "SENT":
            satirlar.append("  UYARI: Outlook mailin GİTTİĞİNİ gösteriyor; "
                            "yeniden gönderime açılamaz.")
        elif o["status"] == "UNKNOWN" and o["location"] == "OUTBOX":
            satirlar.append("  Giden Kutusu'nda bekliyor: GİTMEDİ anlamına "
                            "GELMEZ, yolda olabilir.")
        elif o["status"] == "UNKNOWN":
            satirlar.append("  Bu 'gitmedi' DEMEK DEĞİLDİR.")
    else:
        satirlar.append("  (çalıştırılmadı)")

    satirlar.append("\n-- Önceki kararlar --")
    if not detail.resolutions:
        satirlar.append("  (yok)")
    for r in detail.resolutions:
        satirlar.append(f"  {r.at} · {r.user} ({r.role}) · {r.decision} · {r.reason}")
    return "\n".join(satirlar)


class _VerifyWorker(QObject):
    """Outlook kontrolünü worker thread'inde çalıştırır (COM UI'da çalışmaz)."""

    finished = Signal(object)

    def __init__(self, verify: Callable[..., Any], entry_id: str,
                 message_id: str) -> None:
        super().__init__()
        self._verify, self._entry_id, self._message_id = (
            verify, entry_id, message_id)

    def run(self) -> None:
        try:
            sonuc = self._verify(entry_id=self._entry_id,
                                 message_id=self._message_id)
        except Exception as exc:  # noqa: BLE001 - kontrol hatası = belirsiz
            sonuc = type("_Hata", (), {
                "status": "UNKNOWN", "location": "", "entry_id": "",
                "message_id": "", "reason": f"kontrol hatası — {exc}"})()
        self.finished.emit(sonuc)


class SendUnknownDialog(QDialog):
    """Çözülmemiş belirsiz gönderimleri listeler ve kararı toplar."""

    resolved = Signal()          # bir karar uygulandı (çağıran sayaçları yeniler)

    def __init__(self, *, log: Optional[MailLog] = None,
                 queue: Optional[SendQueue] = None, audit: Any = None,
                 settings: Any = None, period: str = "",
                 verify: Optional[Callable[..., Any]] = None,
                 parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Belirsiz Gönderimler")
        self.resize(980, 640)
        self._log = log or MailLog()
        self._queue = queue or SendQueue()
        self._audit = audit
        self._settings = settings
        self._verify = verify
        self._cases: list[sur.UnknownCase] = []
        self._checks: dict[tuple[str, str], Any] = {}
        self._thread: Optional[QThread] = None
        self._worker: Optional[_VerifyWorker] = None
        self._closed = False

        lay = QVBoxLayout(self)
        ust = QHBoxLayout()
        ust.addWidget(QLabel("Dönem:"))
        self.period_edit = QLineEdit(period)
        self.period_edit.setPlaceholderText("2026-07 (boş = tüm dönemler)")
        self.period_edit.setFixedWidth(200)
        ust.addWidget(self.period_edit)
        self.btn_refresh = QPushButton("Yenile")
        self.btn_refresh.clicked.connect(self.refresh)
        ust.addWidget(self.btn_refresh)
        ust.addStretch(1)
        lay.addLayout(ust)

        uyari = QLabel(
            "Bu firmalara mail GİTMİŞ OLABİLİR. Sistem hiçbirini otomatik "
            "yeniden göndermez. Bu pencere mail GÖNDERMEZ; yalnızca kararınızı "
            "gerekçesiyle kaydeder.")
        uyari.setWordWrap(True)
        lay.addWidget(uyari)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["Firma Kodu", "Firma Adı", "Dönem", "Gönderim Zamanı", "Alıcı",
             "Kanıt"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.itemSelectionChanged.connect(self._on_select)
        lay.addWidget(self.table, 2)

        self.detail = QPlainTextEdit()
        self.detail.setReadOnly(True)
        lay.addWidget(self.detail, 3)

        lay.addWidget(QLabel("Gerekçe (zorunlu — denetim kaydına yazılır):"))
        self.reason = QPlainTextEdit()
        self.reason.setFixedHeight(64)
        lay.addWidget(self.reason)
        self.ack = QCheckBox("Kayıtlı kanıt olmadan karar veriyorum")
        lay.addWidget(self.ack)

        butonlar = QHBoxLayout()
        self.btn_check = QPushButton("Outlook'ta kontrol et")
        self.btn_check.clicked.connect(self._start_verify)
        butonlar.addWidget(self.btn_check)
        butonlar.addStretch(1)
        self.btn_verified = QPushButton(_KARAR_ADI[DECISION_VERIFIED_SENT])
        self.btn_verified.clicked.connect(
            lambda: self._decide(DECISION_VERIFIED_SENT))
        self.btn_reopen = QPushButton(_KARAR_ADI[DECISION_REOPENED])
        self.btn_reopen.clicked.connect(lambda: self._decide(DECISION_REOPENED))
        self.btn_review = QPushButton(_KARAR_ADI[DECISION_UNDER_REVIEW])
        self.btn_review.clicked.connect(
            lambda: self._decide(DECISION_UNDER_REVIEW))
        for b in (self.btn_verified, self.btn_reopen, self.btn_review):
            butonlar.addWidget(b)
        self.btn_close = QPushButton("Kapat")
        self.btn_close.clicked.connect(self.accept)
        butonlar.addWidget(self.btn_close)
        lay.addLayout(butonlar)

        self.status = QLabel("")
        self.status.setWordWrap(True)
        lay.addWidget(self.status)

        self._apply_permissions()
        self.refresh()

    # -- yetki -------------------------------------------------------------

    def _apply_permissions(self) -> None:
        """Yetkisiz rolde karar düğmeleri kapanır (servis yine de reddeder)."""
        rol = authz.role_of(authz.current_user(), self._settings)
        yetkili = authz.can(authz.PERM_RESOLVE_SEND_UNKNOWN, role=rol)
        for b in (self.btn_verified, self.btn_reopen, self.btn_review):
            b.setEnabled(yetkili)
        if not yetkili:
            self.status.setText(
                f"Rol: {rol} — belirsiz gönderimi çözmek yetki ister.")

    # -- liste / ayrıntı ---------------------------------------------------

    def _period(self) -> Optional[str]:
        return (self.period_edit.text() or "").strip() or None

    def refresh(self) -> None:
        try:
            self._cases = sur.list_unresolved(self._log, self._period())
        except (sqlite3.Error, OSError) as exc:
            self._cases = []
            self.status.setText(f"Liste okunamadı: {exc}")
        self.table.setRowCount(len(self._cases))
        for satir, c in enumerate(self._cases):
            for sutun, deger in enumerate([
                    c.company_code, c.company_name, c.period, c.sent_at,
                    c.recipients,
                    c.evidence_level + (" · incelemede" if c.under_review else "")]):
                self.table.setItem(satir, sutun, QTableWidgetItem(str(deger)))
        self.detail.setPlainText(
            "" if self._cases else "Çözüm bekleyen belirsiz gönderim yok.")

    def _selected(self) -> Optional[sur.UnknownCase]:
        satir = self.table.currentRow()
        return self._cases[satir] if 0 <= satir < len(self._cases) else None

    def _on_select(self) -> None:
        secili = self._selected()
        if secili is None:
            return
        self._show_detail(secili)

    def _show_detail(self, c: sur.UnknownCase) -> None:
        try:
            d = sur.describe(self._log, self._queue, c.period, c.company_code,
                             self._checks.get((c.period, c.company_code)))
            self.detail.setPlainText(format_detail(d))
        except (sqlite3.Error, OSError) as exc:
            self.detail.setPlainText(f"Ayrıntı okunamadı: {exc}")

    # -- Outlook kontrolü (worker thread) ----------------------------------

    def _start_verify(self) -> None:
        c = self._selected()
        if c is None:
            self._show_info("Önce listeden bir firma seçin.")
            return
        d = sur.describe(self._log, self._queue, c.period, c.company_code)
        ids = [(q["entry_id"], q["message_id"]) for q in d.evidence.queue or []]
        if d.entry is not None:
            ids.insert(0, (d.entry.entry_id, d.entry.message_id))
        entry_id, message_id = next(((e, m) for e, m in ids if e or m), ("", ""))
        if not (entry_id or message_id):
            self._show_info("Kontrol için kayıtlı Message-ID/EntryID yok.")
            return
        verify = self._verify
        if verify is None:
            from app.mailing.outlook_client import verify_sent as verify
        self.btn_check.setEnabled(False)
        self.status.setText("Outlook kontrol ediliyor…")
        # Thread EBEVEYNSİZ ve modül düzeyinde tutulur: pencere COM çağrısı
        # sürerken kapansa bile QThread çalışırken yok edilmez ("Destroyed
        # while thread is still running" çökmesi). Bitince kendini siler.
        thread = QThread()
        worker = _VerifyWorker(verify, entry_id, message_id)
        worker.moveToThread(thread)
        _LIVE_THREADS.add(thread)
        thread.started.connect(worker.run)
        worker.finished.connect(
            lambda sonuc, c=c: self._on_verify_done(c, sonuc))
        worker.finished.connect(thread.quit)
        thread.finished.connect(worker.deleteLater)
        thread.finished.connect(lambda t=thread: _LIVE_THREADS.discard(t))
        thread.finished.connect(thread.deleteLater)
        self._thread, self._worker = thread, worker
        thread.start()

    def _on_verify_done(self, c: sur.UnknownCase, sonuc: Any) -> None:
        if self._closed:                       # pencere kapandı; sonuç atılır
            return
        self._checks[(c.period, c.company_code)] = sonuc
        self.btn_check.setEnabled(True)
        self.status.setText(
            f"Outlook kontrolü: {getattr(sonuc, 'status', '?')}. Bu sonuç "
            "yalnızca bilgidir; karar sizindir.")
        secili = self._selected()
        if secili is not None and (secili.period, secili.company_code) == (
                c.period, c.company_code):
            self._show_detail(c)

    def _shutdown_thread(self) -> None:
        """Kısa bir nezaket beklemesi; thread bitmediyse BIRAKILIR (yok edilmez)."""
        self._closed = True
        t = self._thread
        if t is not None and t.isRunning():
            t.quit()
            t.wait(1000)

    def done(self, result: int) -> None:  # noqa: N802 - Qt API
        self._shutdown_thread()
        super().done(result)

    # -- karar ---------------------------------------------------------------

    def _confirm(self, metin: str) -> bool:
        return QMessageBox.question(
            self, "Onay", metin,
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No) == QMessageBox.Yes

    def _show_error(self, metin: str) -> None:
        QMessageBox.warning(self, "Karar uygulanamadı", metin)

    def _show_info(self, metin: str) -> None:
        QMessageBox.information(self, "Belirsiz Gönderimler", metin)

    def _decide(self, karar: str) -> None:
        c = self._selected()
        if c is None:
            self._show_info("Önce listeden bir firma seçin.")
            return
        gerekce = self.reason.toPlainText().strip()
        if not gerekce:
            self._show_error(
                "Gerekçe zorunludur. Açıklama denetim kaydına yazılır.")
            return
        if not self._confirm(_ONAY_METNI[karar].format(kod=c.company_code)):
            return
        kontrol = self._checks.get((c.period, c.company_code))
        risk_onayi = False
        if karar == DECISION_REOPENED:
            # Gönderilmediği KANITLANMADIYSA (Outlook NOT_SENT demedi) İKİNCİ,
            # açık onay istenir. Servis bunu ayrıca zorunlu kılar.
            try:
                kanit_durumu = sur.describe(
                    self._log, self._queue, c.period, c.company_code,
                    kontrol).evidence.status
            except (sqlite3.Error, OSError) as exc:
                self._show_error(f"Kanıt durumu okunamadı: {exc}")
                return
            if kanit_durumu == sur.STATUS_EV_UNKNOWN:
                if not self._confirm(_RISK_METNI.format(
                        uyari=sur.DUPLICATE_RISK_WARNING, kod=c.company_code)):
                    return
                risk_onayi = True
        try:
            sonuc = sur.resolve(
                karar, c.period, c.company_code, reason=gerekce,
                log=self._log, queue=self._queue, audit=self._audit,
                settings=self._settings, outlook_check=kontrol,
                ack_no_evidence=self.ack.isChecked(),
                confirm_duplicate_risk=risk_onayi)
        except sur.EvidenceAcknowledgementRequired as exc:
            self._show_error(f"{exc}\n\nKararı yine de vermek istiyorsanız "
                             "'Kayıtlı kanıt olmadan karar veriyorum' kutusunu "
                             "işaretleyin.")
            return
        except (authz.PermissionDenied, authz.ReasonRequired,
                sur.ResolutionError, QueueUnavailableError, ValueError,
                sqlite3.Error, OSError) as exc:
            logger.warning(f"[çözüm] {c.company_code} karar uygulanamadı: {exc}")
            self._show_error(str(exc))
            return
        except Exception as exc:  # noqa: BLE001 - slot istisnası kullanıcıya iletilir
            logger.exception(f"[çözüm] {c.company_code} beklenmeyen hata: {exc}")
            self._show_error(f"Beklenmeyen hata; karar UYGULANMADI olabilir: {exc}\n"
                             "Listeyi yenileyip durumu kontrol edin.")
            self.refresh()
            return
        self.reason.clear()
        self.ack.setChecked(False)
        self.status.setText(
            f"{c.company_code}: " + (
                "karar zaten uygulanmıştı (değişiklik yok)." if not sonuc.changed
                else f"{_KARAR_ADI[karar]} — kaydedildi. Mail GÖNDERİLMEDİ."))
        self.refresh()
        self.resolved.emit()
