"""Teslim edilemeyen mail (NDR / bounce) tespiti ve ayrıştırması.

NEDEN AYRI BİR MODÜL
    Bir mutabakat maili karşı tarafa ULAŞMAMIŞSA, o firma "cevap vermedi"
    değildir — mail hiç gitmemiştir. İkisini karıştırmak, aylarca cevap
    beklenen ama aslında adresi yanlış olan firmalar demektir.

    Teslim hatası bir MÜŞTERİ CEVABI DEĞİLDİR; ama yok sayılacak bir mail de
    değildir. Kendi türü (``DELIVERY_FAILURE``) ile işaretlenir ve ilgili
    mutabakat kaydı ``DELIVERY_FAILED`` durumuna geçer.

TASARIM
    Tamamen deterministiktir — AI kullanılmaz. Gönderen adresi, konu kalıpları
    ve gövdedeki tanı bilgileri (SMTP kodu, başarısız adres, orijinal konu)
    Türkçe ve İngilizce Outlook/Exchange metinleri için taranır.

    Yanlış pozitif pahalıdır: gerçek bir müşteri cevabını "teslim hatası"
    sanmak, o cevabın işlenmemesi demektir. Bu yüzden tespit TEK bir ipucuna
    değil, ağırlıklı kanıtlara dayanır.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

# Outlook/Exchange'in NDR üretirken kullandığı sistem göndericileri.
_SYSTEM_SENDERS = (
    "postmaster@", "mailer-daemon@", "mail delivery system",
    "microsoftexchange", "no-reply@", "noreply@",
)

# Konu satırı kalıpları (TR + EN). Bunlar GÜÇLÜ kanıttır.
_SUBJECT_PATTERNS = (
    "undeliverable",
    "undelivered mail",
    "delivery has failed",
    "delivery status notification",
    "delivery failure",
    "returned mail",
    "mail delivery failed",
    "message not delivered",
    "couldn't be delivered",
    "could not be delivered",
    "wasn't delivered",
    "was not delivered",
    "iletilemedi",
    "teslim edilemedi",
    "teslim edilemeyen",
    "gönderilemedi",
    "ulaştırılamadı",
)

# Gövde kalıpları — tek başına zayıf, konu/gönderici ile birleşince güçlü.
_BODY_PATTERNS = (
    "mailbox unavailable",
    "recipient not found",
    "user unknown",
    "unknown recipient",
    "address rejected",
    "address not found",
    "no such user",
    "does not exist",
    "recipient address rejected",
    "quota exceeded",
    "mailbox full",
    "relay access denied",
    "diagnostic-code",
    "diagnostic code",
    "reporting-mta",
    "final-recipient",
    "action: failed",
    "alıcı bulunamadı",
    "kullanıcı bulunamadı",
    "posta kutusu",
    "adres reddedildi",
    "böyle bir kullanıcı yok",
)

# Otomatik cevap (out-of-office) kalıpları — teslim hatası DEĞİLDİR.
_AUTO_REPLY_PATTERNS = (
    "out of office",
    "automatic reply",
    "auto-reply",
    "autoreply",
    "otomatik yanıt",
    "otomatik cevap",
    "ofis dışı",
    "yıllık izin",
    "izindeyim",
    "annual leave",
    "on vacation",
)

# SMTP durum/tanı kodu:  550 5.1.1  /  #5.1.1  /  Status: 5.1.1
_STATUS_RE = re.compile(r"\b([245]\.\d{1,3}\.\d{1,3})\b")
_SMTP_CODE_RE = re.compile(r"\b([245]\d{2})[\s-]+[245]\.\d{1,3}\.\d{1,3}\b")
_EMAIL_RE = re.compile(r"[\w.!#$%&'*+/=?^`{|}~-]+@[\w-]+(?:\.[\w-]+)+")

# "Final-Recipient: rfc822; ali@firma.com" gibi standart DSN alanları.
_FINAL_RECIPIENT_RE = re.compile(
    r"final-recipient\s*:\s*(?:rfc822\s*;)?\s*([^\s<>]+@[^\s<>;]+)", re.I)
_ORIGINAL_RECIPIENT_RE = re.compile(
    r"original-recipient\s*:\s*(?:rfc822\s*;)?\s*([^\s<>]+@[^\s<>;]+)", re.I)
# Orijinal mailin Message-ID'si (eşleştirmenin EN güvenilir kaynağı).
_ORIGINAL_MESSAGE_ID_RE = re.compile(
    r"(?:original-message-id|in-reply-to|references|message-id)\s*:\s*"
    r"(<[^>\s]+>)", re.I)
# Konudaki orijinal başlık: "Undeliverable: Mutabakat Temmuz 2026"
_SUBJECT_TAIL_RE = re.compile(
    r"^(?:undeliverable|undelivered mail returned to sender|"
    r"delivery status notification(?:\s*\([^)]*\))?|"
    r"teslim edilemedi|iletilemedi)\s*[:\-]\s*(.+)$", re.I)


@dataclass
class DeliveryFailureInfo:
    """Bir teslim hatası mailinden çıkarılabilen her şey."""

    is_failure: bool = False
    confidence: float = 0.0

    failed_recipient: str = ""       # ulaşılamayan adres
    original_subject: str = ""       # orijinal mutabakat mailinin konusu
    original_message_id: str = ""    # orijinal mailin Message-ID'si
    status_code: str = ""            # 5.1.1 gibi DSN durum kodu
    smtp_code: str = ""              # 550 gibi SMTP kodu
    reason: str = ""                 # insan diliyle gerekçe
    evidence: list[str] = field(default_factory=list)

    #: "Bu adres kullanılmıyor" sınıfı: adres yanlış ya da kapatılmış.
    ADDRESS_UNUSED_REASON = "Alıcı adresi bulunamadı (adres yanlış ya da kapatılmış)."

    @property
    def address_unused(self) -> bool:
        """Adres KULLANILMIYOR mu?

        Kalıcı hatanın alt kümesidir: posta kutusu dolu (5.2.2) adresin
        yanlış olduğunu göstermez, ama "recipient not found" gösterir. Bu
        ayrım önemlidir: kullanılmayan adrese hatırlatma göndermek yalnızca
        boşuna değil, vakayı sonsuza kadar "cevap bekliyor"da tutar.
        """
        if not self.is_failure or not self.permanent:
            return False
        if self.status_code.startswith("5.1"):
            return True
        return self.reason == self.ADDRESS_UNUSED_REASON

    @property
    def permanent(self) -> bool:
        """Kalıcı hata mı (5.x.x) — geçici (4.x.x) ise tekrar denenebilir."""
        return self.status_code.startswith("5") or self.smtp_code.startswith("5")

    def describe(self) -> str:
        """UI'da 'Bu firmaya mail neden gitmedi?' sorusunun cevabı."""
        if not self.is_failure:
            return ""
        parts = []
        if self.failed_recipient:
            parts.append(f"Adres: {self.failed_recipient}")
        if self.status_code or self.smtp_code:
            parts.append(f"Kod: {self.smtp_code or ''} {self.status_code or ''}".strip())
        if self.reason:
            parts.append(self.reason)
        parts.append("Kalıcı hata" if self.permanent else "Geçici hata (yeniden denenebilir)")
        return " | ".join(parts)


def _norm(text: str) -> str:
    return (text or "").strip().lower()


def is_automatic_reply(subject: str, body: str = "") -> bool:
    """Otomatik yanıt / ofis dışı mesajı mı?

    Teslim hatasından AYRI tutulur: adres doğrudur, mail ulaşmıştır, sadece
    kişi yerinde değildir. Bu mailler mutabakat cevabı sayılmaz ama firma da
    "ulaşılamadı" olarak işaretlenmez.
    """
    haystack = f"{_norm(subject)}\n{_norm(body)[:2000]}"
    return any(p in haystack for p in _AUTO_REPLY_PATTERNS)


def detect_delivery_failure(subject: str = "", body: str = "",
                            sender: str = "", sender_name: str = "",
                            message_class: str = "") -> DeliveryFailureInfo:
    """Bir mailin teslim hatası olup olmadığını belirle ve ayrıntıları çıkar.

    Kanıtlar ağırlıklandırılır; tek bir ipucu yeterli değildir. Örneğin
    gövdesinde "does not exist" geçen normal bir müşteri maili, konusu ve
    göndericisi normalse teslim hatası SAYILMAZ.
    """
    info = DeliveryFailureInfo()
    s, b = _norm(subject), _norm(body)
    sender_blob = f"{_norm(sender)} {_norm(sender_name)}"

    # Otomatik yanıtlar asla teslim hatası değildir — önce onları ele.
    if is_automatic_reply(subject, body):
        info.reason = "Otomatik yanıt / ofis dışı mesajı."
        return info

    score = 0.0
    # 1) Outlook rapor öğesi (REPORT.IPM.Note.NDR) — en güçlü kanıt.
    mc = _norm(message_class)
    if "report.ipm" in mc and ("ndr" in mc or "dr" in mc):
        score += 0.7
        info.evidence.append(f"message_class={message_class}")
    # 2) Konu kalıbı.
    if any(p in s for p in _SUBJECT_PATTERNS):
        score += 0.5
        info.evidence.append("konu kalıbı")
    # 3) Sistem göndericisi.
    if any(p in sender_blob for p in _SYSTEM_SENDERS):
        score += 0.3
        info.evidence.append("sistem göndericisi")
    # 4) Gövde kalıpları (birden çoksa daha güçlü).
    body_hits = [p for p in _BODY_PATTERNS if p in b]
    if body_hits:
        score += min(0.3, 0.15 * len(body_hits))
        info.evidence.append(f"gövde kalıbı ({len(body_hits)})")
    # 5) DSN durum kodu.
    status = _STATUS_RE.search(body or "")
    if status:
        info.status_code = status.group(1)
        if info.status_code.startswith(("4", "5")):
            score += 0.25
            info.evidence.append(f"durum kodu {info.status_code}")

    info.confidence = min(1.0, score)
    # Eşik: tek zayıf ipucu yetmez, iki bağımsız kanıt gerekir.
    info.is_failure = score >= 0.6
    if not info.is_failure:
        return info

    smtp = _SMTP_CODE_RE.search(body or "")
    if smtp:
        info.smtp_code = smtp.group(1)

    info.failed_recipient = _extract_failed_recipient(body, sender)
    info.original_message_id = _extract_original_message_id(body)
    info.original_subject = _extract_original_subject(subject, body)
    info.reason = _describe_reason(b, info.status_code)
    return info


def _extract_failed_recipient(body: str, sender: str) -> str:
    """Ulaşılamayan adresi bul (DSN alanları önce, sonra ilk makul adres)."""
    for pattern in (_FINAL_RECIPIENT_RE, _ORIGINAL_RECIPIENT_RE):
        found = pattern.search(body or "")
        if found:
            return found.group(1).strip().strip("<>").lower()

    # DSN alanı yoksa: gövdedeki adresler arasından sistem/gönderen adreslerini
    # ele; kalan ilk adres muhtemelen ulaşılamayan alıcıdır.
    sender_norm = _norm(sender)
    for candidate in _EMAIL_RE.findall(body or ""):
        low = candidate.lower()
        if low == sender_norm:
            continue
        if any(low.startswith(p.rstrip("@")) or p.rstrip("@") in low
               for p in ("postmaster", "mailer-daemon", "no-reply", "noreply")):
            continue
        return low
    return ""


def _extract_original_message_id(body: str) -> str:
    found = _ORIGINAL_MESSAGE_ID_RE.search(body or "")
    return found.group(1).strip() if found else ""


def _extract_original_subject(subject: str, body: str) -> str:
    """Orijinal mutabakat mailinin konusunu çıkar.

    Outlook "Undeliverable: <orijinal konu>" biçimini kullanır; Exchange bazen
    yalnızca gövdede "Subject: ..." satırı bırakır.
    """
    tail = _SUBJECT_TAIL_RE.match((subject or "").strip())
    if tail:
        return tail.group(1).strip()
    found = re.search(r"^\s*(?:subject|konu)\s*:\s*(.+)$", body or "",
                      re.I | re.M)
    return found.group(1).strip() if found else ""


def _describe_reason(body_lower: str, status_code: str) -> str:
    """Hata nedenini kullanıcının anlayacağı tek cümleye indir."""
    table = (
        (("mailbox full", "quota exceeded", "posta kutusu dolu"),
         "Alıcının posta kutusu dolu."),
        # "RESOLVER.ADR.RecipNotFound; not found" → gerçek Exchange metni.
        (("recipient not found", "recipnotfound", "not found",
          "user unknown", "no such user", "address not found",
          "does not exist", "unknown recipient",
          "alıcı bulunamadı", "kullanıcı bulunamadı"),
         "Alıcı adresi bulunamadı (adres yanlış ya da kapatılmış)."),
        (("address rejected", "relay access denied", "adres reddedildi"),
         "Alıcı sunucusu adresi reddetti."),
        (("spam", "blocked", "blacklist"),
         "Mail alıcı sunucusu tarafından engellendi."),
    )
    for needles, message in table:
        if any(n in body_lower for n in needles):
            return message
    if status_code.startswith("4"):
        return "Geçici teslim sorunu; sunucu yeniden deneyecek."
    if status_code.startswith("5"):
        return "Kalıcı teslim hatası."
    return "Mail teslim edilemedi."
