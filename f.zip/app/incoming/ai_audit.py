"""LLM çağrılarının denetim günlüğü (madde 3).

NE SAKLANIR
    Her Direct Line çağrısı için: istek kimliği, model/ajan kimliği, prompt
    hash'i, gönderilen yükün hash'i ve boyutu, ek dosyaların özeti (ad, tür,
    SHA-256, boyut), cevabın hash'i, şema doğrulamasının sonucu ve süre.

NE SAKLANMAZ
    Prompt'un ve cevabın METNİ, mail gövdesi, ek içeriği, secret/token.
    Denetim kaydının amacı "aynı girdi mi gitti, aynı cevap mı geldi?"
    sorusunu cevaplamaktır; müşteri verisini ikinci bir yerde çoğaltmak
    değildir. Hash bu soruyu veriyi taşımadan cevaplar.

TASARIM
    * SQLite, kurulum gerektirmez, kullanıcı profilinde durur.
    * SALT EKLENİR (append-only): uygulama içinden silme/güncelleme API'si
      YOKTUR.
    * ASLA çökertmez: yazılamazsa loglanır ve AI çağrısı devam eder.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional, Sequence

from loguru import logger

from app.utils.paths import app_data_dir
from app.utils.sqlite import open_sqlite_connection


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256_text(text: str) -> str:
    """Metnin SHA-256'sı (boş metin için de kararlı bir değer üretir)."""
    return hashlib.sha256((text or "").encode("utf-8")).hexdigest()


def payload_digest(payload: Any) -> str:
    """Yükün içerikten türeyen kararlı hash'i.

    Anahtarlar SIRALANIR: aynı yük, sözlük sırası değişse de aynı hash'i
    üretir; aksi hâlde "aynı veri mi gitti?" sorusu cevapsız kalır.
    """
    try:
        metin = json.dumps(payload, ensure_ascii=False, sort_keys=True,
                           default=str)
    except (TypeError, ValueError):
        metin = str(payload)
    return sha256_text(metin)


def attachment_summaries(mail: Any) -> list[dict[str, Any]]:
    """Eklerin İÇERİK TAŞIMAYAN özeti (ad, tür, boyut, SHA-256)."""
    out: list[dict[str, Any]] = []
    for attachment in getattr(mail, "attachments", None) or ():
        ad = str(getattr(attachment, "filename", "") or "")
        icerik = getattr(attachment, "content", b"") or b""
        out.append({
            "name": ad,
            "suffix": Path(ad).suffix.lower(),
            "size": len(icerik) if isinstance(icerik, (bytes, bytearray))
            else int(getattr(attachment, "size", 0) or 0),
            "sha256": (hashlib.sha256(icerik).hexdigest()
                       if isinstance(icerik, (bytes, bytearray)) and icerik
                       else str(getattr(attachment, "sha256", "") or "")),
        })
    return out


@dataclass(frozen=True)
class AICallRecord:
    """Tek bir LLM çağrısının denetim kaydı."""

    request_id: str
    model: str = ""
    prompt_sha256: str = ""
    payload_sha256: str = ""
    payload_chars: int = 0
    attachments: list[dict[str, Any]] = field(default_factory=list)
    response_sha256: str = ""
    response_chars: int = 0
    status: str = ""
    schema_valid: bool = False
    schema_errors: list[str] = field(default_factory=list)
    company_code: str = ""
    message_id: str = ""
    duration_ms: int = 0
    retries: int = 0
    created_at: str = ""


class AIAuditLog:
    """LLM çağrılarının SALT EKLENİR denetim günlüğü."""

    def __init__(self, path: str | Path | None = None) -> None:
        if path is None:
            base = app_data_dir()
            base.mkdir(parents=True, exist_ok=True)
            path = base / "ai_audit.db"
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    @property
    def path(self) -> Path:
        return self._path

    @contextmanager
    def _session(self):
        conn = open_sqlite_connection(self._path)
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _ensure_schema(self) -> None:
        try:
            with self._session() as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS ai_calls (
                        id              INTEGER PRIMARY KEY AUTOINCREMENT,
                        request_id      TEXT NOT NULL,
                        model           TEXT NOT NULL DEFAULT '',
                        prompt_sha256   TEXT NOT NULL DEFAULT '',
                        payload_sha256  TEXT NOT NULL DEFAULT '',
                        payload_chars   INTEGER NOT NULL DEFAULT 0,
                        attachments     TEXT NOT NULL DEFAULT '[]',
                        response_sha256 TEXT NOT NULL DEFAULT '',
                        response_chars  INTEGER NOT NULL DEFAULT 0,
                        status          TEXT NOT NULL DEFAULT '',
                        schema_valid    INTEGER NOT NULL DEFAULT 0,
                        schema_errors   TEXT NOT NULL DEFAULT '[]',
                        company_code    TEXT NOT NULL DEFAULT '',
                        message_id      TEXT NOT NULL DEFAULT '',
                        duration_ms     INTEGER NOT NULL DEFAULT 0,
                        retries         INTEGER NOT NULL DEFAULT 0,
                        created_at      TEXT NOT NULL
                    )
                """)
                conn.execute("CREATE INDEX IF NOT EXISTS ix_ai_calls_request "
                             "ON ai_calls (request_id)")
        except sqlite3.Error as exc:  # pragma: no cover - ortam bağımlı
            logger.error(f"[ai-audit] şema kurulamadı: {exc}")

    # -- yazma (yalnızca EKLEME) -------------------------------------------

    def record(self, entry: AICallRecord) -> bool:
        """Kaydı ekle. Yazılamazsa loglar, False döner (AI akışını kesmez)."""
        try:
            with self._session() as conn:
                conn.execute("""
                    INSERT INTO ai_calls (
                        request_id, model, prompt_sha256, payload_sha256,
                        payload_chars, attachments, response_sha256,
                        response_chars, status, schema_valid, schema_errors,
                        company_code, message_id, duration_ms, retries,
                        created_at
                    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (
                    entry.request_id, entry.model, entry.prompt_sha256,
                    entry.payload_sha256, int(entry.payload_chars),
                    json.dumps(entry.attachments, ensure_ascii=False,
                               default=str),
                    entry.response_sha256, int(entry.response_chars),
                    entry.status, 1 if entry.schema_valid else 0,
                    json.dumps(list(entry.schema_errors), ensure_ascii=False),
                    entry.company_code, entry.message_id,
                    int(entry.duration_ms), int(entry.retries),
                    entry.created_at or _now(),
                ))
            return True
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[ai-audit] kayıt yazılamadı: {exc}")
            return False

    # -- okuma -------------------------------------------------------------

    _COLUMNS = ("request_id, model, prompt_sha256, payload_sha256, "
                "payload_chars, attachments, response_sha256, response_chars, "
                "status, schema_valid, schema_errors, company_code, "
                "message_id, duration_ms, retries, created_at")

    def _row(self, row: Sequence[Any]) -> AICallRecord:
        def _liste(value):
            try:
                return json.loads(value or "[]")
            except (TypeError, ValueError):
                return []

        return AICallRecord(
            request_id=row[0], model=row[1], prompt_sha256=row[2],
            payload_sha256=row[3], payload_chars=int(row[4]),
            attachments=_liste(row[5]), response_sha256=row[6],
            response_chars=int(row[7]), status=row[8],
            schema_valid=bool(row[9]), schema_errors=_liste(row[10]),
            company_code=row[11], message_id=row[12],
            duration_ms=int(row[13]), retries=int(row[14]), created_at=row[15])

    def entries(self, request_id: Optional[str] = None) -> list[AICallRecord]:
        sql = f"SELECT {self._COLUMNS} FROM ai_calls"
        params: list[Any] = []
        if request_id:
            sql += " WHERE request_id = ?"
            params.append(request_id)
        sql += " ORDER BY id"
        try:
            with self._session() as conn:
                rows = conn.execute(sql, params).fetchall()
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[ai-audit] okunamadı: {exc}")
            return []
        return [self._row(r) for r in rows]

    def count(self) -> int:
        try:
            with self._session() as conn:
                return int(conn.execute(
                    "SELECT COUNT(*) FROM ai_calls").fetchone()[0])
        except sqlite3.Error:  # pragma: no cover
            return 0
