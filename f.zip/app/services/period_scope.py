"""Karşı tarafın ekstresi, TOFAŞ dosyasının DÖNEMİNİ aşıyor mu?

NEDEN GEREKLİ
    Gerçek veriyle ölçüldü: 65 mutabakatta "yalnız firmada" görünen 5.215
    satırın **2.530'u (%49)** TOFAŞ dosyasının tarih aralığının DIŞINDA
    kalıyordu. Bunlar bizde eksik olan faturalar değil; TOFAŞ çıkarımının
    kapsamadığı dönemlere ait satırlar.

    Kullanıcı 5.215 satırlık bir "fark" listesi görüyor, yarısının neden
    orada olduğunu bilmiyordu.

TASARIM İLKESİ — AYIRIR, SİLMEZ
    Dönem dışı satırlar listeden ÇIKARILMAZ. Yalnızca sayılır ve
    raporlanır; kullanıcı gerçek fark adaylarını (dönem içi) ayrı
    görebilsin diye.

    Silmek cazip ama tehlikeli olurdu: tarih okunamamış ya da dönem
    yanlış tespit edilmiş bir satır sessizce kaybolur, gerçek bir fark
    gizlenirdi. Görünürlük her zaman daha güvenlidir.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Iterable, Optional


@dataclass
class PeriodScope:
    """TOFAŞ tarafının kapsadığı tarih aralığı ve firma satırlarının dağılımı."""

    start: Optional[date] = None
    end: Optional[date] = None
    in_scope: int = 0        # dönem İÇİNDE — gerçek fark adayı
    out_of_scope: int = 0    # dönem DIŞINDA — kapsam farkı
    undated: int = 0         # tarihi okunamamış

    @property
    def known(self) -> bool:
        return self.start is not None and self.end is not None

    @property
    def total(self) -> int:
        return self.in_scope + self.out_of_scope + self.undated


def tofas_period(records: Iterable) -> tuple[Optional[date], Optional[date]]:
    """TOFAŞ kayıtlarının kapsadığı [ilk, son] belge tarihi."""
    tarihler = [r.belge_tarihi for r in records
                if getattr(r, "belge_tarihi", None) is not None]
    if not tarihler:
        return None, None
    return min(tarihler), max(tarihler)


def scope_of(only_firma: Iterable, tofas_records: Iterable) -> PeriodScope:
    """Firma-only satırlarını TOFAŞ dönemine göre ayır (SİLMEDEN)."""
    start, end = tofas_period(tofas_records)
    kapsam = PeriodScope(start=start, end=end)
    for r in only_firma:
        tarih = getattr(r, "inv_date", None)
        if tarih is None:
            kapsam.undated += 1
        elif start is not None and end is not None and start <= tarih <= end:
            kapsam.in_scope += 1
        elif start is None or end is None:
            kapsam.undated += 1
        else:
            kapsam.out_of_scope += 1
    return kapsam


def describe(kapsam: PeriodScope) -> Optional[str]:
    """Kullanıcıya gösterilecek açıklama; anlamlı bir şey yoksa None.

    Amaç: "bu fark listesinin ne kadarı gerçekten fark?" sorusunu
    yanıtlamak.
    """
    if not kapsam.known or kapsam.total == 0:
        return None
    if kapsam.out_of_scope == 0:
        return None
    yuzde = 100 * kapsam.out_of_scope / kapsam.total
    return (
        f"Yalnız firmada görünen {kapsam.total} satırın "
        f"{kapsam.out_of_scope}'i (%{yuzde:.0f}) TOFAŞ dosyasının dönemi "
        f"({kapsam.start.isoformat()} – {kapsam.end.isoformat()}) DIŞINDA. "
        f"Gerçek fark adayı: {kapsam.in_scope} satır"
        + (f", tarihi okunamayan: {kapsam.undated}" if kapsam.undated else "")
        + ". Dönem dışı satırlar listeden ÇIKARILMAZ; yalnızca ayrıştırılır."
    )
