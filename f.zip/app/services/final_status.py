"""FAZ 5 — kullanıcıya gösterilen NİHAİ DURUM (dört değerli sadeleştirme).

NEDEN AYRI BİR KATMAN
    ``CaseOutcome`` teknik olarak doğrudur ama yedi değerlidir
    (RECONCILED / DIFFERENCE / CONTRADICTION / NO_STATEMENT /
    DELIVERY_FAILED / AWAITING_REPLY / HUMAN_REVIEW). Ekranda çalışan
    kullanıcının sorusu daha basittir:

        «Bu firmayla mutabık mıyız, değil miyiz, yoksa bakmam mı gerekiyor?»

    Bu modül teknik durumu SİLMEDEN üstüne dört değerli bir gösterim koyar.
    Ayrıntılı gerekçe ve kanıt zinciri detay ekranında durur.

KARAR KAYNAĞI DEĞİŞMEZ
    Rakamlar Python'dan (deterministik motor), niyet mail gövdesinden gelir.
    Bu modül YENİ BİR KARAR ÜRETMEZ; yalnızca zaten üretilmiş kararı
    sadeleştirir ve şüpheli her durumu İNCELEME'ye çeker.

ALTIN KURAL
    MUTABIK yalnızca İKİSİ DE olumluysa verilir: firma kabul etmiş OLACAK
    ve gönderilen snapshot ile gelen ekstre örtüşecek. Tek başına "mutabıkız"
    yazan bir mail MUTABIK değildir — rakamsal teyit yoksa insan bakar.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

from app.incoming.models import ReplyType
from app.services.case_outcome import CaseEvaluation, CaseOutcome


class FinalStatus(str, Enum):
    """Ekranda gösterilen sade durum."""

    MUTABIK = "MUTABIK"
    RED = "RED"
    INCELEME = "İNCELEME"
    CEVAP_BEKLENIYOR = "CEVAP BEKLENİYOR"


# Firmanın "kabul etmiyorum" anlamına gelen cevapları (case_outcome ile aynı).
_REJECTING = frozenset({
    ReplyType.REJECTED, ReplyType.PARTIALLY_ACCEPTED,
    ReplyType.REQUESTED_CORRECTION,
})


@dataclass
class FinalDecision:
    """Nihai durum + neden öyle olduğu."""

    status: FinalStatus = FinalStatus.INCELEME
    outcome: CaseOutcome = CaseOutcome.HUMAN_REVIEW
    reasons: list[str] = field(default_factory=list)
    needs_human_review: bool = True

    def add_reason(self, text: str) -> None:
        if text and text not in self.reasons:
            self.reasons.append(text)

    @property
    def value(self) -> str:
        return self.status.value


def decide(
    evaluation: Optional[CaseEvaluation],
    *,
    snapshot_comparison: Any = None,
    ambiguous_send: bool = False,
    response: Any = None,
) -> FinalDecision:
    """Teknik değerlendirmeyi dört değerli nihai duruma indir.

    ``snapshot_comparison`` — FAZ 4 sonucu. Referans bulunamadıysa ya da
    snapshot bozuksa MUTABIK/RED ÜRETİLMEZ; karar insana bırakılır.
    ``ambiguous_send`` — hangi gönderime cevap verildiği belirsiz.
    """
    if evaluation is None:
        decision = FinalDecision()
        decision.add_reason("Değerlendirme üretilemedi.")
        return decision

    decision = FinalDecision(outcome=evaluation.outcome,
                             needs_human_review=evaluation.needs_human_review)
    for reason in evaluation.reasons:
        decision.add_reason(reason)

    # 1) Henüz gerçek bir cevap yok — mutabakat sorusu daha sorulmamış demektir.
    if evaluation.outcome is CaseOutcome.AWAITING_REPLY:
        decision.status = FinalStatus.CEVAP_BEKLENIYOR
        return decision

    # 2) Hangi gönderime cevap verildiği belirsizse hiçbir finansal karar
    #    güvenilir değildir — yanlış snapshot ihtimali vardır.
    if ambiguous_send:
        decision.status = FinalStatus.INCELEME
        decision.needs_human_review = True
        decision.add_reason(
            "Birden fazla geçerli gönderim adayı var; yanlış pakete "
            "karşılaştırma yapılmaması için karar verilmedi.")
        return decision

    # 3) Snapshot referansı yoksa / bozuksa: "gönderilen veriyi bilmiyoruz".
    blocking = _snapshot_blocking(snapshot_comparison)
    if blocking:
        decision.status = FinalStatus.INCELEME
        decision.needs_human_review = True
        decision.add_reason(blocking)
        return decision

    # 4) Çelişki, teslim hatası ve karar verilemeyen her durum insana gider.
    if evaluation.outcome in (CaseOutcome.CONTRADICTION,
                              CaseOutcome.HUMAN_REVIEW,
                              CaseOutcome.DELIVERY_FAILED):
        decision.status = FinalStatus.INCELEME
        decision.needs_human_review = True
        return decision

    # 5) Rakamlar uyuşmuyor → RED.
    if evaluation.outcome is CaseOutcome.DIFFERENCE:
        decision.status = FinalStatus.RED
        return decision

    # 6) Ekstre gelmedi: rakamsal teyit YOK.
    #    Firma açıkça reddettiyse cevabı nettir → RED.
    #    Kabul ettiyse teyitsiz "mutabık" denemez → İNCELEME.
    if evaluation.outcome is CaseOutcome.NO_STATEMENT:
        if evaluation.reply_type in _REJECTING:
            decision.status = FinalStatus.RED
            decision.add_reason(
                "Firma mutabık olmadığını bildirdi (ekstre gelmedi).")
        else:
            decision.status = FinalStatus.INCELEME
            decision.needs_human_review = True
            decision.add_reason(
                "Ekstre gelmediği için rakamsal teyit yapılamadı; "
                "MUTABIK yazılmadı.")
        return decision

    # 7) Hem cevap hem rakam olumlu → MUTABIK.
    #    Ancak veri kalitesi / AI çelişkisi gibi bir şüphe varsa İNCELEME.
    if evaluation.outcome is CaseOutcome.RECONCILED:
        # Rakamların tek başına örtüşmesi firma iradesi değildir. Boş,
        # bilgi amaçlı veya sınıflandırılamayan bir gövde açık kabul yerine
        # geçirilemez; aksi hâlde yalnızca ek yükleyen bir mail yanlışlıkla
        # MUTABIK görünür.
        explicit_acceptance = evaluation.reply_type is ReplyType.ACCEPTED
        if (not explicit_acceptance or evaluation.needs_human_review
                or _response_suspect(response)):
            decision.status = FinalStatus.INCELEME
            decision.needs_human_review = True
            if not explicit_acceptance:
                decision.add_reason(
                    "Rakamlar örtüşüyor ancak firma açık ve koşulsuz kabul "
                    "bildirmedi; otomatik MUTABIK verilmedi.")
            else:
                decision.add_reason(
                    "Rakamlar örtüşüyor ancak doğrulanması gereken bir nokta "
                    "var; otomatik MUTABIK verilmedi.")
        else:
            decision.status = FinalStatus.MUTABIK
        return decision

    decision.status = FinalStatus.INCELEME
    decision.needs_human_review = True
    return decision


def _snapshot_blocking(comparison: Any) -> str:
    """Snapshot tarafında karar vermeyi ENGELLEYEN bir durum var mı?"""
    if comparison is None:
        return ""
    # Geç import: bu modül UI ve servis katmanının ikisinden de çağrılır.
    from app.services.sent_statement_reconciliation import (
        REASON_COMPANY_MISMATCH,
        REASON_CURRENCY_MISMATCH,
        REASON_PERIOD_MISMATCH,
        REASON_SNAPSHOT_CORRUPT,
        ComparisonReference,
    )

    if getattr(comparison, "reference", None) is ComparisonReference.NONE:
        return ("Bu cevabın karşılaştırılacağı gönderim snapshot'ı "
                "bulunamadı; rakamsal karar verilmedi.")
    reasons = set(getattr(comparison, "reasons", ()) or ())
    if REASON_SNAPSHOT_CORRUPT in reasons:
        return ("Gönderim snapshot'ı bozulmuş; bu veriyle finansal karar "
                "verilmez.")
    if REASON_COMPANY_MISMATCH in reasons:
        return ("Cevaptaki firma kodu, gönderilen paketin firma koduyla "
                "uyuşmuyor.")
    if REASON_PERIOD_MISMATCH in reasons:
        return ("Cevaptaki dönem, gönderilen paketin dönemiyle uyuşmuyor.")
    if REASON_CURRENCY_MISMATCH in reasons:
        return ("Cevaptaki para birimleri gönderilen paketle hiç örtüşmüyor.")
    if getattr(comparison, "error", ""):
        return f"Snapshot karşılaştırması hata verdi: {comparison.error}"
    return ""


# Mail çözümlemesinde MUTABIK'ı ENGELLEYEN gerekçeler.
#
# NEDEN TÜM ``needs_human_review`` DEĞİL
#     Parser, mail gövdesinde firma kodu bulamadığında ya da güveni düşük
#     kaldığında kendini insan incelemesine işaretler. Oysa bu hattın
#     bağlamında firma kodu ZATEN KESİNDİR: cevap, In-Reply-To / zincir
#     kimliğiyle belirli bir gönderime (ve o gönderimin snapshot'ına)
#     bağlanmıştır. Parser'ın bu boşluğunu blokaj saymak, gerçek hayattaki
#     hemen her cevabı İNCELEME'ye düşürür ve özelliği işlevsiz bırakırdı.
#
#     Buna karşılık AŞAĞIDAKİLER gerçek belirsizliktir ve sessizce "mutabık"
#     sayılamaz: mailde birden fazla firma/mektup/ekstre olması, ekin
#     okunamaması, Python ile AI'nın çelişmesi ve ayrıştırıcı hatası.
BLOCKING_REPLY_REASONS = frozenset({
    "MULTIPLE_COMPANY_CODES",
    "MULTIPLE_LETTERS",
    "MULTIPLE_STATEMENTS",
    "ATTACHMENT_UNREADABLE",
    "PYTHON_AI_CONFLICT",
    "AI_REQUESTED_REVIEW",
    "PARSER_ERROR",
    "DUPLICATE_IN_PROGRESS",
    "CONDITIONAL_REPLY",
    "PAYMENT_INSTRUCTION_CHANGE",
})


def blocking_reply_reasons(response: Any) -> list[str]:
    """Cevabın MUTABIK olmasını engelleyen gerekçe kodları."""
    if response is None:
        return []
    reasons = [code for code in (getattr(response, "reasons", None) or ())
               if code in BLOCKING_REPLY_REASONS]
    if getattr(response, "conflicts", None) and "PYTHON_AI_CONFLICT" not in reasons:
        reasons.append("PYTHON_AI_CONFLICT")
    return reasons


def _response_suspect(response: Any) -> bool:
    """Mail çözümlemesinde MUTABIK'ı engelleyecek GERÇEK bir şüphe var mı?"""
    return bool(blocking_reply_reasons(response))
