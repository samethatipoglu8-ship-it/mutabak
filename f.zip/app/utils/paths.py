"""Centralized resolution of MutabakatPro's local application data directory
and of its bundled/user-editable configuration files.

Every service previously duplicated the literal ``Path.home() / ".mutabakat_pro"``
independently. This module gives that path exactly one definition so a future
change (e.g. to ``%LOCALAPPDATA%\\MutabakatPro``) is a one-line edit instead of
a multi-file one. The resolved location itself is unchanged by this module.
"""

from __future__ import annotations

import sys
from pathlib import Path


def app_data_dir() -> Path:
    """Return the local MutabakatPro application data directory.

    Currently ``~/.mutabakat_pro`` (user home directory), chosen because it is
    already the established location referenced throughout the test suite and
    audit docs, and because it resolves per-user with no machine-specific
    assumptions (it never names a specific username or drive layout).
    """
    return Path.home() / ".mutabakat_pro"


def is_frozen() -> bool:
    """True inside a PyInstaller-frozen build."""
    return bool(getattr(sys, "frozen", False))


def bundle_root() -> Path:
    """Repository root in a dev run, or the frozen bundle's contents dir.

    In a PyInstaller onedir build this is the ``_internal`` directory next
    to the ``.exe`` (where ``datas`` were collected); it is NOT where a user
    would look to edit config, which is why ``external_config_dir()`` exists.
    """
    if is_frozen():
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    return Path(__file__).resolve().parents[2]


def external_config_dir() -> Path:
    """The ``config`` directory a user can actually find and edit.

    In a frozen build this is next to the ``.exe`` (``dist/MutabakatPro/config``),
    not inside the hidden ``_internal`` folder. In a dev run there is no
    separate external location yet, so this is the same as the bundled one.
    """
    if is_frozen():
        return Path(sys.executable).parent / "config"
    return bundle_root() / "config"


def resolved_config_path(relative_name: str) -> Path:
    """Resolve a config file, preferring an external override next to the
    ``.exe`` over the bundled default (falls back to the bundled copy if no
    external override exists — this never requires the external file).
    """
    external = external_config_dir() / relative_name
    if external.is_file():
        return external
    return bundle_root() / "config" / relative_name


def resolved_env_path() -> Path:
    """Resolve ``.env``, preferring an external copy next to the ``.exe``."""
    if is_frozen():
        external = Path(sys.executable).parent / ".env"
        if external.is_file():
            return external
    return bundle_root() / ".env"
