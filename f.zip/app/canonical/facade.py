"""Canonical reconciliation facade.

Proves the target architecture: the SAME untouched ``Reconciler`` can be driven
through the canonical model boundary. It accepts canonical
``ReconciliationRecord`` objects (from any source — V4 loaders today, future
extractors/connectors tomorrow), converts them back to the V4 records the
engine expects, and returns the authoritative V4 ``ReconciliationResult``.

The reconciliation algorithm itself is never reimplemented here.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Iterable, Optional

from app.core.reconciler import Reconciler
from app.models.domain import ReconciliationResult

from .adapters import canonical_to_firma, canonical_to_tofas
from .model import ReconciliationRecord, RecordSide


class CanonicalReconciler:
    """Runs the existing deterministic engine from canonical records."""

    def __init__(
        self,
        excluded_belge_turu: Optional[Iterable[str]] = None,
        *,
        engine: Reconciler | None = None,
    ) -> None:
        """Create the canonical boundary over a deterministic engine.

        ``engine`` exists for production orchestration: callers that already
        constructed a fully configured ``Reconciler`` (date/currency/cross
        matching policy included) can pass that exact instance.  This keeps
        the canonical route behaviourally identical to the former direct
        route instead of silently falling back to facade defaults.
        """
        if engine is not None and excluded_belge_turu is not None:
            raise ValueError(
                "engine and excluded_belge_turu cannot both be supplied; "
                "configure exclusions on the injected engine."
            )
        self._engine = engine or Reconciler(excluded_belge_turu=excluded_belge_turu)

    def reconcile(
        self,
        records: Iterable[ReconciliationRecord],
        sap_total: Optional[Decimal] = None,
        firma_total: Optional[Decimal] = None,
    ) -> ReconciliationResult:
        firma = []
        tofas = []
        for rec in records:
            if rec.side is RecordSide.COUNTERPARTY:
                firma.append(canonical_to_firma(rec))
            elif rec.side is RecordSide.OURS:
                tofas.append(canonical_to_tofas(rec))
            else:
                raise ValueError(
                    f"Canonical record {rec.record_id} has no side; cannot route."
                )
        return self._engine.reconcile(
            firma, tofas, sap_total=sap_total, firma_total=firma_total
        )
