"""Otomatik mutabakat için finansal ön koşullar ve şirket toleransı (madde 5).

NEDEN
    Deterministik motor "iki liste tuttu mu?" sorusunu cevaplar. Ama iki
    listenin AYNI ŞEYİN listesi olduğunu kimse doğrulamıyorsa, motorun
    "MUTABIK" demesi bir şey ifade etmez:

      * Firma Haziran ekstresi göndermiş, biz Temmuz'u sormuşuz.
      * Ekstre EUR, bizim kayıt USD.
      * Gelen ekstre BAŞKA bir firmanın (mail yönlendirilmiş).
      * Firma borç bakiyesi göstermiş, biz alacak bakiyesi sormuşuz.

    Bu dördü eşleşmeden otomatik mutabakat YAPILMAZ; kayıt insan
    incelemesine düşer. "Eşleşmiyor" demek karar vermemek değildir —
    yanlış kararı engellemektir.

AYRICA
    * Yuvarlama toleransı ŞİRKET POLİTİKASIDIR: ayarlardan okunur, koda
      gömülü değildir.
    * "Metinde onay, ekte fark" her zaman YÜKSEK ÖNCELİKLİ incelemedir.
    * Birden fazla ekte FARKLI toplam varsa otomatik karar verilmez.

TASARIM
    Saf mantık: SQLite/Qt/COM bilmez, istisna fırlatmaz.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from typing import Any, Iterable, Optional, Sequence

#: Şirket politikası varsayılanları (ayar dosyası boşsa bunlar geçerlidir).
DEFAULT_AMOUNT_TOLERANCE = Decimal("0.01")
DEFAULT_DATE_TOLERANCE_DAYS = 0

#: İnceleme önceliği.
PRIORITY_NORMAL = "NORMAL"
PRIORITY_HIGH = "YÜKSEK"

_TOLERANCE_KEY = "amount_tolerance"
_DATE_TOLERANCE_KEY = "date_tolerance_days"
_STRICT_CURRENCY_KEY = "strict_currency"
_REQUIRE_DIRECTION_KEY = "require_direction_match"


def _decimal(value: Any, default: Decimal) -> Decimal:
    try:
        if value is None or value == "":
            return default
        return Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        return default


@dataclass(frozen=True)
class TolerancePolicy:
    """Şirketin yuvarlama/eşleşme politikası.

    ``amount_tolerance`` mutlak tutar toleransıdır (ör. 0.01 = bir kuruş).
    Kuruş farkları binlerce satırda kaçınılmazdır; ama tolerans KODA
    GÖMÜLÜRSE her şirket aynı eşiğe mahkûm olur ve denetimde "bu eşiği kim
    koydu?" sorusunun cevabı olmaz. Bu yüzden ayarda tutulur.
    """

    amount_tolerance: Decimal = DEFAULT_AMOUNT_TOLERANCE
    date_tolerance_days: int = DEFAULT_DATE_TOLERANCE_DAYS
    strict_currency: bool = False
    require_direction_match: bool = True

    @classmethod
    def from_settings(cls, settings: Any = None) -> "TolerancePolicy":
        """Politikayı ayarlardan oku. Ayar yoksa varsayılanlar geçerlidir."""
        if settings is None:
            return cls()
        try:
            return cls(
                amount_tolerance=_decimal(settings.get(_TOLERANCE_KEY),
                                          DEFAULT_AMOUNT_TOLERANCE),
                date_tolerance_days=int(settings.get(
                    _DATE_TOLERANCE_KEY, DEFAULT_DATE_TOLERANCE_DAYS) or 0),
                strict_currency=bool(settings.get(_STRICT_CURRENCY_KEY, False)),
                require_direction_match=bool(
                    settings.get(_REQUIRE_DIRECTION_KEY, True)),
            )
        except Exception:  # noqa: BLE001 - bozuk ayar varsayılana düşer
            return cls()

    def save_to(self, settings: Any) -> None:
        """Politikayı ayarlara yaz (yönetici ekranı bunu çağırır)."""
        settings.set(_TOLERANCE_KEY, str(self.amount_tolerance))
        settings.set(_DATE_TOLERANCE_KEY, int(self.date_tolerance_days))
        settings.set(_STRICT_CURRENCY_KEY, bool(self.strict_currency))
        settings.set(_REQUIRE_DIRECTION_KEY, bool(self.require_direction_match))

    def within_tolerance(self, difference: Any) -> bool:
        """Fark, şirket politikasının yuvarlama toleransı içinde mi?"""
        fark = _decimal(difference, Decimal("0")).copy_abs()
        return fark <= self.amount_tolerance.copy_abs()


@dataclass
class PreconditionResult:
    """Otomatik mutabakat ön koşullarının sonucu."""

    ok: bool = True
    blockers: list[str] = field(default_factory=list)
    checked: list[str] = field(default_factory=list)

    def block(self, reason: str) -> None:
        self.ok = False
        if reason not in self.blockers:
            self.blockers.append(reason)


def _norm(value: Any) -> str:
    return str(value or "").strip().upper()


def _period(value: Any) -> str:
    """Dönemi karşılaştırılabilir hâle getir ("2026-07" / "07.2026" → 2026-07)."""
    metin = str(value or "").strip()
    if not metin:
        return ""
    metin = metin.replace("/", "-").replace(".", "-")
    parcalar = [p for p in metin.split("-") if p]
    if len(parcalar) >= 2:
        if len(parcalar[0]) == 4:
            return f"{parcalar[0]}-{parcalar[1].zfill(2)}"
        if len(parcalar[-1]) == 4:
            return f"{parcalar[-1]}-{parcalar[0].zfill(2)}"
    return metin.upper()


def check_preconditions(
    *,
    expected_company: str = "",
    observed_company: str = "",
    expected_period: str = "",
    observed_period: str = "",
    expected_direction: str = "",
    observed_direction: str = "",
    expected_currencies: Iterable[str] = (),
    observed_currencies: Iterable[str] = (),
    policy: Optional[TolerancePolicy] = None,
) -> PreconditionResult:
    """Para birimi, dönem, firma kodu ve borç/alacak yönü eşleşiyor mu?

    BOŞ DEĞER ENGEL DEĞİLDİR: "bilinmiyor" ile "uyuşmuyor" farklı şeylerdir.
    Bilinmeyen bir alan zaten aşağıdaki katmanlarda insan incelemesi üretir;
    burada yalnızca AÇIKÇA ÇELİŞEN alanlar otomatik kararı durdurur.
    """
    policy = policy or TolerancePolicy()
    result = PreconditionResult()

    beklenen, gelen = _norm(expected_company), _norm(observed_company)
    if beklenen and gelen:
        result.checked.append("firma_kodu")
        if beklenen != gelen:
            result.block(
                f"Firma kodu uyuşmuyor: gönderim {beklenen}, cevap {gelen}. "
                "Otomatik mutabakat yapılmadı.")

    beklenen_d, gelen_d = _period(expected_period), _period(observed_period)
    if beklenen_d and gelen_d:
        result.checked.append("dönem")
        if beklenen_d != gelen_d:
            result.block(
                f"Dönem uyuşmuyor: gönderim {beklenen_d}, cevap {gelen_d}. "
                "Otomatik mutabakat yapılmadı.")

    if policy.require_direction_match:
        beklenen_y, gelen_y = _norm(expected_direction), _norm(observed_direction)
        # "X" iki yönü de kapsar; UNKNOWN bilgi yokluğudur, çelişki değil.
        if (beklenen_y and gelen_y and gelen_y not in ("X", "UNKNOWN")
                and beklenen_y not in ("X", "UNKNOWN")):
            result.checked.append("borç/alacak yönü")
            if beklenen_y != gelen_y:
                result.block(
                    f"Borç/alacak yönü uyuşmuyor: gönderim {beklenen_y}, "
                    f"cevap {gelen_y}. Otomatik mutabakat yapılmadı.")

    beklenen_pb = {_norm(c) for c in expected_currencies if _norm(c)}
    gelen_pb = {_norm(c) for c in observed_currencies if _norm(c)}
    if beklenen_pb and gelen_pb:
        result.checked.append("para birimi")
        if not (beklenen_pb & gelen_pb):
            result.block(
                "Para birimi uyuşmuyor: gönderim "
                f"{', '.join(sorted(beklenen_pb))}, cevap "
                f"{', '.join(sorted(gelen_pb))}. Otomatik mutabakat yapılmadı.")
    return result


# -- birden fazla ek -------------------------------------------------------

@dataclass
class StatementSelection:
    """Birden fazla ekstre ekinden hangisinin kullanılacağı."""

    statement: Optional[Any] = None
    conflict: bool = False
    reason: str = ""
    totals: list[str] = field(default_factory=list)

    @property
    def auto_decision_allowed(self) -> bool:
        return not self.conflict


def _total_of(statement: Any) -> Optional[Decimal]:
    """Ekstrenin firma tarafı toplamı (okunamıyorsa ``None``)."""
    analysis = getattr(statement, "analysis", None)
    if analysis is None:
        return None
    try:
        return Decimal(str(getattr(analysis, "firma_balance", "0"))
                       ).quantize(Decimal("0.01"))
    except (InvalidOperation, ValueError, TypeError):
        return None


def select_statement(statements: Sequence[Any],
                     policy: Optional[TolerancePolicy] = None
                     ) -> StatementSelection:
    """İşlenebilir ekstreler arasından karar verilecek olanı seç.

    BİRDEN FAZLA EKTE FARKLI TOPLAM VARSA OTOMATİK KARAR VERİLMEZ.
    Hangi dosyanın "asıl ekstre" olduğunu program bilemez; birini seçmek,
    firmanın gönderdiği diğer belgeyi sessizce yok saymaktır. Toplamlar
    politikadaki yuvarlama toleransı içinde AYNI ise çelişki yoktur ve ilk
    ekstre kullanılır.
    """
    policy = policy or TolerancePolicy()
    from app.services.statement_reconciliation import StatementStatus

    islenebilir = [s for s in statements or ()
                   if getattr(s, "status", None) in (StatementStatus.MATCHED,
                                                     StatementStatus.DIFFERENCE)]
    if not islenebilir:
        ilk = statements[0] if statements else None
        return StatementSelection(statement=ilk)

    toplamlar = [(s, _total_of(s)) for s in islenebilir]
    bilinen = [(s, t) for s, t in toplamlar if t is not None]
    if len(bilinen) > 1:
        temel = bilinen[0][1]
        farkli = [t for _s, t in bilinen[1:]
                  if not policy.within_tolerance(t - temel)]
        if farkli:
            return StatementSelection(
                statement=bilinen[0][0], conflict=True,
                totals=[f"{getattr(s, 'source_filename', '?')}: {t}"
                        for s, t in bilinen],
                reason=("Cevapta birden fazla ekstre var ve toplamları "
                        "birbirini tutmuyor; hangisinin geçerli olduğu "
                        "belirsiz olduğu için OTOMATİK KARAR VERİLMEDİ."))
    return StatementSelection(statement=islenebilir[0])


# -- inceleme önceliği -----------------------------------------------------

def review_priority(evaluation: Any) -> str:
    """Bu vaka yüksek öncelikli inceleme mi?

    "Metinde onay, ekte fark" (ÇELİŞKİ) HER ZAMAN yüksek önceliklidir:
    firma mutabık olduğunu yazmışken rakamlar tutmuyorsa, sıradan bir fark
    değil, taraflardan birinin yanlış okuduğu bir tablo vardır.
    """
    if evaluation is None:
        return PRIORITY_NORMAL
    from app.services.case_outcome import CaseOutcome

    if getattr(evaluation, "outcome", None) is CaseOutcome.CONTRADICTION:
        return PRIORITY_HIGH
    if getattr(evaluation, "contradictions", None):
        return PRIORITY_HIGH
    return PRIORITY_NORMAL
