"""FAZ 11 — gelen ekstreyi GÜNCEL FBL datasıyla karşılaştırma (§2, §6).

KULLANICI KARARI
    Finansal fark hesaplanırken referans, sistemdeki **en son yüklenen**
    FBL1H/FBL5H datasıdır. Kullanıcı yeni dosya yüklemediği sürece aynı
    dosyalar kullanılır ve her karşılaştırma bu güncel veriyle yenilenir.
    (Gönderim anındaki snapshot silinmez; kanıt olarak durur ve detay
    ekranında gösterilir — ama farkın kaynağı güncel FBL'dir.)

YÖN DOSYAYI SEÇER
    M  -> FBL5H (müşteri kalemleri)
    S / X -> FBL1H (satıcı kalemleri)

YENİ MOTOR YOK
    Karşılaştırmayı yapan yine ``StatementReconciliationService``, o da yine
    ``app/core/reconciler.py``dır. Bu modül yalnızca motora verilecek KARŞI
    TARAFI hazırlar: güncel FBL dosyasından o firmanın, o yöndeki satırları.

PERFORMANS
    9.000 satırlık bir FBL'yi her satır için yeniden açmak toplu
    karşılaştırmayı dakikalara çıkarırdı. Dosyalar bir kez okunup
    önbelleklenir; önbellek anahtarı dosya yolu + değişiklik zamanıdır, yani
    kullanıcı yeni dosya yüklediğinde önbellek kendiliğinden tazelenir.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path
from typing import Any, Optional, Sequence

from loguru import logger

from app.models.domain import TofasRecord
from app.services.company_statement_service import CompanyStatementService
from app.services.statement_reconciliation import (
    StatementReconciliationResult,
    StatementReconciliationService,
    StatementStatus,
)

# Yön -> hangi dosyadan beslenir.
SOURCE_FOR_DIRECTION = {"M": "FBL5H", "S": "FBL1H", "X": "FBL1H", "": "FBL1H"}


@dataclass
class CurrentFblComparison:
    """Bir case'in güncel FBL ile karşılaştırma sonucu."""

    company_code: str = ""
    balance_type: str = ""
    source_type: str = ""              # FBL1H | FBL5H
    source_path: str = ""
    reference_rows: int = 0
    statement: Optional[StatementReconciliationResult] = None
    error: str = ""
    reasons: list[str] = field(default_factory=list)

    def add_reason(self, text: str) -> None:
        if text and text not in self.reasons:
            self.reasons.append(text)

    @property
    def compared(self) -> bool:
        """Motor gerçekten çalıştı mı?"""
        return (self.statement is not None
                and self.statement.status in (StatementStatus.MATCHED,
                                              StatementStatus.DIFFERENCE))

    @property
    def difference_found(self) -> Optional[bool]:
        """Üç değerli: fark var / yok / karşılaştırılamadı."""
        if not self.compared or self.statement is None:
            return None
        return self.statement.status is StatementStatus.DIFFERENCE

    @property
    def difference_total(self) -> Decimal:
        if self.statement is None or self.statement.analysis is None:
            return Decimal("0")
        return getattr(self.statement.analysis, "difference", Decimal("0"))

    @property
    def status_text(self) -> str:
        if self.error:
            return "KONTROL EDİLEMEDİ"
        if self.statement is None:
            return "EKSTRE YOK"
        return self.statement.status.value

    @staticmethod
    def _serialize_rows(records, *, date_attr: str, text_attr: str,
                        limit: int) -> list[dict[str, Any]]:
        """Kayıtları JSON'a uygun satırlara çevir (ORTAK serileştirici).

        İki yön (firma / TOFAŞ) AYNI biçimi kullanır ki mail üretimi tek
        koddan beslensin; ama listeler ASLA birleştirilmez — finansal
        anlamları farklıdır.
        """
        out: list[dict[str, Any]] = []
        for record in list(records or [])[:limit]:
            tarih = getattr(record, date_attr, None)
            out.append({
                "reference": str(getattr(record, "reference_raw", "")
                                 or getattr(record, "reference", "") or ""),
                "date": tarih.strftime("%d.%m.%Y") if tarih else "",
                "amount": str(getattr(record, "amount", "") or ""),
                "currency": str(getattr(record, "currency", "") or ""),
                "description": str(getattr(record, text_attr, "") or "")[:60],
            })
        return out

    def only_firma_rows(self, limit: int = 40) -> list[dict[str, Any]]:
        """FİRMADA olup BİZDE olmayan satırlar.

        Bu kalemlerin faturası bize ULAŞMAMIŞ olabilir; firmadan FATURA
        istenir (REQUEST_MISSING_INVOICES).

        Uydurma satır üretilmez: kaynak yalnızca motorun ``only_firma``
        listesidir.
        """
        engine = (getattr(self.statement, "engine_result", None)
                  if self.statement else None)
        if engine is None:
            return []
        return self._serialize_rows(getattr(engine, "only_firma", []),
                                    date_attr="inv_date",
                                    text_attr="comment", limit=limit)

    def only_tofas_rows(self, limit: int = 40) -> list[dict[str, Any]]:
        """BİZDE olup FİRMANIN ekstresinde olmayan satırlar.

        DİKKAT — YÖN FARKI FİNANSALDIR: bu kalemlerin faturası ZATEN
        BİZDEDİR. Firmadan fatura İSTENMEZ; kaydını düzeltmesi ya da farkı
        açıklaması istenir (REQUEST_CORRECTED_STATEMENT). İki listeyi aynı
        metinle kullanmak karşı taraftan yanlış belge istemek olur.
        """
        engine = (getattr(self.statement, "engine_result", None)
                  if self.statement else None)
        if engine is None:
            return []
        return self._serialize_rows(getattr(engine, "only_tofas", []),
                                    date_attr="belge_tarihi",
                                    text_attr="metin", limit=limit)

    def summary(self) -> dict[str, Any]:
        """Case kaydına yazılacak özet (JSON'a uygun)."""
        analysis = self.statement.analysis if self.statement else None
        return {
            "reference": "CURRENT_FBL",
            "source_type": self.source_type,
            "source_path": self.source_path,
            "reference_rows": self.reference_rows,
            "status": self.status_text,
            "source_filename": (self.statement.source_filename
                                if self.statement else ""),
            "rows_loaded": self.statement.rows_loaded if self.statement else 0,
            "matched": getattr(analysis, "matched", 0) if analysis else 0,
            "amount_diff": getattr(analysis, "amount_diff", 0) if analysis else 0,
            "cross_matched": getattr(analysis, "cross_matched", 0) if analysis else 0,
            "only_firma": getattr(analysis, "only_firma", 0) if analysis else 0,
            "only_tofas": getattr(analysis, "only_tofas", 0) if analysis else 0,
            "difference": str(self.difference_total),
            "currency": getattr(analysis, "currency", "") if analysis else "",
            "error": self.error,
            "reasons": list(self.reasons),
            "only_firma_rows": self.only_firma_rows(),
            "only_tofas_rows": self.only_tofas_rows(),
        }


class _StatementCache:
    """Dosya yolu + mtime anahtarlı FBL önbelleği (thread güvenli)."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._entries: dict[tuple[str, float, str], dict[str, Any]] = {}

    def load(self, path: str, kind: str,
             service: CompanyStatementService) -> dict[str, Any]:
        target = Path(path)
        try:
            mtime = target.stat().st_mtime
        except OSError as exc:
            raise FileNotFoundError(f"FBL dosyası okunamadı: {path}") from exc

        key = (str(target.resolve()), mtime, kind)
        with self._lock:
            cached = self._entries.get(key)
        if cached is not None:
            return cached

        logger.info(f"[fbl] {kind} okunuyor: {target.name}")
        result = (service.load_customer(str(target)) if kind == "FBL5H"
                  else service.load(str(target)))
        by_code = result.by_code()
        with self._lock:
            # Yalnızca AYNI dosya+tür için eski mtime sürümlerini düşür.
            # Tüm sözlüğü değiştirmek FBL1H ve FBL5H dönüşümlü yüklendiğinde
            # her seferinde diğerinin önbelleğini siliyor, önbelleği
            # işlevsiz bırakıyordu.
            resolved = str(target.resolve())
            eski = [k for k in self._entries
                    if k[0] == resolved and k[2] == kind]
            for k in eski:
                self._entries.pop(k, None)
            self._entries[key] = by_code
        return by_code

    def clear(self) -> None:
        with self._lock:
            self._entries.clear()


class CurrentFblReconciliationService:
    """Gelen ekstreyi, sistemdeki SON FBL datasıyla karşılaştırır."""

    def __init__(
        self,
        fbl1h_path: str = "",
        fbl5h_path: str = "",
        statement_service: Optional[StatementReconciliationService] = None,
        company_service: Optional[CompanyStatementService] = None,
        cache: Optional[_StatementCache] = None,
    ) -> None:
        self._paths = {"FBL1H": fbl1h_path or "", "FBL5H": fbl5h_path or ""}
        self._statements = statement_service or StatementReconciliationService()
        self._companies = company_service or CompanyStatementService()
        self._cache = cache or _StatementCache()

    # -- yapılandırma ------------------------------------------------------

    def set_sources(self, fbl1h_path: str = "", fbl5h_path: str = "") -> None:
        """Kullanıcı yeni dosya yüklediğinde çağrılır; önbellek tazelenir."""
        self._paths = {"FBL1H": fbl1h_path or "", "FBL5H": fbl5h_path or ""}
        self._cache.clear()

    def source_for(self, balance_type: str) -> tuple[str, str]:
        """(kaynak türü, dosya yolu) — yön dosyayı seçer."""
        kind = SOURCE_FOR_DIRECTION.get((balance_type or "").upper(), "FBL1H")
        return kind, self._paths.get(kind, "")

    def reference_records(self, company_code: str,
                          balance_type: str) -> tuple[list[TofasRecord], str, str]:
        """Güncel FBL'den firmanın o yöndeki satırları."""
        kind, path = self.source_for(balance_type)
        if not path:
            raise FileNotFoundError(
                f"{kind} dosyası yüklenmemiş; karşılaştırma yapılamaz.")
        by_code = self._cache.load(path, kind, self._companies)
        statement = by_code.get(company_code)
        rows = list(statement.rows) if statement is not None else []
        return rows, kind, path

    # -- ana işlem ---------------------------------------------------------

    def reconcile(self, case: Any, attachments: Sequence[Any]
                  ) -> CurrentFblComparison:
        """Case'in gelen eklerini güncel FBL ile karşılaştır.

        İSTİSNA FIRLATMAZ: her hata ``error`` alanına yazılır ki toplu
        karşılaştırmada tek bir bozuk satır tüm süreci durdurmasın.
        """
        company_code = getattr(case, "company_code", "") or ""
        balance_type = getattr(case, "balance_type", "") or ""
        kind, path = self.source_for(balance_type)
        comparison = CurrentFblComparison(
            company_code=company_code, balance_type=balance_type,
            source_type=kind, source_path=path)

        try:
            records, kind, path = self.reference_records(company_code,
                                                         balance_type)
        except FileNotFoundError as exc:
            comparison.error = str(exc)
            comparison.add_reason("FBL_NOT_LOADED")
            return comparison
        except Exception as exc:  # noqa: BLE001 - bozuk dosya süreci durdurmaz
            comparison.error = f"{type(exc).__name__}: {exc}"
            comparison.add_reason("FBL_READ_ERROR")
            logger.warning(f"[fbl] {company_code} okunamadı: {exc}")
            return comparison

        comparison.reference_rows = len(records)
        if not records:
            comparison.add_reason("COMPANY_NOT_IN_FBL")

        usable = [a for a in (attachments or [])
                  if getattr(a, "filename", "")]
        if not usable:
            comparison.add_reason("NO_ATTACHMENT")
            return comparison

        best: Optional[StatementReconciliationResult] = None
        for attachment in usable:
            try:
                result = self._statements.reconcile_attachment(attachment,
                                                               records)
            except Exception as exc:  # noqa: BLE001 - tek ek diğerlerini düşürmez
                logger.warning(
                    f"[fbl] ek karşılaştırılamadı ({company_code} "
                    f"{getattr(attachment, 'filename', '')}): {exc}")
                comparison.add_reason("ATTACHMENT_ERROR")
                continue
            if best is None or _rank(result) > _rank(best):
                best = result

        comparison.statement = best
        if best is None:
            comparison.add_reason("STATEMENT_UNREADABLE")
        return comparison


def _rank(result: StatementReconciliationResult) -> int:
    """Birden çok ek varsa EN BİLGİLENDİRİCİ sonucu seç.

    Fark bulunmuş bir karşılaştırma, hiç okunamamış bir ekten daha
    değerlidir; "eşleşti" ise en güçlü sonuçtur.
    """
    order = {
        StatementStatus.MATCHED: 3,
        StatementStatus.DIFFERENCE: 2,
    }
    return order.get(result.status, 1 if result.rows_loaded else 0)
