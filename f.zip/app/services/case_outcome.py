"""Mail cevabı + ekstre sonucunu BİRLİKTE değerlendirme (ama karıştırmadan).

İKİ AYRI GERÇEK
    ``reply_type``  → firma NE DEDİ?      (mail semantiği, dil işi)
    ``statement``   → rakamlar NE DİYOR?  (deterministik motor, finans işi)

    Bu ikisi aynı şey değildir ve birbirinin yerine geçemez:

      "Mutabıkız" diyen bir firmanın ekstresi 6.500 EUR fark gösterebilir.
      "Mutabık değiliz" diyen bir firmanın ekstresi birebir tutabilir.

    Her iki durumda da doğru davranış, birini seçip diğerini yok saymak değil,
    ÇELİŞKİYİ işaretleyip insana sunmaktır. Rakamlar Python'dan, niyet
    mailden gelir; hiçbiri diğerini ezmez.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Optional

from app.incoming.models import ReplyType
from app.services.mail_status import MailStatus
from app.services.statement_reconciliation import (
    StatementReconciliationResult,
    StatementStatus,
)


class CaseOutcome(str, Enum):
    """Bir mutabakat kaydının nihai durumu."""

    RECONCILED = "RECONCILED"                  # hem cevap hem rakam olumlu
    DIFFERENCE = "DIFFERENCE"                  # rakamlarda fark var
    CONTRADICTION = "CONTRADICTION"            # cevap ile rakam çelişiyor
    NO_STATEMENT = "NO_STATEMENT"              # cevap var, ekstre yok
    DELIVERY_FAILED = "DELIVERY_FAILED"        # mail ulaşmadı
    AWAITING_REPLY = "AWAITING_REPLY"          # henüz cevap yok
    HUMAN_REVIEW = "HUMAN_REVIEW"              # karar verilemedi


@dataclass
class CaseEvaluation:
    """Birleşik değerlendirme — hangi bilginin nereden geldiği bellidir."""

    outcome: CaseOutcome = CaseOutcome.HUMAN_REVIEW
    mail_status: MailStatus = MailStatus.UNKNOWN
    reply_type: ReplyType = ReplyType.UNKNOWN
    statement_status: Optional[StatementStatus] = None
    needs_human_review: bool = False
    contradictions: list[str] = field(default_factory=list)
    reasons: list[str] = field(default_factory=list)

    def add_reason(self, text: str) -> None:
        if text and text not in self.reasons:
            self.reasons.append(text)


# Firmanın "kabul ediyorum" anlamına gelen cevapları.
_ACCEPTING = frozenset({ReplyType.ACCEPTED})
# Firmanın "kabul etmiyorum / farklı" anlamına gelen cevapları.
_REJECTING = frozenset({
    ReplyType.REJECTED, ReplyType.PARTIALLY_ACCEPTED,
    ReplyType.REQUESTED_CORRECTION,
})


def _format_difference(statement: StatementReconciliationResult) -> str:
    """Farkı okunabilir yaz: mutlak değer + (biliniyorsa) para birimi.

    İşaret kullanıcıya bilgi vermez ("-550" hangi tarafın eksik olduğunu
    anlatmaz); yön zaten gerekçe satırlarında ("yalnızca firma ekstresinde…")
    açıkça yazılıdır.
    """
    analysis = statement.analysis
    if analysis is None:
        return "bir"
    amount = analysis.difference.copy_abs().quantize(Decimal("0.01"))
    text = f"{amount:,}".replace(",", "@").replace(".", ",").replace("@", ".")
    return f"{text} {analysis.currency}".strip()


def evaluate_case(
    *,
    reply_type: ReplyType = ReplyType.UNKNOWN,
    statement: Optional[StatementReconciliationResult] = None,
    delivery_failed: bool = False,
    automatic_reply: bool = False,
    replied: bool = True,
) -> CaseEvaluation:
    """Mail cevabı ile ekstre sonucunu birleştir; çelişkileri işaretle."""
    evaluation = CaseEvaluation(reply_type=reply_type)

    # 1) Mail hiç ulaşmadıysa cevap beklemenin anlamı yok.
    if delivery_failed:
        evaluation.outcome = CaseOutcome.DELIVERY_FAILED
        evaluation.mail_status = MailStatus.DELIVERY_FAILED
        evaluation.needs_human_review = True
        evaluation.add_reason("Mail teslim edilemedi; adres kontrol edilmeli.")
        return evaluation

    # 2) Otomatik yanıt cevap sayılmaz.
    if automatic_reply:
        evaluation.outcome = CaseOutcome.AWAITING_REPLY
        evaluation.mail_status = MailStatus.AUTOMATIC_REPLY
        evaluation.add_reason("Otomatik yanıt alındı; gerçek cevap bekleniyor.")
        return evaluation

    if not replied:
        evaluation.outcome = CaseOutcome.AWAITING_REPLY
        evaluation.mail_status = MailStatus.AWAITING_REPLY
        return evaluation

    evaluation.mail_status = MailStatus.REPLY_RECEIVED

    # 3) Ekstre yoksa yalnızca mail semantiği vardır — rakamla teyit YOK.
    if statement is None or statement.status in (StatementStatus.NO_STATEMENT,):
        evaluation.statement_status = (
            statement.status if statement is not None else None)
        evaluation.outcome = CaseOutcome.NO_STATEMENT
        if reply_type in _ACCEPTING:
            evaluation.add_reason(
                "Firma mutabık olduğunu bildirdi; ekstre gelmediği için "
                "rakamsal teyit YAPILAMADI.")
        else:
            evaluation.needs_human_review = True
            evaluation.add_reason(
                "Ekstre gelmedi; cevabın rakamsal karşılığı doğrulanamıyor.")
        return evaluation

    evaluation.statement_status = statement.status

    # 4) Ekstre okunamadı / motor hata verdi.
    if statement.status in (StatementStatus.UNREADABLE, StatementStatus.ERROR):
        evaluation.outcome = CaseOutcome.HUMAN_REVIEW
        evaluation.mail_status = MailStatus.HUMAN_REVIEW
        evaluation.needs_human_review = True
        evaluation.add_reason(
            f"Ekstre işlenemedi ({statement.error or 'bilinmeyen hata'}).")
        return evaluation

    matched = statement.status is StatementStatus.MATCHED

    # 5) ÇELİŞKİ KONTROLÜ — mail ne dedi, rakam ne diyor?
    if matched and reply_type in _REJECTING:
        evaluation.contradictions.append(
            "Firma mutabık olmadığını bildirdi ancak gönderdiği ekstre "
            "kayıtlarımızla birebir örtüşüyor.")
    if not matched and reply_type in _ACCEPTING:
        evaluation.contradictions.append(
            "Firma mutabık olduğunu bildirdi ancak ekstresi "
            f"{_format_difference(statement)} fark gösteriyor.")

    if evaluation.contradictions:
        evaluation.outcome = CaseOutcome.CONTRADICTION
        evaluation.mail_status = MailStatus.HUMAN_REVIEW
        evaluation.needs_human_review = True
        for line in evaluation.contradictions:
            evaluation.add_reason(line)
        return evaluation

    # 6) Çelişki yok: kararı RAKAMLAR verir.
    if matched:
        evaluation.outcome = CaseOutcome.RECONCILED
        evaluation.mail_status = MailStatus.RECONCILED
        evaluation.add_reason("Ekstre kayıtlarımızla örtüşüyor.")
    else:
        evaluation.outcome = CaseOutcome.DIFFERENCE
        evaluation.mail_status = MailStatus.RECONCILIATION_DIFFERENCE
        evaluation.needs_human_review = True
        if statement.analysis is not None:
            for line in statement.analysis.explain():
                evaluation.add_reason(line)

    # Ekstrenin kendi veri kalitesi sorunları da insana taşınır.
    if statement.needs_human_review:
        evaluation.needs_human_review = True
        evaluation.add_reason("Ekstrenin veri kalitesi doğrulanmalı.")
    return evaluation
