"""Uygulamanın ürettiği dosyaların (sonuç Excel'i, mektuplar, taslaklar)
kaydedileceği ORTAK klasör.

Kullanıcıya İLK seferde sorulur, ayarlara yazılır ve sonra hatırlanır.
Ayarlar ekranından değiştirilebilir.

Mutabakat sonucu kullanıcının TOFAŞ dosyasının İÇİNE yazılmaz ve kaynak
dosya KOPYALANMAZ: ``ResultWriter`` bağımsız bir sonuç kitabı üretir, bu
modül yalnızca o kitabın nereye ve hangi adla yazılacağını belirler.

NEDEN KOPYA DA KALDIRILDI
    Önceki sürüm kaynağın tam kopyasını alıp sonuç sayfasını kopyaya
    ekliyordu. Gerçekçi bir FBL1H (15.601 satır) üzerinde bu, firma başına
    ~11,7 sn ve kaynak boyutunda bir çıktı demekti; bağımsız kitap ~0,04 sn
    ve ~8 KB. Dönem başına yüzlerce firma çalıştırıldığında fark saatlerle
    dakikalar arasındadır. İzlenebilirlik kaybolmaz: sonucun özet sayfası
    TOFAŞ dosya adını, SHA-256'sını ve satır sayısını taşır.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

OUTPUT_FOLDER_KEY = "output_folder"


def saved_output_folder(settings: Any) -> str:
    """Kayıtlı klasörü döndür; yoksa ya da artık mevcut değilse boş."""
    if settings is None:
        return ""
    try:
        yol = str(settings.get(OUTPUT_FOLDER_KEY, "") or "").strip()
    except Exception:  # noqa: BLE001 - ayar okunamazsa yeniden sorulur
        return ""
    return yol if yol and Path(yol).is_dir() else ""


def save_output_folder(settings: Any, folder: str) -> None:
    settings.set(OUTPUT_FOLDER_KEY, str(folder))


def result_target(tofas_path: str | Path, output_dir: str | Path) -> Path:
    """Sonuç kitabının yazılacağı BENZERSİZ yolu döndür.

    Kaynak dosya ne açılır ne kopyalanır; yalnızca adı kullanılır. Hedef
    daima ``<klasör>/<ad>_mutabakat.xlsx``tir (varsa sonuna ``(2)``, ``(3)``…
    eklenir), çünkü bağımsız sonuç kitabında makro yoktur.

    Dönen yol ``ResultWriter.write(..., target=...)`` ile AYNEN kullanılır.

    AD ATOMİK OLARAK REZERVE EDİLİR
        Dönen yolda 0 baytlık bir dosya OLUŞTURULUR. Sebep: ad yalnızca
        hesaplanıp dosya oluşturulmazsa, yazma gerçekleşmeden yapılan ikinci
        bir çağrı AYNI adı döndürür ve ikinci çalıştırma birincinin sonucunu
        ezer. Rezervasyon ``O_CREAT | O_EXCL`` ile yapıldığı için iki çağrı
        arasında yarış da oluşmaz. ``ResultWriter`` yazarken ``os.replace``
        ile bu yer tutucunun üzerine geçer.
    """
    src = Path(tofas_path)
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    return _reserve(out / f"{src.stem}_mutabakat.xlsx")


def _reserve(path: Path) -> Path:
    """Adı atomik olarak rezerve et; doluysa sonuna (2), (3)… ekleyerek dene."""
    import os

    for n in range(1, 10_000):
        aday = path if n == 1 else path.with_name(f"{path.stem} ({n}){path.suffix}")
        try:
            fd = os.open(str(aday), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            continue
        os.close(fd)
        return aday
    raise OSError(f"Benzersiz dosya adı üretilemedi: {path}")
