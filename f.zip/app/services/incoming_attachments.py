"""FAZ 11 — gelen eklerin kalıcı, içerik adresli deposu (§16).

NEDEN
    "Karşılaştır" butonu tarama bittikten saatler sonra da çalışabilmelidir.
    Gelen ekler şimdiye kadar yalnızca tarama sırasında bellekte yaşıyordu;
    uygulama kapandığında firma ekstresi kayboluyor, karşılaştırma bir daha
    yapılamıyordu.

İÇERİK ADRESLİ
    Dosyalar SHA-256'larıyla saklanır. Aynı ek ikinci kez indirilirse yeniden
    YAZILMAZ (idempotency): firma aynı ekstreyi üç kez yollasa bile diskte
    tek kopya durur ve karşılaştırma aynı sonucu verir.

DOSYA ADI KORUNUR
    Ayrıştırıcılar uzantıya bakar; bu yüzden özgün ad (ve uzantısı) kayıt
    defterinde saklanır, fiziksel dosya ise hash adıyla durur.
"""

from __future__ import annotations

import hashlib
import shutil
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Optional

from loguru import logger

from app.utils.paths import app_data_dir
from app.utils.sqlite import open_sqlite_connection


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@dataclass
class StoredAttachment:
    """Diske alınmış tek bir ek."""

    sha256: str = ""
    filename: str = ""
    path: str = ""
    size: int = 0
    case_id: str = ""
    message_id: str = ""
    stored_at: str = field(default_factory=_now)

    @property
    def exists(self) -> bool:
        return bool(self.path) and Path(self.path).is_file()

    def read_bytes(self) -> bytes:
        return Path(self.path).read_bytes()

    def to_meta(self) -> dict[str, Any]:
        """Case kaydına yazılacak özet (içerik taşımaz)."""
        return {"name": self.filename, "sha256": self.sha256,
                "path": self.path, "size": self.size}


class IncomingAttachmentStore:
    """Gelen ekleri bir kez saklar, hash ile geri verir."""

    def __init__(self, base_dir: str | Path | None = None) -> None:
        if base_dir is None:
            base_dir = app_data_dir() / "incoming_attachments"
        self._base = Path(base_dir)
        self._base.mkdir(parents=True, exist_ok=True)
        self._db = self._base / "index.db"
        self._ensure_schema()

    @property
    def base_dir(self) -> Path:
        return self._base

    def _connect(self) -> sqlite3.Connection:
        return open_sqlite_connection(self._db, isolation_level=None)

    @contextmanager
    def _session(self):
        """Commit/rollback and explicitly close the SQLite connection."""
        conn = self._connect()
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _ensure_schema(self) -> None:
        try:
            with self._session() as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS incoming_attachments (
                        sha256     TEXT PRIMARY KEY,
                        filename   TEXT,
                        path       TEXT,
                        size       INTEGER,
                        case_id    TEXT,
                        message_id TEXT,
                        stored_at  TEXT
                    )
                """)
                conn.execute(
                    "CREATE INDEX IF NOT EXISTS ix_att_case "
                    "ON incoming_attachments (case_id)")
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS incoming_attachment_links (
                        sha256     TEXT NOT NULL,
                        case_id    TEXT NOT NULL,
                        message_id TEXT NOT NULL DEFAULT '',
                        filename   TEXT NOT NULL,
                        stored_at  TEXT NOT NULL,
                        PRIMARY KEY (sha256, case_id, message_id, filename)
                    )
                """)
                conn.execute(
                    "CREATE INDEX IF NOT EXISTS ix_att_link_case "
                    "ON incoming_attachment_links (case_id, stored_at)")
                # One-time compatibility migration: old rows kept the case
                # relation inside the blob table.
                conn.execute("""
                    INSERT OR IGNORE INTO incoming_attachment_links
                        (sha256, case_id, message_id, filename, stored_at)
                    SELECT sha256, case_id, COALESCE(message_id, ''),
                           COALESCE(filename, 'ek'), COALESCE(stored_at, '')
                    FROM incoming_attachments
                    WHERE COALESCE(case_id, '') <> ''
                """)
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[ek] şema kurulamadı: {exc}")

    # -- yazma -------------------------------------------------------------

    def store(self, attachment: Any, *, case_id: str = "",
              message_id: str = "") -> Optional[StoredAttachment]:
        """Bir ``IncomingAttachment``ı sakla (aynı içerik ikinci kez yazılmaz)."""
        data = getattr(attachment, "content", b"") or b""
        filename = getattr(attachment, "filename", "") or "ek"
        if not data:
            path = getattr(attachment, "path", "")
            if path and Path(path).is_file():
                try:
                    data = Path(path).read_bytes()
                except OSError as exc:
                    logger.warning(f"[ek] okunamadı ({filename}): {exc}")
                    return None
        if not data:
            return None

        digest = sha256_bytes(data)
        mevcut = self.get(digest)
        if mevcut is not None and mevcut.exists:
            stored = StoredAttachment(
                sha256=digest, filename=filename, path=mevcut.path,
                size=mevcut.size, case_id=case_id, message_id=message_id)
            self._link(stored)
            return stored          # blob tek; vaka ilişkisi yine ayrı yazılır

        target = self._base / digest[:2] / f"{digest}{Path(filename).suffix}"
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        except OSError as exc:
            logger.error(f"[ek] yazılamadı ({filename}): {exc}")
            return None

        stored = StoredAttachment(
            sha256=digest, filename=filename, path=str(target),
            size=len(data), case_id=case_id, message_id=message_id)
        try:
            with self._session() as conn:
                conn.execute(
                    "INSERT OR REPLACE INTO incoming_attachments "
                    "(sha256, filename, path, size, case_id, message_id, "
                    "stored_at) VALUES (?,?,?,?,?,?,?)",
                    (stored.sha256, stored.filename, stored.path, stored.size,
                     stored.case_id, stored.message_id, stored.stored_at))
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[ek] kaydedilemedi: {exc}")
            return None
        self._link(stored)
        return stored

    def _link(self, stored: StoredAttachment) -> None:
        """Associate an existing content blob with this case/message/name."""
        if not stored.case_id:
            return
        try:
            with self._session() as conn:
                conn.execute(
                    "INSERT OR IGNORE INTO incoming_attachment_links "
                    "(sha256, case_id, message_id, filename, stored_at) "
                    "VALUES (?,?,?,?,?)",
                    (stored.sha256, stored.case_id, stored.message_id,
                     stored.filename, stored.stored_at))
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[ek] vaka ilişkisi kaydedilemedi: {exc}")

    def store_many(self, attachments: Iterable[Any], *, case_id: str = "",
                   message_id: str = "") -> list[StoredAttachment]:
        out: list[StoredAttachment] = []
        for attachment in attachments or ():
            stored = self.store(attachment, case_id=case_id,
                                message_id=message_id)
            if stored is not None:
                out.append(stored)
        return out

    # -- okuma -------------------------------------------------------------

    def get(self, sha256: str) -> Optional[StoredAttachment]:
        try:
            with self._session() as conn:
                row = conn.execute(
                    "SELECT sha256, filename, path, size, case_id, "
                    "message_id, stored_at FROM incoming_attachments "
                    "WHERE sha256 = ?", (sha256,)).fetchone()
        except sqlite3.Error:  # pragma: no cover
            return None
        if row is None:
            return None
        return StoredAttachment(sha256=row[0], filename=row[1] or "",
                                path=row[2] or "", size=int(row[3] or 0),
                                case_id=row[4] or "", message_id=row[5] or "",
                                stored_at=row[6] or "")

    def for_case(self, case_id: str) -> list[StoredAttachment]:
        try:
            with self._session() as conn:
                rows = conn.execute(
                    "SELECT a.sha256, l.filename, a.path, a.size, l.case_id, "
                    "l.message_id, l.stored_at "
                    "FROM incoming_attachment_links l "
                    "JOIN incoming_attachments a ON a.sha256 = l.sha256 "
                    "WHERE l.case_id = ? ORDER BY l.stored_at, l.filename",
                    (case_id,)
                ).fetchall()
        except sqlite3.Error:  # pragma: no cover
            return []
        return [StoredAttachment(sha256=r[0], filename=r[1] or "",
                                 path=r[2] or "", size=int(r[3] or 0),
                                 case_id=r[4] or "", message_id=r[5] or "",
                                 stored_at=r[6] or "") for r in rows]

    def load_attachments(self, metas: Iterable[dict[str, Any]]) -> list[Any]:
        """Case'teki ek özetlerinden ``IncomingAttachment`` listesi kur.

        Diskte bulunamayan ek SESSİZCE atlanmaz: çağıran taraf sayı farkından
        eksiği görür ve "kontrol edilemedi" diyebilir.
        """
        from app.incoming.models import IncomingAttachment

        out: list[Any] = []
        for meta in metas or ():
            digest = str((meta or {}).get("sha256") or "")
            stored = self.get(digest) if digest else None
            if stored is None or not stored.exists:
                continue
            try:
                filename = str((meta or {}).get("name") or stored.filename)
                out.append(IncomingAttachment(filename=filename,
                                              content=stored.read_bytes(),
                                              path=stored.path))
            except OSError as exc:
                logger.warning(f"[ek] geri okunamadı ({stored.filename}): {exc}")
        return out

    def count(self) -> int:
        try:
            with self._session() as conn:
                row = conn.execute(
                    "SELECT COUNT(*) FROM incoming_attachments").fetchone()
            return int(row[0]) if row else 0
        except sqlite3.Error:  # pragma: no cover
            return 0

    def purge_all(self, *, confirm: bool = False) -> int:
        """Tüm ekleri sil (yalnızca kullanıcı açıkça isterse)."""
        if not confirm:
            raise ValueError("purge_all için confirm=True gerekir")
        adet = self.count()
        try:
            with self._session() as conn:
                conn.execute("DELETE FROM incoming_attachment_links")
                conn.execute("DELETE FROM incoming_attachments")
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[ek] silinemedi: {exc}")
            return 0
        for child in self._base.iterdir():
            if child.is_dir():
                shutil.rmtree(child, ignore_errors=True)
        return adet
