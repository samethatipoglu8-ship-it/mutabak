"""FAZ 2 — snapshot'ın firma bazlı NORMALİZE katmanı.

SORU
    «4009668 firmasına Ağustos ayında gönderilen ekstre GERÇEKTE hangi
    satırlardan oluşuyordu?»

    Ham Excel blob'u bu soruyu cevaplar ama pahalıdır: 100 bin satırlık bir
    FBL1H'ı açıp firma koduna göre süzmek, her cevap için saniyeler demektir.
    Bu modül gönderim anında zaten hesaplanmış olan firma bazlı satırları
    (``CompanyPackageDraft.segments[].statement.rows``) snapshot'a yazar ve
    geri okur.

YENİ MOTOR / YENİ AYRIŞTIRICI YOKTUR
    Satırlar ``CompanyStatementService`` tarafından MEVCUT kolon eşleme ve
    normalizasyonla üretilmiş ``TofasRecord`` nesneleridir. Burada yalnızca
    JSON'a yazılır ve JSON'dan aynı modele geri kurulur — tek bir eşleştirme
    kuralı, tek bir tutar dönüşümü burada tanımlanmaz.

YÖN KURALI DEĞİŞMEZ
    FBL5H → M segmenti, FBL1H → S/X segmenti. Kaynak, satırın kendisiyle
    birlikte saklanır; böylece M ve S satırları geri okunurken karışamaz.
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal, InvalidOperation
from typing import Any, Iterable, Optional, Sequence

from loguru import logger

from app.models.domain import TofasRecord

# NOT: ``company_statement_service`` pandas'ı modül düzeyinde çeker. Bu modül
# gelen mail hattından da kullanıldığı için o zincir TEMBEL bırakılır; aksi
# hâlde yalnızca bir yön etiketi okumak için ~0,4 sn'lik import ödenirdi.

# ``TofasRecord``ın tarih taşıyan alanları (ISO string olarak yazılır).
_DATE_FIELDS = ("belge_tarihi", "kayit_tarihi", "giris_tarihi", "net_vade")


def source_for_direction(ms: str) -> str:
    """Yönü besleyen SAP raporu ("FBL1H" / "FBL5H").

    Mevcut ``_SOURCE_FOR_DIRECTION`` tablosu KULLANILIR; burada ikinci bir
    yön kuralı tanımlanmaz.
    """
    from app.services.company_statement_service import (
        _SOURCE_FOR_DIRECTION,
        StatementSource,
    )

    source = _SOURCE_FOR_DIRECTION.get(
        (ms or "").strip().upper(), StatementSource.VENDOR_FBL1H)
    return source.value


def _iso(value: Optional[date]) -> Optional[str]:
    return value.isoformat() if value else None


def _parse_date(value: Any) -> Optional[date]:
    if not value:
        return None
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value))
    except ValueError:
        return None


def _parse_decimal(value: Any) -> Decimal:
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return Decimal("0")


def record_to_dict(record: TofasRecord, *, company_code: str, ms: str,
                   currency_fallback: str = "") -> dict[str, Any]:
    """Tek bir SAP satırını snapshot sözlüğüne çevir (kayıpsız).

    Kaynak izi (``source_file``, ``source_row``, ``extraction_method``) aynen
    korunur: aylar sonra «bu tutar nereden geldi?» sorusu cevaplanabilmelidir.
    """
    return {
        "company_code": company_code,
        "direction": ms,
        "source": source_for_direction(ms),
        "row_index": record.row_index,
        "fiscal_year": record.fiscal_year,
        "main_account": record.main_account,
        "firma_kodu": record.firma_kodu,
        "satici_ad": record.satici_ad,
        "reference": record.reference,
        "reference_raw": record.reference_raw,
        "all_references": list(record.all_references or []),
        "belge_turu": record.belge_turu,
        "belge_tarihi": _iso(record.belge_tarihi),
        "kayit_tarihi": _iso(record.kayit_tarihi),
        "giris_tarihi": _iso(record.giris_tarihi),
        "net_vade": _iso(record.net_vade),
        "amount": str(record.amount),
        "currency": record.currency or currency_fallback or None,
        "metin": record.metin,
        "source_file": record.source_file,
        "source_row": record.source_row,
        "extraction_method": record.extraction_method,
    }


def _parse_int(value: Any) -> int:
    """Satır numarasını topla; okunamazsa 0.

    Satır numarası yalnızca izlenebilirlik alanıdır. Okunamadı diye SATIRI
    DÜŞÜRMEK, karşılaştırmada o kaydı "yalnızca firma ekstresinde var"
    gösterirdi — sessiz ve yanlış bir finansal sonuç.
    """
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def dict_to_record(data: dict[str, Any]) -> TofasRecord:
    """Snapshot sözlüğünden MEVCUT canonical modeli geri kur."""
    return TofasRecord(
        row_index=_parse_int(data.get("row_index")),
        fiscal_year=data.get("fiscal_year"),
        main_account=data.get("main_account"),
        firma_kodu=data.get("firma_kodu"),
        satici_ad=data.get("satici_ad"),
        reference=data.get("reference"),
        reference_raw=data.get("reference_raw"),
        all_references=list(data.get("all_references") or []),
        belge_turu=data.get("belge_turu"),
        belge_tarihi=_parse_date(data.get("belge_tarihi")),
        kayit_tarihi=_parse_date(data.get("kayit_tarihi")),
        giris_tarihi=_parse_date(data.get("giris_tarihi")),
        net_vade=_parse_date(data.get("net_vade")),
        amount=_parse_decimal(data.get("amount")),
        currency=data.get("currency"),
        metin=data.get("metin"),
        source_file=data.get("source_file"),
        source_row=(_parse_int(data["source_row"])
                    if data.get("source_row") is not None else None),
        extraction_method=data.get("extraction_method"),
    )


def records_from_draft(draft) -> list[dict[str, Any]]:
    """``CompanyPackageDraft`` → snapshot satırları (segment sırasıyla).

    Kaynağı yüklenmemiş segment (``source_missing``) ATLANIR: o yönün
    bakiyesi bilinmiyordu, satırları da yoktu. Boş satır listesini "bu
    firmanın o yönde hiç kaydı yok" diye yazmak, sonradan gelen cevabı
    yanlış biçimde "yalnız firmada var" göstermek demektir.
    """
    out: list[dict[str, Any]] = []
    code = getattr(draft, "company_code", "") or ""
    for segment in getattr(draft, "segments", []) or []:
        if getattr(segment, "source_missing", False):
            continue
        statement = getattr(segment, "statement", None)
        if statement is None:
            continue
        for record in statement.rows:
            out.append(record_to_dict(record, company_code=code,
                                      ms=segment.ms))
    return out


def records_to_tofas(records: Iterable[dict[str, Any]],
                     directions: Optional[Sequence[str]] = None
                     ) -> list[TofasRecord]:
    """Snapshot satırlarını mutabakat motorunun beklediği modele çevir.

    ``directions`` verilirse YALNIZCA o yönlerin satırları döner. FBL1H ve
    FBL5H satırlarının birbirine karışmaması bu süzgeçle güvence altındadır.
    """
    wanted = ({d.strip().upper() for d in directions}
              if directions is not None else None)
    out: list[TofasRecord] = []
    for data in records or ():
        if not isinstance(data, dict):
            continue
        if wanted is not None and (data.get("direction") or "").upper() not in wanted:
            continue
        try:
            out.append(dict_to_record(data))
        except Exception as exc:  # noqa: BLE001 - bozuk satır partiyi düşürmesin
            logger.warning(f"[snapshot] satır geri kurulamadı: {exc}")
    return out


def direction_summary(records: Sequence[dict[str, Any]]) -> dict[str, int]:
    """Yön → satır sayısı (UI ve testler için hızlı özet)."""
    summary: dict[str, int] = {}
    for data in records or ():
        if isinstance(data, dict):
            key = (data.get("direction") or "").upper() or "?"
            summary[key] = summary.get(key, 0) + 1
    return summary


def currency_totals(records: Sequence[dict[str, Any]]) -> dict[str, Decimal]:
    """Para birimi → gönderilen satırların toplamı (işaretli).

    Deterministik ``Decimal`` aritmetiği; float'a HİÇ dönülmez.
    """
    totals: dict[str, Decimal] = {}
    for data in records or ():
        if not isinstance(data, dict):
            continue
        currency = (data.get("currency") or "").strip().upper() or "?"
        totals[currency] = totals.get(currency, Decimal("0")) + _parse_decimal(
            data.get("amount"))
    return totals
