"""Mutabakat mail modülü (FAZ1).

Bağımsız, additive modül: mevcut reconciler/core'a dokunmaz. Görevi TOFAŞ
mutabakat raporu Excel'inden firma bazlı mutabakat mailleri üretmek ve
(Windows'ta) Outlook üzerinden göndermek.

Katmanlar:
  - excel_loader:  .xls/.xlsx raporunu okur, satırları normalize eder.
  - mail_builder:  firma koduna göre gruplar, dil/M-S-X kurallarıyla mail üretir.
  - outlook_client: win32com ile taslak/gönderim (yalnızca Windows).
"""
