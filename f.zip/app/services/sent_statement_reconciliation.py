"""FAZ 4 — gelen ekstreyi GÖNDERİLEN SNAPSHOT ile karşılaştırma.

SİSTEMİN ANA AMACI
    Gelen cevap yalnızca bir mail değildir. Gelen cevap; belirli bir firmaya,
    belirli bir dönemde, belirli bir gönderimle yollanmış BELİRLİ bir
    mutabakat paketine verilmiş cevaptır. Bu yüzden karşılaştırmanın referansı
    "bugünkü TOFAŞ dosyası" değil, **o maile eklenmiş olan gerçek FBL1H/FBL5H
    verisi**dir.

    Zincir:  gelen mail → send_id → snapshot_id → gönderilen satırlar

BU MODÜL YENİ BİR MOTOR YAZMAZ
    Karşılaştırmayı yapan yine ``StatementReconciliationService``, o da yine
    ``app/core/reconciler.py``dır. Burada tek yapılan şey, motora verilen
    KARŞI TARAFI değiştirmektir:

        eski:  gelen ekstre  ↔  bugünkü TOFAŞ kayıtları
        yeni:  gelen ekstre  ↔  o firmaya GÖNDERİLEN snapshot kayıtları

    İkinci bir eşleştirme algoritması, ikinci bir tolerans tanımı, ikinci bir
    tutar dönüşümü YOKTUR.

DESTEKLEYİCİ KARŞILAŞTIRMA
    İstenirse bugünkü TOFAŞ kayıtlarıyla da çalıştırılır; ancak bu YALNIZCA
    bilgi amaçlıdır ("gönderimden bu yana bizim kayıtlarımız da değişmiş").
    Nihai finansal karar daima snapshot referansından verilir.

AI BURAYA GİRMEZ
    Tutar, eşleşme, toplam ve fark tamamen Python'dur.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from pathlib import Path
from typing import Any, Optional, Sequence

from loguru import logger

from app.models.domain import TofasRecord
from app.services.send_snapshot import (
    SOURCE_FBL1H,
    SOURCE_FBL5H,
    SentReconciliationSnapshot,
)
from app.services.snapshot_records import (
    currency_totals,
    direction_summary,
    record_to_dict,
    records_to_tofas,
)
from app.services.statement_reconciliation import (
    StatementReconciliationResult,
    StatementReconciliationService,
    StatementStatus,
)


class ComparisonReference(str, Enum):
    """Karşılaştırmanın NEYE karşı yapıldığı — sonuçla birlikte saklanır."""

    SNAPSHOT = "SNAPSHOT"                # gönderilen gerçek veri (istenen)
    SNAPSHOT_REBUILT = "SNAPSHOT_REBUILT"  # ham blob'dan yeniden çıkarıldı
    NONE = "NONE"                        # referans bulunamadı → insan incelemesi


# İnsan incelemesi gerekçe kodları.
REASON_NO_SNAPSHOT = "SNAPSHOT_NOT_FOUND"
REASON_NO_RECORDS = "SNAPSHOT_RECORDS_MISSING"
REASON_SNAPSHOT_CORRUPT = "SNAPSHOT_CORRUPT"
REASON_COMPANY_MISMATCH = "COMPANY_CODE_MISMATCH"
REASON_PERIOD_MISMATCH = "PERIOD_MISMATCH"
REASON_CURRENCY_MISMATCH = "CURRENCY_MISMATCH"
REASON_NO_STATEMENT = "NO_STATEMENT_IN_REPLY"
#: Gelen "ekstre", GÖNDERDİĞİMİZ verinin kendisi görünüyor: her kalem
#: eşleşti, hiç fark yok, AMA işaretler bizim kayıtlarımızla AYNI yönde.
#: Bağımsız bir karşı-beyan değil, kendi verimizin geri dönüşü olabilir.
REASON_SENT_DATA_RETURNED = "SENT_DATA_RETURNED"


@dataclass
class SnapshotComparisonResult:
    """Gelen cevabın, kendisine gönderilen pakete göre finansal sonucu."""

    # -- referans zinciri ---------------------------------------------------
    send_id: str = ""
    snapshot_id: str = ""
    company_code: str = ""
    period: str = ""
    reference: ComparisonReference = ComparisonReference.NONE

    # -- gönderilen taraf ---------------------------------------------------
    sent_record_count: int = 0
    sent_directions: dict[str, int] = field(default_factory=dict)
    sent_totals: dict[str, Decimal] = field(default_factory=dict)
    fbl1h_sha256: str = ""
    fbl5h_sha256: str = ""

    # -- motor sonucu (MEVCUT Reconciler) -----------------------------------
    statement: Optional[StatementReconciliationResult] = None
    # Bugünkü TOFAŞ kayıtlarıyla yapılan DESTEKLEYİCİ kontrol (karar vermez).
    supporting: Optional[StatementReconciliationResult] = None

    # -- gelen taraf --------------------------------------------------------
    incoming_filename: str = ""
    incoming_sha256: str = ""
    #: Gelen ekstre, gönderdiğimiz verinin geri dönüşü GÖRÜNÜYOR mu?
    #: (Bkz. ``REASON_SENT_DATA_RETURNED``.) Karar vermez; insan incelemesi
    #: tetikler ve gerekçesi ``explain()`` ile kullanıcıya yazılır.
    sent_data_returned: bool = False

    reasons: list[str] = field(default_factory=list)
    needs_human_review: bool = False
    error: str = ""

    def add_reason(self, code: str) -> None:
        if code and code not in self.reasons:
            self.reasons.append(code)

    # -- türetilmiş -------------------------------------------------------

    @property
    def status(self) -> StatementStatus:
        """Snapshot'a göre ekstre durumu (referans yoksa UNREADABLE değil, ERROR)."""
        if self.statement is None:
            return StatementStatus.NO_STATEMENT
        return self.statement.status

    @property
    def compared(self) -> bool:
        """Gerçekten snapshot'a karşı bir karşılaştırma yapıldı mı?"""
        return (self.reference is not ComparisonReference.NONE
                and self.statement is not None
                and self.statement.status in (StatementStatus.MATCHED,
                                              StatementStatus.DIFFERENCE))

    @property
    def matched(self) -> bool:
        return (self.compared
                and self.statement.status is StatementStatus.MATCHED)

    @property
    def difference_total(self) -> Decimal:
        analysis = self.statement.analysis if self.statement else None
        return analysis.difference.copy_abs() if analysis else Decimal("0")

    def explain(self) -> list[str]:
        """Kullanıcıya gösterilecek gerekçeler (kanıt zinciriyle)."""
        lines: list[str] = []
        if self.reference is ComparisonReference.NONE:
            lines.append(
                "Bu cevabın karşılaştırılacağı gönderim snapshot'ı "
                "bulunamadı; rakamsal doğrulama YAPILAMADI.")
        else:
            lines.append(
                f"Referans: {self.company_code} firmasına {self.period} "
                f"döneminde gönderilen paket "
                f"({self.sent_record_count} satır, gönderim {self.send_id}).")
        if self.statement is not None and self.statement.analysis is not None:
            lines.extend(self.statement.analysis.explain())
        if self.sent_data_returned:
            lines.append(
                "DİKKAT: Gelen ekstrenin her kalemi bizim kayıtlarımızla "
                "örtüşüyor ANCAK tutarların işareti de bizimle AYNI yönde. "
                "Firma ekstresinde işaretlerin TERS olması beklenir; bu "
                "görünüm, firmanın bize gönderdiğimiz dosyayı (ya da onun "
                "verisini) geri yollamış olabileceğini gösterir. Bağımsız bir "
                "teyit sayılmadı; insan incelemesine alındı.")
        if self.supporting is not None and self.supporting.analysis is not None:
            if not self.supporting.analysis.is_balanced:
                lines.append(
                    "DESTEKLEYİCİ KONTROL: gönderimden bu yana bizim "
                    "kayıtlarımız da değişmiş görünüyor.")
        if self.error:
            lines.append(f"Hata: {self.error}")
        return lines


class SentStatementReconciliationService:
    """Gelen ekstreyi, o firmaya GÖNDERİLEN snapshot ile karşılaştırır."""

    def __init__(
        self,
        snapshot_store,
        statement_service: Optional[StatementReconciliationService] = None,
        *,
        statement_factory=None,
    ) -> None:
        self._store = snapshot_store
        # Motor ayarları dosya hattıyla AYNI kalsın diye mevcut servis
        # doğrudan kullanılır; verilmezse varsayılanıyla kurulur.
        self._statements = statement_service or StatementReconciliationService()
        self._statement_factory = statement_factory
        # Ham blob'dan yeniden çıkarma pahalıdır; snapshot başına bir kez.
        self._rebuilt_cache: dict[str, Optional[list[dict]]] = {}

    # -- ana giriş ---------------------------------------------------------

    def reconcile(
        self,
        mail,
        tracked,
        *,
        current_tofas_records: Sequence[TofasRecord] = (),
        response: Any = None,
    ) -> SnapshotComparisonResult:
        """Bir gelen maili, bağlandığı gönderimin snapshot'ıyla karşılaştır.

        ``tracked`` — ``MailTracker``ın bulduğu gönderim (``send_id`` taşır).
        İSTİSNA FIRLATMAZ; her koşulda bir sonuç nesnesi döner.
        """
        result = SnapshotComparisonResult(
            send_id=getattr(tracked, "send_id", "") or "",
            snapshot_id=getattr(tracked, "snapshot_id", "") or "",
            company_code=getattr(tracked, "company_code", "") or "",
            period=getattr(tracked, "period", "") or "",
        )
        try:
            snapshot = self._resolve_snapshot(tracked)
            if snapshot is None:
                result.add_reason(REASON_NO_SNAPSHOT)
                result.needs_human_review = True
                return result

            result.snapshot_id = snapshot.snapshot_id
            result.send_id = snapshot.send_id
            result.company_code = snapshot.company_code
            result.period = snapshot.period
            result.fbl1h_sha256 = snapshot.fbl1h_sha256
            result.fbl5h_sha256 = snapshot.fbl5h_sha256

            self._check_integrity(snapshot, result)

            records, reference = self._sent_records(snapshot)
            if records is None:
                result.add_reason(REASON_NO_RECORDS)
                result.needs_human_review = True
                return result

            result.reference = reference
            result.sent_record_count = len(records)
            result.sent_directions = direction_summary(records)
            result.sent_totals = currency_totals(records)

            sent_records = records_to_tofas(records)
            result.statement = self._compare(mail, sent_records, result)

            if current_tofas_records:
                result.supporting = self._compare(
                    mail, list(current_tofas_records), None)

            self._cross_check(result, response)
            return result
        except Exception as exc:  # noqa: BLE001 - tek mail partiyi düşürmesin
            logger.exception(
                f"[snapshot-mutabakat] karşılaştırma başarısız "
                f"({result.company_code}).")
            result.error = f"{type(exc).__name__}: {exc}"
            result.needs_human_review = True
            return result

    # -- snapshot çözümleme ------------------------------------------------

    def _resolve_snapshot(self, tracked) -> Optional[SentReconciliationSnapshot]:
        """Gönderimi snapshot'a bağla — TAHMİN YAPILMAZ.

        Yalnızca ``snapshot_id`` / ``send_id`` kullanılır. ``company_code +
        period`` ile "en son gönderimi" seçmek, aynı dönemde ikinci bir mail
        gitmişse YANLIŞ pakete karşılaştırma yapmak demektir.
        """
        if self._store is None or tracked is None:
            return None
        snapshot_id = getattr(tracked, "snapshot_id", "") or ""
        if snapshot_id:
            found = self._store.get(snapshot_id)
            if found is not None:
                return found
        send_id = getattr(tracked, "send_id", "") or ""
        if send_id:
            return self._store.by_send_id(send_id)
        return None

    def _check_integrity(self, snapshot: SentReconciliationSnapshot,
                         result: SnapshotComparisonResult) -> None:
        """Snapshot dosyaları bozulmuşsa bunu SESSİZCE geçme."""
        try:
            problems = self._store.verify(snapshot.snapshot_id)
        except Exception as exc:  # noqa: BLE001
            logger.warning(f"[snapshot-mutabakat] bütünlük kontrolü: {exc}")
            return
        if problems:
            result.add_reason(REASON_SNAPSHOT_CORRUPT)
            result.needs_human_review = True
            result.error = "; ".join(problems)

    def _sent_records(self, snapshot: SentReconciliationSnapshot
                      ) -> tuple[Optional[list[dict]], ComparisonReference]:
        """Gönderilen satırlar: önce normalize kayıt, olmazsa ham blob.

        ``None`` = gönderilen veri BİLİNMİYOR (boş listeyle karıştırılmaz;
        boş liste "o firmanın hiç kaydı yoktu" demektir ve geçerli bir
        referanstır).
        """
        records = self._store.records(snapshot)
        if records is not None:
            return records, ComparisonReference.SNAPSHOT
        rebuilt = self._rebuild_from_blob(snapshot)
        if rebuilt is not None:
            return rebuilt, ComparisonReference.SNAPSHOT_REBUILT
        return None, ComparisonReference.NONE

    def _rebuild_from_blob(self, snapshot: SentReconciliationSnapshot
                           ) -> Optional[list[dict]]:
        """Normalize kayıt yoksa DEĞİŞMEZ ham kopyadan yeniden çıkar.

        Kaynak, gönderim anındaki baytların birebir kopyasıdır; bu yüzden
        sonuç "bugünkü dosya" değil, yine GÖNDERİLEN veridir. Pahalıdır,
        bu yüzden snapshot başına bir kez yapılır ve önbelleklenir.
        """
        if snapshot.snapshot_id in self._rebuilt_cache:
            return self._rebuilt_cache[snapshot.snapshot_id]

        out: Optional[list[dict]] = None
        try:
            from app.services.company_statement_service import (
                CompanyStatementService,
                StatementSource,
            )

            service = CompanyStatementService()
            wanted = {d.strip().upper() for d in snapshot.directions if d}
            collected: list[dict] = []
            found_any = False
            for which, source, ms in (
                (SOURCE_FBL1H, StatementSource.VENDOR_FBL1H, "S"),
                (SOURCE_FBL5H, StatementSource.CUSTOMER_FBL5H, "M"),
            ):
                if wanted and ms not in wanted:
                    continue
                blob = snapshot.source_path(which)
                if not blob or not Path(blob).is_file():
                    continue
                loaded = service.load(blob, source=source)
                found_any = True
                statement = loaded.by_code().get(snapshot.company_code)
                if statement is None:
                    continue
                collected.extend(
                    record_to_dict(row, company_code=snapshot.company_code,
                                   ms=ms)
                    for row in statement.rows)
            out = collected if found_any else None
        except Exception as exc:  # noqa: BLE001 - yeniden çıkarma çökertmez
            logger.warning(
                f"[snapshot-mutabakat] ham kopyadan satır çıkarılamadı "
                f"({snapshot.snapshot_id}): {exc}")
            out = None

        self._rebuilt_cache[snapshot.snapshot_id] = out
        return out

    # -- karşılaştırma -----------------------------------------------------

    def _compare(self, mail, reference_records: list[TofasRecord],
                 result: Optional[SnapshotComparisonResult]
                 ) -> Optional[StatementReconciliationResult]:
        """MEVCUT motoru çalıştır — burada hiçbir eşleştirme kuralı yoktur."""
        service = (self._statement_factory() if self._statement_factory
                   else self._statements)
        statements = service.reconcile_mail(mail, reference_records)
        best = _best_statement(statements)
        if result is not None and best is not None:
            result.incoming_filename = best.source_filename
            if best.status in (StatementStatus.UNREADABLE,
                               StatementStatus.ERROR):
                result.needs_human_review = True
            elif best.status is StatementStatus.NO_STATEMENT:
                result.add_reason(REASON_NO_STATEMENT)
            if self._looks_like_sent_data(best):
                # KENDİ VERİMİZ GERİ DÖNMÜŞ OLABİLİR — sessizce "mutabık"
                # denmez. Ölçülen senaryo: firma gönderdiğimiz Excel'i açıp
                # kaydedip (veri aynı, baytlar farklı) "mutabıkız" diyerek
                # geri yolladı. Bayt kimliğine dayanan echo tespiti bu
                # durumda devreye girmez; karşılaştırma kusursuz eşleşme
                # verir ve vaka İNSAN İNCELEMESİ OLMADAN MUTABIK oluyordu.
                # Firma hiçbir bağımsız doğrulama yapmadığı hâlde teyitli
                # mutabakat kaydediliyordu.
                result.sent_data_returned = True
                result.add_reason(REASON_SENT_DATA_RETURNED)
                result.needs_human_review = True
                best.needs_human_review = True
                if REASON_SENT_DATA_RETURNED not in best.reasons:
                    best.reasons.append(REASON_SENT_DATA_RETURNED)
            if best.needs_human_review:
                result.needs_human_review = True
        return best

    @staticmethod
    def _looks_like_sent_data(best: StatementReconciliationResult) -> bool:
        """Gelen ekstre, gönderdiğimiz verinin geri dönüşü görünüyor mu?

        İŞ KURALI: TOFAŞ kayıtlarında faturalar EKSİLİ, firma ekstresinde
        normalde ARTILI olur (``core/reconciler`` bu beklentiyi açıkça
        tanımlar ve ihlalinde ``isaret_uyari`` düşer). Dolayısıyla gerçek bir
        karşı-beyanda işaretler TERSTİR.

        Üç koşul BİRLİKTE sağlanırsa kendi verimizin geri dönüşünden
        şüphelenilir:
          1. Hiç açıklanmamış fark yok (her kalem eşleşti),
          2. en az bir eşleşme var,
          3. eşleşmelerin TAMAMINDA işaret bizimle aynı yönde.

        NEDEN TEK BAŞINA İŞARET YETERLİ DEĞİL — ve neden REDDETMİYORUZ
            Bazı muhasebe programları bizimle AYNI işaret kuralını kullanır.
            O durumda gerçek ve bağımsız bir ekstre de bu görünümü verebilir;
            ikisini ayırmak mümkün değildir. Bu yüzden eşleşme BOZULMAZ,
            fark UYDURULMAZ ve kalem REDDEDİLMEZ — yalnızca insan incelemesi
            tetiklenir. Bir muhasebecinin bir kez bakması, hiç doğrulama
            yapmamış bir firma için teyitli mutabakat yazmaktan iyidir.

        KASITLI OLARAK MUHAFAZAKÂR
            Sıfır tutarlı satır ``isaret_uyari`` üretmez (işaret karşılaştırması
            yapılamaz), bu yüzden böyle bir satır varsa koşul 3 sağlanmaz ve
            uyarı VERİLMEZ. Yanlış pozitif üretmemek önce gelir.
        """
        analysis = best.analysis
        engine = best.engine_result
        if analysis is None or engine is None:
            return False
        if analysis.matched <= 0:
            return False
        if not analysis.is_balanced:
            return False
        if engine.cross_matches or engine.currency_diff:
            return False
        pairs = list(engine.matched)
        if len(pairs) != analysis.matched:
            return False
        return all(pair.isaret_uyari for pair in pairs)

    @staticmethod
    def _cross_check(result: SnapshotComparisonResult, response: Any) -> None:
        """Cevaptaki firma/dönem/para birimi ile snapshot'ı karşılaştır.

        Uyuşmazlık, karşılaştırmanın yanlış pakete yapılmış olabileceğini
        gösterir; sessizce "mutabık" denmez.
        """
        if response is None:
            return
        code = (getattr(response, "company_code", None) or "").strip()
        if code and result.company_code and code != result.company_code:
            result.add_reason(REASON_COMPANY_MISMATCH)
            result.needs_human_review = True
        period = (getattr(response, "period", None) or "").strip()
        if period and result.period and period != result.period:
            result.add_reason(REASON_PERIOD_MISMATCH)
            result.needs_human_review = True

        sent_currencies = {c for c in result.sent_totals if c and c != "?"}
        reply_currencies = {
            str(c).strip().upper()
            for c in (getattr(response, "currencies", None) or {})}
        if sent_currencies and reply_currencies and not (
                sent_currencies & reply_currencies):
            result.add_reason(REASON_CURRENCY_MISMATCH)
            result.needs_human_review = True


def _best_statement(statements: Sequence[StatementReconciliationResult]
                    ) -> Optional[StatementReconciliationResult]:
    """Ekstre olarak işlenebilmiş ilk sonuç (yoksa ilki, hiç yoksa None).

    ``ScanItem.best_statement`` ile aynı ölçüt — tek doğruluk kaynağı.
    """
    for statement in statements:
        if statement.status in (StatementStatus.MATCHED,
                                StatementStatus.DIFFERENCE):
            return statement
    return statements[0] if statements else None
