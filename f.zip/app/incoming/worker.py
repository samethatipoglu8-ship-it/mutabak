"""Gelen mail hattı için arka plan işçileri (mevcut worker kalıbı).

Direct Line çağrısı saniyeler sürebilir; retry ile dakikalara çıkabilir. Bu iş
UI thread'inde çalışırsa uygulama "yanıt vermiyor" durumuna düşer. Bu yüzden
hat, projede zaten kullanılan kalıpla arka plana alınır:

    worker = IncomingMailAnalyzeWorker(mails, pipeline)
    thread = run_in_thread(worker)        # app/ui/worker.py

İptal KOOPERATİFTİR (``CancellableWorker``): thread zorla öldürülmez, işçi
bir sonraki mailde ya da yoklama adımında kendisi durur. Yarım işlenmiş bir
mail kaydedilmez; sonraki çalıştırmada baştan işlenir.
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional, Sequence  # noqa: F401 - Sequence tip ipucunda

from loguru import logger
from PySide6.QtCore import Signal

from app.incoming.models import IncomingMail
from app.incoming.pipeline import IncomingMailPipeline
from app.mailing.package_worker import CancellableWorker


class IncomingMailFetchWorker(CancellableWorker):
    """Outlook gelen kutusunu arka planda okur (COM UI thread'ini kilitlemesin)."""

    progress = Signal(str, int)
    finished = Signal(object)            # list[IncomingMail]
    failed = Signal(str)

    def __init__(self, limit: int = 50, since: Optional[datetime] = None,
                 folder_name: str = "", unread_only: bool = False,
                 reader=None, account_smtp: str = "") -> None:
        super().__init__()
        self._limit = limit
        self._since = since
        self._folder_name = folder_name
        self._unread_only = unread_only
        self._reader = reader
        self._account_smtp = account_smtp

    def run(self) -> None:
        try:
            reader = self._reader
            if reader is None:
                from app.incoming.outlook_reader import OutlookIncomingReader

                reader = OutlookIncomingReader(
                    self._folder_name, account_smtp=self._account_smtp,
                    require_account_smtp=True)

            self.progress.emit("Outlook gelen kutusu okunuyor…", 10)
            # NOT: bu işçinin bir MailTracker bağlamı YOKTUR (salt "mailleri
            # getir"); bu yüzden ``read()``'in isteğe bağlı metadata-önce
            # ``tracker=`` yoluna bilerek katılmaz (kapsam dışı — bkz. doc 21
            # §IMPLEMENTATION STATUS).
            mails = reader.read(
                limit=self._limit, since=self._since,
                unread_only=self._unread_only,
                should_cancel=lambda: self.cancelled)
            self.progress.emit(
                "İptal edildi." if self.cancelled
                else f"{len(mails)} mail okundu.", 100)
            self.finished.emit(mails)
        except Exception as exc:  # noqa: BLE001 - hata UI'ya taşınsın, çökmesin
            self.failed.emit(str(exc))


class IncomingMailAnalyzeWorker(CancellableWorker):
    """Okunan mailleri hattan geçirir (Python parser + gerekirse AI)."""

    progress = Signal(str, int)
    finished = Signal(object)            # list[ReconciliationResponse]
    failed = Signal(str)

    def __init__(self, mails: Sequence[IncomingMail],
                 pipeline: Optional[IncomingMailPipeline] = None) -> None:
        super().__init__()
        self._mails = list(mails)
        self._pipeline = pipeline

    def run(self) -> None:
        try:
            pipeline = self._pipeline
            if pipeline is None:
                from app.incoming.pipeline import build_default_pipeline

                pipeline = build_default_pipeline()

            total = len(self._mails)
            if not total:
                self.progress.emit("İşlenecek mail yok.", 100)
                self.finished.emit([])
                return

            self.progress.emit(f"{total} mail analiz ediliyor…", 5)

            def ilerleme(index: int, count: int, mail: IncomingMail) -> None:
                label = (mail.subject or mail.sender or "mail")[:60]
                self.progress.emit(f"{label} ({index}/{count})",
                                   5 + int(90 * index / max(1, count)))

            results = pipeline.process_many(
                self._mails, on_progress=ilerleme,
                should_cancel=lambda: self.cancelled)

            kalan = total - len(results)
            message = ("İptal edildi." if self.cancelled
                       else "Analiz tamamlandı.")
            if kalan:
                message += f" {kalan} mail işlenmedi."
            self.progress.emit(message, 100)
            self.finished.emit(results)
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))


class ReplyScanWorker(CancellableWorker):
    """«Gelen Maillerin Dönüşlerini Tespit Et» — tüm iş arka planda.

    Outlook okuma, ek çıkarma, ekstre ayrıştırma ve mutabakat motoru saniyeler
    sürebilir; hepsi burada çalışır, UI thread'i hiç bloklanmaz. İlerleme
    sinyalle bildirilir, iptal kooperatiftir.
    """

    progress = Signal(str, int)
    finished = Signal(object)            # ScanResult
    failed = Signal(str)

    def __init__(self, limit: int = 200, since: Optional[datetime] = None,
                 folder_name: str = "", period: Optional[str] = None,
                 tofas_records: Optional[Sequence] = None,
                 tofas_path: Optional[str] = None, mode: str = "yabanci",
                 company: Optional[str] = None,
                 reader=None, pipeline=None, mail_log=None,
                 statement_service=None, snapshot_store=None,
                 case_store=None, account_smtp: str = "") -> None:
        super().__init__()
        self._limit = limit
        self._since = since
        self._folder_name = folder_name
        self._account_smtp = account_smtp
        self._period = period
        self._tofas_records = list(tofas_records or [])
        # Kayıt listesi yerine DOSYA YOLU verilebilir: yükleme bu thread'de
        # yapılır. 100 bin satırlık bir SAP ekstresini UI thread'inde okumak
        # uygulamayı saniyelerce dondururdu.
        self._tofas_path = tofas_path
        self._mode = mode
        self._company = company
        self._reader = reader
        self._pipeline = pipeline
        self._mail_log = mail_log
        self._statement_service = statement_service
        # Gönderim snapshot'ı: finansal karşılaştırmanın ASIL referansı.
        self._snapshot_store = snapshot_store
        # Gelen cevapların kalıcı iş kaydı.
        self._case_store = case_store
        # Ekstre karşılaştırması yapılamadıysa nedeni (UI'da gösterilir).
        self.tofas_load_error = ""

    def _resolve_pipeline(self):
        """Mail çözümleme hattını hazırla (verilmemişse varsayılanı kur).

        ÖNEMLİ: hat kurulmazsa mail gövdesi hiç ayrıştırılmaz ve cevap türü
        daima UNKNOWN kalır. O zaman "firma 'mutabıkız' dedi ama ekstresi fark
        gösteriyor" ÇELİŞKİSİ hiç yakalanamaz — bu özelliğin ana amacı odur.
        Hat kurulamazsa tarama yine çalışır; yalnızca ekstre karşılaştırması
        ve teslim hatası tespiti kalır.
        """
        if self._pipeline is not None:
            return self._pipeline
        try:
            from app.incoming.pipeline import build_default_pipeline

            return build_default_pipeline()
        except Exception as exc:  # noqa: BLE001 - tarama durmasın
            logger.warning(
                f"Mail çözümleme hattı kurulamadı, yalnızca ekstre "
                f"karşılaştırması yapılacak: {exc}")
            return None

    def _load_tofas_records(self) -> list:
        """TOFAŞ kayıtlarını hazırla (verilmişse doğrudan, yoksa dosyadan).

        Yükleme başarısız olursa tarama DURMAZ: ekstre karşılaştırması
        yapılmaz, ilgili kayıtlar insan incelemesine düşer ve neden açıkça
        bildirilir.
        """
        if self._tofas_records or not self._tofas_path:
            return self._tofas_records
        try:
            from app.services.reconciliation_service import ReconciliationService

            self.progress.emit("TOFAŞ ekstresi yükleniyor…", 22)
            records = ReconciliationService().load_tofas_records(
                self._tofas_path, mode=self._mode, company=self._company)
            if not records:
                self.tofas_load_error = (
                    "TOFAŞ ekstresinden hiç kayıt okunamadı; ekteki ekstreler "
                    "karşılaştırılamayacak.")
            return records
        except Exception as exc:  # noqa: BLE001 - tarama yine çalışsın
            self.tofas_load_error = (
                f"TOFAŞ ekstresi yüklenemedi ({exc}); ekteki ekstreler "
                "karşılaştırılamayacak.")
            return []

    def run(self) -> None:
        try:
            from app.incoming.reply_scan import ReplyScanService
            from app.incoming.tracking import MailTracker

            # 1) Takip edilen gönderimler — kapsamı BURASI belirler.
            self.progress.emit("Gönderilen mutabakat mailleri okunuyor…", 5)
            mail_log = self._mail_log
            if mail_log is None:
                from app.services.mail_log import MailLog

                mail_log = MailLog()
            tracker = MailTracker.from_mail_log(mail_log, period=self._period)
            if tracker.tracked_count == 0:
                self.progress.emit(
                    "Takip edilen gönderilmiş mutabakat maili yok.", 100)
                from app.incoming.reply_scan import ScanResult

                self.finished.emit(ScanResult())
                return
            if self.cancelled:
                self.progress.emit("İptal edildi.", 100)
                from app.incoming.reply_scan import ScanResult

                self.finished.emit(ScanResult(cancelled=True))
                return

            # 2) Gelen kutusu (salt okunur).
            self.progress.emit(
                f"{tracker.tracked_count} mutabakat için gelen kutusu "
                "taranıyor…", 15)
            reader = self._reader
            if reader is None:
                from app.incoming.outlook_reader import OutlookIncomingReader

                reader = OutlookIncomingReader(
                    self._folder_name, account_smtp=self._account_smtp,
                    require_account_smtp=True)
            # METADATA-ÖNCE: tracker ZATEN yukarıda kuruldu (adım 1); read()'e
            # verilince İLGİSİZ mailler için ek HİÇ indirilmez (bkz.
            # OutlookIncomingReader.read docstring'i / doc 21).
            mails = reader.read(limit=self._limit, since=self._since,
                                should_cancel=lambda: self.cancelled,
                                tracker=tracker)
            if self.cancelled:
                self.progress.emit("İptal edildi.", 100)
                from app.incoming.reply_scan import ScanResult

                self.finished.emit(ScanResult(cancelled=True))
                return

            # 3) Sınıflandır + eşleştir + motor.
            #    TOFAŞ kayıtları BU THREAD'de yüklenir (UI donmaz).
            tofas_records = self._load_tofas_records()
            service = ReplyScanService(
                tracker, pipeline=self._resolve_pipeline(),
                statement_service=self._statement_service,
                tofas_records=tofas_records,
                snapshot_store=self._snapshot_store,
                case_store=self._case_store)

            total = len(mails)
            self.progress.emit(f"{total} mail değerlendiriliyor…", 30)

            def ilerleme(index: int, count: int, mail) -> None:
                label = (getattr(mail, "subject", "") or "mail")[:60]
                self.progress.emit(f"{label} ({index}/{count})",
                                   30 + int(65 * index / max(1, count)))

            result = service.scan(mails, on_progress=ilerleme,
                                  should_cancel=lambda: self.cancelled)
            self.progress.emit(
                "İptal edildi." if result.cancelled else "Tarama tamamlandı.",
                100)
            self.finished.emit(result)
        except Exception as exc:  # noqa: BLE001 - hata UI'ya taşınsın, çökmesin
            self.failed.emit(str(exc))


class IncomingMailPipelineWorker(CancellableWorker):
    """Okuma + analiz tek adımda (UI'nin tek düğmeyle çalıştırabilmesi için)."""

    progress = Signal(str, int)
    finished = Signal(object)            # list[ReconciliationResponse]
    failed = Signal(str)

    def __init__(self, limit: int = 50, since: Optional[datetime] = None,
                 folder_name: str = "", unread_only: bool = False,
                 reader=None,
                 pipeline: Optional[IncomingMailPipeline] = None,
                 mail_log=None, only_tracked: bool = True,
                 account_smtp: str = "") -> None:
        super().__init__()
        self._limit = limit
        self._since = since
        self._folder_name = folder_name
        self._account_smtp = account_smtp
        self._unread_only = unread_only
        self._reader = reader
        self._pipeline = pipeline
        # Yalnızca UYGULAMANIN GÖNDERDİĞİ maillere gelen cevaplar işlenir.
        # İlgisiz (kişisel/başka iş) mailler ne listelenir ne AI'ya gider.
        self._mail_log = mail_log
        self._only_tracked = only_tracked

    def _resolve_tracker(self):
        """Takip tracker'ını kur (``only_tracked`` KAPALIYSA ``None``).

        ÖNEMLİ: bu, ARTIK ``read()``'den ÖNCE çağrılır (metadata-önce akış
        için) — önceden yalnızca okuma SONRASI, ``_filter_tracked`` içinde
        kuruluyordu. İki kez kurulmaması için tek yerde tutulur.
        """
        from app.incoming.tracking import MailTracker

        mail_log = self._mail_log
        if mail_log is None:
            from app.services.mail_log import MailLog

            mail_log = MailLog()
        return MailTracker.from_mail_log(mail_log)

    def _filter_tracked(self, mails: list, tracker) -> list:
        """Takip edilen gönderimlerle ilgisi olmayan mailleri ayıkla."""
        if tracker.tracked_count == 0:
            return []
        kalan = []
        for mail in mails:
            try:
                if tracker.match(mail).should_process:
                    kalan.append(mail)
            except Exception as exc:  # noqa: BLE001 - tek mail hepsini düşürmesin
                from loguru import logger

                logger.warning(f"Mail takip kontrolü yapılamadı: {exc}")
        return kalan

    def run(self) -> None:
        try:
            reader = self._reader
            if reader is None:
                from app.incoming.outlook_reader import OutlookIncomingReader

                reader = OutlookIncomingReader(
                    self._folder_name, account_smtp=self._account_smtp,
                    require_account_smtp=True)
            pipeline = self._pipeline
            if pipeline is None:
                from app.incoming.pipeline import build_default_pipeline

                pipeline = build_default_pipeline()

            # Tracker read()'DEN ÖNCE kurulur: metadata-önce akış sayesinde
            # İLGİSİZ maillerin ekleri hiç indirilmez (bkz. doc 21). Yalnızca
            # ``only_tracked=False`` iken (bilerek takipsiz/genel tarama
            # modu) tracker verilmez — o modda bugünkü davranış AYNEN korunur.
            tracker = self._resolve_tracker() if self._only_tracked else None

            self.progress.emit("Outlook gelen kutusu okunuyor…", 5)
            mails = reader.read(limit=self._limit, since=self._since,
                                unread_only=self._unread_only,
                                should_cancel=lambda: self.cancelled,
                                tracker=tracker)
            if self.cancelled:
                self.progress.emit("İptal edildi.", 100)
                self.finished.emit([])
                return

            if self._only_tracked:
                okunan = len(mails)
                mails = self._filter_tracked(mails, tracker)
                self.progress.emit(
                    f"{okunan} mailden {len(mails)} tanesi uygulamanın "
                    "gönderdiği mutabakatlarla ilgili.", 15)

            total = len(mails)
            self.progress.emit(f"{total} mail analiz ediliyor…", 20)

            def ilerleme(index: int, count: int, mail: IncomingMail) -> None:
                label = (mail.subject or mail.sender or "mail")[:60]
                self.progress.emit(f"{label} ({index}/{count})",
                                   20 + int(75 * index / max(1, count)))

            results = pipeline.process_many(
                mails, on_progress=ilerleme,
                should_cancel=lambda: self.cancelled)
            self.progress.emit(
                "İptal edildi." if self.cancelled else "Analiz tamamlandı.", 100)
            self.finished.emit(results)
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))

class CaseCompareWorker(CancellableWorker):
    """FAZ 11 — case'leri güncel FBL ile ARKA PLANDA karşılaştırır (§6, §7).

    Toplu karşılaştırma yüzlerce satırda dakikalar sürebilir; UI thread'inde
    çalışırsa uygulama "yanıt vermiyor" durumuna düşer. İptal kooperatiftir:
    işçi bir sonraki satırda durur, yarım kalan satır kaydedilmez.

    Bir satırın hatası partiyi DURDURMAZ (görev şartı §7): hata o satıra
    yazılır ve sonraki satıra geçilir.
    """

    progress = Signal(str, int)
    finished = Signal(object)            # list[ComparisonOutcome]
    failed = Signal(str)

    def __init__(self, cases, service=None, user: str = "") -> None:
        super().__init__()
        self._cases = list(cases)
        self._service = service
        self._user = user

    def run(self) -> None:
        try:
            service = self._service
            if service is None:
                from app.services.case_comparison import CaseComparisonService

                service = CaseComparisonService()

            total = len(self._cases)
            if not total:
                self.progress.emit("Karşılaştırılacak satır yok.", 100)
                self.finished.emit([])
                return

            self.progress.emit(f"{total} satır karşılaştırılıyor…", 5)

            def ilerleme(index: int, count: int, case) -> None:
                etiket = f"{case.company_code} {case.balance_type}".strip()
                self.progress.emit(f"{etiket} ({index}/{count})",
                                   5 + int(90 * index / max(1, count)))

            outcomes = service.compare_many(
                self._cases, on_progress=ilerleme,
                should_cancel=lambda: self.cancelled, user=self._user)

            kalan = total - len(outcomes)
            mesaj = ("İptal edildi." if self.cancelled
                     else "Karşılaştırma tamamlandı.")
            if kalan:
                mesaj += f" {kalan} satır işlenmedi."
            self.progress.emit(mesaj, 100)
            self.finished.emit(outcomes)
        except Exception as exc:  # noqa: BLE001 - hata UI'ya taşınsın
            self.failed.emit(str(exc))

class ThreadReplyWorker(CancellableWorker):
    """FAZ 11 — hazırlanmış cevapları (hatırlatma / fark maili) Reply-All ile
    ARKA PLANDA gönderir (§3.5, §12).

    Kullanıcı kararı: metin uygulamada onaylanır, gönderim COM ile doğrudan
    yapılır. Her sonuç ayrı ayrı döner ki hangi firmaya gitti, hangisine
    gitmedi görünsün. Bir mailin hatası partiyi DURDURMAZ.
    """

    progress = Signal(str, int)
    finished = Signal(object)            # list[(case_id, SendResult)]
    failed = Signal(str)

    def __init__(self, requests, send: bool = True,
                 outgoing_smtp: str = "") -> None:
        super().__init__()
        # Kurumsal giden hesap (Settings.outgoing_mailbox_smtp); send=True iken
        # boşsa gönderim fail-closed engellenir (bkz. outlook_client.reply_all).
        self._outgoing_smtp = outgoing_smtp
        # requests: (case_id, ReplyRequest) çiftleri
        self._requests = list(requests)
        self._send = send

    @property
    def case_ids(self) -> tuple[str, ...]:
        """Bu worker'ın sonuçlandırmak zorunda olduğu vakalar.

        UI hata/iptal yolunda yalnızca BU worker'a ait kilitleri bırakır.
        Önceden bir worker bittiğinde başka worker'ların bekleyen kayıtları da
        temizlenebiliyor, aynı vaka için ikinci gönderim kapısı erken
        açılabiliyordu.
        """
        return tuple(str(case_id) for case_id, _request in self._requests)

    def run(self) -> None:
        try:
            from app.mailing.outlook_client import reply_all

            total = len(self._requests)
            if not total:
                self.progress.emit("Gönderilecek mail yok.", 100)
                self.finished.emit([])
                return

            results = []
            for index, (case_id, request) in enumerate(self._requests, start=1):
                if self.cancelled:
                    break
                self.progress.emit(
                    f"{request.code} ({index}/{total})",
                    int(100 * index / max(1, total)))
                results.append((case_id, reply_all(
                    request, send=self._send,
                    outgoing_smtp=self._outgoing_smtp)))

            kalan = total - len(results)
            mesaj = ("İptal edildi." if self.cancelled else "Gönderim bitti.")
            if kalan:
                mesaj += f" {kalan} mail gönderilmedi."
            self.progress.emit(mesaj, 100)
            self.finished.emit(results)
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))



class ThreadVerifyWorker(CancellableWorker):
    """Taslak ve belirsiz gönderimleri Outlook'a SORARAK doğrular (§2, §3).

    COM ARKA PLANDA ÇALIŞIR: doğrulama Gönderilmiş Öğeler'i tarar ve
    yavaş olabilir; UI thread'inde yapılırsa uygulama donar.

    Her vaka için tek bir doğrulama isteği gönderilir; bir vakanın hatası
    diğerlerini DURDURMAZ.
    """

    progress = Signal(str, int)
    finished = Signal(object)            # list[(case_id, kind, VerifyResult)]
    failed = Signal(str)

    def __init__(self, targets) -> None:
        super().__init__()
        # targets: (case_id, kind, entry_id, message_id) dörtlüleri
        # kind: "DRAFT" | "UNKNOWN"
        self._targets = list(targets)

    @property
    def case_ids(self) -> tuple[str, ...]:
        return tuple(str(t[0]) for t in self._targets)

    def run(self) -> None:
        try:
            from app.mailing.outlook_client import verify_sent

            total = len(self._targets)
            if not total:
                self.progress.emit("Doğrulanacak kayıt yok.", 100)
                self.finished.emit([])
                return

            results = []
            for index, (case_id, kind, entry_id, message_id) in enumerate(
                    self._targets, start=1):
                if self.cancelled:
                    break
                self.progress.emit(f"Doğrulanıyor ({index}/{total})",
                                   int(100 * index / max(1, total)))
                results.append(
                    (case_id, kind,
                     verify_sent(entry_id=entry_id, message_id=message_id)))
            self.progress.emit(
                "İptal edildi." if self.cancelled else "Doğrulama bitti.", 100)
            self.finished.emit(results)
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))
