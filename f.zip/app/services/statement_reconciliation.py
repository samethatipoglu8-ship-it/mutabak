"""Gelen ekstre eki → MEVCUT mutabakat motoru (tek doğruluk kaynağı).

NEDEN BU MODÜL VAR
    Firma mutabakat mailine bir ekstre (Excel/CSV/PDF) ile cevap verdiğinde,
    sistem şimdiye kadar yalnızca "AI maili okudu" seviyesinde kalıyordu:
    ekteki ekstre, TOFAŞ kayıtlarıyla HİÇ karşılaştırılmıyordu. Oysa finansal
    kararı verecek olan zaten elimizdeki deterministik motordur.

    Bu modül o boşluğu kapatır ve akışı tamamlar:

        IncomingAttachment
              ↓  (mevcut FirmaLoader — aynı kolon eşleme, aynı normalizasyon)
        FirmaRecord listesi
              ↓  (mevcut DataQualityAnalyzer)
        veri kalitesi raporu
              ↓  (MEVCUT Reconciler — T1/T2/T3/CROSS/T4)
        ReconciliationResult
              ↓
        StatementReconciliationResult  (fark analizi + gerekçeler)

TASARIM İLKELERİ
    * YENİ MOTOR YAZILMAZ. ``app/core/reconciler.py`` aynen kullanılır; bu
      modül yalnızca onu besler ve sonucunu yorumlanabilir hâle getirir.
    * YENİ AYRIŞTIRICI YAZILMAZ. Ek, mevcut ``FirmaLoader``a verilir; böylece
      mail hattı ile dosya hattı BİREBİR aynı kuralları uygular.
    * AI BURAYA GİRMEZ. Tutar, eşleşme, toplam ve fark tamamen Python'dur.
    * İSTİSNA SIZDIRMAZ. Her hata bir sonuç nesnesine dönüşür ve ilgili kayıt
      insan incelemesine düşer; bir firmanın bozuk eki tüm partiyi durdurmaz.
    * Geçici dosya bırakmaz: ek diske yazılırsa işlem sonunda SİLİNİR.
"""

from __future__ import annotations

import shutil
import tempfile
from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from pathlib import Path
from typing import Optional, Sequence

from loguru import logger

from app.core.reconciler import Reconciler
from app.models.domain import FirmaRecord, ReconciliationResult, TofasRecord
from app.services.data_quality import DataQualityAnalyzer, QualityLevel

# Ekten ekstre okunurken kabul edilen uzantılar. Mevcut FirmaLoader'ın
# desteklediği kümeyle aynıdır; bilinmeyen uzantı denenmez (bozuk dosyayı
# ekstre sanıp yanlış mutabakat üretmektense "ekstre yok" demek doğrudur).
SUPPORTED_SUFFIXES = frozenset({".xlsx", ".xlsm", ".xls", ".csv", ".txt", ".pdf"})


class StatementStatus(str, Enum):
    """Gelen ekstrenin mutabakat sonucu."""

    MATCHED = "MATCHED"                  # fark yok (tolerans içinde)
    DIFFERENCE = "DIFFERENCE"            # eşleşmeyen kayıt / tutar farkı var
    NO_STATEMENT = "NO_STATEMENT"        # ekte okunabilir bir ekstre yok
    UNREADABLE = "UNREADABLE"            # ek var ama okunamadı / boş
    ERROR = "ERROR"                      # beklenmedik hata (insan incelemesi)


@dataclass
class DifferenceAnalysis:
    """"Neden mutabık değiliz?" sorusunun makine tarafından okunabilir cevabı."""

    firma_balance: Decimal = Decimal("0")     # firmanın ekstresinden toplam
    our_balance: Decimal = Decimal("0")       # TOFAŞ kayıtlarımızdan toplam
    difference: Decimal = Decimal("0")        # |firma| - |bizim|
    currency: str = ""

    matched: int = 0
    amount_diff: int = 0
    cross_matched: int = 0
    #: Aynı fatura no, FARKLI para birimi. AÇIKLANMAMIŞ BİR FARKTIR:
    #: ``is_balanced`` bunu sıfır saymaz, aksi hâlde para birimi çelişen bir
    #: ekstre "mutabık" olarak raporlanırdı.
    currency_diff: int = 0
    only_firma: int = 0                       # yalnız firmada olan kayıtlar
    only_tofas: int = 0                       # yalnız bizde olan kayıtlar

    amount_diff_total: Decimal = Decimal("0")  # tutar farklarının toplamı
    only_firma_total: Decimal = Decimal("0")
    only_tofas_total: Decimal = Decimal("0")

    currency_warnings: int = 0
    sign_warnings: int = 0
    excluded_document_types: list[str] = field(default_factory=list)

    @property
    def is_balanced(self) -> bool:
        """Açıklanamayan fark kalmadı mı?

        ``currency_diff`` BURAYA DAHİLDİR. Motor, aynı fatura numarasını iki
        tarafta farklı para birimiyle bulduğunda bunu artık ``only_firma`` +
        ``only_tofas`` olarak DEĞİL, ayrı bir ``currency_diff`` olarak
        raporluyor. O sayı burada hesaba katılmazsa, para birimi çelişen bir
        ekstre "fark bulunamadı" → MUTABIK olarak görünürdü: projenin altın
        kuralının (rakamsal teyit yoksa mutabık deme) tam ihlali.
        """
        return (self.amount_diff == 0 and self.currency_diff == 0
                and self.only_firma == 0 and self.only_tofas == 0)

    def explain(self) -> list[str]:
        """Farkın kaynaklarını insan diliyle sırala (UI/mail/Excel için).

        Fark yoksa bunu İLK satırda söyler; para birimi/işaret uyarıları
        farkı açıklayan kalem değil, dikkat notudur ve sonra gelir.
        """
        lines: list[str] = []
        if self.is_balanced:
            lines.append("Fark bulunamadı; kayıtlar birebir örtüşüyor.")
        if self.only_firma:
            lines.append(
                f"{self.only_firma} kayıt yalnızca firma ekstresinde var "
                f"(toplam {self.only_firma_total}).")
        if self.only_tofas:
            lines.append(
                f"{self.only_tofas} kayıt yalnızca bizim kayıtlarımızda var "
                f"(toplam {self.only_tofas_total}).")
        if self.amount_diff:
            lines.append(
                f"{self.amount_diff} kayıtta tutar farkı var "
                f"(toplam {self.amount_diff_total}).")
        if self.currency_diff:
            lines.append(
                f"{self.currency_diff} faturada aynı numara iki tarafta da var "
                "ama PARA BİRİMİ farklı; tutarlar karşılaştırılamaz.")
        if self.cross_matched:
            lines.append(
                f"{self.cross_matched} bire-çok eşleşme bulundu "
                "(bir fatura ↔ birden çok satır).")
        if self.currency_warnings:
            lines.append(
                f"{self.currency_warnings} eşleşmede para birimi bilinmiyordu.")
        if self.sign_warnings:
            lines.append(
                f"{self.sign_warnings} eşleşmede işaretler beklenenin tersi.")
        if self.excluded_document_types:
            lines.append("Hariç tutulan belge türleri: "
                         + ", ".join(self.excluded_document_types))
        return lines


@dataclass
class StatementReconciliationResult:
    """Bir ekin mutabakat sonucu — kanıtıyla birlikte."""

    status: StatementStatus = StatementStatus.NO_STATEMENT
    source_filename: str = ""
    rows_loaded: int = 0
    extraction_method: str = ""

    analysis: Optional[DifferenceAnalysis] = None
    # Ham motor sonucu: hangi satır hangi kuralla eşleşti (evidence) burada.
    engine_result: Optional[ReconciliationResult] = None

    data_quality: list[str] = field(default_factory=list)
    reasons: list[str] = field(default_factory=list)
    needs_human_review: bool = False
    error: str = ""
    #: Ekin içerik kimliği — aynı ekin tekrar işlendiği bununla belirlenir.
    attachment_sha256: str = ""
    #: Güvenlik kapısından geçemedi ve karantinaya alındı.
    quarantined: bool = False

    def add_reason(self, code: str) -> None:
        if code and code not in self.reasons:
            self.reasons.append(code)

    @property
    def reconciled(self) -> bool:
        return self.status is StatementStatus.MATCHED

    def summary_line(self) -> str:
        if self.analysis is None:
            return f"{self.status.value} ({self.source_filename or '-'})"
        a = self.analysis
        return (f"{self.status.value}: eşleşen={a.matched} "
                f"tutar_farkı={a.amount_diff} bire-çok={a.cross_matched} "
                f"yalnız_firma={a.only_firma} yalnız_bizde={a.only_tofas} "
                f"fark={a.difference}")


class StatementReconciliationService:
    """Gelen ekstre ekini mevcut mutabakat motoruyla karşılaştırır.

    Motor ayarları (tolerans, tarih penceresi, bire-çok, hariç belge türleri)
    dosya hattıyla AYNI parametrelerdir; böylece aynı ekstre mailden gelince
    farklı bir sonuç üretmez.
    """

    def __init__(
        self,
        *,
        excluded_belge_turu: Optional[Sequence[str]] = None,
        date_tolerance_days: int = 0,
        enable_cross_match: bool = True,
        amount_tolerance: Decimal | str | float | None = None,
        strict_currency: bool = False,
        loader_factory=None,
        quarantine=None,
    ) -> None:
        self._excluded = list(excluded_belge_turu or [])
        self._date_tolerance_days = int(date_tolerance_days)
        self._enable_cross_match = bool(enable_cross_match)
        self._amount_tolerance = amount_tolerance
        self._strict_currency = bool(strict_currency)
        self._loader_factory = loader_factory
        # Karantina deposu: verilmezse İLK ihtiyaçta açılır. ``False``
        # verilirse karantina KAPALIDIR (saf birim testleri için).
        self._quarantine_store = quarantine

    def _quarantine(self, data: bytes, filename: str, security) -> None:
        """Reddedilen eki karantinaya al. Hata iş akışını DURDURMAZ."""
        if self._quarantine_store is False:
            return
        try:
            if self._quarantine_store is None:
                from app.services.quarantine import QuarantineStore

                self._quarantine_store = QuarantineStore()
            self._quarantine_store.quarantine(data, filename, security)
        except Exception as exc:  # noqa: BLE001 - karantina asla çökertmez
            logger.warning(
                f"[ekstre-mutabakat] '{filename}' karantinaya alınamadı: {exc}")

    # -- genel giriş noktaları ---------------------------------------------

    def reconcile_attachment(self, attachment, tofas_records: Sequence[TofasRecord]
                             ) -> StatementReconciliationResult:
        """Bir ``IncomingAttachment``ı TOFAŞ kayıtlarıyla karşılaştır."""
        filename = getattr(attachment, "filename", "") or ""
        content = getattr(attachment, "content", b"") or b""
        if not content:
            path = getattr(attachment, "path", None)
            if path:
                try:
                    content = Path(path).read_bytes()
                except OSError as exc:
                    return self._unreadable(filename, f"ek okunamadı: {exc}")
        return self.reconcile_bytes(content, filename, tofas_records)

    def reconcile_bytes(self, data: bytes, filename: str,
                        tofas_records: Sequence[TofasRecord]
                        ) -> StatementReconciliationResult:
        """Ham bayt + dosya adından ekstre okuyup mutabakat çalıştır.

        Hiçbir koşulda istisna fırlatmaz.
        """
        result = StatementReconciliationResult(source_filename=filename)
        suffix = Path(filename or "").suffix.lower()

        if not data:
            return self._unreadable(filename, "ek içeriği boş.")
        if suffix not in SUPPORTED_SUFFIXES:
            result.status = StatementStatus.NO_STATEMENT
            result.add_reason("UNSUPPORTED_ATTACHMENT")
            result.error = f"desteklenmeyen ek türü: {suffix or '(uzantısız)'}"
            return result
        from app.utils.attachment_security import inspect_attachment

        security = inspect_attachment(data, filename)
        result.attachment_sha256 = security.sha256
        if not security.safe:
            # KARANTİNA: dosya silinmez, normal klasöre de konmaz. Nötr
            # uzantıyla ayrı bir yerde saklanır ve durumu kullanıcıya söylenir.
            self._quarantine(data, filename, security)
            blocked = self._unreadable(filename, security.reason)
            blocked.attachment_sha256 = security.sha256
            blocked.quarantined = True
            blocked.add_reason(f"ATTACHMENT_SECURITY_{security.code}")
            return blocked

        work_dir: Optional[Path] = None
        try:
            work_dir = Path(tempfile.mkdtemp(prefix="mutabakat_stmt_"))
            temp_file = work_dir / f"ekstre{suffix}"
            temp_file.write_bytes(data)

            firma_records, _total = self._load(temp_file)
            result.rows_loaded = len(firma_records)
            result.extraction_method = (
                firma_records[0].extraction_method if firma_records else "")

            if not firma_records:
                return self._unreadable(
                    filename, "ekten hiç kayıt okunamadı (ekstre olmayabilir).")

            self._attach_quality(result, firma_records)
            engine_result = self._run_engine(firma_records, tofas_records)
            result.engine_result = engine_result
            result.analysis = self._analyze(engine_result)
            result.status = (StatementStatus.MATCHED
                             if result.analysis.is_balanced
                             else StatementStatus.DIFFERENCE)
            return result

        except Exception as exc:  # noqa: BLE001 - tek ek tüm partiyi düşürmesin
            logger.exception(
                f"[ekstre-mutabakat] '{filename}' işlenemedi.")
            result.status = StatementStatus.ERROR
            result.error = f"{type(exc).__name__}: {exc}"
            result.add_reason("STATEMENT_ENGINE_ERROR")
            result.needs_human_review = True
            return result
        finally:
            if work_dir is not None:
                # Kişisel/finansal veri diskte bırakılmaz.
                shutil.rmtree(work_dir, ignore_errors=True)

    # -- iç adımlar ---------------------------------------------------------

    def _load(self, path: Path) -> tuple[list[FirmaRecord], Optional[Decimal]]:
        """Mevcut firma yükleyicisini kullan (yeni ayrıştırıcı YAZILMAZ)."""
        if self._loader_factory is not None:
            loader = self._loader_factory()
        else:
            from app.services.loader import FirmaLoader

            loader = FirmaLoader()
        return loader.load(path)

    def _run_engine(self, firma_records: Sequence[FirmaRecord],
                    tofas_records: Sequence[TofasRecord]) -> ReconciliationResult:
        """MEVCUT motoru çalıştır — burada hiçbir eşleştirme kuralı yazılmaz."""
        reconciler = Reconciler(
            excluded_belge_turu=self._excluded,
            date_tolerance_days=self._date_tolerance_days,
            enable_cross_match=self._enable_cross_match,
            amount_tolerance=self._amount_tolerance,
            strict_currency=self._strict_currency,
        )
        return reconciler.reconcile(list(firma_records), list(tofas_records))

    @staticmethod
    def _attach_quality(result: StatementReconciliationResult,
                        firma_records: Sequence[FirmaRecord]) -> None:
        try:
            report = DataQualityAnalyzer().analyze(firma_records, "Firma ekstresi")
            result.data_quality = report.messages()
            if report.max_level in (QualityLevel.ERROR, QualityLevel.BLOCKING):
                result.add_reason("STATEMENT_DATA_QUALITY")
                result.needs_human_review = True
        except Exception as exc:  # noqa: BLE001 - kalite raporu asla çökertmez
            logger.warning(f"[ekstre-mutabakat] kalite raporu üretilemedi: {exc}")

    @staticmethod
    def _analyze(engine: ReconciliationResult) -> DifferenceAnalysis:
        """Motor sonucundan fark analizini çıkar (tamamen Decimal aritmetik)."""
        s = engine.summary
        analysis = DifferenceAnalysis(
            firma_balance=s.firma_diptoplam,
            our_balance=s.tofas_diptoplam_hesap,
            difference=s.fark,
            matched=s.matched,
            amount_diff=s.amount_diff,
            cross_matched=s.cross_matched,
            currency_diff=s.currency_diff,
            only_firma=s.only_firma,
            only_tofas=s.only_tofas,
            excluded_document_types=list(engine.excluded_belge_turu),
        )
        analysis.amount_diff_total = sum(
            (p.abs_difference for p in engine.amount_mismatch), Decimal("0"))
        analysis.only_firma_total = sum(
            (r.amount.copy_abs() for r in engine.only_firma), Decimal("0"))
        analysis.only_tofas_total = sum(
            (r.amount.copy_abs() for r in engine.only_tofas), Decimal("0"))
        analysis.currency_warnings = (
            sum(1 for p in engine.matched + engine.amount_mismatch
                if p.para_birimi_uyari)
            + sum(1 for c in engine.cross_matches if c.para_birimi_uyari))
        analysis.sign_warnings = sum(
            1 for p in engine.matched + engine.amount_mismatch if p.isaret_uyari)

        # Para birimi: kayıtlarda tek bir döviz varsa onu taşı (yoksa boş).
        # only_tofas DA dahildir: fark yalnızca TOFAŞ tarafındaki
        # kayıtlardan oluşuyorsa (firma o kalemleri hiç göstermemişse)
        # para birimi aksi hâlde boş kalıyordu.
        currencies = {
            (r.currency or "").strip().upper()
            for r in engine.only_firma
        } | {
            (getattr(r, "currency", "") or "").strip().upper()
            for r in engine.only_tofas
        } | {
            (p.firma.currency or "").strip().upper()
            for p in engine.matched + engine.amount_mismatch
        }
        currencies.discard("")
        if len(currencies) == 1:
            analysis.currency = next(iter(currencies))
        return analysis

    @staticmethod
    def _unreadable(filename: str, error: str) -> StatementReconciliationResult:
        result = StatementReconciliationResult(
            status=StatementStatus.UNREADABLE, source_filename=filename,
            error=error, needs_human_review=True)
        result.add_reason("STATEMENT_UNREADABLE")
        return result

    # -- birden çok ek ------------------------------------------------------

    def reconcile_mail(self, mail, tofas_records: Sequence[TofasRecord]
                       ) -> list[StatementReconciliationResult]:
        """Bir mailin sınıflandırılmış ekstre eklerini karşılaştır.

        Önce ekler ayrıştırılır ve sınıflandırılır. Bu adım, hattın önündeki
        mail parser idempotency önbelleğinden döndüğünde bile zorunludur:
        taze Outlook ekleri o durumda henüz ``kind`` almamış olabilir. Ekstre
        olmayan ekler mutabakat motoruna VERİLMEZ, fakat ``NO_STATEMENT``
        sonucuyla listede kalır; böylece neden atlandıkları izlenebilir.
        """
        from app.incoming.attachment_classifier import classify_all
        from app.incoming.extractors import extract_all
        from app.incoming.models import AttachmentKind

        attachments = list(getattr(mail, "attachments", []) or [])
        extract_all(attachments)
        classify_all(attachments)
        results: list[StatementReconciliationResult] = []
        for attachment in attachments:
            # Türü belirlenemeyen, fakat okunamayan bir dosya asla sıradan
            # "diğer" ek sayılmaz: bozuk bir XLSX gerçek ekstre de olabilir.
            # İnsan incelemesine düşebilmesi için güvenli hata sonucunu üret.
            if attachment.kind in (AttachmentKind.STATEMENT,
                                   AttachmentKind.UNREADABLE):
                results.append(self.reconcile_attachment(attachment, tofas_records))
                continue
            skipped = StatementReconciliationResult(
                status=StatementStatus.NO_STATEMENT,
                source_filename=attachment.filename,
            )
            skipped.add_reason("NOT_CLASSIFIED_AS_STATEMENT")
            if attachment.kind_reason:
                skipped.error = attachment.kind_reason
            results.append(skipped)
        return results
