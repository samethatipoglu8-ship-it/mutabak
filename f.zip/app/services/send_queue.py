"""Kalıcı gönderim kuyruğu (madde 6).

NEDEN
    Binlerce mail GUI döngüsünden gönderilirse, uygulama kapandığında (ya da
    Outlook takıldığında) "nereye kadar gitti?" sorusunun cevabı KAYBOLUR.
    Yeniden başlatmak ya baştan gönderir — bazı firmalar İKİNCİ mektubu alır —
    ya da hiç göndermez.

    Kuyruk bu ikilemi ortadan kaldırır: her firmanın durumu, gönderimden ÖNCE
    diske yazılır ve her sonuç ANINDA işlenir. Uygulama kapanırsa kaldığı
    yerden devam eder.

DURUMLAR AYRI TUTULUR
    ``QUEUED``   — sırada, henüz denenmedi
    ``SENDING``  — şu an gönderiliyor (devralınabilir)
    ``SENT``     — gönderildi
    ``FAILED``   — KESİN başarısız (Send() çağrılmadan hata) → tekrar güvenli
    ``UNKNOWN``  — BELİRSİZ: mail gitmiş OLABİLİR
    ``RETRY``    — yeniden denenecek (kullanıcı ya da kesin hata sonrası)

EN ÖNEMLİ KURAL
    ``UNKNOWN`` OTOMATİK TEKRAR EDİLMEZ. Belirsiz bir gönderimi yeniden
    denemek, firmaya ikinci bir mutabakat mektubu göndermektir ve geri
    alınamaz. Belirsizlik önce GÖNDERİLMİŞ ÖĞELER'den doğrulanır
    (``resolve_unknown``); yalnızca "gitmediği KANITLANIRSA" tekrar sıraya
    girer.
"""

from __future__ import annotations

import json
import sqlite3
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Optional, Sequence

from loguru import logger

from app.utils.paths import app_data_dir
from app.utils.sqlite import open_sqlite_connection

STATUS_QUEUED = "QUEUED"
STATUS_SENDING = "SENDING"
STATUS_SENT = "SENT"
STATUS_FAILED = "FAILED"
STATUS_UNKNOWN = "UNKNOWN"
STATUS_RETRY = "RETRY"

#: Kuyruktan çekilebilecek durumlar. ``UNKNOWN`` ve ``SENT`` BURADA YOKTUR.
CLAIMABLE = (STATUS_QUEUED, STATUS_RETRY)
#: İş bitmiş sayılan durumlar.
TERMINAL = (STATUS_SENT, STATUS_UNKNOWN)

#: Yarım kalmış (SENDING) bir işin devralınabilmesi için geçmesi gereken süre.
DEFAULT_STALE_AFTER = timedelta(minutes=15)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(moment: datetime) -> str:
    return moment.isoformat(timespec="seconds")


def new_queue_id() -> str:
    return f"Q-{_now():%Y%m%d}-{uuid.uuid4().hex[:8]}"


class QueueUnavailableError(RuntimeError):
    """Kuyruk okunamıyor/yazılamıyor: gönderim durumu BİLİNEMEZ.

    Çağıran taraf bu durumda GÖNDERMEMELİDİR (fail-closed): "bilmiyorum"
    ile "gönderilmedi" aynı şey değildir ve ikinci bir mutabakat mektubu
    geri alınamaz.
    """


@dataclass
class QueueItem:
    """Kuyruktaki tek bir gönderim."""

    company_code: str
    period: str = ""
    batch_id: str = ""
    queue_id: str = field(default_factory=new_queue_id)
    payload: dict[str, Any] = field(default_factory=dict)
    status: str = STATUS_QUEUED
    attempts: int = 0
    reason: str = ""
    entry_id: str = ""
    message_id: str = ""
    conversation_id: str = ""
    claimed_at: str = ""
    created_at: str = ""
    updated_at: str = ""

    @property
    def terminal(self) -> bool:
        return self.status in TERMINAL


class SendQueue:
    """Kalıcı, yeniden başlatmaya dayanıklı gönderim kuyruğu."""

    _COLUMNS = ("queue_id, batch_id, company_code, period, payload, status, "
                "attempts, reason, entry_id, message_id, conversation_id, "
                "claimed_at, created_at, updated_at")

    def __init__(self, path: str | Path | None = None) -> None:
        if path is None:
            base = app_data_dir()
            base.mkdir(parents=True, exist_ok=True)
            path = base / "send_queue.db"
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    @property
    def path(self) -> Path:
        return self._path

    @contextmanager
    def _session(self):
        conn = open_sqlite_connection(self._path, isolation_level=None)
        try:
            yield conn
        finally:
            conn.close()

    def _ensure_schema(self) -> None:
        try:
            with self._session() as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS send_queue (
                        id              INTEGER PRIMARY KEY AUTOINCREMENT,
                        queue_id        TEXT NOT NULL UNIQUE,
                        batch_id        TEXT NOT NULL DEFAULT '',
                        company_code    TEXT NOT NULL,
                        period          TEXT NOT NULL DEFAULT '',
                        payload         TEXT NOT NULL DEFAULT '{}',
                        status          TEXT NOT NULL,
                        attempts        INTEGER NOT NULL DEFAULT 0,
                        reason          TEXT NOT NULL DEFAULT '',
                        entry_id        TEXT NOT NULL DEFAULT '',
                        message_id      TEXT NOT NULL DEFAULT '',
                        conversation_id TEXT NOT NULL DEFAULT '',
                        claimed_at      TEXT NOT NULL DEFAULT '',
                        created_at      TEXT NOT NULL,
                        updated_at      TEXT NOT NULL
                    )
                """)
                conn.execute("CREATE INDEX IF NOT EXISTS ix_queue_status "
                             "ON send_queue (status, id)")
                conn.execute("CREATE INDEX IF NOT EXISTS ix_queue_company "
                             "ON send_queue (period, company_code)")
                # AYNI DÖNEMDE AYNI FİRMA İKİ KEZ SIRAYA GİRMESİN: mükerrer
                # mektup riskini veritabanı seviyesinde de kapatıyoruz.
                conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS "
                             "ux_queue_batch_company "
                             "ON send_queue (batch_id, period, company_code)")
        except sqlite3.Error as exc:  # pragma: no cover - ortam bağımlı
            logger.error(f"[kuyruk] şema kurulamadı: {exc}")

    # -- yazma -------------------------------------------------------------

    def enqueue(self, item: QueueItem) -> bool:
        """Tek bir gönderimi sıraya al. Zaten sıradaysa TEKRAR EKLENMEZ."""
        an = _iso(_now())
        try:
            with self._session() as conn:
                conn.execute("""
                    INSERT OR IGNORE INTO send_queue (
                        queue_id, batch_id, company_code, period, payload,
                        status, attempts, reason, entry_id, message_id,
                        conversation_id, claimed_at, created_at, updated_at
                    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (item.queue_id, item.batch_id, item.company_code,
                      item.period,
                      json.dumps(item.payload, ensure_ascii=False, default=str),
                      item.status, item.attempts, item.reason, item.entry_id,
                      item.message_id, item.conversation_id, item.claimed_at,
                      item.created_at or an, an))
            return True
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[kuyruk] sıraya alınamadı ({item.company_code}): {exc}")
            return False

    def enqueue_many(self, items: Iterable[QueueItem]) -> int:
        return sum(1 for i in items if self.enqueue(i))

    def claim(self, limit: int = 1, *,
              stale_after: timedelta = DEFAULT_STALE_AFTER) -> list[QueueItem]:
        """Sıradaki işleri ATOMİK olarak devral.

        ``UNKNOWN`` ASLA devralınmaz. Yarım kalmış (``SENDING``) işler,
        ``stale_after`` süresi geçtiyse devralınabilir — uygulama çökmüşse
        iş sonsuza kadar kilitli kalmasın diye.
        """
        an = _now()
        esik = _iso(an - stale_after)
        alinan: list[QueueItem] = []
        try:
            with self._session() as conn:
                conn.execute("BEGIN IMMEDIATE")
                rows = conn.execute(
                    f"SELECT {self._COLUMNS} FROM send_queue "
                    "WHERE status IN (?,?) OR (status = ? AND claimed_at <= ?) "
                    "ORDER BY id LIMIT ?",
                    (*CLAIMABLE, STATUS_SENDING, esik, int(limit))).fetchall()
                for row in rows:
                    item = self._row(row)
                    conn.execute(
                        "UPDATE send_queue SET status=?, attempts=attempts+1, "
                        "claimed_at=?, updated_at=? WHERE queue_id=?",
                        (STATUS_SENDING, _iso(an), _iso(an), item.queue_id))
                    item.status = STATUS_SENDING
                    item.attempts += 1
                    alinan.append(item)
                conn.execute("COMMIT")
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[kuyruk] iş devralınamadı: {exc}")
            return []
        return alinan

    def _set_status(self, queue_id: str, status: str, *, reason: str = "",
                    entry_id: str = "", message_id: str = "",
                    conversation_id: str = "") -> bool:
        an = _iso(_now())
        try:
            with self._session() as conn:
                cur = conn.execute("""
                    UPDATE send_queue SET status=?, reason=?,
                        entry_id=CASE WHEN ?<>'' THEN ? ELSE entry_id END,
                        message_id=CASE WHEN ?<>'' THEN ? ELSE message_id END,
                        conversation_id=CASE WHEN ?<>'' THEN ?
                                             ELSE conversation_id END,
                        updated_at=?
                    WHERE queue_id=?
                """, (status, reason[:500], entry_id, entry_id,
                      message_id, message_id, conversation_id, conversation_id,
                      an, queue_id))
                return cur.rowcount > 0
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[kuyruk] durum yazılamadı ({queue_id}): {exc}")
            return False

    def mark_sending(self, queue_id: str, *, force: bool = False) -> bool:
        """Send() ÇAĞRILMADAN ÖNCE kalıcı olarak ``SENDING`` işaretle.

        Write-ahead kaydıdır: süreç ``Send()`` sırasında ölürse kuyrukta
        ``SENDING`` kalır ve yeniden başlatmada BELİRSİZ sayılır (otomatik
        tekrar yok). Tek ``UPDATE`` ile karşılaştır-ve-ayarla yapar: yalnız
        hâlâ gönderilebilir durumdaki (``QUEUED``/``RETRY``/``FAILED``)
        kayıt devralınır; ``SENT``/``UNKNOWN``/``SENDING`` kayıt ikinci kez
        devralınamaz.

        ``False`` dönerse (çakışma, kayıt yok VEYA yazma hatası) çağıran
        mail GÖNDERMEMELİDİR. ``force=True`` yalnız kullanıcının bilinçli
        "tekrar gönder" kararı (``skip_already_sent=False``) içindir.
        """
        an = _iso(_now())
        try:
            with self._session() as conn:
                if force:
                    cur = conn.execute(
                        "UPDATE send_queue SET status=?, attempts=attempts+1, "
                        "claimed_at=?, updated_at=? WHERE queue_id=?",
                        (STATUS_SENDING, an, an, queue_id))
                else:
                    # Aynı (dönem, firma) için BAŞKA bir batch'te SENDING/SENT/
                    # UNKNOWN kayıt varsa devralma: farklı run_id'li iki süreç
                    # aynı firmaya ikinci mektup göndermesin.
                    cur = conn.execute(
                        "UPDATE send_queue SET status=?, attempts=attempts+1, "
                        "claimed_at=?, updated_at=? WHERE queue_id=? "
                        "AND status IN (?,?,?) "
                        "AND NOT EXISTS (SELECT 1 FROM send_queue o "
                        "WHERE o.period = send_queue.period "
                        "AND o.company_code = send_queue.company_code "
                        "AND o.queue_id <> send_queue.queue_id "
                        "AND o.status IN (?,?,?))",
                        (STATUS_SENDING, an, an, queue_id,
                         STATUS_QUEUED, STATUS_RETRY, STATUS_FAILED,
                         STATUS_SENDING, STATUS_SENT, STATUS_UNKNOWN))
                return cur.rowcount == 1
        except sqlite3.Error as exc:
            logger.error(f"[kuyruk] SENDING yazılamadı ({queue_id}): {exc}")
            return False

    # -- belirsiz gönderimin İNSAN çözümü (send_unknown_resolution) -----------
    # ``mark_retry`` belirsiz kaydı KASITLI olarak reddeder. İnsanın verdiği
    # "gönderilmedi / gitti" kararı tek, adlandırılmış bir yoldan uygulanır ve
    # her zaman KATI çalışır: yazılamıyorsa ``QueueUnavailableError`` fırlar,
    # sessizce "oldu" denmez.

    def by_company(self, period: str, company_code: str) -> list[QueueItem]:
        """(dönem, firma) için TÜM batch'lerdeki kayıtlar. KATI okuma."""
        try:
            with self._session() as conn:
                rows = conn.execute(
                    f"SELECT {self._COLUMNS} FROM send_queue "
                    "WHERE period=? AND company_code=? ORDER BY id",
                    (period, company_code)).fetchall()
        except sqlite3.Error as exc:
            raise QueueUnavailableError(
                f"Gönderim kuyruğu okunamadı: {exc}") from exc
        return [self._row(r) for r in rows]

    def _resolve_unfinished(self, period: str, company_code: str,
                            status: str, reason: str,
                            from_statuses: tuple[str, ...] = (
                                STATUS_UNKNOWN, STATUS_SENDING)) -> int:
        """``from_statuses`` kayıtlarını ``status``a çevir. Dönen: değişen adet."""
        an = _iso(_now())
        yer = ",".join("?" * len(from_statuses))
        try:
            with self._session() as conn:
                cur = conn.execute(
                    "UPDATE send_queue SET status=?, reason=?, updated_at=? "
                    f"WHERE period=? AND company_code=? AND status IN ({yer})",
                    (status, reason[:500], an, period, company_code,
                     *from_statuses))
                return int(cur.rowcount or 0)
        except sqlite3.Error as exc:
            raise QueueUnavailableError(
                f"Gönderim kuyruğu güncellenemedi: {exc}") from exc

    def reopen_unknown(self, period: str, company_code: str,
                       reason: str = "") -> int:
        """İnsan "gönderilmedi" dedi: belirsiz kayıtları ``RETRY``'a aç.

        YALNIZCA ``UNKNOWN``/``SENDING`` kayıtlar etkilenir (``SENT`` ve
        diğerleri değişmez). Mail GÖNDERMEZ; yalnız bir sonraki MANUEL
        gönderimin ``mark_sending``i bu kaydı devralabilsin diye açar.
        İdempotent: ikinci çağrı 0 döner.
        """
        return self._resolve_unfinished(
            period, company_code, STATUS_RETRY,
            ("Manuel çözüm: gönderilmediği doğrulandı. " + reason).strip())

    def settle_sent(self, period: str, company_code: str,
                    reason: str = "") -> int:
        """İnsan "gitti" dedi: belirsiz kayıtları ``SENT`` yap (idempotent).

        ``RETRY`` de dahildir: önce "gitmedi" diye açılıp sonra "gitti" diye
        düzeltilen firmanın kuyruk kaydı tutarlı kalsın (REOPENED -> VERIFIED_SENT).
        """
        return self._resolve_unfinished(
            period, company_code, STATUS_SENT,
            ("Manuel çözüm: gönderildiği doğrulandı. " + reason).strip(),
            from_statuses=(STATUS_UNKNOWN, STATUS_SENDING, STATUS_RETRY))

    def mark_sent(self, queue_id: str, *, entry_id: str = "",
                  message_id: str = "", conversation_id: str = "") -> bool:
        return self._set_status(queue_id, STATUS_SENT, entry_id=entry_id,
                                message_id=message_id,
                                conversation_id=conversation_id)

    def mark_failed(self, queue_id: str, reason: str = "") -> bool:
        """KESİN başarısızlık: ortada gönderilmiş mail yok."""
        return self._set_status(queue_id, STATUS_FAILED, reason=reason)

    def mark_unknown(self, queue_id: str, reason: str = "", *,
                     entry_id: str = "", message_id: str = "") -> bool:
        """BELİRSİZ sonuç: otomatik tekrar YOK, önce doğrulama."""
        return self._set_status(queue_id, STATUS_UNKNOWN, reason=reason,
                                entry_id=entry_id, message_id=message_id)

    def mark_retry(self, queue_id: str, reason: str = "") -> bool:
        """Yeniden denenecek. YALNIZCA kesin başarısızlık için güvenlidir."""
        item = self.get(queue_id)
        if item is not None and item.status == STATUS_UNKNOWN:
            # Belirsiz gönderim doğrudan tekrar sıraya ALINAMAZ.
            raise ValueError(
                "Belirsiz gönderim doğrudan tekrar denenemez; önce "
                "Gönderilmiş Öğeler'den doğrulanmalıdır (resolve_unknown).")
        return self._set_status(queue_id, STATUS_RETRY, reason=reason)

    def apply_result(self, queue_id: str, result: Any) -> str:
        """``SendResult``ı kuyruğa işle ve yeni durumu döndür."""
        durum = str(getattr(result, "status", "") or "")
        entry_id = str(getattr(result, "entry_id", "") or "")
        message_id = str(getattr(result, "message_id", "") or "")
        conversation_id = str(getattr(result, "conversation_id", "") or "")
        reason = str(getattr(result, "reason", "") or "")
        if getattr(result, "sent", False) or durum == "SENT":
            self.mark_sent(queue_id, entry_id=entry_id, message_id=message_id,
                           conversation_id=conversation_id)
            return STATUS_SENT
        if durum in ("SEND_UNKNOWN", STATUS_UNKNOWN):
            self.mark_unknown(queue_id, reason, entry_id=entry_id,
                              message_id=message_id)
            return STATUS_UNKNOWN
        self.mark_failed(queue_id, reason or durum)
        return STATUS_FAILED

    # -- belirsizlerin çözülmesi -------------------------------------------

    def resolve_unknown(self, verifier: Callable[[QueueItem], Optional[bool]],
                        *, period: Optional[str] = None) -> dict[str, int]:
        """Belirsiz gönderimleri GÖNDERİLMİŞ ÖĞELER'den doğrula.

        ``verifier(item)`` döndürür:
            ``True``  → mail gerçekten gitmiş  → SENT
            ``False`` → gitmediği KANITLANDI   → RETRY (tekrar güvenli)
            ``None``  → hâlâ bilinmiyor        → UNKNOWN kalır

        ``None`` ile ``False`` arasındaki fark kritiktir: "bulamadım" ile
        "yok" aynı şey değildir ve "bulamadım"a dayanarak tekrar göndermek
        mükerrer mektup üretir.
        """
        sayim = {STATUS_SENT: 0, STATUS_RETRY: 0, STATUS_UNKNOWN: 0}
        for item in self.items(status=STATUS_UNKNOWN, period=period):
            try:
                karar = verifier(item)
            except Exception as exc:  # noqa: BLE001 - doğrulama partiyi durdurmaz
                logger.warning(f"[kuyruk] {item.company_code} doğrulanamadı: {exc}")
                karar = None
            if karar is True:
                self.mark_sent(item.queue_id)
                sayim[STATUS_SENT] += 1
            elif karar is False:
                self._set_status(item.queue_id, STATUS_RETRY,
                                 reason="Gönderilmiş Öğeler'de bulunamadı; "
                                        "gönderilmediği doğrulandı.")
                sayim[STATUS_RETRY] += 1
            else:
                sayim[STATUS_UNKNOWN] += 1
        return sayim

    # -- yeniden başlatma --------------------------------------------------

    def resume(self, *, stale_after: timedelta = DEFAULT_STALE_AFTER) -> int:
        """Uygulama kapanmadan önce yarım kalan işleri geri al.

        Yalnızca ``SENDING`` durumu geri alınır ve ``RETRY``ye ÇEVRİLMEZ:
        ``QUEUED``a döner, çünkü o iş HİÇ denenmiş sayılmaz mı? Denenmiş
        OLABİLİR — bu yüzden ``UNKNOWN``a düşürülür: kullanıcı önce
        Gönderilmiş Öğeler'i doğrulasın, sistem kendiliğinden ikinci mektup
        göndermesin.
        """
        esik = _iso(_now() - stale_after)
        try:
            with self._session() as conn:
                cur = conn.execute(
                    "UPDATE send_queue SET status=?, reason=?, updated_at=? "
                    "WHERE status=? AND claimed_at <= ?",
                    (STATUS_UNKNOWN,
                     "Uygulama gönderim sırasında kapandı; sonuç bilinmiyor. "
                     "Gönderilmiş Öğeler doğrulanmalı.",
                     _iso(_now()), STATUS_SENDING, esik))
                return int(cur.rowcount or 0)
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[kuyruk] yarım işler geri alınamadı: {exc}")
            return 0

    # -- okuma -------------------------------------------------------------

    @staticmethod
    def _row(row: Sequence[Any]) -> QueueItem:
        try:
            payload = json.loads(row[4] or "{}")
        except (TypeError, ValueError):
            payload = {}
        return QueueItem(
            queue_id=row[0], batch_id=row[1], company_code=row[2],
            period=row[3], payload=payload, status=row[5],
            attempts=int(row[6]), reason=row[7], entry_id=row[8],
            message_id=row[9], conversation_id=row[10], claimed_at=row[11],
            created_at=row[12], updated_at=row[13])

    def get_by_key(self, period: str, batch_id: str,
                   company_code: str) -> Optional[QueueItem]:
        """(batch, dönem, firma) anahtarındaki kayıt. KATI: okuma hatasında
        ``QueueUnavailableError`` — "okunamadı" ile "yok" karıştırılmaz."""
        try:
            with self._session() as conn:
                row = conn.execute(
                    f"SELECT {self._COLUMNS} FROM send_queue "
                    "WHERE period=? AND batch_id=? AND company_code=?",
                    (period, batch_id, company_code)).fetchone()
        except sqlite3.Error as exc:
            raise QueueUnavailableError(
                f"Gönderim kuyruğu okunamadı: {exc}") from exc
        return self._row(row) if row else None

    def recoverable(self, period: str) -> list[QueueItem]:
        """Dönemde mail GİTMİŞ ya da GİTMİŞ OLABİLECEK kayıtlar
        (``SENT``/``UNKNOWN``/``SENDING``). KATI: okuma hatasında
        ``QueueUnavailableError``."""
        try:
            with self._session() as conn:
                rows = conn.execute(
                    f"SELECT {self._COLUMNS} FROM send_queue "
                    "WHERE period=? AND status IN (?,?,?) ORDER BY id",
                    (period, STATUS_SENT, STATUS_UNKNOWN,
                     STATUS_SENDING)).fetchall()
        except sqlite3.Error as exc:
            raise QueueUnavailableError(
                f"Gönderim kuyruğu okunamadı: {exc}") from exc
        return [self._row(r) for r in rows]

    def get(self, queue_id: str) -> Optional[QueueItem]:
        try:
            with self._session() as conn:
                row = conn.execute(
                    f"SELECT {self._COLUMNS} FROM send_queue WHERE queue_id=?",
                    (queue_id,)).fetchone()
        except sqlite3.Error:  # pragma: no cover
            return None
        return self._row(row) if row else None

    def items(self, *, status: Optional[str] = None,
              period: Optional[str] = None,
              batch_id: Optional[str] = None) -> list[QueueItem]:
        sql = f"SELECT {self._COLUMNS} FROM send_queue"
        where, params = [], []
        if status:
            where.append("status = ?")
            params.append(status)
        if period:
            where.append("period = ?")
            params.append(period)
        if batch_id:
            where.append("batch_id = ?")
            params.append(batch_id)
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY id"
        try:
            with self._session() as conn:
                rows = conn.execute(sql, params).fetchall()
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[kuyruk] okunamadı: {exc}")
            return []
        return [self._row(r) for r in rows]

    def pending(self, *, period: Optional[str] = None,
                batch_id: Optional[str] = None) -> list[QueueItem]:
        """Hâlâ gönderilmeyi bekleyenler (UNKNOWN DAHİL DEĞİL)."""
        return [i for i in self.items(period=period, batch_id=batch_id)
                if i.status in CLAIMABLE]

    def summary(self, *, period: Optional[str] = None,
                batch_id: Optional[str] = None) -> dict[str, int]:
        """Durum → adet. Dört durum AYRI tutulur."""
        sayim = {STATUS_QUEUED: 0, STATUS_SENDING: 0, STATUS_SENT: 0,
                 STATUS_FAILED: 0, STATUS_UNKNOWN: 0, STATUS_RETRY: 0}
        for item in self.items(period=period, batch_id=batch_id):
            sayim[item.status] = sayim.get(item.status, 0) + 1
        return sayim


def outlook_verifier(namespace=None) -> Callable[[QueueItem], Optional[bool]]:
    """``resolve_unknown`` için Outlook tabanlı doğrulayıcı üret.

    Döner: ``verifier(item)`` — Gönderilmiş Öğeler'e bakar.

      ``True``  → öğe bulundu ve gönderilmiş
      ``False`` → öğe KESİN olarak gönderilmemiş
      ``None``  → karar verilemedi (Outlook yok, senkronizasyon gecikmiş…)

    ``None`` döndürmek KASITLIDIR: doğrulanamayan bir gönderimi "gitmedi"
    saymak, firmaya ikinci bir mutabakat mektubu göndermekle sonuçlanır.
    """

    def verifier(item: QueueItem) -> Optional[bool]:
        try:
            from app.mailing.outlook_client import verify_sent

            sonuc = verify_sent(entry_id=item.entry_id,
                                message_id=item.message_id,
                                namespace=namespace)
        except Exception as exc:  # noqa: BLE001 - Outlook yoksa karar verme
            logger.debug(f"[kuyruk] {item.company_code} doğrulanamadı: {exc}")
            return None
        durum = str(getattr(sonuc, "status", "") or "")
        if durum == "SENT":
            return True
        if durum == "NOT_SENT":
            return False
        return None

    return verifier
