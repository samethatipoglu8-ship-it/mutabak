"""Gelen mail hattı için küçük metin yardımcıları (saf Python, AI yok).

Türkçe karakter katlaması ayrı bir yardımcı olarak durur çünkü ``str.lower()``
Türkçe'de güvenli değildir: ``"İ".lower()`` iki kod noktalı (``i`` + birleşen
nokta) bir dizi üretir ve sözlük eşleşmelerini sessizce kaçırır.
"""

from __future__ import annotations

import re
import unicodedata

# Katlama HARF HARF yapılır; önce çevir sonra küçült (aksi hâlde "İ" bozulur).
_TR_MAP = str.maketrans({
    "İ": "i", "I": "i", "ı": "i",
    "Ş": "s", "ş": "s",
    "Ğ": "g", "ğ": "g",
    "Ü": "u", "ü": "u",
    "Ö": "o", "ö": "o",
    "Ç": "c", "ç": "c",
    "Â": "a", "â": "a", "Î": "i", "î": "i", "Û": "u", "û": "u",
    " ": " ",
})

_WS_RE = re.compile(r"\s+")


def fold(value: object) -> str:
    """Aksan/boşluk/büyük-küçük farkını silen karşılaştırma biçimi.

    ``"MUTABAKAT MEKTUBU.PDF"`` ve ``"mutabakat  mektubu.pdf"`` aynı sonucu
    verir. Sözlük tabanlı tüm eşleşmeler bu biçim üzerinden yapılır.
    """
    if value is None:
        return ""
    text = str(value).translate(_TR_MAP).lower()
    # Kalan aksanlı harfleri (é, ü gibi yabancı diller) taban harfe indir.
    text = "".join(
        ch for ch in unicodedata.normalize("NFKD", text)
        if not unicodedata.combining(ch)
    )
    return _WS_RE.sub(" ", text).strip()


_TAG_RE = re.compile(r"<[^>]+>")
_STYLE_RE = re.compile(r"<(script|style)[^>]*>.*?</\1>", re.IGNORECASE | re.DOTALL)
_ENTITIES = {
    "&nbsp;": " ", "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"',
    "&#39;": "'", "&apos;": "'", "&ouml;": "ö", "&uuml;": "ü", "&ccedil;": "ç",
}


def html_to_text(html: str) -> str:
    """HTML gövdeyi düz metne indir (harici bağımlılık yok).

    Outlook'un ``HTMLBody`` alanı geldiğinde kullanılır. Satır yapısı korunur:
    ``<br>``/``</p>``/``</div>`` satır sonuna çevrilir, böylece "We confirm the
    balance" gibi cümleler bitişip anlamsız bir tek satıra dönüşmez.
    """
    if not html:
        return ""
    text = _STYLE_RE.sub(" ", html)
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"</(p|div|tr|li|h[1-6])\s*>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"</t[dh]\s*>", "\t", text, flags=re.IGNORECASE)
    text = _TAG_RE.sub(" ", text)
    for entity, char in _ENTITIES.items():
        text = text.replace(entity, char)
    text = re.sub(r"&#(\d+);", lambda m: _safe_chr(m.group(1)), text)
    lines = [_WS_RE.sub(" ", ln).strip() for ln in text.splitlines()]
    return "\n".join(ln for ln in lines if ln)


def _safe_chr(number: str) -> str:
    try:
        return chr(int(number))
    except (ValueError, OverflowError):
        return " "


def looks_like_html(text: str) -> bool:
    """Gövde HTML mi? (Outlook bazen HTML'i düz metin alanında verir.)"""
    if not text:
        return False
    sample = text[:4000].lower()
    return "<html" in sample or "<body" in sample or "<div" in sample or "<p>" in sample


def normalize_body(text: str) -> str:
    """Mail gövdesini analiz edilebilir düz metne indir."""
    if not text:
        return ""
    if looks_like_html(text):
        return html_to_text(text)
    lines = [_WS_RE.sub(" ", ln).strip() for ln in str(text).splitlines()]
    return "\n".join(ln for ln in lines if ln)


def truncate(text: str, limit: int) -> tuple[str, int]:
    """Metni ``limit`` karaktere indir; (metin, atılan karakter) döndür.

    Kırpma SESSİZ olmaz: atılan karakter sayısı çağırana döner ve AI
    yüküne "… (N karakter kırpıldı)" notu olarak yazılır.

    ``limit <= 0`` metnin TAMAMEN düşürülmesi demektir (bütçe tükendi). Bu
    durumda tüm metni geri vermek, yük sınırını anlamsız kılardı.
    """
    if not text:
        return "", 0
    if limit <= 0:
        return "", len(text)
    if len(text) <= limit:
        return text, 0
    return text[:limit], len(text) - limit


def contains_any(haystack_folded: str, needles: tuple[str, ...]) -> str:
    """Katlanmış metinde geçen İLK ifadeyi döndür (yoksa boş string)."""
    for needle in needles:
        if needle and needle in haystack_folded:
            return needle
    return ""
