"""Veritabanı ve ayarların OTOMATİK, ŞİFRELİ yedeği (madde 10).

NEDEN
    Uygulamanın tüm hafızası kullanıcı profilindeki birkaç SQLite dosyasında
    ve ``settings.json``da durur: gönderim günlüğü, vaka kayıtları, denetim
    izi, adres defteri. Bu dosyalar kaybolursa "hangi firmaya ne gönderdik,
    kim ne karar verdi?" sorusunun cevabı da kaybolur.

    Yedek ŞİFRELİDİR çünkü içeriği finansal ve kişisel veridir; yedek
    dosyası ağ sürücüsüne ya da USB'ye kopyalanacaktır.

ŞİFRELEME
    Öncelik ``cryptography`` paketinin AES-256-GCM'idir. Paket ortamda yoksa
    yalnızca standart kütüphaneye dayanan bir yedek şemaya düşülür:
    PBKDF2-HMAC-SHA256 ile türetilen anahtardan üretilen HMAC-SHA256 akış
    şifresi + HMAC-SHA256 bütünlük etiketi.

    Kullanılan şema, dosyanın başlığına AÇIKÇA yazılır; "şifreli" deyip
    hangi yöntemin kullanıldığını gizlemek denetlenebilir değildir.

ASLA ÇÖKERTMEZ
    Yedek alınamazsa hata döndürülür ve loglanır; kullanıcının mutabakatı
    durmaz.
"""

from __future__ import annotations

import hashlib
import hmac
import io
import json
import os
import zipfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional, Sequence

from loguru import logger

from app.utils.paths import app_data_dir

MAGIC = b"MUTABAKAT-BACKUP-1"
SCHEME_AES_GCM = "AES-256-GCM"
SCHEME_HMAC_CTR = "PBKDF2-HMAC-SHA256-CTR"
PBKDF2_ROUNDS = 240_000
SALT_BYTES = 16
NONCE_BYTES = 12

#: Yedeklenen dosyalar (kullanıcı profiline göre görelidir).
BACKUP_TARGETS: tuple[str, ...] = (
    "settings.json",
    "mail_log.db",
    "incoming_cases.db",
    "action_audit.db",
    "ai_audit.db",
    "address_registry.db",
    "send_queue.db",
    "incoming_mail.db",      # işlenen mail önbelleği (idempotency.py)
    "session.json",          # oturum durumu (session_state.py)
)


def _now_tag() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")


@dataclass
class BackupResult:
    """Bir yedekleme denemesinin sonucu."""

    ok: bool = False
    path: str = ""
    scheme: str = ""
    files: list[str] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)
    size: int = 0
    error: str = ""


# -- şifreleme -------------------------------------------------------------

def _derive(password: str, salt: bytes) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt,
                               PBKDF2_ROUNDS, dklen=32)


def _keystream(key: bytes, nonce: bytes, length: int) -> bytes:
    """HMAC-SHA256 sayaç modundan anahtar akışı üret."""
    out = bytearray()
    sayac = 0
    while len(out) < length:
        out += hmac.new(key, nonce + sayac.to_bytes(8, "big"),
                        hashlib.sha256).digest()
        sayac += 1
    return bytes(out[:length])


def _aes_available() -> bool:
    try:
        from cryptography.hazmat.primitives.ciphers.aead import (  # noqa: F401
            AESGCM,
        )

        return True
    except Exception:  # noqa: BLE001 - paket yoksa yedek şemaya düşeriz
        return False


def encrypt_bytes(data: bytes, password: str) -> tuple[bytes, str]:
    """Veriyi şifrele. Döner: ``(şifreli_paket, şema_adı)``."""
    if not password:
        raise ValueError("Yedek parolası boş olamaz.")
    salt = os.urandom(SALT_BYTES)
    nonce = os.urandom(NONCE_BYTES)
    key = _derive(password, salt)

    if _aes_available():
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM

        govde = AESGCM(key).encrypt(nonce, data, MAGIC)
        sema = SCHEME_AES_GCM
    else:
        # ÖNCE ŞİFRELE, SONRA ETİKETLE (encrypt-then-MAC): etiket şifreli
        # metnin üzerinden alınır, böylece bozulmuş bir dosya çözülmeden
        # reddedilir.
        sifreli = bytes(a ^ b for a, b in
                        zip(data, _keystream(key, nonce, len(data))))
        etiket = hmac.new(key, MAGIC + nonce + sifreli, hashlib.sha256).digest()
        govde = sifreli + etiket
        sema = SCHEME_HMAC_CTR

    basli = json.dumps({"scheme": sema, "rounds": PBKDF2_ROUNDS},
                       ensure_ascii=False).encode("utf-8")
    paket = (MAGIC + b"\n"
             + len(basli).to_bytes(2, "big") + basli
             + salt + nonce + govde)
    return paket, sema


def decrypt_bytes(package: bytes, password: str) -> bytes:
    """Şifreli paketi çöz. Parola yanlışsa/dosya bozuksa ``ValueError``."""
    if not package.startswith(MAGIC + b"\n"):
        raise ValueError("Bu dosya bir MutabakatPro yedeği değil.")
    imlec = len(MAGIC) + 1
    basli_uzunluk = int.from_bytes(package[imlec:imlec + 2], "big")
    imlec += 2
    basli = json.loads(package[imlec:imlec + basli_uzunluk].decode("utf-8"))
    imlec += basli_uzunluk
    salt = package[imlec:imlec + SALT_BYTES]
    imlec += SALT_BYTES
    nonce = package[imlec:imlec + NONCE_BYTES]
    imlec += NONCE_BYTES
    govde = package[imlec:]
    key = _derive(password, salt)

    sema = str(basli.get("scheme") or "")
    if sema == SCHEME_AES_GCM:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM

        try:
            return AESGCM(key).decrypt(nonce, govde, MAGIC)
        except Exception as exc:  # noqa: BLE001
            raise ValueError("Parola yanlış ya da yedek bozuk.") from exc
    if sema == SCHEME_HMAC_CTR:
        if len(govde) < 32:
            raise ValueError("Yedek bozuk (etiket eksik).")
        sifreli, etiket = govde[:-32], govde[-32:]
        beklenen = hmac.new(key, MAGIC + nonce + sifreli,
                            hashlib.sha256).digest()
        if not hmac.compare_digest(etiket, beklenen):
            raise ValueError("Parola yanlış ya da yedek bozuk.")
        return bytes(a ^ b for a, b in
                     zip(sifreli, _keystream(key, nonce, len(sifreli))))
    raise ValueError(f"Bilinmeyen yedek şeması: {sema or '—'}")


# -- yedekleme -------------------------------------------------------------

def _archive(source_dir: Path, targets: Sequence[str]
             ) -> tuple[bytes, list[str], list[str]]:
    """Hedef dosyaları tek bir ZIP'e topla. Döner: (zip, bulunan, eksik)."""
    bulunan: list[str] = []
    eksik: list[str] = []
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for ad in targets:
            yol = source_dir / ad
            if not yol.is_file():
                eksik.append(ad)
                continue
            try:
                archive.writestr(ad, yol.read_bytes())
                bulunan.append(ad)
            except OSError as exc:
                logger.warning(f"[yedek] '{ad}' okunamadı: {exc}")
                eksik.append(ad)
    return buffer.getvalue(), bulunan, eksik


def create_backup(password: str, *, source_dir: str | Path | None = None,
                  target_dir: str | Path | None = None,
                  targets: Sequence[str] = BACKUP_TARGETS,
                  keep: int = 10) -> BackupResult:
    """Veritabanlarını ve ayarları ŞİFRELİ tek dosyaya yedekle.

    ``keep`` en yeni kaç yedeğin saklanacağını söyler; eskiler silinir
    (yedek klasörü sınırsız büyümesin). Denetim GÜNLÜĞÜ silinmez — burada
    silinen yalnızca ESKİ YEDEK KOPYALARIDIR.
    """
    kaynak = Path(source_dir) if source_dir else app_data_dir()
    hedef = Path(target_dir) if target_dir else kaynak / "backups"
    sonuc = BackupResult()
    try:
        if not password:
            raise ValueError("Yedek parolası boş olamaz.")
        hedef.mkdir(parents=True, exist_ok=True)
        ham, bulunan, eksik = _archive(kaynak, targets)
        if not bulunan:
            sonuc.error = "Yedeklenecek dosya bulunamadı."
            sonuc.missing = eksik
            return sonuc
        paket, sema = encrypt_bytes(ham, password)
        dosya = hedef / f"mutabakat-yedek-{_now_tag()}.mpb"
        dosya.write_bytes(paket)
        sonuc.ok = True
        sonuc.path = str(dosya)
        sonuc.scheme = sema
        sonuc.files = bulunan
        sonuc.missing = eksik
        sonuc.size = len(paket)
        prune(hedef, keep=keep)
    except Exception as exc:  # noqa: BLE001 - yedek hatası işi durdurmaz
        logger.error(f"[yedek] alınamadı: {exc}")
        sonuc.error = str(exc)
    return sonuc


def prune(backup_dir: str | Path, *, keep: int = 10) -> int:
    """En yeni ``keep`` yedeği bırak, eskilerini sil. Döner: silinen sayısı."""
    klasor = Path(backup_dir)
    if keep <= 0 or not klasor.is_dir():
        return 0
    dosyalar = sorted(klasor.glob("mutabakat-yedek-*.mpb"),
                      key=lambda p: p.name, reverse=True)
    silinen = 0
    for eski in dosyalar[keep:]:
        try:
            eski.unlink()
            silinen += 1
        except OSError as exc:  # pragma: no cover
            logger.warning(f"[yedek] eski yedek silinemedi ({eski}): {exc}")
    return silinen


def restore_backup(path: str | Path, password: str,
                   target_dir: str | Path) -> list[str]:
    """Yedeği çöz ve dosyaları hedef klasöre yaz. Döner: yazılan dosyalar.

    ZIP üyeleri KLASÖRE ÇIKILMADAN doğrulanır: yol ayracı ya da ".."
    içeren bir üye reddedilir (zip-slip). Yedek dosyası dışarıdan gelmiş
    olabilir; kendi ürettiğimiz dosyaya bile körlemesine güvenilmez.
    """
    hedef = Path(target_dir)
    hedef.mkdir(parents=True, exist_ok=True)
    ham = decrypt_bytes(Path(path).read_bytes(), password)
    yazilan: list[str] = []
    with zipfile.ZipFile(io.BytesIO(ham)) as archive:
        for ad in archive.namelist():
            if ad != Path(ad).name or ad in ("", ".", ".."):
                logger.warning(f"[yedek] güvensiz üye atlandı: {ad}")
                continue
            (hedef / ad).write_bytes(archive.read(ad))
            yazilan.append(ad)
    return yazilan


def latest_backup(backup_dir: str | Path | None = None) -> Optional[Path]:
    """En son alınan yedek (yoksa ``None``)."""
    klasor = (Path(backup_dir) if backup_dir
              else app_data_dir() / "backups")
    if not klasor.is_dir():
        return None
    dosyalar = sorted(klasor.glob("mutabakat-yedek-*.mpb"),
                      key=lambda p: p.name, reverse=True)
    return dosyalar[0] if dosyalar else None


def backup_due(*, interval_hours: int = 24,
               backup_dir: str | Path | None = None,
               now: Optional[datetime] = None) -> bool:
    """Otomatik yedeğin zamanı geldi mi?

    Zaman damgası DOSYA ADINDAN okunur: ayrı bir "son yedek" kaydı tutmak,
    dosya elle silindiğinde yalan söylerdi.
    """
    son = latest_backup(backup_dir)
    if son is None:
        return True
    try:
        damga = datetime.strptime(son.stem.split("mutabakat-yedek-")[-1],
                                  "%Y%m%d-%H%M%S").replace(tzinfo=timezone.utc)
    except ValueError:
        return True
    an = now or datetime.now(timezone.utc)
    return (an - damga).total_seconds() >= max(1, int(interval_hours)) * 3600


def auto_backup(password: str, *, interval_hours: int = 24,
                source_dir: str | Path | None = None,
                target_dir: str | Path | None = None,
                now: Optional[datetime] = None) -> Optional[BackupResult]:
    """Zamanı geldiyse yedek al. Zamanı gelmediyse ``None`` döner."""
    hedef = (Path(target_dir) if target_dir
             else (Path(source_dir) if source_dir
                   else app_data_dir()) / "backups")
    if not backup_due(interval_hours=interval_hours, backup_dir=hedef, now=now):
        return None
    return create_backup(password, source_dir=source_dir, target_dir=hedef)


def resolve_password(settings: Any = None) -> str:
    """Yedek parolasını çöz: ortam değişkeni → ayar → boş.

    Parola BULUNAMAZSA yedek alınmaz; şifresiz yedek YAZILMAZ. Sessizce
    şifresiz yazmak, "yedeğim şifreli" sanan kullanıcıyı yanıltır.
    """
    parola = (os.environ.get("MUTABAKAT_BACKUP_PASSWORD") or "").strip()
    if parola:
        return parola
    if settings is not None:
        try:
            return str(settings.get("backup_password", "") or "").strip()
        except Exception:  # noqa: BLE001
            return ""
    return ""
