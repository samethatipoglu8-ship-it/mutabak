"""Firma paketi: Excel ekstre + PDF mektup + TEK mail.

Bu katman, daha önce yazılmış üç parçayı bir araya getirir:

    CompanyPackageDraft (PHASE A/A.1)
        │
        ├─ StatementExcelWriter          → <kod>_<yön>_ekstre.xlsx
        ├─ ReconciliationLetterWriter    → <kod>_<yön>_mutabakat.pdf
        │
        └─ MailDraft (ekler iliştirilmiş) → Outlook

Kurallar (önceki fazlarda onaylandı):
  - Segment başına ayrı Excel ve ayrı PDF; firma başına TEK mail.
    Bir firmada M + S varsa: 1 mail + 4 ek.
  - Bakiye 0 olsa bile paket üretilir ve mail engellenmez.
  - Yalnızca tutarı olan dövizler yazılır.
  - Dil firma kodundan belirlenir (2 → tr, 4 → en). Dil belirlenemezse mail
    TOPLU gönderime GİRMEZ (``MailDraft.needs_confirmation``) — yanlış dilde
    mutabakat mektubu geri alınamaz bir hatadır.
  - Türkçe şablon yoksa MISSING_TR_LETTER_TEMPLATE uyarısı düşer ve o firma
    için PDF üretilmez; sahte metinle mektup ÜRETİLMEZ.

Qt kullanılmaz, Outlook'a bağlanılmaz: bu modül yalnızca dosya üretir ve
taslak kurar. Gönderim çağıranın işidir (``outlook_client.send_all_mails``),
böylece arka plan thread'inde güvenle çalışır.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path
from typing import Iterable, Optional, Sequence

from loguru import logger

from app.mailing.mail_builder import (
    BuildConfig,
    MailDraft,
    _block_en,
    _block_tr,
    _body_en,
    _body_tr,
    _subject,
    classify_locale,
    fmt_amount_tr,
    zero_balance_block,
)
from app.services.company_statement_service import (
    CompanyPackageDraft,
    StatementSegment,
)
from app.services.reconciliation_letter_writer import (
    UNKNOWN_LOCALE_CODE,
    LetterPeriod,
    ReconciliationLetterWriter,
    is_blocking_warning,
)
from app.services.statement_writer import StatementExcelWriter
from app.utils.email import is_valid_email

# Mail metninde para birimi kodları rapordaki gibi yazılır: TRY -> TL.
_MAIL_CURRENCY = {"TRY": "TL"}

# Mail metnindeki döviz sırası. Listede olmayanlar alfabetik olarak SONA
# eklenir — sessizce düşürülmez.
_MAIL_ORDER = ("TL", "EUR", "USD")


@dataclass
class CompanyMailPackage:
    """Bir firmanın tam paketi: dosyalar + gönderilmeye hazır taslak."""

    company_code: str
    company_name: str = ""
    locale: str = "unknown"
    statements: list[Path] = field(default_factory=list)   # Excel ekstreler
    letters: list[Path] = field(default_factory=list)      # PDF mektuplar
    draft: Optional[MailDraft] = None
    warnings: list[str] = field(default_factory=list)
    # Mektup ya da bakiye hatalı üretildiyse gönderimi ENGELLEYEN gerekçeler.
    blocked_reasons: list[str] = field(default_factory=list)

    @property
    def attachments(self) -> list[Path]:
        """Ekler, segment sırasına göre: her yön için önce Excel sonra PDF."""
        return list(self.statements) + list(self.letters)

    @property
    def attachment_count(self) -> int:
        return len(self.attachments)

    # Paketin hangi yönleri (M/S) taşıdığı — gönderim günlüğüne yazılır.
    directions: list[str] = field(default_factory=list)

    # FAZ 2 — bu firmaya GÖNDERİLEN ekstrenin normalize satırları.
    # Gönderim anında hesaplanır ve snapshot'a yazılır; böylece firmanın
    # cevabı, bugünkü dosyayla değil GERÇEKTEN GÖNDERİLEN veriyle
    # karşılaştırılabilir. ``None`` = hesaplanmadı (snapshot yalnızca ham
    # blob'a dayanır); boş liste = hesaplandı, satır yoktu.
    snapshot_records: Optional[list] = None
    responsible: str = ""

    @property
    def blocked(self) -> bool:
        """Mektup güvenli üretilemedi mi? (taşan metin / eksik bakiye)"""
        return bool(self.blocked_reasons)

    @property
    def block_reason(self) -> str:
        """Gönderilemiyorsa TEK CÜMLEYLE nedeni (gönderilebiliyorsa boş).

        Gönderilebilirlik ölçütü tek yerde tanımlıdır: ekran, gönderim işçisi
        ve özet aynı kaynağı kullanır. Eskiden ekran ``letters``, gönderim
        ``statements`` üzerinden süzüyordu; bir paket ekranda "hazır" görünüp
        gönderimde sessizce düşebiliyordu.
        """
        if self.draft is None:
            return "mail taslağı üretilemedi"
        if not self.letters:
            # GERÇEK gerekçe uyarı listesindedir ve eksik dosyanın TAM YOLUNU
            # taşır. Buradan tahmin üretmek ("şablon yok") kullanıcıyı yanlış
            # yere bakmaya gönderirdi.
            for warning in self.warnings:
                if "MISSING_" in warning or UNKNOWN_LOCALE_CODE in warning:
                    return f"PDF mektup üretilemedi — {warning}"
            return "PDF mektup üretilemedi"
        if not self.statements:
            return "Excel ekstre üretilemedi"
        if self.blocked:
            return "mektup güvenli üretilemedi: " + "; ".join(
                self.blocked_reasons[:2])
        return self.draft.skip_reason

    @property
    def sendable(self) -> bool:
        return not self.block_reason


def _mail_balances(segment: StatementSegment) -> dict[str, Decimal]:
    """Segment bakiyelerini mail metninin beklediği kodlara çevir."""
    return {_MAIL_CURRENCY.get(cur, cur): amount
            for cur, amount in segment.display_balances.items()}


def _join_amounts(balances: dict[str, Decimal]) -> str:
    """Bakiyeleri 'X TL, Y EUR and Z GBP' biçiminde birleştir.

    ``mail_builder.format_balances`` yalnızca TL/EUR/USD tanır ve diğer
    para birimlerini SESSİZCE düşürür. Mutabakat mektubunda eksik bir döviz
    yanlış bilgi demektir; bu yüzden burada TÜM para birimleri yazılır:
    önce TL/EUR/USD, sonra kalanlar alfabetik.
    """
    def order(code: str) -> tuple[int, str]:
        return ((_MAIL_ORDER.index(code), "") if code in _MAIL_ORDER
                else (len(_MAIL_ORDER), code))

    parts = [f"{fmt_amount_tr(balances[c])} {c}"
             for c in sorted(balances, key=order) if balances[c] != 0]
    if not parts:
        return ""
    if len(parts) == 1:
        return parts[0]
    return " and ".join([", ".join(parts[:-1]), parts[-1]])


class CompanyPackageService:
    """Firma başına Excel + PDF üretir ve tek mail taslağı kurar."""

    def __init__(
        self,
        excel_writer: Optional[StatementExcelWriter] = None,
        letter_writer: Optional[ReconciliationLetterWriter] = None,
    ) -> None:
        self._excel = excel_writer or StatementExcelWriter()
        self._letters = letter_writer or ReconciliationLetterWriter()

    @staticmethod
    def period_dir(output_dir: str | Path, period: LetterPeriod) -> Path:
        """Dönem klasörü: <çıktı>/<yıl>-<ay>. Aylar birbirini ezmez."""
        return Path(output_dir) / f"{period.year}-{period.month:02d}"

    # -- tek firma ---------------------------------------------------------

    def build_one(
        self,
        draft: CompanyPackageDraft,
        output_dir: str | Path,
        period: LetterPeriod,
        config: Optional[BuildConfig] = None,
    ) -> CompanyMailPackage:
        """Bir firmanın dosyalarını üret ve mail taslağını kur."""
        before = len(draft.warnings)

        # Dosyalar DÖNEM klasörüne yazılır: aynı firmanın Temmuz ve Ağustos
        # mektupları aynı ada sahip olduğu için düz klasörde biri diğerini
        # eziyordu (kanıtlandı). Dönem klasörü bunu önler.
        target = self.period_dir(output_dir, period)

        statements = self._excel.write_package(draft, target)
        letters = self._letters.write_package(draft, target, period)

        package = CompanyMailPackage(
            company_code=draft.company_code,
            company_name=draft.company_name,
            locale=classify_locale(draft.company_code),
            statements=statements,
            letters=letters,
            directions=list(draft.directions),
            responsible=draft.responsible,
            warnings=list(draft.warnings),
        )
        # Gönderilen ekstrenin satırları BURADA dondurulur. Üretim zaten bu
        # satırlardan Excel yazdı; aynı veriyi snapshot'a taşımak ek maliyet
        # getirmez ama cevabın doğru referansla karşılaştırılmasını sağlar.
        try:
            from app.services.snapshot_records import records_from_draft

            package.snapshot_records = records_from_draft(draft)
        except Exception as exc:  # noqa: BLE001 - snapshot üretimi bozmaz
            logger.warning(
                f"[snapshot] {draft.company_code} satırları çıkarılamadı: {exc}")
            package.snapshot_records = None
        # Üretim sırasında eklenen uyarılar (eksik şablon, taşan alan vb.).
        new_warnings = draft.warnings[before:]
        package.warnings.extend(new_warnings)

        # Mektup güvenli üretilemediyse gönderimi engelle: sayfadan taşan bir
        # metin ya da eksik yazılmış bir bakiye, karşı tarafa yanlış bilgi
        # gider ve geri alınamaz.
        package.blocked_reasons.extend(
            w for w in new_warnings if is_blocking_warning(w))
        package.blocked_reasons.extend(
            w for w in draft.warnings if w.startswith("Geçersiz e-posta adresi:"))

        if not letters:
            package.warnings.append(
                "PDF mektup üretilemedi; mail ekleri eksik kalacağı için "
                "gönderim yapılmayacak."
            )

        # Bir yönün SAP dosyası yüklenmediyse o yönün bakiyesi BİLİNMİYOR
        # demektir. "Borcunuz yok" diyen bir mektup göndermektense gönderimi
        # engellemek doğrudur; kullanıcı eksik dosyayı yükleyip tekrar üretir.
        missing = [s.ms or "yön belirsiz" for s in draft.segments
                   if s.source_missing]
        if missing:
            package.blocked_reasons.append(
                f"{', '.join(missing)} yönü için SAP dosyası yüklenmedi; "
                "bakiye hesaplanamadı"
            )

        package.draft = self._build_mail(draft, package, period, config)
        return package

    # -- toplu -------------------------------------------------------------

    def build_all(
        self,
        drafts: Iterable[CompanyPackageDraft],
        output_dir: str | Path,
        period: LetterPeriod,
        config: Optional[BuildConfig] = None,
    ) -> list[CompanyMailPackage]:
        return [self.build_one(d, output_dir, period, config)
                for d in drafts]

    @staticmethod
    def sendable(packages: Sequence[CompanyMailPackage]) -> list[MailDraft]:
        """Toplu gönderime girebilecek taslaklar.

        Şu firmalar dışarıda kalır: eki eksik, dili belirlenememiş, mektubu
        güvenli üretilememiş (taşan metin / eksik bakiye) olanlar. Bunlar
        kullanıcı tarafından bilerek ve kontrol edilerek gönderilmelidir.
        Ölçüt ``CompanyMailPackage.block_reason``dır — tek doğruluk kaynağı.
        """
        return [p.draft for p in packages if p.sendable]

    @staticmethod
    def block_reasons(
        packages: Sequence[CompanyMailPackage],
    ) -> dict[str, list[str]]:
        """Gönderilemeyen firmaları GEREKÇEYE göre grupla (ekranda gösterilir).

        Dönüş: gerekçe -> firma kodları. Boşsa engellenen firma yok.
        """
        grouped: dict[str, list[str]] = {}
        for package in packages:
            reason = package.block_reason
            if reason:
                grouped.setdefault(reason, []).append(package.company_code)
        return grouped

    # -- mail taslağı ------------------------------------------------------

    def _build_mail(
        self,
        draft: CompanyPackageDraft,
        package: CompanyMailPackage,
        period: LetterPeriod,
        config: Optional[BuildConfig],
    ) -> MailDraft:
        locale = package.locale
        as_of = period.as_of.strftime("%d.%m.%Y")

        # Her yön için ayrı cümle — FAZ1 metinleriyle birebir aynı şablonlar,
        # ancak bakiye SAP kaynağından (segment) gelir.
        blocks: list[str] = []
        for segment in draft.segments:
            amounts = _join_amounts(_mail_balances(segment))
            if not amounts:
                continue
            ms = segment.ms or "S"
            blocks.append(_block_tr(ms, amounts, as_of) if locale == "tr"
                          else _block_en(ms, amounts, as_of))

        if not blocks:
            # Tüm segmentler sıfır: gönderim ENGELLENMEZ, metin değişir.
            blocks = [zero_balance_block(locale, draft.zero_balance_currency)]

        body = (_body_tr(blocks, as_of) if locale == "tr"
                else _body_en(blocks, as_of))
        subject = _subject(draft.company_code, locale,
                           period.year, period.month)

        cc: list[str] = []
        responsible = draft.responsible
        if config is not None:
            cc = []
            invalid_cc: list[str] = []
            for address in config.extra_cc:
                if is_valid_email(address) and address not in cc:
                    cc.append(address)
                elif address:
                    invalid_cc.append(address)
            if config.include_responsible_cc and responsible:
                address = config.responsible_emails.get(responsible.strip())
                if address:
                    for part in address.replace(",", ";").split(";"):
                        part = part.strip()
                        if is_valid_email(part) and part not in cc:
                            cc.append(part)
                        elif part:
                            invalid_cc.append(part)
                else:
                    package.warnings.append(
                        f"Sorumlu '{responsible}' için mail adresi tanımlı değil."
                    )
            if invalid_cc:
                reason = "Geçersiz e-posta adresi: " + ", ".join(
                    dict.fromkeys(invalid_cc))
                package.warnings.append(reason)
                package.blocked_reasons.append(reason)

        if not draft.recipient_emails:
            package.warnings.append("Firma mail adresi tanımlı değil.")
        if locale == "unknown":
            package.warnings.append(
                "Firma kodu 2/4 ile başlamıyor; dil belirlenemedi. Bu firma "
                "toplu gönderime girmez."
            )

        return MailDraft(
            code=draft.company_code,
            locale=locale,
            to=list(draft.recipient_emails),
            cc=cc,
            subject=subject,
            body=body,
            responsible=responsible,
            warnings=list(package.warnings),
            attachments=[str(p) for p in package.attachments],
        )
