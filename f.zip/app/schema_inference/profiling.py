"""FAZ 6 — deterministic per-column content profiling (dormant, advisory).

BİLİNÇLİ TASARIM KARARI: bu modül ``app/utils/normalization.py``'yi
İMPORT ETMEZ/KULLANMAZ. Kendi, basit, bağımsız kaba-ayrıştırıcılarını
taşır. Böylece:

- bu modülde yapılan HİÇBİR değişiklik production normalizasyon
  davranışını (``normalize_amount``/``normalize_date``) yanlışlıkla
  etkileyemez,
- production normalizasyonunda yapılan HİÇBİR değişiklik bu modülün
  profil sonuçlarını sessizce bozamaz.

Bu kasıtlı bağımsızlık, "üretim matching semantiği değişmedi" iddiasını
import-grafiği seviyesinde kanıtlanabilir kılar.

Performans (Aşama 14): her kolon TEK SEFER profillenir; regex'ler modül
seviyesinde ÖNCEDEN derlenir; örnekleme ``MAX_PROFILE_SAMPLE`` ile sınırlıdır.
"""

from __future__ import annotations

import re
from collections import Counter
from decimal import Decimal, InvalidOperation
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field

#: Performans sınırı (Aşama 14) — kolon profili bu kadar örnekle hesaplanır.
MAX_PROFILE_SAMPLE = 500

_NON_NUMERIC_CHARS_RE = re.compile(r"[^0-9.,]")
_DIGIT_RE = re.compile(r"\d")
_CURRENCY_CODE_RE = re.compile(r"^[A-Za-z]{3}$|^(TRY|TRL|TL|USD|EUR|GBP|CHF|JPY)$", re.I)
_IDENTIFIER_LIKE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9\-_/.]{2,39}$")


class PrimitiveType(str, Enum):
    NUMERIC = "numeric"
    DATE = "date"
    TEXT = "text"
    EMPTY = "empty"
    MIXED = "mixed"


class NumericLocale(str, Enum):
    """Aşama 7 — kolon-seviyesi ondalık ayracı oylaması sonucu."""

    TR_STYLE = "tr_style"     # virgül ondalık, nokta binlik: 1.234,56
    EN_STYLE = "en_style"     # nokta ondalık, virgül binlik: 1,234.56
    AMBIGUOUS = "ambiguous"   # tek ayraç, 3 haneli kuyruk: 1.234 / 1,234
    UNKNOWN = "unknown"       # kanıt yok (ayraçsız/boş)


class DateFormatHypothesis(str, Enum):
    """Aşama 8 — kolon-seviyesi tarih format oylaması sonucu."""

    DMY_DOT = "dmy_dot"       # 31.12.2026
    DMY_SLASH = "dmy_slash"   # 31/12/2026
    MDY_SLASH = "mdy_slash"   # 12/31/2026
    YMD_DASH = "ymd_dash"     # 2026-12-31
    DMY_DASH = "dmy_dash"     # 31-12-2026
    AMBIGUOUS = "ambiguous"   # gün<=12: DMY_SLASH ve MDY_SLASH ayırt edilemez
    UNKNOWN = "unknown"


def _single_value_numeric_locale(raw: str) -> NumericLocale:
    """Tek bir hücreden, VARSA, kesin ya da belirsiz ondalık-ayracı kanıtı.

    Kolon geneli oylamasına girecek TEK bir hücrenin oyu — karar DEĞİL.
    """
    body = _NON_NUMERIC_CHARS_RE.sub("", raw)
    if not body or not _DIGIT_RE.search(body):
        return NumericLocale.UNKNOWN
    has_dot, has_comma = "." in body, "," in body
    if has_dot and has_comma:
        # İki ayraç birlikte: SON ayraç ondalıktır (kesin kanıt).
        return NumericLocale.TR_STYLE if body.rfind(",") > body.rfind(".") else NumericLocale.EN_STYLE
    if has_comma:
        tail = body.rsplit(",", 1)[1]
        if body.count(",") > 1:
            return NumericLocale.EN_STYLE  # 1,234,567 -> virgül binlik (EN)
        if len(tail) in (0, 1, 2):
            return NumericLocale.TR_STYLE  # tek virgül, kısa kuyruk -> ondalık (TR)
        if len(tail) == 3:
            return NumericLocale.AMBIGUOUS  # "1,234" -> binlik mi ondalık mı belirsiz
        return NumericLocale.UNKNOWN
    if has_dot:
        tail = body.rsplit(".", 1)[1]
        if body.count(".") > 1:
            return NumericLocale.TR_STYLE  # 1.234.567 -> nokta binlik (TR)
        if len(tail) in (0, 1, 2):
            return NumericLocale.EN_STYLE  # tek nokta, kısa kuyruk -> ondalık (EN)
        if len(tail) == 3:
            return NumericLocale.AMBIGUOUS  # "1.234" -> belirsiz
        return NumericLocale.UNKNOWN
    return NumericLocale.UNKNOWN  # ayraçsız tam sayı: kanıt yok


def vote_numeric_locale(values: list[str]) -> dict[str, int]:
    """Kolon genelinde ``NumericLocale`` oylarının SAYIMI (karar değil,
    kanıt). Dominant locale ``dominant_numeric_locale`` ile türetilir."""
    counts: Counter[str] = Counter()
    for v in values:
        counts[_single_value_numeric_locale(v).value] += 1
    return dict(counts)


def dominant_numeric_locale(votes: dict[str, int]) -> NumericLocale:
    """Oy sayımından TEK bir dominant hipotez türet (deterministik).

    Üretim ``normalize_amount`` davranışını DEĞİŞTİRMEZ — bu salt
    profilleme/öneri amaçlıdır.
    """
    tr, en = votes.get(NumericLocale.TR_STYLE.value, 0), votes.get(NumericLocale.EN_STYLE.value, 0)
    if tr == 0 and en == 0:
        amb = votes.get(NumericLocale.AMBIGUOUS.value, 0)
        return NumericLocale.AMBIGUOUS if amb > 0 else NumericLocale.UNKNOWN
    if tr > en:
        return NumericLocale.TR_STYLE
    if en > tr:
        return NumericLocale.EN_STYLE
    return NumericLocale.AMBIGUOUS  # eşit kanıt -> çözülmez, zorlanmaz


_DATE_PATTERNS: tuple[tuple[DateFormatHypothesis, re.Pattern], ...] = (
    (DateFormatHypothesis.YMD_DASH, re.compile(r"^(\d{4})-(\d{1,2})-(\d{1,2})$")),
    (DateFormatHypothesis.DMY_DOT, re.compile(r"^(\d{1,2})\.(\d{1,2})\.(\d{4})$")),
    (DateFormatHypothesis.DMY_SLASH, re.compile(r"^(\d{1,2})/(\d{1,2})/(\d{4})$")),
    (DateFormatHypothesis.DMY_DASH, re.compile(r"^(\d{1,2})-(\d{1,2})-(\d{4})$")),
)
_SLASH_RE = re.compile(r"^(\d{1,2})/(\d{1,2})/(\d{4})$")


def _single_value_date_candidates(raw: str) -> list[DateFormatHypothesis]:
    """Bu hücreyi ayrıştırabilen TÜM format hipotezleri. ``31/02/2026`` gibi
    tek bir değer birden fazla hipotezi destekleyebilir (DMY/MDY ayrımı gün
    alanı tek başına 12'yi aşmıyorsa ÇÖZÜLEMEZ)."""
    text = raw.strip()[:10]
    out: list[DateFormatHypothesis] = []
    m = _SLASH_RE.match(text)
    if m:
        day, month = int(m.group(1)), int(m.group(2))
        if day <= 12 and month <= 12:
            out.extend([DateFormatHypothesis.DMY_SLASH, DateFormatHypothesis.MDY_SLASH])
        elif day <= 31 and month <= 12:
            out.append(DateFormatHypothesis.DMY_SLASH)
        elif month <= 31 and day <= 12:
            out.append(DateFormatHypothesis.MDY_SLASH)
        return out
    for fmt, pattern in _DATE_PATTERNS:
        if fmt is DateFormatHypothesis.DMY_SLASH:
            continue
        if pattern.match(text):
            out.append(fmt)
    return out


def vote_date_format(values: list[str]) -> dict[str, int]:
    """Kolon genelinde format-hipotezi oylarının SAYIMI."""
    counts: Counter[str] = Counter()
    for v in values:
        for fmt in _single_value_date_candidates(v):
            counts[fmt.value] += 1
    return dict(counts)


def dominant_date_format(votes: dict[str, int], sample_count: int) -> DateFormatHypothesis:
    """Format oylarından dominant hipotez türet.

    ``DMY_SLASH``/``MDY_SLASH`` kolon genelinde HİÇ gün>12 kanıtı yoksa
    (yani ikisi de tüm örneklerde eşit oy aldıysa) ``AMBIGUOUS`` kalır —
    kullanıcı talimatı: "must NOT be force-resolved solely from one value."
    """
    if not votes or sample_count == 0:
        return DateFormatHypothesis.UNKNOWN
    best_fmt, best_n = max(votes.items(), key=lambda kv: kv[1])
    # Birden fazla format EŞİT en-yüksek oyu aldıysa (DMY/MDY tipik durumu)
    # ve hiçbiri diğerini aşmıyorsa belirsiz kalır.
    tied = [f for f, n in votes.items() if n == best_n]
    if len(tied) > 1:
        return DateFormatHypothesis.AMBIGUOUS
    return DateFormatHypothesis(best_fmt)


_ALPHA_RE = re.compile(r"[A-Za-zÇĞİÖŞÜçğıöşü]")
_SIGN_CURRENCY_DECORATION_RE = re.compile(
    r"^[\(\s]*[+-]?|\b(TRY|TRL|TL|USD|EUR|GBP|CHF|JPY)\b|[\)\s]*$", re.I,
)


def _looks_numeric(raw: str) -> bool:
    """Bu hücre bir SAYI mı — harf İÇERMEYEN, yalnızca rakam/ayraç/işaret/
    bilinen para birimi kodu taşıyan bir değer mi?

    KRİTİK DÜZELTME: eski sürüm harfleri SESSİZCE ATIYOR, böylece
    "FTR-2026/00412" gibi alfasayısal bir REFERANS'ı da "sayısal" sayıyordu
    (yalnızca rakamlara bakıp harfleri yok sayması nedeniyle). Bu, bir
    referans kolonunun yanlışlıkla DEBIT/CREDIT/AMOUNT adayı sanılmasına yol
    açabilirdi — düzeltildi: HARF içeren (bilinen para birimi kodu/B-A-D-C
    gibi tek-harf işaret göstergesi dışında) hiçbir değer sayısal SAYILMAZ.
    """
    if _looks_date(raw):
        return False
    core = _SIGN_CURRENCY_DECORATION_RE.sub("", raw.strip())
    if _ALPHA_RE.search(core):
        return False
    body = _NON_NUMERIC_CHARS_RE.sub("", core)
    return bool(body) and bool(_DIGIT_RE.search(body))


def _looks_date(raw: str) -> bool:
    return bool(_single_value_date_candidates(raw))


def _try_parse_loose_number(raw: str) -> Optional[Decimal]:
    """Profilleme İÇİN kaba bir sayı ayrıştırması (karar DEĞİL, salt
    magnitude/sign istatistiği için). Üretim ``normalize_amount``'u
    KULLANMAZ/TAKLİT ETMEZ — bilerek basit ve bağımsızdır."""
    text = raw.strip()
    neg = False
    if text.startswith("(") and text.endswith(")"):
        neg, text = True, text[1:-1]
    if text.startswith("-"):
        neg, text = True, text[1:]
    body = _NON_NUMERIC_CHARS_RE.sub("", text)
    if not body or not _DIGIT_RE.search(body):
        return None
    locale = _single_value_numeric_locale(raw)
    if locale is NumericLocale.TR_STYLE:
        body = body.replace(".", "").replace(",", ".")
    elif locale is NumericLocale.EN_STYLE:
        body = body.replace(",", "")
    else:
        body = body.replace(",", "").replace(".", "") if body.count(".") + body.count(",") > 1 else body
    try:
        value = Decimal(body)
    except InvalidOperation:
        return None
    return -value if neg else value


class ColumnProfile(BaseModel):
    """Aşama 2 — bir kolonun deterministik içerik parmak izi (dormant)."""

    index: int
    header_raw: Optional[str] = None
    header_normalized: str = ""
    sample_values: list[str] = Field(default_factory=list)
    neighboring_headers: list[str] = Field(default_factory=list)

    non_null_ratio: float = 0.0
    unique_ratio: float = 0.0
    inferred_primitive_type: PrimitiveType = PrimitiveType.EMPTY

    numeric_ratio: float = 0.0
    date_ratio: float = 0.0
    text_ratio: float = 0.0
    negative_ratio: float = 0.0
    zero_ratio: float = 0.0
    integer_ratio: float = 0.0
    decimal_ratio: float = 0.0
    avg_text_length: float = 0.0

    min_magnitude: Optional[Decimal] = None
    max_magnitude: Optional[Decimal] = None
    monotonic_score: float = 0.0

    currency_code_ratio: float = 0.0
    identifier_like_ratio: float = 0.0

    date_format_votes: dict[str, int] = Field(default_factory=dict)
    numeric_locale_votes: dict[str, int] = Field(default_factory=dict)

    @property
    def dominant_numeric_locale(self) -> NumericLocale:
        return dominant_numeric_locale(self.numeric_locale_votes)

    @property
    def dominant_date_format(self) -> DateFormatHypothesis:
        non_empty = sum(1 for v in self.sample_values if v.strip())
        return dominant_date_format(self.date_format_votes, non_empty)


def normalize_header_text(header: object) -> str:
    """Başlığı karşılaştırılabilir anahtara indir (public — ``inference.py``
    override eşleştirmesi için de kullanır; ``column_mapper.py``'nin KENDİ
    ``_norm`` fonksiyonundan BAĞIMSIZ, bilerek ayrı bir kopya)."""
    text = str(header).strip().lower() if header is not None else ""
    trans = str.maketrans("çğıöşü", "cgiosu")
    text = text.translate(trans)
    return re.sub(r"[^a-z0-9]", "", text)


def build_column_profile(
    index: int,
    header: object,
    values: list[object],
    neighboring_headers: Optional[list[str]] = None,
) -> ColumnProfile:
    """Bir kolonu TEK SEFER profille (Aşama 14 — çağıran taraf sonucu
    cache'lemelidir; bu fonksiyon kendi başına tekrar hesaplama yapmaz).
    """
    sample = values[:MAX_PROFILE_SAMPLE]
    raw_strings = ["" if v is None else str(v).strip() for v in sample]
    non_empty = [s for s in raw_strings if s]
    n = len(raw_strings)

    header_raw = None if header is None else str(header)
    profile = ColumnProfile(
        index=index,
        header_raw=header_raw,
        header_normalized=normalize_header_text(header),
        sample_values=non_empty[:20],
        neighboring_headers=list(neighboring_headers or []),
    )
    if n == 0 or not non_empty:
        profile.inferred_primitive_type = PrimitiveType.EMPTY
        return profile

    profile.non_null_ratio = len(non_empty) / n
    profile.unique_ratio = len(set(non_empty)) / len(non_empty)
    profile.avg_text_length = sum(len(s) for s in non_empty) / len(non_empty)

    date_flags = [_looks_date(s) for s in non_empty]
    numeric_flags = [(not d) and _looks_numeric(s) for s, d in zip(non_empty, date_flags)]
    text_flags = [not (d or nm) for d, nm in zip(date_flags, numeric_flags)]

    profile.date_ratio = sum(date_flags) / len(non_empty)
    profile.numeric_ratio = sum(numeric_flags) / len(non_empty)
    profile.text_ratio = sum(text_flags) / len(non_empty)

    if profile.numeric_ratio >= 0.6:
        profile.inferred_primitive_type = PrimitiveType.NUMERIC
    elif profile.date_ratio >= 0.6:
        profile.inferred_primitive_type = PrimitiveType.DATE
    elif profile.text_ratio >= 0.6:
        profile.inferred_primitive_type = PrimitiveType.TEXT
    else:
        profile.inferred_primitive_type = PrimitiveType.MIXED

    numeric_values = [s for s, is_num in zip(non_empty, numeric_flags) if is_num]
    parsed = [v for v in (_try_parse_loose_number(s) for s in numeric_values) if v is not None]
    if parsed:
        profile.negative_ratio = sum(1 for p in parsed if p < 0) / len(parsed)
        profile.zero_ratio = sum(1 for p in parsed if p == 0) / len(parsed)
        profile.integer_ratio = sum(1 for p in parsed if p == p.to_integral_value()) / len(parsed)
        profile.decimal_ratio = 1.0 - profile.integer_ratio
        magnitudes = [abs(p) for p in parsed]
        profile.min_magnitude = min(magnitudes)
        profile.max_magnitude = max(magnitudes)
        if len(parsed) > 3:
            diffs = [b - a for a, b in zip(parsed, parsed[1:])]
            flips = sum(1 for a, b in zip(diffs, diffs[1:]) if (a > 0) != (b > 0))
            profile.monotonic_score = 1.0 - flips / max(1, len(diffs) - 1)

    profile.currency_code_ratio = (
        sum(1 for s in non_empty if _CURRENCY_CODE_RE.match(s)) / len(non_empty)
    )
    profile.identifier_like_ratio = (
        sum(1 for s, is_num, is_date in zip(non_empty, numeric_flags, date_flags)
            if not is_num and not is_date and _IDENTIFIER_LIKE_RE.match(s))
        / len(non_empty)
    )

    profile.date_format_votes = vote_date_format(non_empty)
    profile.numeric_locale_votes = vote_numeric_locale(numeric_values)
    return profile
