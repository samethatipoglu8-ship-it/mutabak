"""Column recognition with automatic multi-candidate detection.

Different firms follow different policies: the invoice number may live in a
column called DocFatt, Numero documento, Invoice, Fatura No, Referans... and on
the TOFAŞ side the matching value may sit in "Referans", "Referans anahtar 1",
or "Referans anahtar 2". Rather than fixing one column, we detect *all*
plausible candidate columns for each role and let the reconciler try them,
accepting a match only when the amount also agrees. Pure, deterministic
dictionary lookup — no AI.
"""

from __future__ import annotations

import re


def _norm(header: object) -> str:
    """Başlığı karşılaştırılabilir anahtara indir.

    Köşeli parantezli ETİKETLER atılır: bazı kurumsal dışa-aktarımlar
    kolon adlarını kaynak sistemle işaretler (ör. "[D] Accounting document
    number", "[M] Legal entity", "[Master-enhanced] AR category L2").
    Etiket kolonun ANLAMINI değiştirmez, yalnızca eşleşmeyi engellerdi.
    """
    text = str(header).strip().lower()
    text = re.sub(r"\[[^\]]*\]", " ", text)
    trans = str.maketrans("çğıöşü", "cgiosu")
    text = text.translate(trans)
    return re.sub(r"[^a-z0-9]", "", text)


# ---------------------------------------------------------------------------
# TOFAŞ (SAP) side
# ---------------------------------------------------------------------------

TOFAS_FIELDS: dict[str, str] = {
    "mali yıl": "fiscal_year",
    "yıl/ay": "fiscal_year",
    # main account (Defteri-i Kebir ana hesabı) — varyantlar
    "defteri kebir muhasebesi ana hesabı": "main_account",
    "defteri kebir muhasebe ana hesabı": "main_account",
    "ana hesap": "main_account",
    # cari/firma hesabı
    "firma kodu": "firma_kodu",
    "hesap": "firma_kodu",
    # FBL5H (müşteri defteri) firma kodunu "Müşteri" başlığı altında verir.
    # Bu kolon eşlenmediği sürece 120* satırları HİÇBİR firmaya bağlanamıyor
    # ve müşteri modu config/customer_accounts.yaml'daki elle eşleme tablosu
    # doldurulmadan çalışmıyordu. Gerçek bir FBL5H çıktısında 1.272 satırın
    # 126 farklı müşteri kodu bu kolonda HAZIR duruyor.
    "müşteri": "firma_kodu",
    "musteri": "firma_kodu",
    "müşteri no": "firma_kodu",
    "müşteri kodu": "firma_kodu",
    "customer": "firma_kodu",
    "customer no": "firma_kodu",
    "customer code": "firma_kodu",
    "satıcı hesabı: ad 1": "satici_ad",
    "satıcı hesabı ad 1": "satici_ad",
    "ad 1": "satici_ad",
    "belge türü": "belge_turu",
    "belge tarihi": "belge_tarihi",
    "kayıt tarihi": "kayit_tarihi",
    "belge numarası": "belge_no",
    # tutar — SAP export şablonuna göre değişir
    "belge para birimi değeri": "amount",
    "belge pb cinsinden tutar": "amount",
    "belge para biriminde tutar": "amount",
    # para birimi kodu
    "belge para birimi anahtarı": "currency",
    "belge para birimi": "currency",
    "ulusal para birimi": "currency",
    "metin": "metin",
    "giriş tarihi": "giris_tarihi",
    "net vade tarihi": "net_vade",
}

# Columns whose values may hold the invoice/reference number, priority order.
TOFAS_REF_CANDIDATES: tuple[str, ...] = (
    "referans",
    "referans anahtar 1",
    "referans anahtar 2",
    "referans anahtar 3",
)


def map_tofas_columns(headers: list[object]) -> tuple[dict[str, int], list[int]]:
    """Return (field->index, [reference-candidate indexes]) for a TOFAŞ header row."""
    field_lookup = {_norm(k): v for k, v in TOFAS_FIELDS.items()}
    ref_norms = {_norm(k) for k in TOFAS_REF_CANDIDATES}

    mapping: dict[str, int] = {}
    ref_seen: dict[str, int] = {}

    for idx, header in enumerate(headers):
        if header is None:
            continue
        n = _norm(header)
        field = field_lookup.get(n)
        if field and field not in mapping:
            mapping[field] = idx
        if n in ref_norms and n not in ref_seen:
            ref_seen[n] = idx

    ref_indexes: list[int] = []
    for cand in TOFAS_REF_CANDIDATES:
        i = ref_seen.get(_norm(cand))
        if i is not None:
            ref_indexes.append(i)
    return mapping, ref_indexes


# ---------------------------------------------------------------------------
# Firma (supplier) side — multilingual, multi-candidate
# ---------------------------------------------------------------------------

_FIRMA_ROLE_SYNONYMS: dict[str, set[str]] = {
    "reference": set(),
    "amount": set(),
    "debit": set(),     # Borç (yerli ekstrelerde ayrı kolon)
    "credit": set(),    # Alacak (yerli ekstrelerde ayrı kolon)
    "ba_indicator": set(),  # B/A göstergesi: tek "Tutar" + ayrı "B/A" kolonu
                            # olan yerli ekstrelerde işaret kaynağı. AYRI
                            # Borç/Alacak kolonu VARSA yok sayılır (debit-credit
                            # önceliklidir — kullanıcı kararı).
    "balance": set(),   # Bakiye/Balance — yürüyen bakiye; işlem tutarı DEĞİL,
                        # yalnızca amount ve debit/credit yoksa son çare tutar.
    "currency": set(),  # Para birimi kolonu (varsa eşleştirmede kullanılır)
    "inv_date": set(),
    "due_date": set(),
    "account": set(),
    "name": set(),
    "comment": set(),
}


def _reg(role: str, *aliases: str) -> None:
    for a in aliases:
        _FIRMA_ROLE_SYNONYMS[role].add(_norm(a))


# NOTE: reference adayları TEK role toplanır ama okuma sırasında kolon
# önceliği REFERENCE_PRIORITY ile belirlenir: gerçek "fatura/belge no"
# kolonları, "fiş no" gibi yerli-özgü yedek kolonlardan ÖNCE denenir.
_reg("reference",
     # English
     "invoice", "invoice no", "invoice number", "invoice #", "inv no", "inv. no",
     "inv", "inv#", "invoices", "invoices reference", "invoice reference",
     "invoices ref", "document number", "document no", "doc no", "docno",
     "reference", "ref", "ref no", "reference number", "reference no",
     "bill no", "bill number", "voucher no", "voucher number", "vch no",
     "our ref", "your ref", "transaction no", "transaction number", "trans no",
     # Turkish — fatura/belge öncelikli
     "fatura no", "fatura numarası", "fatura numarasi", "fatura no.", "fatura nu",
     "faturano", "fatura belge no", "referans", "referans no", "referans kodu",
     "referans anahtarı", "referans anahtari", "belge no", "belge numarası",
     "belge numarasi", "belge nu", "belgeno", "evrak no", "evrak numarası",
     "evrak numarasi", "evrakno", "irsaliye no", "irsaliye numarası",
     "fatura/belge no", "belge/fatura no", "fatura/fiş no",
     # SAP satış/teslimat belgeleri (POLONYAV2): fatura no yerine bunlar taşınır
     "billing document", "delivery note", "delivery note no",
     # Yerli-özgü yedek referanslar (fiş / dekont / makbuz / yevmiye / seri-sıra)
     "fiş no", "fiş numarası", "fis no", "fis numarasi", "fisno", "fiş nu",
     "fiş/belge no", "belge/fiş no", "makbuz no", "makbuz numarası",
     "dekont no", "dekont numarası", "yevmiye no", "yevmiye numarası",
     "muhasebe fiş no", "muhasebe fis no", "seri no", "seri sıra no",
     "seri/sıra no", "seri sira no", "sıra no", "sira no", "seri", "sıra",
     # German
     "rechnung", "rechnungsnummer", "rechnungs-nr", "rechnung nr", "rg-nr", "rg nr",
     "beleg", "belegnummer", "beleg-nr", "beleg nr", "rechnungsnr", "dokumentnummer",
     "dokument-nr", "referenz", "referenznummer", "vorgang", "vorgangsnummer",
     "verwendungszweck",
     # Italian
     "docfatt", "doc fatt", "numero documento", "n documento", "n° documento",
     "numero fattura", "n. fattura", "n° fattura", "fattura", "attribuzione",
     "nr fattura", "num fattura", "riferimento", "documento nr", "protocollo",
     # French
     "facture", "numero de facture", "n° facture", "numéro facture", "no facture",
     "num facture", "piece", "numero piece", "n° piece", "reference facture",
     # Spanish
     "factura", "numero de factura", "nº factura", "num factura", "documento",
     "numero documento", "referencia", "num documento",
     # Portuguese
     "fatura", "numero da fatura", "nº fatura", "documento", "nota fiscal",
     "numero documento", "referencia",
     # Dutch
     "factuur", "factuurnummer", "factuur nr", "documentnummer", "referentie",
     # Polish
     "faktura", "numer faktury", "nr faktury", "dokument", "numer dokumentu",
     # Romanian
     "factura", "numar factura", "nr factura", "document", "numar document")

# ÖNEMLİ: amount rolü artık YALNIZCA gerçek "işlem tutarı" kolonlarını içerir.
# Borç/Alacak (debit/credit) ve düz Bakiye/Balance/Saldo/Solde/Sold kolonları
# buradan ÇIKARILDI — çünkü çift-kolon muhasebe ekstrelerinde bir Borç ya da
# yürüyen Bakiye kolonu yanlışlıkla "tutar" seçilip mutabakatı bozuyordu.
# Bunlar sırasıyla "debit"/"credit" ve "balance" rollerinde ele alınır.
_reg("amount",
     # English
     "amount", "value", "value/€", "value eur", "total", "net", "net amount",
     "open amount", "outstanding", "gross", "gross amount", "sum",
     # Turkish
     "tutar", "meblağ", "değer",
     "belge para birimi değeri", "belge pb cinsinden tutar",
     "belge para biriminde tutar", "yerel para birimi değeri",
     # SAP FBL dışa-aktarım (EN) — gerçek başlıklar (ölçülmüş; belge para birimi
     # cinsinden işlem tutarı). NOT: "local currency" KASITLI eklenmedi — belge
     # para birimi cinsi eşleştirmede esas alınır (yerel/TRY karşılığı değil).
     "amount in doc. curr.", "amount in doc curr", "amount in doc.curr.",
     "amount in document currency", "document currency value",
     # İtalyan ERP (Account_payables): Importo in DD
     "importo in dd",
     # İspanyol ERP (aging raporu): vadesi geçmiş açık tutar
     "saldo vencido",
     # SAP kısaltmalı (ornekv3): Amount in DC
     "amount in dc",
     # Odoo (İSVEÇ): imzalı tutar kolonları
     "total in currency signed", "untaxed amount signed",
     "amount total signed", "total signed",
     # German
     "betrag", "wert", "summe", "nettobetrag", "bruttobetrag", "offener betrag",
     # Italian
     "importo", "importo in divisa interna", "valore", "totale",
     "importo documento",
     # French
     "montant", "valeur", "montant total",
     "montant en devise interne", "montant en devise", "montant devise",
     "montant en euro", "montant eur", "montant ttc", "montant net",
     "montant en devise du document", "montant en monnaie interne",
     # Spanish
     "importe", "valor", "total",
     # Portuguese
     "valor", "montante", "total",
     # Dutch
     "bedrag", "waarde", "totaal",
     # Polish
     "kwota", "wartosc", "suma",
     # Romanian
     "suma", "valoare", "total")

# Bakiye / yürüyen bakiye kolonları — ayrı "balance" rolünde. Yalnızca hiç
# amount ve hiç debit/credit kolonu yoksa son çare tutar olarak kullanılır.
# NOT: "kalan/açık bakiye", "open balance", "offener saldo" gibi AÇIK bakiye
# (outstanding) kolonları gerçek bir ödenmemiş tutar olduğundan amount rolünde
# kalır. Buradaki balance rolü yalnızca DÜZ yürüyen-bakiye kolonlarıdır.
_reg("balance",
     "bakiye", "balance", "saldo", "solde", "sold", "bakiye (tl)",
     "döviz bakiye", "doviz bakiye", "yürüyen bakiye", "yuruyen bakiye",
     "cari bakiye")

# Para birimi (currency) kolonları — eşleştirmede opsiyonel güvenlik kontrolü.
_reg("currency",
     "currency", "para birimi", "para b.", "para b", "döviz", "doviz",
     "döviz cinsi", "doviz cinsi", "pb", "devise", "devise interne",
     "divisa", "moneda", "moeda", "waluta", "valuta", "währung", "wahrung",
     "belge para birimi", "belge para birimi anahtarı", "ulusal para birimi",
     # İşlem dövizi kolonu (yerli ekstreler): İD / Dvz. Cinsi / İşlem Dövizi.
     # NOT: değerler loader'da clean_currency ile doğrulanır; rakamlı/uzun bir
     # 'ID' kolonu para birimi guard'ını yanlışlıkla tetikleyemez.
     "id", "işlem dövizi", "islem dovizi", "işlem döv.", "islem dov",
     "işlem para birimi", "islem para birimi", "dvz cinsi", "dvz. cinsi",
     "döviz cins", "doviz cins", "dvz", "işlem dvz",
     # Gerçek ekstrelerde ölçülen varyantlar. Para birimi kolonu
     # tanınmadığında motorun döviz UYUŞMAZLIK KORUMASI hiç devreye
     # girmiyor: gerçek dosyalarda eşleşmelerin %60'ında firma tarafı
     # boştu ve 65 firmanın 13'ü çok dövizliydi.
     "orjinal döviz", "orijinal döviz", "orjinal doviz", "orijinal doviz",
     "döviz türü", "doviz turu", "döviz kodu", "doviz kodu",
     "currency code", "document_currency__c", "curr", "cur.", "curr.",
     "waehrung", "währung", "moneda", "moeda")

_reg("debit",
     # Turkish
     "borç", "borc", "borç tutarı", "borc tutari", "borç tutari", "borc tutarı",
     "döviz borç", "doviz borc", "borç (tl)", "borc tl", "borç tl",
     # English / German / Italian / French / Spanish
     "debit", "debit amount", "debit (dr)", "dr", "soll", "sollbetrag",
     "lastschrift", "dare", "debito", "debe", "debit eur", "obbligo",
     "débit", "debito importo",
     # İtalyan cari ekstresi (Estratto Conto): Dare Valuta/EUR (borç)
     "dare valuta", "dare eur", "dare divisa")

_reg("credit",
     # Turkish
     "alacak", "alacak tutarı", "alacak tutari", "döviz alacak", "doviz alacak",
     "alacak (tl)", "alacak tl",
     # English / German / Italian / French / Spanish
     "credit", "credit amount", "credit (cr)", "cr", "haben", "habenbetrag",
     "gutschrift", "avere", "haber", "credit eur", "crédit", "avere importo",
     # İtalyan cari ekstresi (Estratto Conto): Avere Valuta/EUR (alacak)
     "avere valuta", "avere eur", "avere divisa")

# B/A göstergesi (Borç/Alacak yön kolonu) — tek "Tutar" kolonuyla birlikte
# kullanılan yerli ekstrelerde işaret kaynağı. Değerler loader'da yorumlanır
# ('A'/'Alacak' → negatif, 'B'/'Borç' → pozitif). AYRI Borç/Alacak kolonu
# varsa bu rol YOK SAYILIR (mevcut debit-credit önceliği korunur).
_reg("ba_indicator",
     "b/a", "ba", "b / a", "borç/alacak", "borc/alacak", "borç / alacak",
     "borc / alacak", "b/a göstergesi", "b/a gostergesi", "ba göstergesi",
     "borç alacak", "borc alacak", "yön", "yon", "işaret", "isaret",
     # EN / DE
     "d/c", "dc", "debit/credit", "dr/cr", "s/h", "soll/haben")

_reg("inv_date",
     # English
     "date", "inv date", "inv. date", "invoice date", "document date", "doc date",
     "posting date", "bill date",
     # Turkish
     "tarih", "belge tarihi", "fatura tarihi", "işlem tarihi", "islem tarihi",
     "fiş tarihi", "fis tarihi", "kayıt tarihi", "kayit tarihi",
     # German
     "datum", "rechnungsdatum", "belegdatum", "buchungsdatum",
     # Italian
     "data", "data documento", "data fattura", "data registrazione",
     # French
     "date", "date facture", "date de facture", "date document",
     "date du document", "date piece", "date de piece", "date comptable",
     "date d'enregistrement",
     # Spanish
     "fecha", "fecha factura", "fecha de factura", "fecha documento",
     # Portuguese
     "data", "data da fatura", "data documento",
     # Dutch
     "datum", "factuurdatum",
     # Polish
     "data", "data faktury",
     # Romanian
     "data", "data facturii")

_reg("due_date",
     "due date", "due", "vade", "vade tarihi", "maturity", "maturity date",
     "fälligkeit", "faelligkeit", "zahlungsziel", "fälligkeitsdatum",
     "scadenza", "data scadenza", "simbolo scadenza al netto", "data pagamento",
     "echeance", "échéance", "date echeance", "date d'échéance",
     "date d échéance", "date decheance", "echeance nette", "ech nette",
     "ech.nette", "date d'echeance",
     "vencimiento", "fecha vencimiento",
     "vervaldatum", "termin platnosci", "scadenta", "data scadenta")

_reg("account",
     "account", "konto", "cari", "cari hesap", "conto", "cliente", "compte",
     "cuenta", "customer", "kunde")

_reg("name",
     "name", "customer name", "ad", "ünvan", "unvan", "firma", "lieferant",
     "nome cliente", "ragione sociale", "nom", "nombre")

_reg("comment",
     "comment", "comments", "description", "text", "note", "notes",
     "açıklama", "izahat", "bemerkung", "testo", "descrizione", "commento",
     "motivo differenza", "commentaire", "descripcion", "texte", "libelle",
     "libellé", "designation", "désignation")


# ---------------------------------------------------------------------------
# Kaynak muhasebe/ERP programlarına özgü kolon başlıkları
# ---------------------------------------------------------------------------
# Karşı taraf ekstresi LOGO, Mikro, Paraşüt, LUCA, Zirve, Uyumsoft, ETA,
# QuickBooks, Sage, Oracle, Dynamics 365, Xero, NetSuite veya Sage Intacct
# çıktısı olabilir. Her programın kendine has kolon adları vardır; hepsi
# SAP FBL1N/FBL1H alanlarına eşlenir. Aşağıdaki kayıtlar bu programların
# gerçek dışa-aktarım başlıklarını (ve dil versiyonlarını) mevcut rollere
# ekler. Ekstre_karşılaştırma dokümanındaki mapping tablolarına dayanır.
#
# NOT: Amaç, ekstre hangi programdan gelirse gelsin kolonların sessizce
# tanınabilmesi. Program tespiti yapmıyoruz; sadece sinonim havuzunu
# genişletiyoruz — deterministik, salt sözlük araması.

# --- reference (fatura/belge/evrak/fiş numarası) ----------------------------
_reg("reference",
     # LOGO / Mikro (TR): fiş+belge no ayrı sütun mantığı
     "fiş / belge no", "fiş/belge no", "evrak no / belge no", "evrak/belge no",
     "evrak seri/no", "evrak seri no", "evrak serino", "evrak seri",
     # Zirve / ETA (TR): fiş no + evrak no
     "fiş no", "evrak no",
     # QuickBooks: Num
     "num", "number",
     # Oracle Payables (EN/TR)
     "invoice number", "voucher number", "fatura no", "fiş/belge no (voucher number)",
     "fatura no (invoice number)", "voucher no", "voucher",
     # NetSuite: Document Number / Internal ID
     "document number", "internal id", "internal id (belge no)",
     # Sage / Sage Intacct: Tran No / Reference / Document No
     "tran no", "tran number", "transaction no", "document no", "doc no",
     "reference", "referans",
     # Dynamics 365: Fiş (Voucher) + Fatura (Invoice) ayrı kolon
     "fiş", "fatura", "fiş (voucher)", "fatura (invoice)", "voucher",
     "belge (document)",
     # Xero: Invoice Number + Reference
     "invoice number", "reference",
     # Paraşüt: XBLNR / SGTXT açıklama içinde birleşik → "Açıklama" ayrıca
     # comment rolünde; referans olarak "belge no"/"fatura no" da denenir.
     # LUCA: Evrak No (GIB.../e-Fatura XML ID)
     "evrak no", "evrak numarası",
     # --- dil versiyonları (source-system kolon adlarının çevirileri) ---
     # DE
     "belegnummer", "rechnungsnummer", "referenznummer", "vorgangsnummer",
     "gutschrift-nr", "gutschriftnummer",
     # IT
     "numero documento", "numero fattura", "numero voucher", "riferimento",
     "id interno", "numero transazione", "numero registrazione",
     # FR
     "numero de piece", "numéro de pièce", "numero de facture",
     "numéro de facture", "numero de document", "numéro de document",
     "reference", "référence", "numero de bon", "numéro de transaction",
     "id interne",
     # ES
     "numero de documento", "número de documento", "numero de factura",
     "número de factura", "numero de comprobante", "número de comprobante",
     "referencia", "id interno", "numero de transaccion",
     # PT
     "numero do documento", "número do documento", "numero da fatura",
     "número da fatura", "id interno", "numero da transacao",
     # NL
     "documentnummer", "factuurnummer", "referentienummer", "transactienummer",
     "intern id",
     # PL
     "numer dokumentu", "numer faktury", "numer transakcji", "identyfikator",
     # RO
     "numar document", "numar factura", "numar tranzactie", "id intern")

# --- belge_turu / işlem türü (Type, Transaction Type, Fiş Türü ...) ----------
# Bu bilgi eşleştirmede belge-türü filtresi ve iade/ödeme ayrımı için önemli.
# comment rolüne ek olarak ayrı bir "doc_type" havuzunda tutulmaz; mevcut
# "comment" rolü açıklama/tür metnini yakalar. Program-özgü tür kolonlarını
# comment'e ekliyoruz ki serbest-metin tür bilgisi kaybolmasın.
_reg("comment",
     # TR tür kolonları
     "fiş türü", "fiş tipi", "evrak tipi", "evrak cinsi", "hareket cinsi",
     "işlem türü", "islem turu", "belge türü", "kapatma durumu",
     "ödeme durumu", "durum",
     # EN
     "transaction type", "type", "tran type", "status", "state",
     "payment status", "settlement", "memo", "memo/description",
     "details", "particulars",
     # DE
     "belegart", "transaktionstyp", "typ", "zahlungsstatus", "status",
     # IT
     "tipo documento", "tipo transazione", "tipo", "stato",
     "stato pagamento", "descrizione",
     # FR
     "type de document", "type de transaction", "type", "statut",
     "statut de paiement", "libelle", "libellé",
     # ES
     "tipo de documento", "tipo de transaccion", "tipo", "estado",
     "estado de pago", "concepto",
     # PT
     "tipo de documento", "tipo de transacao", "tipo", "estado",
     "estado de pagamento",
     # NL
     "documenttype", "transactietype", "type", "status", "betaalstatus",
     "omschrijving",
     # PL
     "typ dokumentu", "typ transakcji", "typ", "status", "opis",
     # RO
     "tip document", "tip tranzactie", "tip", "stare", "descriere")

# --- inv_date (Posting Date / GL Date / Kayıt Tarihi / Vade ayrı ele alınır) -
_reg("inv_date",
     # EN — source-system varyantları
     "gl date", "gl posting date", "posting date", "transaction date",
     "date paid", "clearing date",
     # TR
     "kayıt tarihi", "muhasebe tarihi", "fiş tarihi", "işlem tarihi",
     # DE
     "gl-datum", "buchungsdatum", "transaktionsdatum",
     # IT
     "data gl", "data contabile", "data transazione",
     # FR
     "date gl", "date comptable", "date de transaction",
     # ES
     "fecha gl", "fecha contable", "fecha de transaccion",
     # PT
     "data gl", "data contabil", "data da transacao",
     # NL
     "gl-datum", "boekdatum", "transactiedatum",
     # PL
     "data ksiegowania", "data transakcji",
     # RO
     "data contabila", "data tranzactiei")

# --- amount / open balance (Total, Gross, Open Balance, Amount Remaining ...) -
_reg("amount",
     # EN — source-system varyantları
     "amount", "total amount", "gross", "open balance", "amount remaining",
     "amount due", "amount paid", "invoice amt", "invoice amount",
     "amount (tutar)", "net", "tax", "gross amount",
     # TR
     "tutar", "fatura tutarı", "kalan bakiye", "açık bakiye", "brüt tutar",
     # DE
     "betrag", "gesamtbetrag", "bruttobetrag", "offener saldo", "restbetrag",
     "faelliger betrag", "fälliger betrag",
     # IT
     "importo", "importo totale", "importo lordo", "saldo aperto",
     "importo residuo", "importo dovuto",
     # FR
     "montant", "montant total", "montant brut", "solde restant",
     "montant restant", "montant du", "montant dû", "montant paye",
     "montant payé",
     # ES
     "importe", "importe total", "importe bruto", "saldo pendiente",
     "importe restante", "importe adeudado", "importe pagado",
     # PT
     "valor", "valor total", "valor bruto", "saldo em aberto",
     "valor restante", "valor devido", "valor pago",
     # NL
     "bedrag", "totaalbedrag", "brutobedrag", "openstaand saldo",
     "resterend bedrag", "verschuldigd bedrag",
     # PL
     "kwota", "kwota calkowita", "kwota brutto", "saldo otwarte",
     "kwota pozostala", "kwota do zaplaty",
     # RO
     "suma", "suma totala", "suma bruta", "sold ramas", "suma ramasa",
     "suma datorata")

# --- due_date (Net Due Date / Vade Tarihi — source-system dilleri) -----------
_reg("due_date",
     "net due date", "due date", "vade tarihi", "vade",
     "net faelligkeitsdatum", "net fälligkeitsdatum",
     "data scadenza netta", "date d'echeance nette", "date d'échéance nette",
     "fecha de vencimiento neta", "data de vencimento liquida",
     "netto vervaldatum", "termin platnosci netto", "data scadenta neta")

# --- account / name (Vendor/Supplier/Contact/Cari — çok dilli) --------------
_reg("account",
     # source-system: satıcı kodu / cari kodu
     "vendor", "vendor id", "vendor no", "vendor number", "vendor account",
     "supplier", "supplier no", "supplier number", "supplier id",
     "contact", "cari kodu", "hesap kodu", "satıcı hesabı", "satıcı kodu",
     "satici kodu", "tedarikçi no", "tedarikci no", "iş birimi",
     "business unit", "operating unit",
     # dil versiyonları
     "lieferant", "lieferantennummer", "fornitore", "codice fornitore",
     "fournisseur", "code fournisseur", "proveedor", "codigo de proveedor",
     "fornecedor", "codigo do fornecedor", "leverancier", "dostawca",
     "furnizor")

_reg("name",
     "vendor", "supplier", "vendor name", "supplier name", "name (vendor)",
     "contact",
     "tedarikçi adı", "tedarikci adi", "satıcı adı", "satici adi",
     "cari unvanı", "cari ünvanı", "cari unvani",
     # dil versiyonları
     "lieferantenname", "nome fornitore", "nom du fournisseur",
     "nombre del proveedor", "nome do fornecedor", "leveranciersnaam",
     "nazwa dostawcy", "nume furnizor")


# Referans kolon önceliği. Bir ekstrede birden çok referans-adayı kolon
# olabilir (ör. hem "Belge No" hem "Fiş No"). Eşleştirmede önce gerçek
# fatura/belge no'yu deneriz; "fiş no / dekont / yevmiye / seri-sıra" gibi
# yerli-özgü yedek kolonlar en sona düşer. Küçük sayı = yüksek öncelik.
_REF_PRIORITY_TIERS: tuple[tuple[int, set[str]], ...] = (
    (0, {_norm(x) for x in (
        "fatura no", "fatura numarası", "fatura numarasi", "fatura no.",
        "fatura nu", "faturano", "fatura belge no", "invoice", "invoice no",
        "invoice number", "invoice #", "inv no", "inv. no", "inv", "inv#",
        "fattura", "numero fattura", "n. fattura", "n° fattura", "nr fattura",
        "num fattura", "rechnung", "rechnungsnummer", "rechnungsnr", "rechnung nr",
        "rechnungs-nr", "rg-nr", "rg nr", "facture", "numero de facture",
        "n° facture", "numéro facture", "no facture", "num facture", "factura",
        "numero de factura", "nº factura", "num factura", "fatura",
        "numero da fatura", "nº fatura", "nota fiscal", "factuur",
        "factuurnummer", "factuur nr", "faktura", "numer faktury", "nr faktury",
        "factura no", "fatura/belge no", "belge/fatura no",
        # source-system: fatura numarası kolonları (Oracle/D365/Xero/NetSuite)
        "invoice number", "fatura no (invoice number)", "numéro de facture",
        "numero da fatura", "número da fatura", "número de factura",
        "fattura (invoice)", "fatura (invoice)", "numero factura",
        "numer faktury", "numar factura",
    )}),
    (1, {_norm(x) for x in (
        "belge no", "belge numarası", "belge numarasi", "belge nu", "belgeno",
        "document number", "document no", "doc no", "docno", "numero documento",
        "n documento", "n° documento", "belegnummer", "beleg-nr", "beleg nr",
        "beleg", "dokumentnummer", "dokument-nr", "documento", "documentnummer",
        "dokument", "numer dokumentu", "numar document", "documento nr",
        "num documento", "protocollo", "evrak no", "evrak numarası",
        "evrak numarasi", "evrakno", "irsaliye no", "irsaliye numarası",
        # source-system: belge/voucher no (LUCA/Zirve/ETA/Oracle/NetSuite)
        # NOT: "tran no", "num", "internal id" gibi SİSTEM-İÇİ numaralar burada
        # DEĞİL; onlar tedarikçi fatura no'su değildir → tier 3'e (en son) düşer.
        "document no", "evrak seri/no", "evrak seri no", "evrak serino",
        "belge (document)", "numero voucher",
        "voucher number", "voucher no", "voucher",
    )}),
    (2, {_norm(x) for x in (
        "referans", "referans no", "referans kodu", "referans anahtarı",
        "referans anahtari", "reference", "ref", "ref no", "reference number",
        "reference no", "referenz", "referenznummer", "referenz-nr",
        "riferimento", "referencia", "referentie", "our ref", "your ref",
        "attribuzione", "verwendungszweck", "vorgang", "vorgangsnummer",
        # source-system: Reference kolonu (Xero/Sage — XBLNR karşılığı)
        "reference", "référence", "referenznummer", "referentienummer",
        "referencja", "referinta",
    )}),
    # tier 3 (varsayılan) — fiş no / dekont / makbuz / yevmiye / seri-sıra vb.
    #   + source-system: Internal ID, Fiş, Tran No (iç sistem anahtarları) —
    #     bunlar tedarikçinin fatura no'su DEĞİL; en son çare olarak denenir.
)


def _ref_priority(header_norm: str) -> int:
    for tier, names in _REF_PRIORITY_TIERS:
        if header_norm in names:
            return tier
    return 3  # yerli-özgü yedek referanslar (fiş no vb.) en sona


# Referans-benzeri anahtar kökleri (token çıkarımı için). Yalnızca "fatura/belge/
# evrak/fiş numarası" gibi gerçek belge-no kolonlarını yakalar; "belge tarihi"
# gibi başlıkları yakalamaz (numara eki aranır).
_REF_INFER_KEYS: tuple[str, ...] = (
    "faturano", "faturanumaras", "faturanu",
    "belgeno", "belgenumaras", "belgenu",
    "evrakno", "evraknumaras",
    "fisno", "fisnumaras",
    "irsaliyeno", "makbuzno", "dekontno", "referansno",
    # İngilizce/uluslararası karşılıklar. "number"/"no" EKİ ARANIR;
    # böylece "document date" gibi başlıklar referans sayılmaz.
    "documentnumber", "documentno", "docnumber", "docno",
    "voucherno", "vouchernumber", "receiptno", "receiptnumber",
    "numerodocumento", "numerofattura", "belegnummer", "belegnr",
)


#: "valueineur", "valueinusd", "valueintry" … (bkz. _infer_role)
_VALUE_IN_CURRENCY_RE = re.compile(r"^value(in)?[a-z]{3}$")


def _infer_role(n: str) -> str | None:
    """Birebir eşleşme bulunamayan bir başlık için rolü TOKEN/İÇEREN mantığıyla
    çıkar. Yalnızca DÜŞÜK belirsizlikli roller çıkarılır (debit/credit/amount/
    balance/reference); currency/date/account gibi belirsiz roller yalnızca
    birebir sözlükle eşlenir. Böylece 'ANA DÖVİZ BORÇ', 'ORJİNAL DÖVİZ TUTAR'
    gibi bileşik başlıklar da tanınır ama yanlış eşleşme riski minimumda tutulur.

    Sıra önemlidir: borç/alacak, 'tutar'dan önce denenir; böylece 'Borç Tutarı'
    debit olarak kalır.
    """
    if not n:
        return None
    if "borc" in n:
        return "debit"
    if "alacak" in n:
        return "credit"
    # Raporlama/yerel para birimi tutar kolonları GERÇEK işlem tutarı DEĞİLDİR
    # (ör. "RD Tutarı", "Rap. Döviz Tutarı", "UP cinsinden tutar", "local
    # currency amount"). Bunlar amount rolüne çıkarımla alınmaz; böylece
    # Borç/Alacak (ya da belge-PB tutarı) esas tutar olarak kalır. Kullanıcı
    # kararı: Borç/Alacak önceliklidir.
    _REPORTING_MARKERS = ("rdtutar", "raptutar", "rapor", "upcinsinden",
                          "ulusalpara", "yerelpara", "localcurrency",
                          "reportingamount", "rapordoviz", "rapdoviz")
    if ("tutar" in n or "meblag" in n or "amount" in n) and any(
            m in n for m in _REPORTING_MARKERS):
        return None
    # KDV / vergi kolonları GERÇEK işlem tutarı DEĞİLDİR. "VAT Amount",
    # "Tax Value", "KDV Tutarı" gibi başlıklar tutar rolüne ALINMAZ; aksi
    # hâlde satırın tutarı yerine vergisi eşleştirmeye girerdi.
    #
    # DİKKAT — YALNIZCA TUTAR ROLÜNÜ ENGELLER.
    #     Bu kontrol baştan "return None" yapamaz: PDF'lerden gelen çökmüş
    #     başlık hücreleri birden çok kolon adını birlikte taşır (ör.
    #     "Evrak No Ort. Vade İsk. Toplam KDV ..."). Böyle bir hücrede
    #     vergi kelimesi yüzünden tüm çıkarımı iptal etmek, hücrenin
    #     REFERANS rolünü de öldürüyor ve dosya okunamaz hâle geliyordu.
    _VERGI_MARKERS = ("vat", "kdv", "tax", "iva", "mwst", "tva",
                      "vergi", "stopaj", "tevkifat")
    vergi_kolonu = any(m in n for m in _VERGI_MARKERS)

    if not vergi_kolonu:
        if "tutar" in n or "meblag" in n:
            return "amount"
        # İngilizce karşılığı ("amount") yalnızca birebir sözlükte vardı;
        # bileşik başlıklarda ("Document_Currency_Amount__c", "Amount in
        # doc currency") çıkarım yapılamıyordu. Türkçe "tutar" ile aynı
        # kurala bağlanır — raporlama kolonları yukarıda zaten elendi.
        if "amount" in n or "importo" in n or "montant" in n or "importe" in n:
            return "amount"
        # "Value in EUR" / "Value in USD" gibi para-birimi ekli tutar
        # kolonları. Tek başına "value" zaten birebir sözlüktedir.
        if _VALUE_IN_CURRENCY_RE.match(n):
            return "amount"
        if "bakiye" in n:
            return "balance"
    for kw in _REF_INFER_KEYS:
        if kw in n:
            return "reference"
    # Çok dilli referans çıkarımı — bileşik/parantezli başlıklar (ör.
    # "INVOICES REFERENCE (...)", "Numero documento cliente"). "reference/
    # referans/riferimento/referencia" kökü doğrudan referanstır. "invoice/
    # fattura/factura/facture" kökü yalnızca TARİH/TUTAR içermiyorsa referanstır
    # (böylece "invoice date"/"invoice amount" yanlış referans sayılmaz —
    # bunlar zaten yukarıda ele alındı ya da tarih içerdiği için elenir).
    if any(k in n for k in ("reference", "referans", "riferimento",
                            "referencia", "referenz", "referentie")):
        return "reference"
    if any(k in n for k in ("invoice", "fattura", "factura", "facture",
                            "faktura")) and not any(
            k in n for k in ("date", "datum", "data", "fecha", "tarih",
                             "amount", "importo", "montant", "importe")):
        return "reference"
    return None


def map_firma_columns(headers: list[object]) -> dict[str, list[int]]:
    """Map a firma header row to role -> [candidate column indexes].

    İki aşamalı tanıma: (1) birebir sözlük eşleşmesi (mevcut, değişmedi);
    (2) hiçbir role birebir eşleşmeyen başlıklar için token/içeren çıkarımı
    (_infer_role). Böylece bileşik ERP başlıkları (ör. 'ANA DÖVİZ BORÇ',
    'ORJİNAL DÖVİZ TUTAR') da yakalanır. Birebir eşleşenler önceliklidir;
    çıkarımla bulunanlar ilgili listenin SONUNA (düşük öncelik) eklenir.
    """
    result: dict[str, list[int]] = {role: [] for role in _FIRMA_ROLE_SYNONYMS}
    ref_with_prio: list[tuple[int, int]] = []  # (priority, column_index)
    inferred_refs: list[int] = []
    for idx, header in enumerate(headers):
        if header is None:
            continue
        n = _norm(header)
        matched = False
        for role, synonyms in _FIRMA_ROLE_SYNONYMS.items():
            if n in synonyms:
                matched = True
                if role == "reference":
                    ref_with_prio.append((_ref_priority(n), idx))
                else:
                    result[role].append(idx)
        if not matched:
            inferred = _infer_role(n)
            if inferred == "reference":
                inferred_refs.append(idx)
            elif inferred is not None:
                result[inferred].append(idx)
    # Referansları önceliğe göre sırala (kararlı: eşit öncelikte kolon sırası korunur).
    ref_with_prio.sort(key=lambda t: (t[0], t[1]))
    result["reference"] = [idx for _, idx in ref_with_prio] + inferred_refs
    return result
