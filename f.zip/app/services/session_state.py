"""FAZ 7 — panel oturumunun kalıcı hâli.

DAVRANIŞ
    Kullanıcı uygulamayı kapatıp açtığında «en son ne yaptıysam oradan devam
    et» demelidir. Seçilen dosyalar, dönem, filtreler, sorumlu eşlemesi, son
    açık sekme ve pencere boyutu kalıcıdır.

İKİ KURAL
    1. Açılış hiçbir şeyi TEMİZLEMEZ. Temizlik yalnızca kullanıcı açıkça
       "Sıfırla" derse olur (bkz. FAZ 8).
    2. Kayıtlı bir dosya artık yoksa, o yol SESSİZCE KULLANILMAZ ve state de
       SİLİNMEZ. Kullanıcıya "Dosya bulunamadı" denir; kalan oturum durur.
       (Var olmayan bir dosyayı varmış gibi kullanmak, yanlış veriyle
       mutabakat üretmenin en sessiz yoludur.)

NE SAKLANMAZ
    Finansal kayıt, gönderim geçmişi ve snapshot burada TUTULMAZ. Onların
    kendi kalıcı depoları vardır (``mail_log``, ``send_snapshot``,
    ``incoming_cases``) ve oturum sıfırlaması onlara DOKUNMAZ.
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Iterable, Optional

from loguru import logger

from app.utils.file_lock import exclusive_file_lock
from app.utils.paths import app_data_dir

# Sıfırlanabilir bölümler — hepsi yalnızca ARAYÜZ/OTURUM durumudur.
SECTION_RECONCILIATION = "mutabakat"
SECTION_MAILING = "mutabakat_mailleri"
SECTION_INCOMING = "gelen_cevaplar"
SECTION_UI = "arayuz"

RESETTABLE_SECTIONS: tuple[str, ...] = (
    SECTION_RECONCILIATION, SECTION_MAILING, SECTION_INCOMING, SECTION_UI,
)

# Bu anahtarlar dosya yolu taşır; açılışta varlıkları kontrol edilir.
PATH_KEYS: dict[str, tuple[str, ...]] = {
    SECTION_RECONCILIATION: ("tofas_path", "firma_path"),
    SECTION_MAILING: ("report_path", "fbl1h_path", "fbl5h_path",
                      "output_dir"),
}


class SessionState:
    """JSON tabanlı, bölümlere ayrılmış kalıcı oturum durumu."""

    def __init__(self, path: str | Path | None = None) -> None:
        if path is None:
            base = app_data_dir()
            try:
                base.mkdir(parents=True, exist_ok=True)
            except OSError:  # pragma: no cover
                pass
            path = base / "session.json"
        self._path = Path(path)
        self._data: dict[str, dict[str, Any]] = self._load()
        # Bu örnekte AÇIKÇA sıfırlanan bölümler. Birleştirmeli yazma sırasında
        # diskteki eski hâllerinin geri gelmemesi için gerekir.
        self._removed: set[str] = set()

    @property
    def path(self) -> Path:
        return self._path

    # -- disk --------------------------------------------------------------

    def _load(self) -> dict[str, dict[str, Any]]:
        if not self._path.is_file():
            return {}
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            # BOZUK DOSYA SİLİNMEZ: kullanıcı isterse elle kurtarabilsin.
            logger.warning(f"[oturum] durum okunamadı ({exc}); boş başlanıyor.")
            return {}
        if not isinstance(data, dict):
            return {}
        return {str(k): dict(v) for k, v in data.items()
                if isinstance(v, dict)}

    def save(self) -> bool:
        """Durumu diske yaz. ASLA çökertmez.

        Önce geçici dosyaya yazılıp atomik olarak taşınır: kapanış sırasında
        kesilen bir yazma, mevcut oturumu bozmaz.

        YAZMA BİRLEŞTİRİLİR: aynı dosyayı kullanan başka bir örnek (ör. ayrı
        oluşturulmuş bir sayfa) kendi bölümünü yazmışsa, o bölüm KORUNUR.
        Yoksa bir sayfanın kaydı diğerinin bölümünü sessizce silerdi.
        """
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            with exclusive_file_lock(self._path.with_suffix(".lock")):
                birlesik = self._load()
                for name, values in self._data.items():
                    birlesik.setdefault(name, {}).update(values)
                # Bu örneğin sildiği bölümler (reset) birleşimde de silinir.
                for name in list(birlesik):
                    if name not in self._data and name in self._removed:
                        birlesik.pop(name, None)
                self._data = birlesik
                handle, temp_name = tempfile.mkstemp(
                    dir=str(self._path.parent), prefix=".session-", suffix=".tmp")
                with os.fdopen(handle, "w", encoding="utf-8") as stream:
                    json.dump(self._data, stream, ensure_ascii=False, indent=2,
                              default=str)
                os.replace(temp_name, self._path)
            return True
        except (OSError, TimeoutError) as exc:
            logger.warning(f"[oturum] durum yazılamadı: {exc}")
            return False

    # -- okuma / yazma -----------------------------------------------------

    def section(self, name: str) -> dict[str, Any]:
        """Bölümün KOPYASI (dışarıdan sessizce değiştirilemez)."""
        return dict(self._data.get(name, {}))

    def get(self, section: str, key: str, default: Any = None) -> Any:
        return self._data.get(section, {}).get(key, default)

    def set(self, section: str, key: str, value: Any,
            *, save: bool = True) -> None:
        self._data.setdefault(section, {})[key] = value
        if save:
            self.save()

    def update(self, section: str, values: dict[str, Any],
               *, save: bool = True) -> None:
        """Bölümü topluca güncelle (tek disk yazması)."""
        if not values:
            return
        self._data.setdefault(section, {}).update(values)
        if save:
            self.save()

    def remove(self, section: str, key: str, *, save: bool = True) -> None:
        if self._data.get(section, {}).pop(key, None) is not None and save:
            self.save()

    # -- eksik dosyalar ----------------------------------------------------

    def missing_paths(self, sections: Optional[Iterable[str]] = None
                      ) -> list[tuple[str, str, str]]:
        """Kayıtlı ama artık DİSKTE OLMAYAN yollar.

        Döner: ``[(bölüm, anahtar, yol), …]``. Bu metot hiçbir şeyi SİLMEZ;
        yalnızca kullanıcıya gösterilecek uyarıyı üretir. State korunur ki
        kullanıcı dosyayı geri koyduğunda oturum kaldığı yerden sürsün.
        """
        out: list[tuple[str, str, str]] = []
        for name in (sections if sections is not None else PATH_KEYS):
            for key in PATH_KEYS.get(name, ()):
                value = self.get(name, key, "")
                if value and not Path(str(value)).exists():
                    out.append((name, key, str(value)))
        return out

    @staticmethod
    def describe_missing(missing: Iterable[tuple[str, str, str]]) -> str:
        """Eksik dosya uyarısının kullanıcıya gösterilecek metni."""
        labels = {
            "tofas_path": "TOFAŞ ekstresi",
            "firma_path": "Firma ekstresi",
            "report_path": "Mutabakat Mailleri Excel'i",
            "fbl1h_path": "FBL1H (satıcı)",
            "fbl5h_path": "FBL5H (müşteri)",
            "output_dir": "Çıktı klasörü",
        }
        lines = [f"• {labels.get(key, key)}: {path}"
                 for _section, key, path in missing]
        if not lines:
            return ""
        return ("Önceki oturumdan hatırlanan şu dosyalar bulunamadı:\n\n"
                + "\n".join(lines)
                + "\n\nDiğer ayarlarınız korundu. Dosyaları yeniden seçebilir "
                  "ya da eski yerlerine koyabilirsiniz.")

    # -- sıfırlama (YALNIZCA kullanıcı isterse) ----------------------------

    def reset(self, sections: Optional[Iterable[str]] = None) -> list[str]:
        """Belirtilen oturum bölümlerini temizle.

        YALNIZCA arayüz/oturum durumu silinir. Gönderim geçmişi, snapshot ve
        gelen cevapların finansal kayıtları BAŞKA depolardadır ve bu metot
        onlara ERİŞMEZ — bir arayüz temizliği denetim kaydını yok edemez.
        """
        hedef = list(sections) if sections is not None else list(
            RESETTABLE_SECTIONS)
        temizlenen = []
        for name in hedef:
            if name not in RESETTABLE_SECTIONS:
                logger.warning(
                    f"[oturum] '{name}' sıfırlanabilir bir bölüm değil; "
                    "atlandı.")
                continue
            self._removed.add(name)
            if self._data.pop(name, None) is not None:
                temizlenen.append(name)
        self.save()
        self._removed.clear()
        logger.info(f"[oturum] sıfırlanan bölümler: {temizlenen or 'yok'}")
        return temizlenen

    def is_empty(self) -> bool:
        return not any(self._data.values())
