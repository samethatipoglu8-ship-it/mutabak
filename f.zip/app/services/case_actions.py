"""Vaka bazlı AÇIK AKSİYON modeli ve deterministik öneri motoru.

NEDEN GEREKLİ
    Hatırlatma uygunluğu yalnızca ``has_reply`` ile belirleniyordu. Oysa
    firma cevap vermiş olup hâlâ açık bir işimiz olabilir: ekstre
    göndereceğini söyleyip göndermemiş, ekstre okunamıyor, yanlış döneme
    ait, istenen faturalar eksik ya da fark açıklaması bekleniyor.
    "Cevap geldi" ile "iş bitti" aynı şey değildir.

TASARIM İLKELERİ
    * ÖNERİ DETERMİNİSTİKTİR. Aynı vaka durumu her zaman aynı aksiyonu
      üretir; AI hiçbir finansal karara katılmaz.
    * BELİRSİZLİKTE DIŞ MAİL HAZIRLANMAZ. Güven düşükse, eşleşme
      belirsizse ya da dil belirlenemiyorsa aksiyon ``INTERNAL_REVIEW``
      olur — firmaya yanlış talep gitmez.
    * "YALNIZ FİRMADA" ile "YALNIZ TOFAŞ'TA" AYNI ŞEY DEĞİLDİR. Biri
      bizde eksik olan faturayı, diğeri karşı tarafın işlemediği kaydı
      gösterir; aynı metinle istenmez, yanlış taraftan fatura istenmez.
    * GEÇMİŞ SİLİNMEZ. Aksiyonlar kapanır, silinmez.
"""

from __future__ import annotations

import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, Iterable

from app.services.case_comparison import (
    BODY_CEVAP_YOK,
    BODY_MUTABIK,
    STATEMENT_DIFFERENCE,
    STATEMENT_MANUAL,
    STATEMENT_MATCHED,
    STATEMENT_NOT_AVAILABLE,
    STATEMENT_UNREADABLE,
)

# ---------------------------------------------------------------------------
# Aksiyon türleri (§5)
# ---------------------------------------------------------------------------

REMIND_FOR_REPLY = "REMIND_FOR_REPLY"
REQUEST_STATEMENT = "REQUEST_STATEMENT"
REQUEST_SIMPLIFIED_STATEMENT = "REQUEST_SIMPLIFIED_STATEMENT"
REQUEST_MISSING_INVOICES = "REQUEST_MISSING_INVOICES"
REQUEST_READABLE_DOCUMENTS = "REQUEST_READABLE_DOCUMENTS"
REQUEST_CORRECT_PERIOD = "REQUEST_CORRECT_PERIOD"
REQUEST_DIFFERENCE_EXPLANATION = "REQUEST_DIFFERENCE_EXPLANATION"
REQUEST_CORRECTED_STATEMENT = "REQUEST_CORRECTED_STATEMENT"
RESOLVE_CONTRADICTION = "RESOLVE_CONTRADICTION"
FIX_DELIVERY_ADDRESS = "FIX_DELIVERY_ADDRESS"
RECOMPARE = "RECOMPARE"
INTERNAL_REVIEW = "INTERNAL_REVIEW"
CLOSE_CASE = "CLOSE_CASE"

#: Dışarıya mail GİTMEYEN aksiyonlar (iç iş).
INTERNAL_ACTIONS = frozenset({RECOMPARE, INTERNAL_REVIEW, CLOSE_CASE})

#: Kullanıcıya gösterilecek Türkçe adlar.
ACTION_LABELS: dict[str, str] = {
    REMIND_FOR_REPLY: "Cevap hatırlatması",
    REQUEST_STATEMENT: "Ekstre iste",
    REQUEST_SIMPLIFIED_STATEMENT: "Sade/okunabilir ekstre iste",
    REQUEST_MISSING_INVOICES: "Eksik faturaları iste",
    REQUEST_READABLE_DOCUMENTS: "Okunabilir belge iste",
    REQUEST_CORRECT_PERIOD: "Doğru dönem ekstresi iste",
    REQUEST_DIFFERENCE_EXPLANATION: "Fark açıklaması iste",
    REQUEST_CORRECTED_STATEMENT: "Düzeltilmiş ekstre iste",
    RESOLVE_CONTRADICTION: "Çelişkiyi çöz (mutabık ama fark var)",
    FIX_DELIVERY_ADDRESS: "Teslim adresini düzelt",
    RECOMPARE: "Yeniden karşılaştır",
    INTERNAL_REVIEW: "İç inceleme (dış mail YOK)",
    CLOSE_CASE: "Vakayı kapat",
}

# ---------------------------------------------------------------------------
# Durumlar (§8)
# ---------------------------------------------------------------------------

STATUS_OPEN = "OPEN"
STATUS_IN_PROGRESS = "IN_PROGRESS"       # gönderim SÜRÜYOR (kilit tutuluyor)
STATUS_DRAFTED = "DRAFTED"               # taslak açıldı, GÖNDERİLMEDİ
STATUS_SENT = "SENT"
STATUS_WAITING = "WAITING_RESPONSE"      # gönderildi, firmadan cevap bekleniyor
STATUS_RESOLVED = "RESOLVED"
STATUS_CANCELLED = "CANCELLED"
STATUS_SEND_UNKNOWN = "SEND_UNKNOWN"
STATUS_FAILED_PRE_SEND = "FAILED_PRE_SEND"   # Send() ÖNCESİ kesin hata

#: Hâlâ iş bekleyen durumlar.
#:
#: SENT BURADA YOKTUR AMA WAITING_RESPONSE VARDIR: bir belge talebinin
#: gönderilmiş olması işin bittiği anlamına GELMEZ — firma cevaplayana
#: kadar iş açıktır.
OPEN_STATUSES = frozenset({STATUS_OPEN, STATUS_IN_PROGRESS, STATUS_DRAFTED,
                           STATUS_WAITING, STATUS_SEND_UNKNOWN,
                           STATUS_FAILED_PRE_SEND})

#: Gönderildikten sonra CEVAP BEKLENEN aksiyonlar. Bunlar SENT olunca
#: kapanmaz; WAITING_RESPONSE'a geçer.
AWAITS_RESPONSE = frozenset({
    REMIND_FOR_REPLY, REQUEST_STATEMENT, REQUEST_SIMPLIFIED_STATEMENT,
    REQUEST_MISSING_INVOICES, REQUEST_READABLE_DOCUMENTS,
    REQUEST_CORRECT_PERIOD, REQUEST_DIFFERENCE_EXPLANATION,
    REQUEST_CORRECTED_STATEMENT, RESOLVE_CONTRADICTION,
})


def stale_in_progress(case, *, older_than_seconds: float = 3600.0) -> list:
    """Uygulama kapanınca askıda kalmış IN_PROGRESS aksiyonlar.

    Süreç çökerse ya da kapanırsa IN_PROGRESS kaydı diskte kalır ve
    kilit sonsuza kadar sürüyormuş gibi görünürdü. Bellekteki kilitler
    süreçle birlikte gittiği için gerçek bir kilit yoktur; bu kayıtlar
    açılışta OPEN'a döndürülerek kurtarılır.
    """
    from datetime import datetime, timezone

    simdi = datetime.now(timezone.utc)
    eskiler = []
    for aksiyon in actions_of(case):
        if aksiyon.status != STATUS_IN_PROGRESS:
            continue
        try:
            baslangic = datetime.fromisoformat(aksiyon.updated_at)
        except (TypeError, ValueError):
            eskiler.append(aksiyon)
            continue
        if (simdi - baslangic).total_seconds() >= older_than_seconds:
            eskiler.append(aksiyon)
    return eskiler


def recover_stale_actions(case, *, older_than_seconds: float = 3600.0) -> int:
    """Askıda kalmış IN_PROGRESS kayıtlarını SEND_UNKNOWN'a düşür.

    Süreç ``Send()`` çağrısından sonra kapanmış olabilir. OPEN'a dönmek aynı
    aksiyonun yeniden gönderilmesine izin verirdi; bu yüzden belirsizlik
    çözülene kadar mükerrer gönderim engellenir.
    """
    eskiler = stale_in_progress(case, older_than_seconds=older_than_seconds)
    for aksiyon in eskiler:
        aksiyon.status = STATUS_SEND_UNKNOWN
        aksiyon.user_note = (
            (aksiyon.user_note + " | ") if aksiyon.user_note else ""
        ) + "Uygulama gönderim sırasında kapanmış olabilir; Gönderilmiş Öğeler doğrulanmalı."
        case.pending_unknown_action = aksiyon.action_type
        case.pending_unknown_at = aksiyon.updated_at
        upsert_action(case, aksiyon)
    if eskiler:
        case.add_event(
            "ACTION_RECOVERED",
            f"{len(eskiler)} askıda kalan aksiyon SEND_UNKNOWN yapıldı "
            "(otomatik yeniden gönderim ENGELLENDİ)")
    return len(eskiler)


@dataclass
class ActionItem:
    """Bir vaka için açık iş kaydı. SİLİNMEZ, yalnızca durumu değişir."""

    action_id: str = ""
    case_id: str = ""
    action_type: str = ""
    status: str = STATUS_OPEN
    reason_codes: list[str] = field(default_factory=list)
    requested_documents: list[str] = field(default_factory=list)
    created_at: str = ""
    updated_at: str = ""
    sent_at: str = ""
    resolved_at: str = ""
    related_inbound_message_id: str = ""
    related_outbound_message_id: str = ""
    attempt_id: str = ""
    user_note: str = ""

    def __post_init__(self) -> None:
        if not self.action_id:
            self.action_id = uuid.uuid4().hex[:16]
        if not self.created_at:
            from app.services.incoming_cases import _now

            self.created_at = _now()
        if not self.updated_at:
            self.updated_at = self.created_at

    @property
    def open(self) -> bool:
        return self.status in OPEN_STATUSES

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ActionItem":
        bilinen = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in (data or {}).items() if k in bilinen})


# ---------------------------------------------------------------------------
# Vaka üzerindeki aksiyonlar
# ---------------------------------------------------------------------------

def actions_of(case: Any) -> list[ActionItem]:
    return [ActionItem.from_dict(d)
            for d in (getattr(case, "action_items", None) or [])]


def open_actions(case: Any) -> list[ActionItem]:
    return [a for a in actions_of(case) if a.open]


def save_actions(case: Any, actions: Iterable[ActionItem]) -> None:
    case.action_items = [a.to_dict() for a in actions]


def upsert_action(case: Any, action: ActionItem) -> None:
    """Aksiyonu ekle ya da güncelle. GEÇMİŞ SİLİNMEZ."""
    from app.services.incoming_cases import _now

    action.updated_at = _now()
    mevcut = actions_of(case)
    for i, a in enumerate(mevcut):
        if a.action_id == action.action_id:
            mevcut[i] = action
            break
    else:
        mevcut.append(action)
    save_actions(case, mevcut)


def has_open_action(case: Any, action_type: str = "") -> bool:
    for a in open_actions(case):
        if not action_type or a.action_type == action_type:
            return True
    return False


# ---------------------------------------------------------------------------
# Öneri motoru (§5) — DETERMİNİSTİK
# ---------------------------------------------------------------------------

@dataclass
class Suggestion:
    """Sistemin önerdiği aksiyon ve gerekçesi."""

    action_type: str = INTERNAL_REVIEW
    reason_codes: list[str] = field(default_factory=list)
    explanation: str = ""
    #: Dış mail hazırlanabilir mi? Belirsizlikte HAYIR.
    external_mail_allowed: bool = True

    @property
    def label(self) -> str:
        return ACTION_LABELS.get(self.action_type, self.action_type)


#: Bu güvenin altında otomatik dış mail HAZIRLANMAZ (§5).
MIN_CONFIDENCE_FOR_EXTERNAL = 50


def _has_only_firma_rows(case: Any) -> bool:
    """Firma ekstresinde olup BİZDE olmayan satır var mı?

    Bu satırlar BİZİM kayıtlarımızda eksik olan faturalardır: firmadan
    fatura İSTENİR.
    """
    sonuc = getattr(case, "statement_result", None) or {}
    try:
        return int(sonuc.get("only_firma") or 0) > 0
    except (TypeError, ValueError):
        return False


def _has_only_tofas_rows(case: Any) -> bool:
    """Bizde olup FİRMANIN ekstresinde olmayan satır var mı?

    Bu satırlar için firmadan fatura İSTENMEZ — fatura zaten bizdedir.
    Firmanın kaydını düzeltmesi ya da farkı açıklaması istenir.
    """
    sonuc = getattr(case, "statement_result", None) or {}
    try:
        return int(sonuc.get("only_tofas") or 0) > 0
    except (TypeError, ValueError):
        return False


def _wrong_period(case: Any) -> bool:
    """Gelen ekstre YANLIŞ döneme mi ait?"""
    sonuc = getattr(case, "statement_result", None) or {}
    if bool(sonuc.get("wrong_period")):
        return True
    gerekce = {str(r).upper() for r in (getattr(case, "reasons", None) or [])}
    return any("PERIOD" in r for r in gerekce)


def _delivery_failed(case: Any) -> bool:
    tur = str(getattr(case, "reply_type", "") or "").upper()
    if "DELIVERY" in tur or "NDR" in tur or "UNDELIVER" in tur:
        return True
    gerekce = {str(r).upper() for r in (getattr(case, "reasons", None) or [])}
    return any("DELIVERY_FAIL" in r or "NDR" in r for r in gerekce)


def _uncertain(case: Any) -> bool:
    """Güven düşük ya da eşleşme belirsiz mi?"""
    try:
        guven = int(getattr(case, "confidence_100", 0) or 0)
    except (TypeError, ValueError):
        guven = 0
    if guven and guven < MIN_CONFIDENCE_FOR_EXTERNAL:
        return True
    yontem = str(getattr(case, "match_method", "") or "").upper()
    return "AMBIG" in yontem or "BELIRSIZ" in yontem


def suggest_action(case: Any) -> Suggestion:
    """Vaka durumuna göre ÖNERİLEN aksiyon. Deterministik, AI yok."""
    body = str(getattr(case, "body_decision", "") or "")
    stmt = str(getattr(case, "statement_decision", "") or "")

    # 0) Teslim edilemedi — firmaya yeni talep göndermenin anlamı yok.
    if _delivery_failed(case):
        return Suggestion(FIX_DELIVERY_ADDRESS, ["DELIVERY_FAILED"],
                          "Mail teslim edilemedi; adres düzeltilmeli.")

    # 1) BELİRSİZLİKTE DIŞ MAİL YOK. Bu kontrol, içerik kararlarından
    #    ÖNCE gelir: güvenilmeyen bir çözümlemeye dayanarak firmadan
    #    belge istemek yanlış talep üretir.
    if _uncertain(case):
        return Suggestion(
            INTERNAL_REVIEW, ["LOW_CONFIDENCE"],
            "Güven düşük ya da eşleşme belirsiz; otomatik dış mail "
            "hazırlanmadı. Önce insan incelemesi gerekir.",
            external_mail_allowed=False)

    # 2) Hiç cevap gelmedi.
    if not getattr(case, "has_reply", False) or body == BODY_CEVAP_YOK:
        return Suggestion(REMIND_FOR_REPLY, ["NO_REPLY"],
                          "Firma henüz cevap vermedi.")

    # 3) Yanlış dönem — fark hesaplamak anlamsız, önce doğru dönem gelmeli.
    if _wrong_period(case):
        return Suggestion(REQUEST_CORRECT_PERIOD, ["WRONG_PERIOD"],
                          "Gelen ekstre mutabakat dönemine ait değil.")

    # 4) Ekstre yok / okunamıyor.
    if stmt == STATEMENT_NOT_AVAILABLE:
        return Suggestion(REQUEST_STATEMENT, ["STATEMENT_MISSING"],
                          "Cevap geldi ama ekstre eklenmemiş.")
    if stmt == STATEMENT_UNREADABLE:
        return Suggestion(
            REQUEST_SIMPLIFIED_STATEMENT, ["STATEMENT_UNREADABLE"],
            "Ekstre okunamadı (taranmış/şifreli/bozuk olabilir); sade "
            "biçimde yeniden istenmeli.")

    # 5) Fark var — YÖNÜ ÖNEMLİ.
    if stmt == STATEMENT_DIFFERENCE:
        firma_var = _has_only_firma_rows(case)
        tofas_var = _has_only_tofas_rows(case)

        # Body "mutabık" diyor ama ekstre farklı: ÇELİŞKİ.
        if body == BODY_MUTABIK:
            return Suggestion(
                RESOLVE_CONTRADICTION, ["BODY_SAYS_MATCHED", "STATEMENT_DIFF"],
                "Firma mailde mutabık olduğunu yazmış ama ekstre farkı var; "
                "çelişki firmaya sorulmalı.")

        if firma_var and not tofas_var:
            # Firmanın ekstresinde olup bizde OLMAYAN kayıtlar: fatura
            # bize ulaşmamış olabilir — FATURA İSTENİR.
            return Suggestion(
                REQUEST_MISSING_INVOICES, ["ONLY_IN_SUPPLIER"],
                "Firma ekstresinde bizde bulunmayan kayıtlar var; "
                "bu faturaların gönderilmesi istenmeli.")
        if tofas_var and not firma_var:
            # Bizde olup firmada olmayan kayıtlar: fatura BİZDE.
            # Firmadan fatura İSTENMEZ; kaydını düzeltmesi istenir.
            return Suggestion(
                REQUEST_CORRECTED_STATEMENT, ["ONLY_IN_TOFAS"],
                "Bizim kayıtlarımızda olup firma ekstresinde görünmeyen "
                "kalemler var; firmanın kaydını gözden geçirmesi istenmeli.")
        # İki yönde de fark var: açıklama istenir.
        return Suggestion(
            REQUEST_DIFFERENCE_EXPLANATION, ["DIFF_BOTH_SIDES"],
            "Her iki tarafta da eşleşmeyen kalemler var; farkın "
            "açıklanması istenmeli.")

    # 6) Elle inceleme isteyen ekstre.
    if stmt == STATEMENT_MANUAL:
        return Suggestion(INTERNAL_REVIEW, ["STATEMENT_MANUAL"],
                          "Ekstre elle inceleme gerektiriyor.",
                          external_mail_allowed=False)

    # 7) Her şey uyuşuyor.
    if stmt == STATEMENT_MATCHED and body in (BODY_MUTABIK, ""):
        return Suggestion(CLOSE_CASE, ["ALL_MATCHED"],
                          "Ekstre ve mail mutabık; vaka kapatılabilir.",
                          external_mail_allowed=False)

    return Suggestion(INTERNAL_REVIEW, ["UNCLASSIFIED"],
                      "Durum otomatik sınıflandırılamadı.",
                      external_mail_allowed=False)


# ---------------------------------------------------------------------------
# Hatırlatma uygunluğu (§3)
# ---------------------------------------------------------------------------

def needs_followup(case: Any) -> bool:
    """Bu vaka için hâlâ firmadan bir şey bekliyor muyuz?

    ``has_reply`` TEK BAŞINA yeterli değildir: cevap vermiş ama ekstre
    göndermemiş bir firma da takip edilmelidir. Kapanmış / mutabık /
    gerçekten cevap beklenmeyen vakalara hatırlatma GİTMEZ.
    """
    if str(getattr(case, "final_status", "") or "").strip().upper() in (
            "MUTABIK", "KAPANDI", "CLOSED"):
        return False
    if has_open_action(case):
        return True
    oneri = suggest_action(case)
    return oneri.action_type not in (CLOSE_CASE, INTERNAL_REVIEW,
                                     FIX_DELIVERY_ADDRESS, RECOMPARE)


def eligible_for_followup(cases: Iterable[Any]) -> list[Any]:
    """Takip maili gönderilebilecek vakalar (zinciri bilinen + açık işi olan)."""
    from app.services.reply_target import resolve_target

    out: list[Any] = []
    for case in cases or ():
        if not needs_followup(case):
            continue
        if not resolve_target(case).ready:
            continue
        out.append(case)
    return out
