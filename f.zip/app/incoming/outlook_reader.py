"""Outlook GELEN KUTUSU okuyucu — mevcut ``outlook_client.py`` kalıbıyla aynı.

Mevcut gönderim kodu (gümrük uygulamasıyla birebir aynı yapı) DEĞİŞTİRİLMEZ;
bu modül aynı COM kalıbını okuma yönünde kullanır:

    modül seviyesinde try: import pythoncom, win32com.client / except: None
    her işlemde pythoncom.CoInitialize() … try/finally … CoUninitialize()
    kurulu değilse net RuntimeError

SALT OKUNUR: mail silinmez, taşınmaz, okundu işaretlenmez, cevaplanmaz.
Ekler geçici bir klasöre çıkarılır, baytları belleğe alınır ve dosya HEMEN
silinir; kişisel veri diskte bırakılmaz.

AYRIŞTIRMA (görev şartı): Outlook erişimi AI servisinin içine KONMAZ.
    OutlookReader → IncomingMail → MailParser → AI fallback → Response
"""

from __future__ import annotations

import shutil
import tempfile
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Optional

from loguru import logger

from app.incoming.mailbox_resolver import (
    MailboxResolutionError,
    MailboxResolutionFailed,
    resolve_mailbox_folder,
)
from app.incoming.models import (
    MAX_ATTACHMENT_BYTES,
    IncomingAttachment,
    IncomingMail,
)

if TYPE_CHECKING:
    from app.incoming.tracking import MailTracker

# --- Gümrük/gönderim kodundaki modül-seviyesi import kalıbı ------------------
try:
    import pythoncom
    import win32com.client
except Exception:  # pragma: no cover - Windows dışı ortam
    pythoncom = None
    win32com = None

# Outlook sabitleri.
MAIL_ITEM_CLASS = 43          # olMail
OL_FOLDER_INBOX = 6           # olFolderInbox
# InternetMessageID MAPI etiketi (mükerrer mail tespitinin en güvenilir kaynağı).
PR_INTERNET_MESSAGE_ID = "http://schemas.microsoft.com/mapi/proptag/0x1035001F"
PR_SMTP_ADDRESS = "http://schemas.microsoft.com/mapi/proptag/0x39FE001E"
# Zincir başlıkları: cevabı GÖNDERDİĞİMİZ maile bağlamanın en güvenilir yolu.
PR_IN_REPLY_TO_ID = "http://schemas.microsoft.com/mapi/proptag/0x1042001F"
PR_INTERNET_REFERENCES = "http://schemas.microsoft.com/mapi/proptag/0x1039001F"

# Outlook rapor öğesi sınıfı: teslim edilemeyen mail bildirimleri (NDR) MailItem
# DEĞİL, ReportItem olarak gelir. Eskiden yalnızca MailItem okunduğu için bu
# bildirimler HİÇ görünmüyordu — firma "cevap vermedi" sanılıyordu.
REPORT_ITEM_CLASS = 46        # olReport

# Çok büyük ekleri belleğe almayız (mutabakat ekleri birkaç MB'ı geçmez).
# Sınır app.incoming.models içinde tanımlıdır; buradan da
# erişilebilir kalsın diye yeniden dışa aktarılır.


def _require_com() -> None:
    """Gönderim tarafındaki guard ile birebir aynı kontrol."""
    if pythoncom is None or win32com is None:
        raise RuntimeError(
            "pywin32 kurulu değil. CMD: python -m pip install pywin32"
        )


def _safe(getter: Callable[[], Any], default: Any = "") -> Any:
    """COM özelliği okunamazsa (izin/profil/bozuk öğe) varsayılana düş."""
    try:
        value = getter()
    except Exception:  # noqa: BLE001 - COM her özellikte patlayabilir
        return default
    return default if value is None else value


def _to_datetime(value: Any) -> Optional[datetime]:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    try:
        # pywintypes.datetime datetime'a çevrilebilir; olmazsa metinden dene.
        return datetime.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None


def _clean_file_name(name: str) -> str:
    """Ek adını dosya sistemi için güvenli hâle getir (yol geçişi engellenir).

    PLATFORMDAN BAĞIMSIZ
        ``Path(...).name`` işletim sistemine bağlıdır: POSIX'te ters bölü
        bir ayraç DEĞİLDİR, bu yüzden ``..\\..\\kotu.pdf`` olduğu gibi kalır
        ve karakter süzgeci onu ``....kotu.pdf``e çevirirdi — yol geçişi
        engellenmiş gibi görünürken ad bozulmuş olurdu. Bu yüzden ayraçlar
        ELLE, her iki biçim için de bölünür.

    Yalnızca noktadan oluşan ya da baştaki noktalarla gizlenen adlar da
    normalize edilir: ``..`` bir dosya adı değildir.
    """
    raw = str(name or "").replace("\\", "/")
    base = raw.rsplit("/", 1)[-1].strip()
    safe = "".join(ch for ch in base if ch not in '<>:"/\\|?*\x00')
    # Baştaki noktalar atılır; "..", "." gibi adlar geriye boş kalır.
    safe = safe.lstrip(".").strip()
    return safe or "ek"


def read_attachment(attachment_com: Any, work_dir: Path,
                    index: int = 0) -> IncomingAttachment:
    """Tek bir Outlook ekini baytlarıyla birlikte modele çevir.

    Ek diske çıkarılır, okunur ve DOSYA HEMEN SİLİNİR. Okunamayan ek sessizce
    atlanmaz: ``read_error`` ile işaretlenir, üst katman insan incelemesi
    tetikler.
    """
    name = _clean_file_name(_safe(lambda: attachment_com.FileName, "ek"))
    result = IncomingAttachment(filename=name)

    # Sıra numarası, aynı adı taşıyan iki ekin birbirini ezmesini önler
    # (Outlook aynı dosyayı iki kez ekleyebilir).
    target = work_dir / f"{index:03d}_{name}"
    try:
        attachment_com.SaveAsFile(str(target))
    except Exception as exc:  # noqa: BLE001
        result.read_error = f"ek diske çıkarılamadı: {exc}"
        return result

    try:
        size = target.stat().st_size
        if size > MAX_ATTACHMENT_BYTES:
            result.read_error = (
                f"ek çok büyük ({size} bayt); belleğe alınmadı.")
        else:
            result.content = target.read_bytes()
    except OSError as exc:
        result.read_error = f"ek okunamadı: {exc}"
    finally:
        try:
            target.unlink(missing_ok=True)
        except OSError:  # pragma: no cover
            pass
    return result


def _materialize_attachments(item: Any, mail: IncomingMail,
                             directory: Path) -> None:
    """``mail.attachments``'ı doldur. Dizin YAŞAM DÖNGÜSÜ çağırana aittir.

    Bu, hem ``to_incoming_mail(load_attachments=True)`` hem de
    ``OutlookIncomingReader.read()``'in METADATA-ÖNCE akışında (yalnızca
    İLGİLİ bulunan mailler için) kullanılan TEK gerçek uygulamadır — iki
    yerde aynı mantığın kopyalanması, ikisinin zamanla BİRBİRİNDEN
    SAPMASI riskini taşırdı.
    """
    count = int(_safe(lambda: item.Attachments.Count, 0) or 0)
    for index in range(1, count + 1):
        try:
            attachment_com = item.Attachments.Item(index)
        except Exception as exc:  # noqa: BLE001
            mail.attachments.append(IncomingAttachment(
                filename=f"ek_{index}", read_error=f"ek alınamadı: {exc}"))
            continue
        mail.attachments.append(read_attachment(attachment_com, directory, index))


def to_incoming_mail(item: Any, work_dir: Optional[Path] = None,
                     load_attachments: bool = True) -> IncomingMail:
    """Outlook MailItem'ı ``IncomingMail`` modeline çevir.

    Ördek-tipli (duck-typed) yazılmıştır: testlerde sahte bir nesne verilebilir,
    Outlook gerekmez.
    """
    mail = IncomingMail(
        subject=str(_safe(lambda: item.Subject, "")),
        body=str(_safe(lambda: item.Body, "")),
        entry_id=str(_safe(lambda: item.EntryID, "")),
        sender_name=str(_safe(lambda: item.SenderName, "")),
        received_at=_to_datetime(_safe(lambda: item.ReceivedTime, None)),
    )

    # Gövde boşsa HTML gövdeye düş (bazı firmalar yalnızca HTML gönderir).
    if not mail.body.strip():
        mail.body = str(_safe(lambda: item.HTMLBody, ""))

    mail.message_id = str(_safe(
        lambda: item.PropertyAccessor.GetProperty(PR_INTERNET_MESSAGE_ID), ""))

    # Zincir kimlikleri — okunamazsa boş kalır, eşleştirme diğer ipuçlarına düşer.
    mail.conversation_id = str(_safe(lambda: item.ConversationID, ""))
    mail.in_reply_to = str(_safe(
        lambda: item.PropertyAccessor.GetProperty(PR_IN_REPLY_TO_ID), ""))
    mail.references = str(_safe(
        lambda: item.PropertyAccessor.GetProperty(PR_INTERNET_REFERENCES), ""))
    mail.message_class = str(_safe(lambda: item.MessageClass, ""))

    sender = str(_safe(lambda: item.SenderEmailAddress, ""))
    if sender and "@" not in sender:
        # Exchange (X500) adresi: gerçek SMTP adresini almayı dene.
        smtp = _safe(
            lambda: item.Sender.GetExchangeUser().PrimarySmtpAddress, "")
        if not smtp:
            smtp = _safe(
                lambda: item.Sender.PropertyAccessor.GetProperty(
                    PR_SMTP_ADDRESS), "")
        sender = str(smtp) or sender
    mail.sender = sender

    mail.to = _split_addresses(_safe(lambda: item.To, ""))
    mail.cc = _split_addresses(_safe(lambda: item.CC, ""))
    mail.folder = str(_safe(lambda: item.Parent.Name, ""))

    if load_attachments:
        owns_dir = work_dir is None
        directory = Path(work_dir) if work_dir else Path(
            tempfile.mkdtemp(prefix="mutabakat_incoming_"))
        try:
            _materialize_attachments(item, mail, directory)
        finally:
            if owns_dir:
                shutil.rmtree(directory, ignore_errors=True)
    return mail


def _split_addresses(value: Any) -> list[str]:
    text = str(value or "")
    parts = [p.strip() for p in text.replace(",", ";").split(";")]
    return [p for p in parts if p]


class OutlookIncomingReader:
    """Gelen kutusundan mutabakat cevaplarını okur (SALT OKUNUR).

    MAĞAZA/KLASÖR ÇÖZÜMLEMESİ dinamiktir (bkz. ``mailbox_resolver.py``):
    hiçbir StoreID/FolderEntryID SAKLANMAZ; her ``read()`` çağrısında isme
    göre YENİDEN aranır. ``folder_name``/``store_identifier`` boşsa bugünkü
    davranışla BİREBİR AYNI sonuç (varsayılan mağazanın Gelen Kutusu)
    döner. Biri doluysa VE çözülemiyorsa (bulunamadı/belirsiz), SESSİZCE
    Gelen Kutusu'na DÜŞÜLMEZ — ``MailboxResolutionFailed`` fırlatılır.
    """

    def __init__(self, folder_name: str = "", store_identifier: str = "",
                 account_smtp: str = "",
                 require_account_smtp: bool = False) -> None:
        self._folder_name = folder_name
        self._store_identifier = store_identifier
        # Kontrollü hesabın SMTP adresi (örn. Settings.incoming_mailbox_smtp)
        # — doluysa ``store_identifier`` (DisplayName) yerine ``Accounts``
        # üzerinden SMTP ile eşleştirilir; bkz. mailbox_resolver.py.
        self._account_smtp = account_smtp
        # KONTROLLÜ ÜRETİM ÇAĞRI NOKTALARI İÇİN (reply_scan, incoming
        # worker/pipeline, incoming page): True iken ``account_smtp`` BOŞ
        # OLSA BİLE varsayılan Gelen Kutusu'na ASLA düşülmez — ``read()``
        # Outlook'a HİÇ bağlanmadan ``MailboxResolutionFailed``
        # (``CONFIG_MISSING``) fırlatır. Varsayılan ``False``: genel/test
        # kullanımı (boş = bugünkü varsayılan mağaza davranışı) BOZULMAZ.
        self._require_account_smtp = require_account_smtp

    def read(self, limit: int = 50, since: Optional[datetime] = None,
             unread_only: bool = False,
             load_attachments: bool = True,
             should_cancel: Optional[Callable[[], bool]] = None,
             tracker: "Optional[MailTracker]" = None,
             ) -> list[IncomingMail]:
        """Gelen kutusundaki son ``limit`` maili modele çevirerek döndür.

        ``tracker`` VERİLİRSE akış METADATA-ÖNCE çalışır: her öğe önce
        eksiz (ek YÜKLENMEDEN) ``IncomingMail``e çevrilir,
        ``tracker.match(...).should_process`` ile İLGİLİ bulunursa ANCAK O
        ZAMAN ekler diske çıkarılır/okunur. İLGİSİZ mailler için ek
        koleksiyonu HİÇ erişilmez (``Attachments.Count`` dahi okunmaz) —
        gereksiz COM çağrısı ve disk I/O'su yapılmaz. ``tracker`` VERİLMEZSE
        davranış bu değişiklikten ÖNCEKİYLE birebir aynıdır (her öğe için
        ``load_attachments`` doğrudan uygulanır).
        """
        if self._require_account_smtp and not (self._account_smtp or "").strip():
            # KONTROLLÜ MOD + yapılandırma eksik: Outlook'a HİÇ bağlanmadan
            # (Dispatch/GetNamespace/GetDefaultFolder ÇAĞRILMADAN) dur —
            # varsayılan Gelen Kutusu'na sessizce düşmenin FİZİKEN mümkün
            # olmadığının kanıtı budur (bkz. doc 21 §FIFTH PASS).
            raise MailboxResolutionFailed(MailboxResolutionError(
                "CONFIG_MISSING",
                "Kontrollü gelen kutusu modu için 'incoming_mailbox_smtp' "
                "yapılandırılmalıdır; boşken Outlook'a hiç bağlanılmaz."))
        _require_com()
        pythoncom.CoInitialize()
        work_dir = Path(tempfile.mkdtemp(prefix="mutabakat_incoming_"))
        mails: list[IncomingMail] = []
        try:
            namespace = win32com.client.Dispatch(
                "Outlook.Application").GetNamespace("MAPI")
            folder = self._resolve_folder(namespace)
            items = folder.Items
            try:
                items.Sort("[ReceivedTime]", True)
            except Exception:  # noqa: BLE001 - sıralama desteklenmeyebilir
                pass
            if since is not None:
                try:
                    items = items.Restrict(
                        f"[ReceivedTime] >= '{since.strftime('%m/%d/%Y %H:%M %p')}'")
                except Exception as exc:  # noqa: BLE001
                    logger.warning(f"Outlook tarih filtresi uygulanamadı: {exc}")
            if unread_only:
                try:
                    items = items.Restrict("[Unread] = True")
                except Exception as exc:  # noqa: BLE001
                    logger.warning(f"Outlook okunmadı filtresi uygulanamadı: {exc}")

            for index, item in enumerate(items):
                if should_cancel is not None and should_cancel():
                    break
                if len(mails) >= limit:
                    break
                # Teslim hatası bildirimleri (ReportItem) de okunur: "mail
                # gitmedi" bilgisi, "cevap gelmedi" bilgisinden farklıdır ve
                # kullanıcıdan gizlenemez.
                item_class = int(_safe(lambda: item.Class, 0) or 0)
                if item_class not in (MAIL_ITEM_CLASS, REPORT_ITEM_CLASS):
                    continue
                try:
                    mail = to_incoming_mail(item, work_dir, load_attachments=False)
                    proceed = load_attachments
                    if tracker is not None:
                        proceed = load_attachments and tracker.match(mail).should_process
                    if proceed:
                        _materialize_attachments(item, mail, work_dir)
                    mails.append(mail)
                except Exception as exc:  # noqa: BLE001 - tek mail hepsini düşürmesin
                    logger.warning(
                        f"Gelen mail okunamadı (sıra {index}): {exc}")
        finally:
            shutil.rmtree(work_dir, ignore_errors=True)
            pythoncom.CoUninitialize()
        return mails

    def _resolve_folder(self, namespace: Any) -> Any:
        """Yapılandırılmış mağaza/klasörü DİNAMİK olarak çöz.

        Çözülemezse (bulunamadı/belirsiz) ``MailboxResolutionFailed``
        fırlatılır — Gelen Kutusu'na SESSİZCE DÜŞÜLMEZ (onaylanmış karar).
        """
        resolution = resolve_mailbox_folder(
            namespace, store_identifier=self._store_identifier,
            folder_path=self._folder_name,
            account_smtp=self._account_smtp,
            require_account_smtp=self._require_account_smtp)
        if resolution.error is not None:
            raise MailboxResolutionFailed(resolution.error)
        return resolution.folder
