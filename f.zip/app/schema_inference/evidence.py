"""FAZ 6 — ERP araştırma kanıtı provenance modeli.

Bu modülün ``FieldEvidence``'ı, ``app.canonical.evidence.FieldEvidence`` İLE
AYNI ŞEY DEĞİLDİR:

- ``app.canonical.evidence.FieldEvidence`` — ÜRETİMDE, GERÇEK bir kaydın bir
  alanının HANGİ dosyadan/satırdan/yöntemle çıkarıldığını anlatır.
- ``app.schema_inference.evidence.FieldEvidence`` (bu dosya) — DORMANT, bir
  ARAŞTIRMA İDDİASININ ("ERP X'in Y alanı muhtemelen Z rolünü taşır") HANGİ
  TÜR kaynağa dayandığını anlatır. Hiçbir üretim kaydı bu sınıfı taşımaz.

KRİTİK KURAL (kullanıcı talimatı, birebir):
    OFFICIAL_API_SCHEMA   != EXCEL_EXPORT_SCHEMA
    OFFICIAL_DB_SCHEMA     != EXCEL_EXPORT_SCHEMA
    IMPORT_TEMPLATE        != EXPORT_SCHEMA
    SCREEN_FIELD           != FILE_COLUMN

Bu ayrım ``is_export_schema_evidence()`` ile KOD SEVİYESİNDE zorlanır:
export-şema kanıtı olmayan bir ``EvidenceType`` ile ``safe_for_auto_mapping=
True`` birlikte var olamaz (model construction'da ``ValueError``).
"""

from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, model_validator


class EvidenceType(str, Enum):
    """Bir ERP-alan iddiasının kanıt türü (kullanıcı talimatındaki minimum
    liste, birebir)."""

    OFFICIAL_EXPORT_SAMPLE = "official_export_sample"
    OFFICIAL_PRODUCT_DOC = "official_product_doc"
    OFFICIAL_API_SCHEMA = "official_api_schema"
    OFFICIAL_DB_SCHEMA = "official_db_schema"
    OFFICIAL_IMPORT_TEMPLATE = "official_import_template"
    VENDOR_BLOG = "vendor_blog"
    TRAINING_DOC = "training_doc"
    PARTNER_DOC = "partner_doc"
    COMMUNITY = "community"
    REAL_USER_SAMPLE = "real_user_sample"
    LLM_RESEARCH_ONLY = "llm_research_only"
    UNKNOWN = "unknown"


#: Yalnızca bu iki tür, GERÇEK bir Excel/CSV EXPORT dosyasının kolon
#: şemasını kanıtlar (dosya gerçekten görülmüş/üretilmiş). Diğer HER ŞEY —
#: API, DB, import template, doküman, blog, community, salt LLM araştırması —
#: export kolon şemasının KANITI DEĞİLDİR (kullanıcı talimatı, "CRITICAL
#: RULE").
EXPORT_SCHEMA_EVIDENCE: frozenset[EvidenceType] = frozenset({
    EvidenceType.OFFICIAL_EXPORT_SAMPLE,
    EvidenceType.REAL_USER_SAMPLE,
})

NOT_EXPORT_SCHEMA_EVIDENCE: frozenset[EvidenceType] = frozenset(
    set(EvidenceType) - EXPORT_SCHEMA_EVIDENCE
)


class FieldEvidence(BaseModel):
    """Bir ERP araştırma iddiasının kanıt kaydı (bkz. modül docstring'i)."""

    source_system: str                        # ör. "Mikro", "Logo", "DIA"
    product: Optional[str] = None              # ör. "Mikro Jump"
    version: Optional[str] = None
    field_name: str                            # kaynaktaki ham alan adı
    proposed_role: Optional[str] = None         # SemanticRole.value (gevşek bağ, döngüsel import yok)
    evidence_type: EvidenceType
    source_reference: str                      # kısa atıf etiketi (ör. "Mikro API docs v2026")
    confidence: float = Field(ge=0.0, le=1.0)
    observed_in_real_file: bool = False
    safe_for_auto_mapping: bool = False
    notes: Optional[str] = None

    def is_export_schema_evidence(self) -> bool:
        """Bu kanıt GERÇEKTEN bir export dosyasının kolon şemasını mı
        kanıtlıyor (True), yoksa API/DB/import-template/doküman/araştırma
        mı (False)?"""
        return self.evidence_type in EXPORT_SCHEMA_EVIDENCE

    @model_validator(mode="after")
    def _enforce_export_schema_rule(self) -> "FieldEvidence":
        """Kullanıcının "CRITICAL RULE"ü kod seviyesinde zorlanır: export
        şema kanıtı OLMAYAN bir tür ``safe_for_auto_mapping=True`` ile asla
        bir arada var olamaz. Bu, hiçbir üretim davranışını DEĞİŞTİRMEZ —
        bu sınıf dormant'tır; yalnızca YANLIŞ bir araştırma kaydının
        (ör. "API şeması, otomatik-mapping-güvenli" gibi çelişkili bir
        iddianın) bu modelde HİÇ TEMSİL EDİLEMEMESİNİ garanti eder.
        """
        if self.safe_for_auto_mapping and not self.is_export_schema_evidence():
            raise ValueError(
                f"{self.evidence_type.value} kanıt türü export şema kanıtı "
                "DEĞİLDİR; safe_for_auto_mapping=True olamaz "
                f"(source={self.source_system!r}, field={self.field_name!r})."
            )
        if self.safe_for_auto_mapping and not self.observed_in_real_file:
            raise ValueError(
                "safe_for_auto_mapping=True, gerçek bir dosyada GÖZLENMEDEN "
                f"(observed_in_real_file=False) ayarlanamaz "
                f"(source={self.source_system!r}, field={self.field_name!r})."
            )
        return self
