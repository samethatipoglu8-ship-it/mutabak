"""Gelen cevap ve gönderim kayıtlarının TAM sıfırlaması.

Kullanıcı "Sıfırla" ekranında bu seçeneği AÇIKÇA işaretlerse çalışır.
Kural: ÖNCE şifreli yedek alınır; yedek alınamazsa HİÇBİR ŞEY silinmez.

Silinen kayıtlar (Gelen Cevaplar tablosunu ve takibi besleyenler):
    incoming_cases.db       gelen cevap iş kayıtları
    mail_log.db             gönderim günlüğü (takip edilen mailler)
    snapshots/              gönderim anı verileri (tabloyu yeniden doldurur)
    incoming_mail.db        "bu mail işlendi" önbelleği
    send_queue.db           yarım kalan gönderim kuyruğu
    incoming_attachments/   gelen eklerin kopyaları

Korunanlar: ayarlar, adres defteri, denetim günlükleri, loglar, yedekler.

Dosyalar silinmez, TABLOLARI boşaltılır: Windows'ta açık bir SQLite
dosyasını silmek "dosya kullanımda" hatası verir; satır silmek vermez.
"""

from __future__ import annotations

import shutil
import sqlite3
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from loguru import logger

from app.utils.paths import app_data_dir
from app.utils.sqlite import open_sqlite_connection

RECORD_DATABASES: tuple[str, ...] = (
    "incoming_cases.db",
    "mail_log.db",
    "snapshots/snapshots.db",
    "incoming_mail.db",
    "send_queue.db",
)
RECORD_FOLDERS: tuple[str, ...] = (
    "snapshots/_blobs",
    "incoming_attachments",
)


@dataclass
class RecordResetResult:
    ok: bool = False
    backup_path: str = ""
    cleared: list[str] = field(default_factory=list)
    error: str = ""


def _default_base() -> Path:
    return app_data_dir()


def _copy_database(source: Path, target: Path) -> None:
    """SQLite'ı TUTARLI kopyala (WAL modundaki son yazılar dahil).

    Kaynak ortak bağlantı politikasıyla açılır (30 sn meşgul penceresi:
    uygulama o anda yazıyorsa yedek hemen "database is locked" ile düşmez),
    ancak ``enable_wal=False`` ile: bu yalnız OKUMA yapan bir yoldur, kaynak
    dosyanın journal kipini DEĞİŞTİRMEMELİDİR. Hedef ise sıfırdan oluşan bir
    yedek artefaktıdır; ``backup()`` içine yazar, pragma uygulanmaz.
    """
    src = open_sqlite_connection(source, enable_wal=False)
    try:
        dst = sqlite3.connect(str(target))
        try:
            src.backup(dst)
        finally:
            dst.close()
    finally:
        src.close()


def _checkpoint(path: Path) -> None:
    """WAL dosyasındaki bekleyen yazıları ana dosyaya aktar.

    ``enable_wal=False``: checkpoint sırasında journal kipine dokunulmaz,
    yalnız ortak meşgul penceresi kazanılır.
    """
    try:
        conn = open_sqlite_connection(path, enable_wal=False)
        try:
            conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        finally:
            conn.close()
    except sqlite3.Error as exc:
        logger.warning(f"[sıfırla] {path.name} checkpoint yapılamadı: {exc}")


def _stage_backup(base: Path, staging: Path) -> list[str]:
    """Yedeklenecekleri DÜZ adlarla geçici klasöre hazırla.

    ``restore_backup`` güvenlik gereği alt klasörlü yolları reddeder; bu
    yüzden her veritabanı düz bir ada kopyalanır, klasörler ise tek bir
    ``.zip`` dosyası olarak eklenir. Döner: yedeğe girecek dosya adları.
    """
    adlar: list[str] = []
    for ad in RECORD_DATABASES:
        kaynak = base / ad
        if kaynak.is_file():
            duz = ad.replace("/", "__")
            _copy_database(kaynak, staging / duz)
            adlar.append(duz)
    for ad in RECORD_FOLDERS:
        kaynak = base / ad
        if kaynak.is_dir() and any(kaynak.iterdir()):
            for db in kaynak.rglob("*.db"):
                _checkpoint(db)
            duz = ad.replace("/", "__")
            shutil.make_archive(str(staging / duz), "zip", root_dir=kaynak)
            adlar.append(f"{duz}.zip")
    return adlar


def _clear_database(path: Path) -> None:
    """Veritabanındaki tüm tabloların satırlarını sil (şema kalır).

    Ortak bağlantı politikası KULLANILIR: silme yıkıcı bir işlemdir ve
    arka plan işçisi aynı deponun bir tablosuna yazıyor olabilir. 30 sn
    meşgul penceresi olmadan sıfırlama yarıda "database is locked" ile
    düşebilirdi. Tüm tablolar tek ``with conn`` işleminde boşaltıldığı için
    kilit beklemesi dışında yarım bir sıfırlama oluşmaz.
    """
    conn = open_sqlite_connection(path)
    try:
        tablolar = [row[0] for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%'")]
        with conn:
            for tablo in tablolar:
                conn.execute(f'DELETE FROM "{tablo}"')
    finally:
        conn.close()


def _clear_folder(path: Path) -> None:
    """Klasörün İÇİNİ boşalt (klasörün kendisi kalır)."""
    for item in path.iterdir():
        if item.is_dir():
            shutil.rmtree(item)
        else:
            item.unlink()


def reset_records(password: str, base_dir: Optional[str | Path] = None
                  ) -> RecordResetResult:
    """Önce yedekle, sonra gelen cevap/gönderim kayıtlarını sil.

    Yedek alınamazsa ``ok=False`` döner ve hiçbir şeye dokunulmaz.
    """
    from app.services.backup import create_backup

    base = Path(base_dir) if base_dir else _default_base()
    sonuc = RecordResetResult()
    if not password:
        sonuc.error = "Yedek parolası girilmedi; kayıtlar silinmedi."
        return sonuc

    try:
        with tempfile.TemporaryDirectory(prefix="mutabakat_sifirla_") as tmp:
            hedefler = _stage_backup(base, Path(tmp))
            if hedefler:
                yedek = create_backup(password, source_dir=tmp,
                                      target_dir=base / "backups",
                                      targets=hedefler, keep=10)
                if not yedek.ok:
                    sonuc.error = ("Yedek alınamadı, kayıtlar SİLİNMEDİ: "
                                   f"{yedek.error}")
                    return sonuc
                sonuc.backup_path = yedek.path
    except (OSError, sqlite3.Error) as exc:
        sonuc.error = f"Yedek hazırlanamadı, kayıtlar SİLİNMEDİ: {exc}"
        return sonuc

    hatalar: list[str] = []
    for ad in RECORD_DATABASES:
        yol = base / ad
        if not yol.is_file():
            continue
        try:
            _clear_database(yol)
            sonuc.cleared.append(ad)
        except (sqlite3.Error, OSError) as exc:
            hatalar.append(f"{ad}: {exc}")
    for ad in RECORD_FOLDERS:
        yol = base / ad
        if not yol.is_dir():
            continue
        try:
            _clear_folder(yol)
            sonuc.cleared.append(ad)
        except OSError as exc:
            hatalar.append(f"{ad}: {exc}")

    if hatalar:
        sonuc.error = "Bazı kayıtlar silinemedi: " + "; ".join(hatalar)
        logger.error(f"[sıfırla] {sonuc.error}")
    sonuc.ok = not hatalar
    logger.info(f"[sıfırla] kayıtlar silindi: {sonuc.cleared} "
                f"(yedek: {sonuc.backup_path or 'silinecek kayıt yoktu'})")
    return sonuc
