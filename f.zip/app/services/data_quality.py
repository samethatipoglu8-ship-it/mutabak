"""Girdi veri kalitesi raporu (deterministik, AI'sız).

Yükleyicinin kolonları BULMASI tek başına yeterli değildir: doğru kolon
bulunmuş ama içi boş/bozuk olabilir. O zaman motor sessizce "hiçbir şey
eşleşmedi" der ve kullanıcı bunu bir mutabakat sonucu sanır.

Bu modül, yüklenmiş kayıtlar üzerinden bir kalite raporu üretir ve bulguları
dört seviyeye ayırır:

    INFO      bilgi — aksiyon gerekmez
    WARNING   şüpheli — sonuç yine de üretilir, kullanıcı görmeli
    ERROR     ciddi — sonuç muhtemelen yanıltıcı
    BLOCKING  mutabakat anlamsız (ör. sıfır satır)

Eşikler ORANSALdır ve sınıf üzerinde açıkça tanımlıdır; iş kuralı olarak
kabul edilmiş sabitler değil, yapılandırılabilir varsayılanlardır.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Iterable, Optional


class QualityLevel(str, Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    BLOCKING = "BLOCKING"


_ORDER = {
    QualityLevel.INFO: 0,
    QualityLevel.WARNING: 1,
    QualityLevel.ERROR: 2,
    QualityLevel.BLOCKING: 3,
}


@dataclass(frozen=True)
class QualityFinding:
    level: QualityLevel
    code: str
    message: str

    def __str__(self) -> str:  # pragma: no cover - gösterim
        return f"[{self.level.value}] {self.message}"


@dataclass
class DataQualityReport:
    """Bir girdi dosyasının kalite raporu."""

    side: str                       # "TOFAŞ" | "Firma"
    rows: int = 0
    reference_populated: int = 0
    amount_populated: int = 0       # sıfırdan farklı tutar
    date_populated: int = 0
    currency_populated: int = 0
    duplicate_rows: int = 0
    findings: list[QualityFinding] = field(default_factory=list)

    @property
    def parse_quality(self) -> int:
        """Dosya ne kadar GÜVENİLİR okundu? 0–100 (deterministik).

        NEDEN GEREKLİ
            "Dosya yüklendi" ile "dosya DOĞRU yüklendi" aynı şey değildir.
            Gerçek bir dosyada 296 satırın 292'sinde tutar 0 çıktı ve motor
            30 sahte fark üretti; kullanıcı raporun ne kadar güvenilir
            olduğunu tek bakışta göremiyordu.

        FORMÜL — salt ölçüm, tahmin yok
            Eşleştirmenin dayandığı iki alan (referans, tutar) ağır basar;
            tarih ve para birimi eşleştirmeyi güçlendirir ama zorunlu
            değildir. Mükerrer satırlar ayrıca düşürür.

            Puan yalnızca BİLGİLENDİRİR: hiçbir satırı elemez, hiçbir
            tutarı değiştirmez, mutabakatı durdurmaz.
        """
        if self.rows <= 0:
            return 0
        n = self.rows
        # Referans ve tutar TOPLANABİLİR DEĞİL: eşleştirme ikisini birden
        # gerektirir. Biri eksikse dosya okunamamıştır — bu yüzden zayıf
        # olanı belirleyicidir (min). Toplama kullanıldığında %97'si tutarsız
        # bir dosya "orta" puan alıyordu; oysa o dosyada eşleştirilecek
        # hiçbir şey yoktur.
        zorunlu = min(self.reference_populated / n, self.amount_populated / n)
        puan = (
            80 * zorunlu
            + 12 * (self.date_populated / n)
            + 8 * (self.currency_populated / n)
        )
        # Mükerrer satırlar okuma hatasının klasik işaretidir
        # (aynı blok iki kez alınmış olabilir).
        puan -= 10 * min(1.0, self.duplicate_rows / n)
        return max(0, min(100, round(puan)))

    @property
    def parse_quality_label(self) -> str:
        """Puanın sözle karşılığı."""
        p = self.parse_quality
        if p >= 85:
            return "iyi"
        if p >= 60:
            return "orta"
        if p >= 35:
            return "zayıf"
        return "çok zayıf"

    @property
    def max_level(self) -> QualityLevel:
        if not self.findings:
            return QualityLevel.INFO
        return max((f.level for f in self.findings), key=lambda lv: _ORDER[lv])

    @property
    def blocking(self) -> bool:
        return any(f.level is QualityLevel.BLOCKING for f in self.findings)

    def messages(self, min_level: QualityLevel = QualityLevel.WARNING) -> list[str]:
        return [str(f) for f in self.findings if _ORDER[f.level] >= _ORDER[min_level]]

    def summary_line(self) -> str:
        return (
            f"{self.side}: okuma kalitesi {self.parse_quality}/100 "
            f"({self.parse_quality_label}) | "
            f"{self.rows} satır | referans {self.reference_populated}"
            f" | tutar {self.amount_populated} | tarih {self.date_populated}"
            f" | döviz {self.currency_populated} | mükerrer {self.duplicate_rows}"
        )


class DataQualityAnalyzer:
    """Yüklenmiş kayıtlardan kalite raporu üretir.

    Eşikler ORAN (0-1) cinsindendir; ilgili alanın DOLU olma oranı bu değerin
    altına düşerse bulgu üretilir.
    """

    min_reference_ratio: float = 0.60
    min_amount_ratio: float = 0.80
    min_date_ratio: float = 0.30
    max_duplicate_ratio: float = 0.20

    def analyze(self, records: Iterable, side: str) -> DataQualityReport:
        recs = list(records)
        rep = DataQualityReport(side=side, rows=len(recs))

        if not recs:
            rep.findings.append(QualityFinding(
                QualityLevel.BLOCKING, "NO_ROWS",
                f"{side} dosyasından hiç kayıt okunamadı. Dosya boş olabilir ya "
                "da kolon başlıkları tanınmamış olabilir.",
            ))
            return rep

        dup_counter: Counter = Counter()
        for r in recs:
            if self._reference_of(r):
                rep.reference_populated += 1
            if r.amount is not None and r.amount != Decimal("0"):
                rep.amount_populated += 1
            if self._date_of(r) is not None:
                rep.date_populated += 1
            if r.currency:
                rep.currency_populated += 1
            # Tutar DEĞER olarak anahtarlanır. str() ile "100.00" ve
            # "100.0" farklı anahtar üretiyor ve GERÇEK mükerrerler
            # yakalanmadan geçiyordu. Decimal değere göre hash'lenir,
            # quantize gerekmez (kuruş altı ayrım da korunur).
            dup_counter[(self._reference_of(r), r.amount,
                         self._date_of(r))] += 1

        rep.duplicate_rows = sum(c - 1 for c in dup_counter.values() if c > 1)

        n = len(recs)
        self._check_ratio(
            rep, rep.reference_populated / n, self.min_reference_ratio,
            "LOW_REFERENCE",
            f"{side}: satırların yalnızca %{100 * rep.reference_populated / n:.0f}"
            f"'ünde referans/fatura no var ({n - rep.reference_populated} boş)."
            " Eşleştirme büyük ölçüde referansa dayanır; yanlış kolon seçilmiş"
            " olabilir.",
            error_below=0.20,
        )
        self._check_ratio(
            rep, rep.amount_populated / n, self.min_amount_ratio,
            "LOW_AMOUNT",
            f"{side}: satırların %{100 * (n - rep.amount_populated) / n:.0f}"
            f"'ünde tutar sıfır ya da okunamadı ({n - rep.amount_populated} satır).",
            error_below=0.50,
            # TUTARLARIN NEREDEYSE TAMAMI OKUNAMADIYSA MUTABAKAT ANLAMSIZDIR.
            #
            # normalize_amount okunamayan hücrede Decimal("0") döndürür;
            # "gerçekten sıfır" ile "okunamadı" ayırt edilemez. Gerçek bir
            # dosyada ölçüldü: 296 satırın 292'sinde tutar 0 çıktı ve motor
            # 30 SAHTE "tutar farkı" üretti. Böyle bir dosyada eşleştirecek
            # bir tutar yoktur; sessiz yanlış rapor yerine açık durdurma
            # doğrudur (BLOCKING tanımı: "mutabakat anlamsız").
            blocking_below=0.05,
        )
        self._check_ratio(
            rep, rep.date_populated / n, self.min_date_ratio,
            "LOW_DATE",
            f"{side}: satırların yalnızca %{100 * rep.date_populated / n:.0f}"
            "'ünde geçerli tarih var. Tarih toleranslı katmanlar bu dosyada"
            " çalışmayacaktır.",
            error_below=0.0,          # tarih zorunlu değil → ERROR'a yükseltme
        )

        if rep.duplicate_rows / n > self.max_duplicate_ratio:
            rep.findings.append(QualityFinding(
                QualityLevel.WARNING, "DUPLICATES",
                f"{side}: {rep.duplicate_rows} satır (referans + tutar + tarih)"
                " bakımından bir başkasının birebir kopyası. Dosya iki kez"
                " yapıştırılmış olabilir; mükerrer kayıtlar eşleşmeyi bozar.",
            ))

        # Fatura DIŞI hareketler (kur farkı / iade / avans / virman).
        # Bunlar eşleştirmeden ÇIKARILMAZ — yalnızca görünür kılınır ki
        # kullanıcı "bu satırlar neden fark olarak çıktı?" sorusunun
        # cevabını görebilsin. Gerçek FBL1H'de 726 satır bu sınıflara girdi.
        try:
            from app.services.row_classifier import (
                classify_records,
                describe_classes,
            )

            aciklama = describe_classes(classify_records(recs))
            if aciklama:
                rep.findings.append(QualityFinding(
                    QualityLevel.INFO, "NON_INVOICE_ROWS", f"{side}: {aciklama}"))
        except Exception:  # noqa: BLE001 - sınıflandırma asla çökertmemeli
            pass

        if rep.currency_populated == 0:
            rep.findings.append(QualityFinding(
                QualityLevel.INFO, "NO_CURRENCY",
                f"{side}: para birimi kolonu yok. Para birimi kontrolü"
                " yapılamayacak; eşleşmeler 'para birimi bilinmiyor' olarak"
                " işaretlenecek.",
            ))
        elif rep.currency_populated < n:
            rep.findings.append(QualityFinding(
                QualityLevel.WARNING, "PARTIAL_CURRENCY",
                f"{side}: {n - rep.currency_populated} satırda para birimi boş."
                " Bu satırlar farklı dövizdeki bir kayıtla eşleşebilir.",
            ))

        return rep

    # -- yardımcılar --------------------------------------------------------

    @staticmethod
    def _reference_of(rec) -> Optional[str]:
        if getattr(rec, "reference", None):
            return rec.reference
        refs = getattr(rec, "all_references", None) or []
        return refs[0] if refs else None

    @staticmethod
    def _date_of(rec):
        return getattr(rec, "belge_tarihi", None) or getattr(rec, "inv_date", None)

    @staticmethod
    def _check_ratio(rep, ratio, threshold, code, message, *, error_below,
                     blocking_below: float | None = None):
        if ratio >= threshold:
            return
        if blocking_below is not None and ratio < blocking_below:
            level = QualityLevel.BLOCKING
        elif ratio < error_below:
            level = QualityLevel.ERROR
        else:
            level = QualityLevel.WARNING
        rep.findings.append(QualityFinding(level, code, message))
