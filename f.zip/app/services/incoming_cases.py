"""FAZ 6 — gelen cevapların KALICI iş kaydı (business case).

NEDEN GEREKLİ
    Tarama sonuçları şimdiye kadar yalnızca ``IncomingPage._results`` içinde,
    yani RAM'de yaşıyordu. Uygulama kapandığında "hangi firma ne cevap verdi,
    hangi karara vardık" bilgisi kayboluyordu. ``ProcessedMailStore`` bu
    boşluğu doldurmaz: o yalnızca «bu mail işlendi mi?» sorusunu cevaplar
    (idempotency), «bu mutabakatın sonucu nedir?» sorusunu değil.

    Bu depo iş sonucunu kalıcı kılar: dönem raporu, sorumlu bazlı oran ve
    "geçen ay ne olmuştu?" sorusu buradan cevaplanır.

İDEMPOTENCY
    Aynı mail tekrar tarandığında YENİ CASE ÜRETİLMEZ. Anahtar
    gönderimde üretilmiş ``send_id + yön`` case kimliğidir. Aynı gönderime
    gelen takip mailleri yeni satır açmak yerine bu case'in mail zaman
    çizelgesine eklenir; ilk gönderim ve cevap zinciri bölünmez.

SİLİNMEZLİK
    Bu kayıtlar finansal iştir. Sıradan "UI Sıfırla" bunlara DOKUNMAZ
    (bkz. FAZ 8); silme yalnızca ayrı ve açıkça tehlikeli bir işlemdir.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional, Sequence

from loguru import logger

from app.utils.paths import app_data_dir
from app.utils.sqlite import open_sqlite_connection


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def _current_user() -> str:
    """Audit için oturum kullanıcısı (bulunamazsa boş)."""
    import getpass

    try:
        return getpass.getuser()
    except Exception:  # noqa: BLE001 - kullanıcı adı okunamazsa audit durmaz
        return ""


def make_case_id(fingerprint: str, send_id: str = "") -> str:
    """Aynı mail + aynı gönderim için DAİMA aynı kimlik.

    Böylece tarama tekrarlandığında kayıt çoğalmaz, güncellenir.
    """
    raw = f"{fingerprint}|{send_id}".encode("utf-8", "replace")
    return "CASE-" + hashlib.sha256(raw).hexdigest()[:20]


# Kalıcı alanların TEK tanımı: (alan, SQL tipi, tür).
# Şema, SELECT listesi, satır çözümü ve INSERT bu listeden türer; yeni bir
# alan eklemek için tek satır yeter ve eski veritabanları göç ile güncellenir.
_FIELDS: tuple[tuple[str, str, str], ...] = (
    ("case_id", "TEXT PRIMARY KEY", "text"),
    ("fingerprint", "TEXT NOT NULL", "text"),
    ("send_id", "TEXT", "text"),
    ("snapshot_id", "TEXT", "text"),
    ("company_code", "TEXT", "text"),
    ("company_name", "TEXT", "text"),
    ("period", "TEXT", "text"),
    ("responsible", "TEXT", "text"),
    ("sender", "TEXT", "text"),
    ("subject", "TEXT", "text"),
    ("received_at", "TEXT", "text"),
    ("message_id", "TEXT", "text"),
    ("conversation_id", "TEXT", "text"),
    ("match_method", "TEXT", "text"),
    ("match_confidence", "REAL", "real"),
    ("reply_type", "TEXT", "text"),
    ("currencies", "TEXT", "json_dict"),
    ("body_result", "TEXT", "json_dict"),
    ("statement_result", "TEXT", "json_dict"),
    ("snapshot_result", "TEXT", "json_dict"),
    ("outcome", "TEXT", "text"),
    ("final_status", "TEXT", "text"),
    ("reasons", "TEXT", "json_list"),
    ("confidence", "REAL", "real"),
    ("ai_status", "TEXT", "text"),
    ("needs_human_review", "INTEGER", "bool"),
    # -- FAZ 11 -----------------------------------------------------------
    ("balance_type", "TEXT", "text"),
    ("data_source_type", "TEXT", "text"),
    ("has_reply", "INTEGER", "bool"),
    ("sent_date", "TEXT", "text"),
    ("last_reply_date", "TEXT", "text"),
    ("latest_reply_sender", "TEXT", "text"),
    ("latest_reply_subject", "TEXT", "text"),
    ("latest_reply_snippet", "TEXT", "text"),
    ("recipients", "TEXT", "text"),
    ("cc", "TEXT", "text"),
    ("original_attachments", "TEXT", "json_list"),
    ("incoming_attachments", "TEXT", "json_list"),
    ("fbl1h_sha256", "TEXT", "text"),
    ("fbl5h_sha256", "TEXT", "text"),
    ("body_decision", "TEXT", "text"),
    ("statement_decision", "TEXT", "text"),
    ("financial_difference", "TEXT", "text"),
    ("difference_currency", "TEXT", "text"),
    ("confidence_100", "INTEGER", "int"),
    ("confidence_explanation", "TEXT", "text"),
    ("status_color", "TEXT", "text"),
    ("previous_status", "TEXT", "text"),
    ("manual_override", "INTEGER", "bool"),
    ("manual_note", "TEXT", "text"),
    ("invoice_received", "INTEGER", "bool"),
    ("prepared_reply_path", "TEXT", "text"),
    ("timeline", "TEXT", "json_list"),
    ("mail_events", "TEXT", "json_list"),
    # -- GİDEN ZİNCİR (§1) -------------------------------------------------
    # Hatırlatma, İLK mutabakat mailinden değil EN SON gönderdiğimiz
    # mailden cevaplanmalıdır. İlk gönderimin kimlikleri ASLA ezilmez;
    # ayrı alanlarda saklanır ki son kimlik geçersizse ona düşülebilsin.
    ("initial_outbound_entry_id", "TEXT", "text"),
    ("initial_outbound_message_id", "TEXT", "text"),
    ("last_outbound_entry_id", "TEXT", "text"),
    ("last_outbound_message_id", "TEXT", "text"),
    ("last_outbound_conversation_id", "TEXT", "text"),
    ("last_outbound_at", "TEXT", "text"),
    ("last_outbound_kind", "TEXT", "text"),
    ("reminder_count", "INTEGER", "int"),
    ("last_reminder_at", "TEXT", "text"),
    # Çözülmemiş SEND_UNKNOWN: aynı vaka+aksiyon için yeni gönderim
    # ENGELLENİR (mail gitmiş olabilir; mükerrer gönderim geri alınamaz).
    ("pending_unknown_action", "TEXT", "text"),
    ("pending_unknown_at", "TEXT", "text"),
    # TASLAK GÖNDERİLMİŞ MAİL DEĞİLDİR. Ayrı alanlarda tutulur; kullanıcı
    # taslağı Outlook'tan gönderene ve bu DOĞRULANANA kadar zincir
    # ilerlemez. Aksi hâlde bir sonraki hatırlatma, hiç gönderilmemiş
    # (hatta silinmiş olabilecek) bir taslağı hedefler.
    ("last_draft_entry_id", "TEXT", "text"),
    ("last_draft_conversation_id", "TEXT", "text"),
    ("last_draft_at", "TEXT", "text"),
    ("last_draft_action", "TEXT", "text"),
    # -- TESLİM EDİLEMEYEN ADRES ------------------------------------------
    # NDR sonrası adres durumu. GEÇERSİZ_ADRES olan bir vakaya hatırlatma
    # GÖNDERİLMEZ ve YENİ adres girilmeden vaka KAPATILAMAZ; aksi hâlde
    # firma "cevap vermedi" sanılır ve mutabakat sessizce kaybolur.
    ("address_status", "TEXT", "text"),
    ("invalid_address", "TEXT", "text"),
    ("replacement_address", "TEXT", "text"),
    ("address_failure_reason", "TEXT", "text"),
    # -- AÇIK AKSİYONLAR (§8) ---------------------------------------------
    ("action_items", "TEXT", "json_list"),
    ("created_at", "TEXT", "text"),
    ("updated_at", "TEXT", "text"),
)

_FIELD_NAMES = tuple(name for name, _sql, _kind in _FIELDS)


def _encode(value: Any, kind: str) -> Any:
    if kind in ("json_dict", "json_list"):
        return json.dumps(value, ensure_ascii=False, default=str)
    if kind == "bool":
        return 1 if value else 0
    if kind == "real":
        return float(value or 0.0)
    if kind == "int":
        return int(value or 0)
    return value if value is not None else ""


def _decode(value: Any, kind: str) -> Any:
    if kind in ("json_dict", "json_list"):
        default: Any = {} if kind == "json_dict" else []
        try:
            return json.loads(value) if value else default
        except (TypeError, ValueError):
            return default
    if kind == "bool":
        return bool(value)
    if kind == "real":
        return float(value or 0.0)
    if kind == "int":
        return int(value or 0)
    return value or ""


def _merge_dict_list(existing: list[dict[str, Any]],
                     incoming: list[dict[str, Any]],
                     *, identity: tuple[str, ...] = ()) -> list[dict[str, Any]]:
    """Stable union for append-only audit/history collections."""
    out = [dict(item) for item in existing]
    if identity:
        known = {tuple(str(item.get(k, "")) for k in identity) for item in out}
        for item in incoming:
            key = tuple(str(item.get(k, "")) for k in identity)
            if key not in known:
                out.append(dict(item))
                known.add(key)
        return out
    known_json = {json.dumps(item, sort_keys=True, ensure_ascii=False, default=str)
                  for item in out}
    for item in incoming:
        key = json.dumps(item, sort_keys=True, ensure_ascii=False, default=str)
        if key not in known_json:
            out.append(dict(item))
            known_json.add(key)
    return out


def _merge_action_items(existing: list[dict[str, Any]],
                        incoming: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Aksiyonları ``action_id`` ile birleştir; en yeni durum tek kayıt olsun.

    Timeline/mail olayları append-only'dir; aksiyon ise aynı kimliğin durum
    makinesidir (IN_PROGRESS → SENT/CANCELLED...). Aynı kimliğin iki durumunu
    yan yana eklemek vakayı sonsuza kadar kilitli gösterebilir.
    """
    out = [dict(item) for item in existing]
    indexes = {str(item.get("action_id") or ""): index
               for index, item in enumerate(out) if item.get("action_id")}
    for item in incoming:
        current = dict(item)
        action_id = str(current.get("action_id") or "")
        if not action_id:
            out = _merge_dict_list(out, [current])
            continue
        index = indexes.get(action_id)
        if index is None:
            indexes[action_id] = len(out)
            out.append(current)
            continue
        old_updated = str(out[index].get("updated_at") or "")
        new_updated = str(current.get("updated_at") or "")
        if new_updated >= old_updated:
            out[index] = current
    return out


def _merge_concurrent_case(case: "IncomingCase", existing: "IncomingCase") -> None:
    """Preserve append-only evidence added by another process/store instance."""
    case.created_at = existing.created_at
    case.timeline = _merge_dict_list(existing.timeline, case.timeline)
    case.mail_events = _merge_dict_list(
        existing.mail_events, case.mail_events,
        identity=("direction", "mail_id", "at"))
    case.action_items = _merge_action_items(existing.action_items, case.action_items)
    case.original_attachments = _merge_dict_list(
        existing.original_attachments, case.original_attachments,
        identity=("sha256", "name"))
    case.incoming_attachments = _merge_dict_list(
        existing.incoming_attachments, case.incoming_attachments,
        identity=("sha256", "name"))
    # A stale object must not blank outbound-chain evidence written meanwhile.
    for name in (
        "initial_outbound_entry_id", "initial_outbound_message_id",
        "last_outbound_entry_id", "last_outbound_message_id",
        "last_outbound_conversation_id", "last_outbound_at",
        "last_outbound_kind", "last_reminder_at", "pending_unknown_action",
        "pending_unknown_at", "last_draft_entry_id",
        "last_draft_conversation_id", "last_draft_at", "last_draft_action",
    ):
        if not getattr(case, name):
            setattr(case, name, getattr(existing, name))
    case.reminder_count = max(case.reminder_count, existing.reminder_count)


@dataclass
class IncomingCase:
    """Bir firmanın bir gönderime verdiği cevabın kalıcı iş kaydı."""

    case_id: str = ""
    fingerprint: str = ""

    # -- zincir ------------------------------------------------------------
    send_id: str = ""
    snapshot_id: str = ""
    company_code: str = ""
    company_name: str = ""
    period: str = ""
    responsible: str = ""

    # -- gelen mail --------------------------------------------------------
    sender: str = ""
    subject: str = ""
    received_at: str = ""
    message_id: str = ""
    conversation_id: str = ""
    match_method: str = ""
    match_confidence: float = 0.0

    # -- çözümleme ---------------------------------------------------------
    reply_type: str = "UNKNOWN"
    currencies: dict[str, str] = field(default_factory=dict)
    body_result: dict[str, Any] = field(default_factory=dict)
    statement_result: dict[str, Any] = field(default_factory=dict)
    snapshot_result: dict[str, Any] = field(default_factory=dict)

    # -- karar -------------------------------------------------------------
    outcome: str = ""                 # teknik CaseOutcome
    final_status: str = ""            # sade MUTABIK / RED / İNCELEME / …
    reasons: list[str] = field(default_factory=list)
    confidence: float = 0.0
    ai_status: str = ""
    needs_human_review: bool = True

    # -- FAZ 11: takip ekranı alanları -------------------------------------
    # Yön ayrı bir case satırıdır: bir firmanın M ve S bakiyesi aynı satırda
    # birleşmez (aynı maile bağlı olsalar bile ayrı takip edilir).
    balance_type: str = ""            # "M" | "S" | ""
    data_source_type: str = ""        # M -> FBL5H, S/X -> FBL1H
    has_reply: bool = False           # cevap geldi mi (yoksa CEVAP BEKLENİYOR)
    sent_date: str = ""
    last_reply_date: str = ""
    latest_reply_sender: str = ""
    latest_reply_subject: str = ""
    latest_reply_snippet: str = ""
    recipients: str = ""
    cc: str = ""
    # Gönderilen ve gelen eklerin kimliği (SHA-256 ile; içerik taşınmaz).
    original_attachments: list[dict[str, Any]] = field(default_factory=list)
    incoming_attachments: list[dict[str, Any]] = field(default_factory=list)
    fbl1h_sha256: str = ""
    fbl5h_sha256: str = ""
    # Ayrı ayrı saklanan kararlar (biri diğerinin yerine geçmez).
    body_decision: str = ""
    statement_decision: str = ""
    financial_difference: str = ""
    difference_currency: str = ""
    # 0-100 güven puanı ve ZORUNLU açıklaması.
    confidence_100: int = 0
    confidence_explanation: str = ""
    # Kullanıcı müdahalesi: geri alınabilir olması için ÖNCEKİ durum saklanır.
    status_color: str = ""
    previous_status: str = ""
    manual_override: bool = False
    manual_note: str = ""
    invoice_received: bool = False
    prepared_reply_path: str = ""
    # İşlem geçmişi (audit): her adım zaman damgasıyla eklenir, SİLİNMEZ.
    timeline: list[dict[str, Any]] = field(default_factory=list)
    # MAIL TIMELINE (§14): zincirdeki her gelen/giden mailin kaydı. Son mail
    # öncekini EZMEZ; karar en güncel anlamlı cevaba göre verilir ama geçmiş
    # kayıt hiçbir zaman silinmez.
    mail_events: list[dict[str, Any]] = field(default_factory=list)

    # -- giden zincir (§1) -------------------------------------------------
    # İLK gönderimin kimlikleri KORUNUR (üzerine yazılmaz); son gönderimin
    # kimlikleri ayrı tutulur. Bir sonraki hatırlatma önce SON maili,
    # bulunamazsa İLK maili hedefler (bkz. reply_target.resolve_target).
    initial_outbound_entry_id: str = ""
    initial_outbound_message_id: str = ""
    last_outbound_entry_id: str = ""
    last_outbound_message_id: str = ""
    last_outbound_conversation_id: str = ""
    last_outbound_at: str = ""
    last_outbound_kind: str = ""
    reminder_count: int = 0
    last_reminder_at: str = ""
    # Çözülmemiş SEND_UNKNOWN (§2): bu aksiyon için yeni gönderim yapılmaz.
    pending_unknown_action: str = ""
    pending_unknown_at: str = ""
    # Açılan ama HENÜZ GÖNDERİLMEMİŞ taslak (bkz. şema notu).
    last_draft_entry_id: str = ""
    last_draft_conversation_id: str = ""
    last_draft_at: str = ""
    last_draft_action: str = ""

    # -- teslim edilemeyen adres -------------------------------------------
    address_status: str = ""          # "" | GECERSIZ_ADRES | ADRES_DUZELTILDI
    invalid_address: str = ""         # ulaşılamayan adres
    replacement_address: str = ""     # kullanıcının girdiği YENİ adres
    address_failure_reason: str = ""

    # -- açık aksiyonlar (§8) ----------------------------------------------
    action_items: list[dict[str, Any]] = field(default_factory=list)

    # -- zaman -------------------------------------------------------------
    created_at: str = field(default_factory=_now)
    updated_at: str = field(default_factory=_now)

    def __post_init__(self) -> None:
        if not self.case_id:
            # Gönderim anında henüz cevap (fingerprint) yoktur; kimlik
            # gönderim + yön üzerinden kurulur ve cevap geldiğinde AYNI
            # kayıt güncellenir — ikinci bir satır doğmaz.
            seed = self.fingerprint or f"send:{self.send_id}:{self.balance_type}"
            self.case_id = make_case_id(seed, self.send_id)

    # -- işlem geçmişi -----------------------------------------------------

    def add_event(self, kind: str, description: str = "", *,
                  old_value: str = "", new_value: str = "",
                  user: str = "", detail: str = "") -> None:
        """İşlem geçmişine kayıt ekle. Geçmiş ASLA silinmez, yalnızca büyür."""
        self.timeline.append({
            "at": _now(),
            "kind": kind,
            "description": description,
            "old_value": old_value,
            "new_value": new_value,
            "user": user or _current_user(),
            "detail": detail,
        })

    def add_mail_event(self, direction: str, *, mail_id: str = "",
                       sender: str = "", subject: str = "",
                       occurred_at: str = "", snippet: str = "",
                       attachment_count: int = 0,
                       attachment_hashes: Optional[list[str]] = None,
                       reply_type: str = "") -> None:
        """Zincire giren/çıkan bir maili kaydet (§14).

        ``direction``: "OUT" (bizden gitti) | "IN" (firmadan geldi).
        Aynı mail iki kez eklenmez: ``mail_id`` zaten varsa atlanır.
        """
        if mail_id and any(e.get("mail_id") == mail_id
                           for e in self.mail_events):
            return
        self.mail_events.append({
            "at": occurred_at or _now(),
            "direction": direction,
            "mail_id": mail_id,
            "conversation_id": self.conversation_id,
            "sender": sender,
            "subject": subject,
            "snippet": (snippet or "")[:200],
            "attachment_count": attachment_count,
            "attachment_hashes": list(attachment_hashes or []),
            "reply_type": reply_type,
            "linked_case_id": self.case_id,
        })

    @property
    def waiting_reply(self) -> bool:
        return not self.has_reply

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class IncomingCaseStore:
    """Gelen cevap iş kayıtlarının kalıcı deposu."""

    def __init__(self, path: str | Path | None = None) -> None:
        if path is None:
            base = app_data_dir()
            base.mkdir(parents=True, exist_ok=True)
            path = base / "incoming_cases.db"
        self._path = Path(path)
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
        except OSError:  # pragma: no cover
            pass
        self._ensure_schema()

    @property
    def path(self) -> Path:
        return self._path

    def _connect(self) -> sqlite3.Connection:
        return open_sqlite_connection(self._path, isolation_level=None)

    @contextmanager
    def _session(self):
        conn = self._connect()
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _ensure_schema(self) -> None:
        columns = ", ".join(f"{name} {sql}" for name, sql, _kind in _FIELDS)
        try:
            with self._session() as conn:
                conn.execute(
                    f"CREATE TABLE IF NOT EXISTS incoming_cases ({columns})")
                # GÖÇ: eski veritabanında olmayan kolonlar eklenir. Kullanıcının
                # birikmiş kayıtları SİLİNMEZ; yeni alanlar boş başlar.
                mevcut = {row[1] for row in
                          conn.execute("PRAGMA table_info(incoming_cases)")}
                for name, sql, _kind in _FIELDS:
                    if name in mevcut:
                        continue
                    tip = sql.replace(" PRIMARY KEY", "").replace(" NOT NULL", "")
                    conn.execute(
                        f"ALTER TABLE incoming_cases ADD COLUMN {name} {tip}")
                    logger.info(f"[case] yeni kolon eklendi: {name}")
                for name, cols in (
                    ("ix_cases_period", "(period)"),
                    ("ix_cases_company", "(company_code, period)"),
                    ("ix_cases_responsible", "(responsible, period)"),
                    ("ix_cases_send", "(send_id)"),
                    ("ix_cases_fingerprint", "(fingerprint)"),
                ):
                    conn.execute(
                        f"CREATE INDEX IF NOT EXISTS {name} "
                        f"ON incoming_cases {cols}")
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[case] şema kurulamadı: {exc}")

    # -- yazma -------------------------------------------------------------

    def upsert(self, case: IncomingCase) -> bool:
        """Kaydı yaz ya da güncelle. Aynı mail ikinci kez YENİ CASE ÜRETMEZ.

        ``created_at`` korunur: bir cevabın ilk görüldüğü an, yeniden
        taramayla değişmemelidir.
        """
        alanlar = ", ".join(_FIELD_NAMES)
        isaret = ",".join("?" * len(_FIELD_NAMES))
        try:
            with self._session() as conn:
                # Serialize read-merge-write across processes. Reading through
                # self.get() before this transaction allowed a concurrent writer
                # to append history which INSERT OR REPLACE then erased.
                conn.execute("BEGIN IMMEDIATE")
                row = conn.execute(
                    f"SELECT {self._COLUMNS} FROM incoming_cases "
                    "WHERE case_id = ?", (case.case_id,)).fetchone()
                if row is not None:
                    _merge_concurrent_case(case, self._row(row))
                case.updated_at = _now()
                degerler = [_encode(getattr(case, name), kind)
                            for name, _sql, kind in _FIELDS]
                conn.execute(
                    f"INSERT OR REPLACE INTO incoming_cases ({alanlar}) "
                    f"VALUES ({isaret})", degerler)
            return True
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[case] yazılamadı ({case.case_id}): {exc}")
            return False

    def upsert_many(self, cases: Sequence[IncomingCase]) -> int:
        return sum(1 for c in cases if self.upsert(c))

    # -- okuma -------------------------------------------------------------

    _COLUMNS = ", ".join(_FIELD_NAMES)

    @staticmethod
    def _row(row: Sequence[Any]) -> IncomingCase:
        values = {name: _decode(row[i], kind)
                  for i, (name, _sql, kind) in enumerate(_FIELDS)}
        return IncomingCase(**values)

    def _query(self, where: str = "",
               params: Sequence[Any] = ()) -> list[IncomingCase]:
        sql = f"SELECT {self._COLUMNS} FROM incoming_cases"
        if where:
            sql += f" WHERE {where}"
        sql += " ORDER BY created_at, rowid"
        try:
            with self._session() as conn:
                rows = conn.execute(sql, list(params)).fetchall()
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[case] okunamadı: {exc}")
            return []
        return [self._row(r) for r in rows]

    def get(self, case_id: str) -> Optional[IncomingCase]:
        found = self._query("case_id = ?", (case_id,))
        return found[0] if found else None

    def by_fingerprint(self, fingerprint: str) -> list[IncomingCase]:
        return self._query("fingerprint = ?", (fingerprint,))

    def by_send_id(self, send_id: str) -> list[IncomingCase]:
        return self._query("send_id = ?", (send_id,))

    def find(self, *, period: Optional[str] = None,
             company_code: Optional[str] = None,
             responsible: Optional[str] = None,
             final_status: Optional[str] = None) -> list[IncomingCase]:
        where, params = [], []
        for column, value in (("period", period),
                              ("company_code", company_code),
                              ("responsible", responsible),
                              ("final_status", final_status)):
            if value:
                where.append(f"{column} = ?")
                params.append(value)
        return self._query(" AND ".join(where), params)

    def all(self) -> list[IncomingCase]:
        return self._query()

    def count(self, period: Optional[str] = None) -> int:
        """Kayıt sayısı — nesneler KURULMADAN sayılır.

        Eskiden tüm kayıtlar okunup IncomingCase nesnelerine çevriliyor,
        sonra len() alınıyordu; yalnızca sayı için binlerce nesne (ve JSON
        çözümlemesi) boşuna üretiliyordu.
        """
        sql = "SELECT COUNT(*) FROM incoming_cases"
        params: list = []
        if period:
            sql += " WHERE period = ?"
            params.append(period)
        try:
            with self._session() as conn:
                row = conn.execute(sql, params).fetchone()
            return int(row[0]) if row else 0
        except sqlite3.Error as exc:  # pragma: no cover - ortam bağımlı
            logger.error(f"Gelen cevap kayıtları sayılamadı: {exc}")
            return 0

    # -- silme (TEHLİKELİ, açıkça çağrılır) --------------------------------

    def purge_all(self, *, confirm: bool = False) -> int:
        """TÜM iş kayıtlarını sil.

        ``confirm=True`` verilmeden çalışmaz. Sıradan "UI Sıfırla" bu metodu
        ASLA çağırmaz — finansal kayıt bir arayüz temizliğiyle yok edilemez.
        """
        if not confirm:
            raise ValueError(
                "purge_all yalnızca confirm=True ile çağrılabilir; bu işlem "
                "gelen cevapların finansal kayıtlarını kalıcı olarak siler.")
        adet = self.count()
        try:
            with self._session() as conn:
                conn.execute("DELETE FROM incoming_cases")
        except sqlite3.Error as exc:  # pragma: no cover
            logger.error(f"[case] silinemedi: {exc}")
            return 0
        logger.warning(f"[case] {adet} iş kaydı KULLANICI ONAYIYLA silindi.")
        return adet


# -- ScanItem → IncomingCase ------------------------------------------------

def record_incoming_mail(case: IncomingCase, mail: Any,
                         reply_type: str = "") -> IncomingCase:
    """Gelen maili case'in mail timeline'ına ekle (§14).

    Son cevap öncekini EZMEZ: her mail ayrı kayıt olarak durur.
    """
    received = getattr(mail, "received_at", None)
    ekler = list(getattr(mail, "attachments", None) or [])
    case.add_mail_event(
        "IN",
        mail_id=getattr(mail, "message_id", "") or "",
        sender=getattr(mail, "sender", "") or "",
        subject=getattr(mail, "subject", "") or "",
        occurred_at=received.isoformat() if received else "",
        snippet=(getattr(mail, "body", "") or "")[:200],
        attachment_count=len(ekler),
        attachment_hashes=[getattr(a, "sha256", "") for a in ekler],
        reply_type=reply_type,
    )
    return case


def _decimals(mapping) -> dict[str, str]:
    return {str(k): str(v) for k, v in (mapping or {}).items()}


def _statement_summary(statement) -> dict[str, Any]:
    """Ekstre sonucunun kalıcı özeti (motor nesnesi saklanmaz)."""
    if statement is None:
        return {}
    analysis = getattr(statement, "analysis", None)
    data: dict[str, Any] = {
        "status": getattr(statement, "status", None)
        and statement.status.value,
        "source_filename": getattr(statement, "source_filename", ""),
        "rows_loaded": getattr(statement, "rows_loaded", 0),
        "extraction_method": getattr(statement, "extraction_method", ""),
        "error": getattr(statement, "error", ""),
    }
    if analysis is not None:
        data.update({
            "matched": analysis.matched,
            "amount_diff": analysis.amount_diff,
            "cross_matched": analysis.cross_matched,
            "only_firma": analysis.only_firma,
            "only_tofas": analysis.only_tofas,
            "difference": str(analysis.difference),
            "currency": analysis.currency,
            "amount_diff_total": str(analysis.amount_diff_total),
            "only_firma_total": str(analysis.only_firma_total),
            "only_tofas_total": str(analysis.only_tofas_total),
            "explain": analysis.explain(),
        })
    return data


def _snapshot_summary(comparison) -> dict[str, Any]:
    """Snapshot karşılaştırmasının kalıcı kanıt özeti."""
    if comparison is None:
        return {}
    return {
        "send_id": comparison.send_id,
        "snapshot_id": comparison.snapshot_id,
        "reference": comparison.reference.value,
        "sent_record_count": comparison.sent_record_count,
        "sent_directions": dict(comparison.sent_directions),
        "sent_totals": _decimals(comparison.sent_totals),
        "fbl1h_sha256": comparison.fbl1h_sha256,
        "fbl5h_sha256": comparison.fbl5h_sha256,
        "incoming_filename": comparison.incoming_filename,
        "matched": comparison.matched,
        "difference_total": str(comparison.difference_total),
        "reasons": list(comparison.reasons),
        "error": comparison.error,
    }


def _body_summary(response) -> dict[str, Any]:
    """Mail gövdesi çözümlemesinin kalıcı özeti."""
    if response is None:
        return {}
    return {
        "reply_type": response.reply_type.value,
        "balance_accepted": response.balance_accepted,
        "letter_present": response.letter_present,
        "letter_filled": response.letter_filled,
        "letter_signed": response.letter_signed,
        "letter_sealed": response.letter_sealed,
        "statement_present": response.statement_present,
        "direction": response.direction.value,
        "period": response.period,
        "confidence": round(response.confidence, 4),
        "conflicts": [
            {"field": c.field_name, "python": c.python_value, "ai": c.ai_value}
            for c in response.conflicts
        ],
        "reasons": list(response.reasons),
        "ai_error": response.ai_error,
        "from_cache": response.from_cache,
    }


_INBOUND_CASE_FIELDS = (
    "fingerprint", "sender", "subject", "received_at", "message_id",
    "conversation_id", "match_method", "match_confidence", "reply_type",
    "currencies", "body_result", "statement_result", "snapshot_result",
    "outcome", "final_status", "reasons", "confidence", "ai_status",
    "needs_human_review",
)


def case_from_scan_item(item, existing: IncomingCase | None = None) -> IncomingCase:
    """Bir ``ScanItem``ı kalıcı iş kaydına çevir.

    Kararı BURASI ÜRETMEZ; yalnızca zaten üretilmiş sonucu kalıcı hâle
    getirir (tek doğruluk kaynağı ``ScanItem.decision``dır).
    """
    mail = item.mail
    tracked = item.match.tracked
    decision = item.decision
    response = item.response
    statement = item.best_statement

    received = getattr(mail, "received_at", None)
    incoming = IncomingCase(
        fingerprint=getattr(mail, "fingerprint", "") or "",
        send_id=item.send_id,
        snapshot_id=item.snapshot_id,
        company_code=item.company_code,
        company_name=(tracked.company_name if tracked else "")
        or (response.company_name if response else "") or "",
        period=item.period,
        responsible=item.responsible,
        sender=getattr(mail, "sender", "") or "",
        subject=getattr(mail, "subject", "") or "",
        received_at=received.isoformat() if received else "",
        message_id=getattr(mail, "message_id", "") or "",
        conversation_id=getattr(mail, "conversation_id", "") or "",
        match_method=item.match.method.value,
        match_confidence=item.match.confidence,
        reply_type=(response.reply_type.value if response else "UNKNOWN"),
        currencies=_decimals(response.currencies if response else {}),
        body_result=_body_summary(response),
        statement_result=_statement_summary(statement),
        snapshot_result=_snapshot_summary(item.snapshot_comparison),
        outcome=decision.outcome.value,
        final_status=decision.status.value,
        reasons=list(decision.reasons),
        confidence=(response.confidence if response else 0.0),
        ai_status=(response.review_status.value if response else ""),
        needs_human_review=decision.needs_human_review,
    )
    if existing is None:
        return incoming

    # A reply belongs to the already seeded send+direction case. Preserve its
    # stable identity, outbound evidence, direction, action history and mail
    # timeline; only refresh fields derived from the latest inbound message.
    for name in _INBOUND_CASE_FIELDS:
        setattr(existing, name, getattr(incoming, name))
    if not existing.snapshot_id:
        existing.snapshot_id = incoming.snapshot_id
    if not existing.company_code:
        existing.company_code = incoming.company_code
    if not existing.company_name:
        existing.company_name = incoming.company_name
    if not existing.period:
        existing.period = incoming.period
    if not existing.responsible:
        existing.responsible = incoming.responsible
    return existing
