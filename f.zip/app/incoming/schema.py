"""AI çıktısının JSON şeması, ayrıştırılması ve DOĞRULANMASI.

Copilot Studio ajanı serbest metin döndürmemelidir; ama gerçek hayatta
döndürebilir (selamlama cümlesi, ```json çiti, kısmi cevap…). Bu modül üç işi
yapar:

    1. Cevabın içinden JSON nesnesini güvenle çıkarır (dengeli parantez tarama).
    2. Her alanı TİP ve DEĞER olarak doğrular.
    3. Kurtarılamayan alanı sessizce kabul etmez: bilinmeyene çeker,
       gerekçesini yazar ve maili insan incelemesine düşürür.

"Eksik/yanlış tipte alanları otomatik kabul etme" kuralı burada uygulanır.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from typing import Any, Optional

from app.incoming.models import Direction, ReplyType
from app.mailing.mail_builder import normalize_code

# Ajanın döndürmesi beklenen şema (prompt dosyasıyla AYNI olmalıdır).
SCHEMA_TEMPLATE: dict[str, Any] = {
    "company_code": None,
    "company_name": None,
    "letter_present": False,
    "statement_present": False,
    "letter_filled": False,
    "letter_signed": False,
    "letter_sealed": False,
    "balance_present": False,
    "balance_accepted": None,
    "reply_type": None,
    "period": None,
    "currencies": {},
    "direction": None,
    "confidence": 0.0,
    "needs_human_review": True,
    "reason": None,
}

SCHEMA_FIELDS: tuple[str, ...] = tuple(SCHEMA_TEMPLATE.keys())

BOOL_FIELDS: tuple[str, ...] = (
    "letter_present", "statement_present", "letter_filled", "letter_signed",
    "letter_sealed", "balance_present", "balance_accepted",
)

# Bu alanlar bozuksa mail KOŞULSUZ insan incelemesine gider.
CRITICAL_FIELDS: tuple[str, ...] = ("company_code", "balance_accepted",
                                    "reply_type", "confidence")

_UNKNOWN_TOKENS = {"", "unknown", "null", "none", "n/a", "na", "bilinmiyor",
                   "belirsiz", "unsure", "not sure", "-", "?"}
_TRUE_TOKENS = {"true", "yes", "evet", "var", "1"}
_FALSE_TOKENS = {"false", "no", "hayir", "hayır", "yok", "0"}

_PERIOD_RE = re.compile(r"^(\d{4})[-/.](\d{1,2})")
_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL | re.IGNORECASE)


class SchemaError(ValueError):
    """AI cevabı hiç JSON içermiyor."""


@dataclass
class ValidationOutcome:
    """Doğrulama sonucu: temizlenmiş alanlar + gerekçeler."""

    values: dict[str, Any] = field(default_factory=dict)
    invalid_fields: list[str] = field(default_factory=list)
    coerced_fields: list[str] = field(default_factory=list)
    unknown_keys: list[str] = field(default_factory=list)

    @property
    def errors(self) -> list[str]:
        out = [f"gecersiz:{name}" for name in self.invalid_fields]
        out += [f"donusturuldu:{name}" for name in self.coerced_fields]
        out += [f"fazla_alan:{name}" for name in self.unknown_keys]
        return out

    @property
    def critical_broken(self) -> bool:
        return any(name in CRITICAL_FIELDS for name in self.invalid_fields)


#: JSON taraması için en uzun metin. Daha uzun cevaplar TARANMAZ:
#: dengeli parantez araması kötü niyetli girdide işlemciyi meşgul eder.
MAX_JSON_SCAN_CHARS = 100_000

#: Tek geçişte denenecek en fazla JSON adayı. Gerçek cevaplarda tek nesne
#: vardır; sınır iç içe geçmiş bozuk girdilerde ayrıştırma maliyetini kapar.
MAX_JSON_CANDIDATES = 50


def extract_json_object(text: str) -> dict[str, Any]:
    """Serbest metnin içinden İLK dengeli JSON nesnesini çıkar.

    Sırayla denenir: (1) doğrudan ``json.loads``, (2) ```json çiti içeriği,
    (3) ilk ``{`` ile dengelenen ``}`` arası. Hiçbiri olmazsa SchemaError.
    """
    if text is None or not str(text).strip():
        raise SchemaError("AI cevabı boş.")

    raw = str(text).strip()

    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        data = None
    if isinstance(data, dict):
        return data
    if isinstance(data, list):
        # Ajan cevabı listeye sarmış olabilir. TEK nesne varsa kurtarılır;
        # birden çok nesne varsa hangisinin geçerli olduğu belirsizdir ve
        # rastgele biri seçilmez.
        objects = [item for item in data if isinstance(item, dict)]
        if len(objects) == 1:
            return objects[0]
        raise SchemaError(
            f"AI cevabında {len(objects)} JSON nesnesi var; hangisinin "
            "geçerli olduğu belirsiz.")

    for match in _FENCE_RE.finditer(raw):
        candidate = match.group(1).strip()
        try:
            data = json.loads(candidate)
            if isinstance(data, dict):
                return data
        except (json.JSONDecodeError, ValueError):
            continue

    # -- dengeli süslü parantez taraması --------------------------------
    #
    # Eskiden HER '{' için metnin sonuna kadar ayrı bir tarama yapılıyordu:
    # O(n²). Bozuk/kötü niyetli bir AI cevabı ("{" * 100000) işlemciyi
    # kilitliyor ve uygulama donuyordu. Artık metin TEK GEÇİŞTE taranır,
    # aday sayısı ve metin uzunluğu sınırlıdır.
    if len(raw) > MAX_JSON_SCAN_CHARS:
        raise SchemaError(
            f"AI cevabı çok uzun ({len(raw)} karakter); JSON taranmadı.")

    stack: list[int] = []
    candidates: list[tuple[int, int]] = []
    in_string = False
    escape = False
    for index, char in enumerate(raw):
        if in_string:
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == "{":
            stack.append(index)
        elif char == "}" and stack:
            candidates.append((stack.pop(), index + 1))
            if len(candidates) >= MAX_JSON_CANDIDATES:
                break

    # Dıştaki nesne önce denenir (eski davranış: en erken '{' kazanır).
    for start, end in sorted(candidates):
        try:
            data = json.loads(raw[start:end])
        except (json.JSONDecodeError, ValueError):
            continue
        if isinstance(data, dict):
            return data

    raise SchemaError("AI cevabında geçerli JSON nesnesi yok.")


def _coerce_bool(value: Any, name: str,
                 outcome: ValidationOutcome) -> Optional[bool]:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        token = value.strip().lower()
        if token in _UNKNOWN_TOKENS:
            return None
        if token in _TRUE_TOKENS:
            outcome.coerced_fields.append(name)
            return True
        if token in _FALSE_TOKENS:
            outcome.coerced_fields.append(name)
            return False
    outcome.invalid_fields.append(name)
    return None


def _coerce_str(value: Any, name: str,
                outcome: ValidationOutcome) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, bool) or isinstance(value, (list, dict)):
        outcome.invalid_fields.append(name)
        return None
    text = str(value).strip()
    if text.lower() in _UNKNOWN_TOKENS:
        return None
    return text


def _coerce_confidence(value: Any, outcome: ValidationOutcome) -> float:
    if value is None:
        outcome.invalid_fields.append("confidence")
        return 0.0
    if isinstance(value, bool):
        outcome.invalid_fields.append("confidence")
        return 0.0
    if isinstance(value, (int, float)):
        number = float(value)
    else:
        try:
            number = float(str(value).strip().replace(",", "."))
            outcome.coerced_fields.append("confidence")
        except (TypeError, ValueError):
            outcome.invalid_fields.append("confidence")
            return 0.0
    if number > 1.0 and number <= 100.0:
        # Yüzde olarak dönmüş olabilir (ör. 96) — 0..1'e indir ve kaydet.
        number = number / 100.0
        outcome.coerced_fields.append("confidence")
    if not 0.0 <= number <= 1.0:
        # GEÇERSİZ GÜVEN SKORU SIFIRDIR, BİR DEĞİL.
        #
        # Eskiden aralık dışı değer kırpılıyordu: 500 gibi anlamsız bir
        # cevap max(0, min(1, 500)) = 1.0 ile TAM GÜVEN'e dönüşüyordu.
        # Yani bozuk bir AI cevabı, en güvenilir cevap gibi davranıyordu —
        # güven eşiğini de otomatik geçiyordu. Okunamayan güven skoru
        # "güven yok" demektir.
        outcome.invalid_fields.append("confidence")
        return 0.0
    return number


def _coerce_currencies(value: Any,
                       outcome: ValidationOutcome) -> dict[str, Decimal]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        outcome.invalid_fields.append("currencies")
        return {}
    out: dict[str, Decimal] = {}
    for key, amount in value.items():
        code = str(key).strip().upper()
        if not code or not code.isalpha():
            outcome.invalid_fields.append("currencies")
            continue
        if code in ("TL", "TRL"):
            code = "TRY"
        try:
            if isinstance(amount, bool):
                raise InvalidOperation("bool")
            if isinstance(amount, (int, float)):
                out[code] = Decimal(str(amount))
            else:
                from app.utils.normalization import normalize_amount
                text = str(amount).strip()
                if not any(ch.isdigit() for ch in text):
                    raise InvalidOperation("sayı yok")
                out[code] = normalize_amount(text)
        except (InvalidOperation, TypeError, ValueError):
            outcome.invalid_fields.append("currencies")
    return out


def _coerce_period(value: Any, outcome: ValidationOutcome) -> Optional[str]:
    text = _coerce_str(value, "period", outcome)
    if text is None:
        return None
    match = _PERIOD_RE.match(text)
    if not match:
        outcome.invalid_fields.append("period")
        return None
    year, month = int(match.group(1)), int(match.group(2))
    if not 1 <= month <= 12 or not 1990 <= year <= 2100:
        outcome.invalid_fields.append("period")
        return None
    return f"{year}-{month:02d}"


def validate(data: dict[str, Any]) -> ValidationOutcome:
    """AI'nın döndürdüğü sözlüğü şemaya göre doğrula ve temizle."""
    outcome = ValidationOutcome()
    if not isinstance(data, dict):
        outcome.invalid_fields.extend(SCHEMA_FIELDS)
        outcome.values = dict(SCHEMA_TEMPLATE)
        return outcome

    for key in data:
        if key not in SCHEMA_FIELDS:
            outcome.unknown_keys.append(str(key))

    values: dict[str, Any] = {}

    code = _coerce_str(data.get("company_code"), "company_code", outcome)
    if code is not None:
        normalized = normalize_code(code)
        if not normalized:
            outcome.invalid_fields.append("company_code")
            code = None
        else:
            code = normalized
    values["company_code"] = code

    values["company_name"] = _coerce_str(data.get("company_name"),
                                         "company_name", outcome)

    for name in BOOL_FIELDS:
        values[name] = _coerce_bool(data.get(name), name, outcome)

    reply_raw = _coerce_str(data.get("reply_type"), "reply_type", outcome)
    if reply_raw is None:
        values["reply_type"] = ReplyType.UNKNOWN
    else:
        try:
            values["reply_type"] = ReplyType(reply_raw.strip().upper())
        except ValueError:
            outcome.invalid_fields.append("reply_type")
            values["reply_type"] = ReplyType.UNKNOWN

    direction_raw = _coerce_str(data.get("direction"), "direction", outcome)
    if direction_raw is None:
        values["direction"] = Direction.UNKNOWN
    else:
        try:
            values["direction"] = Direction(direction_raw.strip().upper())
        except ValueError:
            outcome.invalid_fields.append("direction")
            values["direction"] = Direction.UNKNOWN

    values["period"] = _coerce_period(data.get("period"), outcome)
    values["currencies"] = _coerce_currencies(data.get("currencies"), outcome)
    values["confidence"] = _coerce_confidence(data.get("confidence"), outcome)

    review = _coerce_bool(data.get("needs_human_review"), "needs_human_review",
                          outcome)
    # Güvenli varsayılan: alan yoksa/bozuksa İNSAN İNCELEMESİ.
    values["needs_human_review"] = True if review is None else review

    values["reason"] = _coerce_str(data.get("reason"), "reason", outcome)

    # Aynı alan birden çok kez hatalı işaretlenmiş olabilir (currencies).
    outcome.invalid_fields = list(dict.fromkeys(outcome.invalid_fields))
    outcome.coerced_fields = list(dict.fromkeys(outcome.coerced_fields))
    outcome.values = values
    return outcome


def parse_and_validate(text: str) -> ValidationOutcome:
    """Ham AI cevabından doğrulanmış alanlara — tek adım."""
    return validate(extract_json_object(text))
