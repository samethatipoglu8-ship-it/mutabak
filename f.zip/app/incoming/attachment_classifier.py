"""Eklerin sınıflandırılması: LETTER / STATEMENT / OTHER.

Dosya adına KÖRÜ KÖRÜNE güvenilmez. Gerçek hayatta gelen adlar:

    "mutabakat.pdf", "reconciliation.pdf", "balance confirmation.pdf",
    "statement.xlsx", "ekstre.xlsx", "SKM_C25826.pdf" (tarayıcı çıktısı),
    "ATT00001.pdf", "Doc1.pdf"

Bu yüzden karar iki sinyalin toplamıdır:

    dosya adı sinyali  +  İÇERİK sinyali  →  skor  →  tür + güven

İkisi çelişirse İÇERİK kazanır ve gerekçe kaydedilir; güven düşer, böylece
üst katman gerekirse AI/insan incelemesine taşır. Sessiz karar YOKTUR.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from app.incoming.extractors import is_inline_image
from app.incoming.models import AttachmentKind, IncomingAttachment
from app.incoming.textutil import fold

# --- dosya adı sözlükleri ----------------------------------------------------

LETTER_NAME_TOKENS: tuple[str, ...] = (
    "mutabakat mektubu", "mutabakat", "mektup", "letter", "reconciliation",
    "reconcilation", "balance confirmation", "confirmation", "confirmed",
    "teyit", "bakiye teyidi", "onay", "signed", "imzali", "imzali mutabakat",
    "kaseli", "kase", "mutabakat formu", "saldenbestatigung", "conferma saldo",
)

STATEMENT_NAME_TOKENS: tuple[str, ...] = (
    "hesap ekstresi", "ekstre", "statement", "account statement", "ledger",
    "cari hesap", "cari", "hesap hareket", "hareket", "acik kalem",
    "open item", "openitems", "aging", "yaslandirma", "fatura listesi",
    "invoice list", "invoices", "detay", "dokum", "kontoauszug", "estratto",
)

# --- içerik sözlükleri -------------------------------------------------------

LETTER_TEXT_TOKENS: tuple[str, ...] = (
    "mutabakat mektubu", "mutabakat", "bakiye teyidi", "teyit ediniz",
    "lutfen teyit", "reconciliation", "balance confirmation",
    "please confirm", "we confirm", "confirm this", "as of",
    "the amount must be paid", "odenmesi gereken tutar", "sayin yetkili",
    "kasrlikli", "yukarida belirtilen bakiye", "the balance on our book",
    "hesabimizda gorunen bakiye", "kaselenmis", "imza", "signature", "stamp",
)

STATEMENT_HEADER_TOKENS: tuple[str, ...] = (
    "fatura no", "fatura", "belge no", "belge turu", "belge tarihi",
    "invoice", "invoice no", "document", "document no", "posting date",
    "due date", "vade", "tarih", "date", "tutar", "amount", "borc", "alacak",
    "debit", "credit", "bakiye", "balance", "aciklama", "reference",
    "referans", "para birimi", "currency",
)

# Ekstre sayılması için gereken en az veri satırı ve kolon sayısı.
MIN_STATEMENT_ROWS = 4
MIN_STATEMENT_COLS = 3

# Çizgisiz (tablo çerçevesi olmayan) PDF ekstreleri: pdfplumber tablo
# çıkaramaz, ama metinde "tarih + tutar" taşıyan satırlar dizilir. Bu, dosya
# adı hiçbir şey söylemediğinde ("SKM_C25826.pdf") tek güvenilir sinyaldir.
MIN_TABULAR_LINES = 5

_SPREADSHEET_EXT = {".xlsx", ".xlsm", ".xls", ".xltx", ".csv", ".tsv"}

_DATE_IN_LINE_RE = re.compile(r"\b\d{1,2}[./-]\d{1,2}[./-]\d{2,4}\b")
_AMOUNT_IN_LINE_RE = re.compile(r"\d[\d.,]{2,}\d")


@dataclass
class Classification:
    kind: AttachmentKind
    confidence: float = 0.0
    reason: str = ""
    letter_score: float = 0.0
    statement_score: float = 0.0
    signals: list[str] = field(default_factory=list)


def _name_hits(folded_name: str, tokens: tuple[str, ...]) -> list[str]:
    return [t for t in tokens if t in folded_name]


def _table_shape(attachment: IncomingAttachment) -> tuple[int, int]:
    """(en geniş kolon sayısı, toplam veri satırı) — tablo yoksa (0, 0)."""
    max_cols = 0
    rows = 0
    for table in attachment.tables:
        for row in table:
            filled = sum(1 for c in row if str(c).strip())
            max_cols = max(max_cols, filled)
        rows += max(0, len(table) - 1)      # başlık satırı düşülür
    return max_cols, rows


def _tabular_line_count(text: str) -> int:
    """Aynı satırda hem tarih hem tutar taşıyan satır sayısı (ekstre deseni)."""
    count = 0
    for line in (text or "").splitlines():
        if _DATE_IN_LINE_RE.search(line) and _AMOUNT_IN_LINE_RE.search(line):
            count += 1
    return count


def _text_header_hits(folded_text: str) -> list[str]:
    """Ekstre kolon adlarının düz METİNDE geçenleri (tablo çıkmayan PDF'ler)."""
    head = "\n".join(folded_text.splitlines()[:40])
    return [token for token in STATEMENT_HEADER_TOKENS if token in head]


def _header_hits(attachment: IncomingAttachment) -> list[str]:
    """Tablo başlıklarında geçen ekstre kolon adları."""
    hits: list[str] = []
    for table in attachment.tables[:3]:
        for row in table[:5]:
            folded = fold(" | ".join(str(c) for c in row))
            for token in STATEMENT_HEADER_TOKENS:
                if token in folded and token not in hits:
                    hits.append(token)
    return hits


def classify(attachment: IncomingAttachment) -> Classification:
    """Tek bir eki sınıflandır (ek daha önce ``extract_attachment`` görmüş olmalı)."""
    folded_name = fold(attachment.filename)
    folded_text = fold(attachment.text)[:20000]

    signals: list[str] = []
    letter = 0.0
    statement = 0.0

    # 1) Dosya adı sinyali.
    name_letter = _name_hits(folded_name, LETTER_NAME_TOKENS)
    name_statement = _name_hits(folded_name, STATEMENT_NAME_TOKENS)
    if name_letter:
        letter += 3.0
        signals.append(f"ad:mektup({name_letter[0]})")
    if name_statement:
        statement += 3.0
        signals.append(f"ad:ekstre({name_statement[0]})")

    # 2) Uzantı sinyali — hesap tablosu ekstre olmaya meyillidir, ama tek
    #    başına karar vermez (mektup taranıp xlsx'e gömülmüş olabilir).
    if attachment.extension in _SPREADSHEET_EXT:
        statement += 1.5
        signals.append("uzanti:tablo")

    # 3) İçerik: tablo yapısı.
    cols, rows = _table_shape(attachment)
    if cols >= MIN_STATEMENT_COLS and rows >= MIN_STATEMENT_ROWS:
        statement += 3.0
        signals.append(f"icerik:tablo({cols}x{rows})")
    header_hits = _header_hits(attachment)
    if len(header_hits) >= 2:
        statement += 2.0
        signals.append(f"icerik:kolon({','.join(header_hits[:3])})")

    # Çizgisiz PDF ekstresi: tablo çıkarılamaz ama satır deseni ekstredir.
    tabular_lines = _tabular_line_count(attachment.text)
    if tabular_lines >= MIN_TABULAR_LINES:
        statement += 3.0
        signals.append(f"icerik:satir-deseni({tabular_lines})")
    text_headers = _text_header_hits(folded_text)
    if len(text_headers) >= 3 and not attachment.tables:
        statement += 1.5
        signals.append(f"icerik:metin-kolon({','.join(text_headers[:3])})")

    # 4) İçerik: mektup ifadeleri.
    text_letter = [t for t in LETTER_TEXT_TOKENS if t in folded_text]
    if text_letter:
        letter += min(3.0, 1.0 * len(text_letter))
        signals.append(f"icerik:mektup({text_letter[0]})")

    # 5) Kısa, tablosuz PDF → mektup lehine küçük bir katkı.
    if attachment.extension == ".pdf" and not attachment.tables:
        if 0 < attachment.page_count <= 3:
            letter += 1.0
            signals.append("icerik:kisa-pdf")

    # 6) Okunamayan ek: karar VERİLMEZ, ada göre tahmin edilir ve düşük güvenle
    #    işaretlenir (taranmış mektup / görsel ekstre olabilir).
    if attachment.read_error:
        if is_inline_image(attachment):
            return Classification(AttachmentKind.OTHER, 0.9,
                                  "gövdeye gömülü görsel", signals=signals)
        kind = (AttachmentKind.LETTER if name_letter else
                AttachmentKind.STATEMENT if name_statement else
                AttachmentKind.UNREADABLE)
        return Classification(
            kind, 0.25 if kind is not AttachmentKind.UNREADABLE else 0.0,
            f"okunamadı ({attachment.read_error})", letter, statement, signals)

    if is_inline_image(attachment):
        return Classification(AttachmentKind.OTHER, 0.9,
                              "gövdeye gömülü görsel", signals=signals)

    # 7) Karar.
    if letter <= 0 and statement <= 0:
        return Classification(AttachmentKind.OTHER, 0.3,
                              "mektup/ekstre sinyali yok", letter, statement,
                              signals)

    if statement > letter:
        kind = AttachmentKind.STATEMENT
        top, other = statement, letter
    else:
        kind = AttachmentKind.LETTER
        top, other = letter, statement

    # Güven: baskınlık oranı. Beraberliğe yakın sonuç düşük güven üretir ve
    # üst katmanda AI/insan incelemesini tetikler.
    # Tablo uzantısı tek başına ekstre kanıtı değildir. Banka/ödeme talimatı
    # sıkça CSV/XLSX gelir; böyle bir eki mutabakat motoruna vermek gereksiz
    # "okunamadı" hatası ve sahte insan incelemesi üretirdi. Dosya adı veya
    # içerikten en az bir ekstre sinyali gelmeden OTHER olarak bırakılır.
    if kind is AttachmentKind.STATEMENT and statement <= 1.5:
        return Classification(
            AttachmentKind.OTHER, 0.7,
            "tablo uzantısı var ancak ekstre sinyali yok", letter, statement,
            signals,
        )

    confidence = round(min(1.0, (top - other) / max(top, 1.0) * 0.6 + 0.4), 3)

    reason = ", ".join(signals) or "sinyal yok"
    conflicting = (kind is AttachmentKind.STATEMENT and name_letter) or \
                  (kind is AttachmentKind.LETTER and name_statement)
    if conflicting:
        reason = "dosya adı ile içerik çelişti, İÇERİK esas alındı — " + reason
        confidence = min(confidence, 0.6)

    return Classification(kind, confidence, reason, letter, statement, signals)


def classify_all(attachments: list[IncomingAttachment]) -> list[IncomingAttachment]:
    """Tüm ekleri sınıflandır ve sonucu eke yaz (yerinde günceller).

    ``ECHO`` İŞARETİ KORUNUR
        Bir ek, gönderim snapshot'ındaki hash ile BİREBİR eşleştiği için
        ``ECHO`` işaretlendiyse yeniden sınıflandırılmaz. Bayt kimliği,
        buradaki ad/içerik sezgisinden daha güçlü bir kanıttır: kendi
        mutabakat mektubumuz içerikçe "mektup"tur ve bu fonksiyon onu
        tekrar ``LETTER`` yapıp işareti silerse, firmanın hiç dokunmadığı
        belge "firma mektup gönderdi ve dolu" olarak okunur.
    """
    for attachment in attachments:
        if attachment.kind is AttachmentKind.ECHO:
            continue
        result = classify(attachment)
        attachment.kind = result.kind
        attachment.kind_confidence = result.confidence
        attachment.kind_reason = result.reason
    return attachments
