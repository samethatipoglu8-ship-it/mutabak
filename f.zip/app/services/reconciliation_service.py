"""Application orchestration service.

Single entry point the UI calls. Coordinates loading, reconciliation, and
result writing, logs every operation, and never lets an exception escape
uncaught (the UI wraps this so the app never crashes).
"""

from __future__ import annotations

import getpass
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from typing import Callable, Iterable, Optional

from loguru import logger

from app import APP_VERSION
from app.canonical import CanonicalReconciler, firma_to_canonical, tofas_to_canonical
from app.core.reconciler import Reconciler
from app.models.domain import ReconciliationResult, TofasRecord
from app.services.audit import RULE_VERSION, AuditStore, file_sha256
from app.services.company_config import CompanyConfig
from app.services.data_quality import DataQualityAnalyzer, QualityLevel
from app.services.errors import DataValidationError
from app.services.loader import FirmaLoader, TofasLoader
from app.services.result_writer import ResultWriter

# Mod → TOFAŞ ana-hesap prefiks filtresi (KOD İÇİ VARSAYILAN / fallback).
#   None  => filtre yok (hesap türüne bakılmaz).
# Eşleştirme mantığı her modda aynıdır (fatura no + tutar); bu sadece hangi
# TOFAŞ satırlarının mutabakata alınacağını belirler. Şirket-bazlı override
# artık config/companies.yaml üzerinden CompanyConfig ile yapılır; bu sözlük
# YAML yoksa geçerli olan güvenli varsayılandır.
_ACCOUNT_PREFIXES_BY_MODE: dict[str, tuple[str, ...] | None] = {
    "yerli": ("120", "121"),          # yerli müşteri/cari hesapları
    "yabanci": ("320", "323"),        # yabancı/ithal satıcı hesapları
    "birlikte": None,                 # ikisi birden — filtre kapalı
}


def _dosyalar_ters_mi(tofas_skor: float, firma_skor: float) -> bool:
    """TOFAŞ ve firma dosyaları YER DEĞİŞTİRMİŞ mi?

    NEDEN GEREKLİ
        Yükleyiciler müsamahakârdır: firma ekstresi TOFAŞ yuvasına
        konduğunda da okunur. Böyle bir durumda motor SESSİZCE anlamsız
        bir mutabakat üretiyordu — hiçbir uyarı çıkmıyordu.

    ÖLÇÜT
        ``sap_header_score``: başlıkta SAP FBL'ye özgü alanların
        (ana hesap + belge türü) bulunma oranı. Gerçek dosyalarla
        ölçüldü: FBL1H/FBL5H 1.00, firma ekstreleri 0.00.

    KURAL — YANLIŞ ALARM ÜRETMEZ
        Yalnızca kanıt KESİN olduğunda True döner: firma yuvasındaki
        dosya SAP başlıklarını taşıyor VE TOFAŞ yuvasındaki dosya hiç
        taşımıyor. Doğru sıralanmış bir çift bunu asla sağlayamaz; SAP
        başlığı olmayan sıradan bir TOFAŞ çıktısı da tek başına
        reddedilmez (firma tarafı da 0 ise koşul sağlanmaz).
    """
    return firma_skor >= 0.99 and tofas_skor <= 0.01


class ReconciliationService:
    """Coordinates a full reconciliation run end to end."""

    def __init__(
        self,
        tofas_loader: TofasLoader | None = None,
        firma_loader: FirmaLoader | None = None,
        writer: ResultWriter | None = None,
        company_config: CompanyConfig | None = None,
        audit: AuditStore | None = None,
    ) -> None:
        self._tofas_loader = tofas_loader or TofasLoader()
        self._firma_loader = firma_loader or FirmaLoader()
        self._writer = writer or ResultWriter()
        # Son çalıştırmada sonucun yazıldığı dosya (UI kullanıcıya gösterir).
        self.last_output_path: str = ""
        self._company_config = company_config or CompanyConfig()
        # Audit best-effort: oluşturulamazsa mutabakat yine çalışır.
        if audit is not None:
            self._audit = audit
        else:
            try:
                self._audit = AuditStore()
            except Exception as exc:  # noqa: BLE001
                logger.warning("Audit deposu açılamadı: {}", exc)
                self._audit = None

    def _tofas_loader_for(self, mode: str, company: Optional[str] = None) -> TofasLoader:
        """Moda göre uygun TOFAŞ yükleyiciyi döndür.

        Üç mod desteklenir (eşleştirme her modda 'fatura no + tutar' üzerinden
        yürür; mod yalnızca hangi hesap satırlarının dikkate alınacağını, yani
        ana-hesap prefiks filtresini belirler):

        - 'yerli'    : yerli firma → 120* (müşteri/cari) hesapları.
        - 'yabanci'  : yabancı/ithal firma → 320*/323* (satıcı) hesapları.
        - 'birlikte' : ikisi birden → 120*/320*/323* hepsi (filtre pratikte
                        kapalı; hesap türüne bakılmaz).

        Not: TofasLoader'daki prefix filtresi yalnızca dosyadaki hesapların
        ÇOĞUNLUĞU verilen prefikslere uyuyorsa devreye girer; aksi halde
        kendini otomatik devre dışı bırakır. Böylece yanlış mod seçilse bile
        geçerli satırlar elenmez.
        """
        # Önce config/companies.yaml'e danış (şirket-bazlı override + mod
        # varsayılanı). Config yoksa kod içi _ACCOUNT_PREFIXES_BY_MODE'a düşer.
        try:
            prefixes = self._company_config.account_prefixes(mode, company)
        except Exception as exc:  # noqa: BLE001 - config asla çökertmesin
            logger.warning("Şirket yapılandırması okunamadı: {}", exc)
            prefixes = _ACCOUNT_PREFIXES_BY_MODE.get(
                mode, _ACCOUNT_PREFIXES_BY_MODE["birlikte"]
            )
        if prefixes is None:
            return TofasLoader(account_prefixes=None)
        return TofasLoader(account_prefixes=tuple(prefixes))

    def _run_parameters(
        self, *, reconciler: Reconciler, tofas_path, firma_path,
        tofas_rows: int, firma_rows: int, mode: str, company: Optional[str],
        balance_delta: bool, account_prefixes: Optional[tuple[str, ...]],
        prefix_filter_active: bool, off_prefix_referenced_rows: int,
        sap_total: Optional[Decimal], firma_total: Optional[Decimal],
        tofas_opening: Decimal, firma_opening: Decimal,
    ) -> dict[str, str]:
        """Sonucu tek başına açıklayan parametre sözlüğü (Excel özeti için).

        Dosya YOLU değil yalnızca DOSYA ADI ve SHA-256 saklanır: tam yol
        kullanıcı adı / klasör yapısı gibi gereksiz bilgi sızdırabilir.
        """
        app_dir = Path(__file__).resolve().parents[1]
        return {
            "Program Sürümü": APP_VERSION,
            "Kural Sürümü": RULE_VERSION,
            "Çalıştırma Tarihi": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "Firma Modu": mode,
            "Şirket": company or "-",
            "TOFAŞ Dosyası": Path(tofas_path).name,
            "TOFAŞ SHA-256": file_sha256(tofas_path) or "-",
            "TOFAŞ Satır Sayısı": str(tofas_rows),
            "Firma Dosyası": Path(firma_path).name,
            "Firma SHA-256": file_sha256(firma_path) or "-",
            "Firma Satır Sayısı": str(firma_rows),
            "Tutar Toleransı": str(reconciler.amount_tolerance),
            "Tarih Toleransı (gün)": str(reconciler.date_tolerance_days),
            "Bire-Çok Eşleşme": "açık" if reconciler.enable_cross_match else "kapalı",
            "Bire-Çok Havuz Sınırı": str(reconciler.cross_max_pool),
            "Bire-Çok Alt-Küme Sınırı": str(reconciler.cross_max_subset),
            "Bire-Çok Aday Sınırı": str(reconciler.cross_max_candidates),
            "Global Arama Bütçesi": str(reconciler._SEARCH_NODE_BUDGET),
            "Alt-Küme Tarama Bütçesi": str(reconciler._SUBSET_SCAN_BUDGET),
            "Bakiye Delta Modu": "açık" if balance_delta else "kapalı",
            "Hesap Prefiksleri": ", ".join(account_prefixes or ()) or "filtre yok",
            "Prefiks Filtresi Aktif": "evet" if prefix_filter_active else "hayır",
            "Prefiks Dışı Referanslı Dahil Satır": str(off_prefix_referenced_rows),
            "SAP Toplam Kontrolü": (
                "uygulanmadı (prefiks filtresi aktif)"
                if prefix_filter_active else "karşılaştırıldı"),
            "Şirket Config SHA-256": file_sha256(self._company_config.path) or "-",
            "Eşleştirme Motoru SHA-256": (
                file_sha256(app_dir / "core" / "reconciler.py") or "-"),
            "Yükleyici SHA-256": file_sha256(Path(__file__).with_name("loader.py")) or "-",
            "SAP Beyan Toplamı": str(sap_total) if sap_total is not None else "-",
            "Firma Beyan Toplamı": str(firma_total) if firma_total is not None else "-",
            "TOFAŞ Açılış/Devir": str(tofas_opening),
            "Firma Açılış/Devir": str(firma_opening),
        }

    @staticmethod
    def _total_control_warnings(
        *, result: ReconciliationResult, sap_total: Optional[Decimal],
        firma_total: Optional[Decimal], tofas_opening: Decimal,
        firma_opening: Decimal, tolerance: Decimal,
        prefix_filter_active: bool,
    ) -> list[str]:
        """Dosyada beyan edilen dip toplamları hesaplanan tutarla doğrula.

        İşaret yönü iki ekstrede ters olabildiği için mutlak toplamlar kıyaslanır.
        Açılış/devir satırları kalem eşleştirmesine girmez ama toplam kontrolüne
        dahildir. Prefiks filtresi aktifken SAP sarı toplamı tüm hesapları
        kapsayabileceğinden TOFAŞ kıyası bilinçli olarak yapılmaz.
        """
        warnings: list[str] = []

        def differs(declared: Decimal, calculated: Decimal) -> bool:
            return abs(declared.copy_abs() - calculated.copy_abs()) > tolerance

        firma_calculated = result.summary.firma_diptoplam + firma_opening
        if firma_total is not None and differs(firma_total, firma_calculated):
            warnings.append(
                "Firma dip toplamı uyuşmuyor: "
                f"beyan={firma_total}, hesaplanan={firma_calculated} "
                f"(açılış/devir={firma_opening}).")

        tofas_calculated = result.summary.tofas_diptoplam_hesap + tofas_opening
        if (sap_total is not None and not prefix_filter_active
                and differs(sap_total, tofas_calculated)):
            warnings.append(
                "SAP dip toplamı uyuşmuyor: "
                f"beyan={sap_total}, hesaplanan={tofas_calculated} "
                f"(açılış/devir={tofas_opening}).")
        return warnings

    def load_tofas_records(
        self, tofas_path: str | Path, mode: str = "yabanci",
        company: Optional[str] = None,
    ) -> list[TofasRecord]:
        """TOFAŞ ekstresini kayıt listesi olarak yükle (mod filtresiyle).

        Gelen mail cevaplarındaki ekstreler de bu kayıtlarla karşılaştırılır.
        Dosya hattı ile mail hattının AYNI yükleyiciyi ve AYNI hesap
        filtresini kullanması için tek giriş noktası budur — mail tarafında
        ayrı bir yükleme mantığı yazılmaz.

        Not: Bu çağrı büyük dosyalarda saniyeler sürebilir; UI thread'inde
        DEĞİL, arka plan işçisinde çağrılmalıdır.
        """
        loader = self._tofas_loader_for(mode, company)
        records, _sap_total = loader.load(tofas_path)
        logger.info(
            "TOFAŞ kayıtları yüklendi: {} satır (mod={} dosya={})",
            len(records), mode, Path(tofas_path).name,
        )
        return records

    def peek_belge_turleri(self, tofas_path: str | Path, mode: str = "yabanci") -> list[str]:
        """Return the distinct belge türü values in a TOFAŞ file.

        Used to populate the include/exclude selection screen before running.
        """
        # NOT — HIZLI YOL DENENDİ VE GERİ ALINDI.
        #
        # 15.601 satırlık bir dosyada bu çağrı ~6.5 sn sürüyor ve sürenin
        # yarısı hiç ihtiyaç duyulmayan TofasRecord'ların kurulmasına
        # gidiyor. Yalnızca belge türü kolonunu okuyan bir hızlı yol
        # süreyi 2.6 sn'ye indiriyor — ANCAK aynı listeyi vermiyordu
        # (42-44 tür yerine 41).
        #
        # Sebep: tam yükleyici açılış/devir satırlarını, dip toplamı,
        # fatura olmayan referansları ve referanssız satırları da eler.
        # Bu kuralları ikinci bir yerde tekrarlamak, kullanıcıya sunulan
        # belge türü listesinin mutabakata GERÇEKTEN giren satırlardan
        # sessizce ayrışması demekti; kullanıcı olmayan bir türü hariç
        # tutabilir ya da var olanı göremezdi.
        #
        # Çağrı zaten arka plan thread'inde çalışıyor ve ilerleme mesajı
        # gösteriliyor: 4 saniyelik kazanç, finansal sonucu etkileyebilecek
        # bir sapma riskini haklı çıkarmıyor.
        loader = self._tofas_loader_for(mode)
        records, _ = loader.load(tofas_path)
        seen = sorted({(r.belge_turu or "").strip() for r in records if r.belge_turu})
        logger.info("TOFAŞ belge türleri: {}", seen)
        return seen

    def run(
        self,
        tofas_path: str | Path,
        firma_path: str | Path,
        excluded_belge_turu: Optional[Iterable[str]] = None,
        write_result: bool = True,
        progress: Optional[Callable[[str, int], None]] = None,
        mode: str = "yabanci",
        company: Optional[str] = None,
        date_tolerance_days: int = 0,
        enable_cross_match: bool = True,
        balance_delta: bool = False,
        output_dir: Optional[str | Path] = None,
    ) -> ReconciliationResult:
        """Load both files, reconcile, and (optionally) write the result sheet.

        ``output_dir`` verilirse sonuç kaynak TOFAŞ dosyasına DEĞİL, bu
        klasördeki bir kopyaya yazılır (kaynak dosya değişmez).

        ``mode`` = 'yerli' | 'yabanci' | 'birlikte'. ``company`` verilirse
        config/companies.yaml içindeki şirkete özel hesap prefiksleri kullanılır.
        Her çalıştırma benzersiz bir RUN-ID ile audit trail'e kaydedilir.
        """

        def report(msg: str, pct: int) -> None:
            logger.info("[{}%] {}", pct, msg)
            if progress:
                progress(msg, pct)

        # -- audit: çalıştırmayı başlat (best-effort, asla çökertmez) --------
        run_id: Optional[str] = None
        if self._audit is not None:
            try:
                run_id = self._audit.start_run(
                    tofas_file=str(tofas_path),
                    firma_file=str(firma_path),
                    mode=mode,
                    company=company,
                    app_user=getpass.getuser(),
                )
            except Exception as exc:  # noqa: BLE001
                logger.warning("Audit başlatılamadı: {}", exc)

        logger.info(
            "Mutabakat başladı. run_id={} mod={} şirket={} TOFAŞ={} Firma={}",
            run_id, mode, company, tofas_path, firma_path,
        )
        try:
            tofas_loader = self._tofas_loader_for(mode, company)
            report("TOFAŞ ekstresi yükleniyor...", 10)
            tofas, sap_total = tofas_loader.load(tofas_path)
            report(f"TOFAŞ: {len(tofas)} kayıt yüklendi.", 35)

            report("Firma ekstresi yükleniyor...", 45)
            firma_loader = FirmaLoader(balance_delta=True) if balance_delta else self._firma_loader
            firma, firma_total = firma_loader.load(firma_path)
            report(f"Firma: {len(firma)} kayıt yüklendi.", 60)

            # -- dosyalar ters mi? Sessiz anlamsız mutabakatı önle ---------
            if _dosyalar_ters_mi(getattr(tofas_loader, "sap_header_score", 0.0),
                                 getattr(firma_loader, "sap_header_score", 0.0)):
                raise DataValidationError(
                    "Dosyalar TERS görünüyor: TOFAŞ yuvasındaki dosya bir SAP "
                    "çıktısı değil, firma yuvasındaki dosya ise SAP çıktısı "
                    "(ana hesap ve belge türü alanları dolu). Dosyaları "
                    "değiştirip yeniden deneyin — aksi hâlde mutabakat "
                    "anlamsız bir sonuç üretir."
                )

            # -- veri kalitesi: sessiz "hiçbir şey eşleşmedi" sonucunu önle ---
            quality_lines: list[str] = []
            try:
                analyzer = DataQualityAnalyzer()
                for records, side in ((tofas, "TOFAŞ"), (firma, "Firma")):
                    rep = analyzer.analyze(records, side)
                    logger.info("Veri kalitesi — {}", rep.summary_line())
                    for msg in rep.messages():
                        logger.warning(msg)
                    # Okuma kalitesi HER ZAMAN raporlanır: "dosya yüklendi"
                    # ile "dosya DOĞRU yüklendi" aynı şey değildir.
                    quality_lines.append(
                        f"{side}: okuma kalitesi {rep.parse_quality}/100 "
                        f"({rep.parse_quality_label})")
                    quality_lines.extend(rep.messages())
                    if rep.blocking:
                        raise DataValidationError(
                            f"{side} dosyası mutabakata uygun değil: "
                            + "; ".join(rep.messages(QualityLevel.BLOCKING))
                        )
            except DataValidationError:
                raise
            except Exception as exc:  # noqa: BLE001 - kalite raporu asla çökertmez
                logger.warning("Veri kalitesi raporu üretilemedi: {}", exc)

            report("Eşleştirme yapılıyor...", 70)
            reconciler = Reconciler(
                excluded_belge_turu=excluded_belge_turu,
                date_tolerance_days=date_tolerance_days,
                enable_cross_match=enable_cross_match,
            )
            # All production inputs cross the canonical boundary before the
            # deterministic engine.  The adapter retains the complete V4
            # payload, therefore this is lossless while giving every future
            # connector (ERP/API/PDF/UBL) one integration contract.
            canonical_records = [tofas_to_canonical(record) for record in tofas]
            canonical_records.extend(firma_to_canonical(record) for record in firma)
            result = CanonicalReconciler(engine=reconciler).reconcile(
                canonical_records, sap_total=sap_total, firma_total=firma_total
            )

            total_warnings = self._total_control_warnings(
                result=result,
                sap_total=sap_total,
                firma_total=firma_total,
                tofas_opening=tofas_loader.opening_balance,
                firma_opening=firma_loader.opening_balance,
                tolerance=reconciler.amount_tolerance,
                prefix_filter_active=tofas_loader.prefix_filter_active,
            )
            if total_warnings:
                quality_lines.extend(total_warnings)
                result.summary.diptoplam_uyari = " | ".join(total_warnings)

            if tofas_loader.off_prefix_referenced_rows:
                quality_lines.append(
                    f"TOFAŞ: {tofas_loader.off_prefix_referenced_rows} prefiks dışı "
                    "satır, gerçek belge referansı taşıdığı için iş kuralı gereği "
                    "mutabakata dahil edildi.")

            # Dönem kapsamı: "yalnız firmada" listesinin ne kadarı gerçekten
            # fark, ne kadarı TOFAŞ dosyasının kapsamadığı dönem? Gerçek
            # veriyle ölçüldü: %49'u kapsam dışıydı. Satırlar SİLİNMEZ.
            try:
                from app.services.period_scope import describe, scope_of

                kapsam = describe(scope_of(result.only_firma, tofas))
                if kapsam:
                    quality_lines.append(kapsam)
            except Exception as exc:  # noqa: BLE001 - kapsam raporu çökertmez
                logger.warning("Dönem kapsamı hesaplanamadı: {}", exc)

            # Reconciler kendi çalışma zamanı uyarılarını (özellikle arama
            # bütçesi tükendiğinde CROSS_MATCH_APPROXIMATE) sonuca ekler.
            # Dosya-kalitesi satırlarını atarken bu uyarıları EZME: aksi hâlde
            # yaklaşık bir finansal eşleşme kullanıcıya kesinmiş gibi görünür.
            engine_quality = list(result.data_quality)
            result.data_quality = list(quality_lines)
            for line in engine_quality:
                if line not in result.data_quality:
                    result.data_quality.append(line)

            # -- tekrar üretilebilirlik: sonucu üreten parametreleri taşı ----
            result.summary.parameters = self._run_parameters(
                reconciler=reconciler, tofas_path=tofas_path, firma_path=firma_path,
                tofas_rows=len(tofas), firma_rows=len(firma),
                mode=mode, company=company,
                balance_delta=balance_delta,
                account_prefixes=tofas_loader.account_prefixes,
                prefix_filter_active=tofas_loader.prefix_filter_active,
                off_prefix_referenced_rows=tofas_loader.off_prefix_referenced_rows,
                sap_total=sap_total, firma_total=firma_total,
                tofas_opening=tofas_loader.opening_balance,
                firma_opening=firma_loader.opening_balance,
            )
            if self._audit is not None:
                try:
                    self._audit.record_parameters(
                        run_id,
                        program_version=APP_VERSION,
                        amount_tolerance=str(reconciler.amount_tolerance),
                        date_tolerance_days=reconciler.date_tolerance_days,
                        cross_match_enabled=int(reconciler.enable_cross_match),
                        cross_max_pool=reconciler.cross_max_pool,
                        cross_max_subset=reconciler.cross_max_subset,
                        cross_max_candidates=reconciler.cross_max_candidates,
                        search_node_budget=reconciler._SEARCH_NODE_BUDGET,
                        subset_scan_budget=reconciler._SUBSET_SCAN_BUDGET,
                        balance_delta=int(balance_delta),
                        account_prefixes=",".join(tofas_loader.account_prefixes or ()),
                        prefix_filter_active=int(tofas_loader.prefix_filter_active),
                        off_prefix_referenced_rows=tofas_loader.off_prefix_referenced_rows,
                        company_config_hash=file_sha256(self._company_config.path),
                        engine_hash=file_sha256(
                            Path(__file__).resolve().parents[1] / "core" / "reconciler.py"),
                        loader_hash=file_sha256(Path(__file__).with_name("loader.py")),
                        sap_declared_total=(
                            str(sap_total) if sap_total is not None else None),
                        firma_declared_total=(
                            str(firma_total) if firma_total is not None else None),
                        tofas_opening_balance=str(tofas_loader.opening_balance),
                        firma_opening_balance=str(firma_loader.opening_balance),
                        excluded_belge_turu=", ".join(result.excluded_belge_turu),
                        tofas_rows=len(tofas), firma_rows=len(firma),
                    )
                except Exception as exc:  # noqa: BLE001 - audit asla çökertmez
                    logger.warning("Audit parametreleri yazılamadı: {}", exc)

            output_status = "NOT_REQUESTED"
            written = None
            if write_result:
                report("Sonuç dosyaya yazılıyor...", 90)
                from pathlib import Path as _P
                src = _P(tofas_path)
                try:
                    # Sonuç DAİMA bağımsız bir kitaptır; kaynak ekstre ne
                    # açılır ne kopyalanır. Çıktı klasörü ayarlıysa oraya,
                    # değilse kaynağın yanına yazılır.
                    if output_dir:
                        from app.services.output_location import result_target

                        hedef = result_target(tofas_path, output_dir)
                        written = self._writer.write(tofas_path, result,
                                                     target=hedef)
                    else:
                        written = self._writer.write(tofas_path, result)
                    output_status = "OUTPUT_SUCCESS"
                except Exception as exc:  # noqa: BLE001 - yazma asla mutabakatı çökertmesin
                    # Hedef kilitli (kullanıcı dosyayı Excel'de açık tutuyor)
                    # ya da klasör yazılamıyor ise: ikinci bir ada yaz,
                    # mutabakatı yine de başarılı say.
                    alt = (_P(output_dir) / (src.stem + "_mutabakat_yedek.xlsx")
                           if output_dir
                           else src.with_name(src.stem + "_mutabakat_yedek.xlsx"))
                    try:
                        written = self._writer.write(tofas_path, result,
                                                     target=alt)
                        output_status = "OUTPUT_SUCCESS_FALLBACK"
                        logger.warning(
                            "Sonuç hedefine yazılamadı ({}). Sonuç şuraya "
                            "yazıldı: {}", exc, written
                        )
                    except Exception as exc2:  # noqa: BLE001
                        # ÖNEMLİ: mutabakat başarılı ama ÇIKTI YAZILAMADI.
                        # Bu durum kullanıcıdan gizlenmemeli — aksi halde
                        # sonuç dosyasının yazıldığı sanılır.
                        output_status = "OUTPUT_FAILED"
                        logger.error("Sonuç yazılamadı: {}", exc2)
                        result.summary.diptoplam_uyari = (
                            (result.summary.diptoplam_uyari or "")
                            + "  |  UYARI: Mutabakat tamamlandı ancak sonuç DOSYAYA "
                            "YAZILAMADI. Dosya açık ya da salt-okunur olabilir; "
                            "kapatıp yeniden deneyin."
                        ).strip()
                # Sonuç DAİMA ayrı bir dosyadır; kullanıcı bir klasör
                # seçmediyse dosyanın kaynağın yanına yazıldığını söyle.
                # (Eskiden sonuç kaynak dosyanın İÇİNE ekleniyordu ve bu not
                # yalnızca "eklenemedi" durumunda çıkıyordu; artık ayrı dosya
                # normal davranış olduğu için metin de buna göre.)
                self.last_output_path = str(written) if written is not None else ""
                if output_dir:
                    pass  # kullanıcı klasörü seçti; ayrıca not düşmeye gerek yok
                elif written is not None:
                    result.summary.diptoplam_uyari = (
                        (result.summary.diptoplam_uyari or "")
                        + f"  |  Not: Sonuç '{_P(written).name}' dosyasına "
                        "yazıldı; kaynak ekstreniz değiştirilmedi."
                    ).strip()

            report("Tamamlandı.", 100)
            s = result.summary
            # run_id'yi sonuç özetinde taşı (UI/rapor gösterebilsin).
            result.summary.run_id = run_id
            logger.info(
                "Bitti: run_id={} eşleşen={} tutar_farkı={} sadece_firma={} sadece_tofaş={}",
                run_id, s.matched, s.amount_diff, s.only_firma, s.only_tofas,
            )
            if s.diptoplam_uyari:
                logger.warning(s.diptoplam_uyari)
            if self._audit is not None:
                self._audit.complete_run(
                    run_id, status="COMPLETED", matched=s.matched,
                    amount_diff=s.amount_diff, only_firma=s.only_firma,
                    only_tofas=s.only_tofas, cross_matched=s.cross_matched,
                    output_file=(Path(written).name if written else None),
                    output_status=output_status,
                )
            return result
        except Exception as exc:
            logger.exception("Mutabakat başarısız oldu.")
            if self._audit is not None:
                self._audit.complete_run(run_id, status="FAILED", error=str(exc))
            raise
