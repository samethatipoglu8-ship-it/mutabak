"""Gelen ekler için uzantı, içerik, makro ve şifreleme güvenlik kapısı.

NEDEN
    Bir mutabakat cevabının eki, dışarıdan gelen ve İÇERİĞİ BİLİNMEYEN bir
    dosyadır. Ayrıştırıcıya doğrudan verilirse:

      * parolalı bir dosya ayrıştırıcıyı beklemeye/çökmeye sokar,
      * makrolu bir Office dosyası (``.xlsm``) yanlış bir kütüphaneyle
        açılırsa kod çalıştırma riski doğar,
      * uzantısı ``.pdf`` ama içeriği başka bir şey olan dosya, sessizce
        "okunamadı" sayılıp gerçek bir ekstrenin kaybolmasına yol açar,
      * aşırı büyük ya da bozuk bir arşiv belleği tüketir.

    Bu modül tek bir kapıdır: geçemeyen dosya KARANTİNAYA alınır, işleme
    girmez ve durumu insana bildirilir. Hiçbir koşulda makro ÇALIŞTIRILMAZ —
    Office dosyaları yalnızca ZIP/OLE kabı olarak İNCELENİR, açılmaz.
"""

from __future__ import annotations

import hashlib
import io
import zipfile
from dataclasses import dataclass
from pathlib import Path

from app.utils.file_safety import (
    MAX_INPUT_FILE_BYTES,
    UnsafeInputError,
    validate_input_bytes,
)

# -- sonuç kodları ---------------------------------------------------------
SAFE = "SAFE"
EMPTY = "EMPTY"
TOO_LARGE = "TOO_LARGE"
TYPE_MISMATCH = "TYPE_MISMATCH"
MACRO_PRESENT = "MACRO_PRESENT"
ENCRYPTED = "ENCRYPTED"
INVALID_CONTAINER = "INVALID_CONTAINER"


@dataclass(frozen=True)
class AttachmentSecurityResult:
    safe: bool
    code: str = SAFE
    reason: str = ""
    quarantine: bool = False
    #: İnsan incelemesi gerekiyor mu? (dosya reddedildi ama "zararlı" değil —
    #: kullanıcı bakıp doğru dosyayı isteyebilir)
    needs_human_review: bool = False
    sha256: str = ""


_OLE = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"
_PDF = b"%PDF-"
_PNG = b"\x89PNG\r\n\x1a\n"
_JPEG = b"\xff\xd8\xff"
_ZIP_EXTS = {".xlsx", ".xlsm", ".xltx", ".xltm", ".docx"}
#: Şifreli OOXML, OLE kabı içinde bu akışları taşır.
_ENCRYPTED_OLE_MARKERS = (b"EncryptedPackage", b"StrongEncryptionDataSpace",
                          b"EncryptionInfo")


def sha256_of(data: bytes) -> str:
    """Ekin içerik kimliği. Aynı ekin tekrar işlendiği bununla belirlenir."""
    return hashlib.sha256(data or b"").hexdigest()


def _encrypted_ole(data: bytes) -> bool:
    """OLE kabı şifreli bir OOXML paketi mi taşıyor?

    Arama ilk 64 KB ile sınırlıdır: dizin akışları kabın başındadır ve
    50 MB'lık bir dosyanın tamamını taramak partiyi yavaşlatır.
    """
    bas = data[:65536]
    return any(marker in bas for marker in _ENCRYPTED_OLE_MARKERS)


def _encrypted_zip(archive: zipfile.ZipFile) -> bool:
    """Arşivdeki herhangi bir üye parola korumalı mı? (genel amaçlı bit 0)"""
    return any(info.flag_bits & 0x1 for info in archive.infolist())


def _encrypted_pdf(data: bytes) -> bool:
    """PDF şifre sözlüğü taşıyor mu?

    ``/Encrypt`` anahtarı yalnızca şifreli/izin kısıtlı PDF'lerde bulunur.
    Arama sonda yapılır: trailer dosyanın sonundadır.
    """
    return b"/Encrypt" in data[-8192:] or b"/Encrypt" in data[:8192]


def inspect_attachment(data: bytes, filename: str) -> AttachmentSecurityResult:
    """Eki işleme almadan ÖNCE denetle.

    Döner: ``safe=True`` ise dosya ayrıştırıcıya verilebilir. Aksi hâlde
    ``code`` reddin nedenini, ``quarantine`` dosyanın ayrı saklanması
    gerektiğini, ``needs_human_review`` ise kullanıcının bakması gerektiğini
    söyler.
    """
    suffix = Path(filename or "").suffix.lower()
    digest = sha256_of(data)

    def _red(code: str, reason: str, review: bool = True):
        return AttachmentSecurityResult(False, code, reason, True, review,
                                        digest)

    if not data:
        return _red(EMPTY, "Ek içeriği boş.", False)
    if len(data) > MAX_INPUT_FILE_BYTES:
        return _red(TOO_LARGE, "Ek güvenli boyut sınırını aşıyor.")

    # Uzantı ile gerçek kap türü uyuşmazlığı; yanlış uzantıyla parser zorlanmaz.
    signatures = {
        ".pdf": data.startswith(_PDF),
        ".png": data.startswith(_PNG),
        ".jpg": data.startswith(_JPEG),
        ".jpeg": data.startswith(_JPEG),
        ".xls": data.startswith(_OLE),
    }
    if suffix in signatures and not signatures[suffix]:
        return _red(TYPE_MISMATCH,
                    "Dosya uzantısı gerçek içerik türüyle uyuşmuyor; "
                    "insan incelemesi gerekiyor.")

    if suffix == ".pdf" and _encrypted_pdf(data):
        return _red(ENCRYPTED,
                    "PDF parola/izin korumalı; otomatik işleme alınmadı.")

    if suffix in (".xls", ".xlsb") and data.startswith(_OLE) \
            and _encrypted_ole(data):
        return _red(ENCRYPTED,
                    "Excel dosyası parola korumalı; otomatik işleme alınmadı.")

    if suffix in _ZIP_EXTS:
        # ŞİFRELİ OOXML BİR ZIP DEĞİLDİR: Office, parolalı dosyayı OLE kabına
        # sarar. Bunu "bozuk kap" saymak kullanıcıya yanlış bilgi verirdi.
        if data.startswith(_OLE):
            if _encrypted_ole(data):
                return _red(ENCRYPTED, "Office dosyası parola korumalı; "
                                       "otomatik işleme alınmadı.")
            return _red(TYPE_MISMATCH,
                        "Office uzantısı gerçek içerik türüyle uyuşmuyor.")
        if not data.startswith(b"PK"):
            return _red(TYPE_MISMATCH,
                        "Office uzantısı geçerli ZIP kabı değil.")
        # PAROLA KONTROLÜ ÖNCE YAPILIR: parolalı bir arşiv, boyut/oran
        # doğrulamasında "bozuk kap" gibi görünür ve kullanıcı yanlış gerekçe
        # okur ("dosyanız bozuk" yerine doğrusu "dosyanız parolalı").
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                if _encrypted_zip(archive):
                    return _red(ENCRYPTED, "Arşiv parola korumalı; otomatik "
                                           "işleme alınmadı.")
        except zipfile.BadZipFile:
            return _red(INVALID_CONTAINER, "Bozuk/okunamayan arşiv.")

        try:
            validate_input_bytes(data, filename)
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                names = {name.lower() for name in archive.namelist()}
                # MAKRO ASLA ÇALIŞTIRILMAZ: dosya yalnızca ZIP olarak
                # LİSTELENİR, hiçbir Office/COM bileşeni açmaz.
                if any(name.endswith("vbaproject.bin") for name in names):
                    return _red(
                        MACRO_PRESENT,
                        "Makro içeren Office eki otomatik işleme alınmadı; "
                        "makrolar ÇALIŞTIRILMADI.")
        except (UnsafeInputError, zipfile.BadZipFile) as exc:
            return _red(INVALID_CONTAINER, f"Bozuk/güvensiz arşiv: {exc}")
    return AttachmentSecurityResult(True, SAFE, sha256=digest)
