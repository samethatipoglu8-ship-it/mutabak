"""PHASE B — segment bazlı Excel ekstre (attachment) üretimi.

``CompanyStatementService`` firmayı yön bazlı segmentlere ayırır (M = 120*,
S = 120 dışı; X, S'e dahildir). Bu modül her segment için AYRI bir Excel
dosyası üretir:

    Firma 4009668 (M + S)  ->  4009668_Receivable_ekstre.xlsx
                               4009668_Payable_ekstre.xlsx

Mail firma seviyesinde TEK kalır; iki dosya aynı maile eklenir (sonraki faz).

Kurallar:
  - Excel yalnızca ilgili firmanın, ilgili segmentinin FBL1H satırlarını içerir.
  - M/S/X filtresi BURADA tekrar uygulanmaz; servisin ürettiği segment olduğu
    gibi yazılır (tek doğruluk kaynağı).
  - FBL1H satır sırası korunur (yeniden sıralama yapılmaz).
  - Ara toplam / açılış satırları segmente hiç girmediği için tekrar eklenmez.
  - Bakiye 0 olsa bile dosya üretilir.
  - Biçimlendirme deseni ``result_writer.py`` ile aynıdır (başlık dolgusu,
    beyaz kalın başlık yazısı, kolon genişlikleri, donmuş başlık satırı).

Bu modül Qt kullanmaz ve Outlook'a bağlanmaz; arka plan thread'inde güvenle
çalışır.
"""

from __future__ import annotations

from datetime import date
from pathlib import Path
from typing import Iterable

from app.services.company_statement_service import (
    BalanceStatus,
    CompanyPackageDraft,
    StatementSegment,
)

# Görünüm sabitleri ORTAK modülden gelir (``excel_style``): uygulamanın
# ürettiği tüm Excel'ler tek görünüme sahip olsun ve firmaya gönderilen
# ekstre, mutabakat sonucu yazıcısına bağımlı olmasın.
from app.services.excel_style import (
    DATE_FORMAT as _DATE_FORMAT,
)
from app.services.excel_style import (
    HEADER_FILL as _HEADER,
)
from app.services.excel_style import (
    MONEY_FORMAT as _MONEY_FORMAT,
)
from app.services.result_writer import ResultWriter
from app.utils.excel import safe_excel_value

# Yön -> dosya adı eki.
#
# Karşı taraf "S" / "M" / "X" harflerini bilmez; bunlar TOFAŞ'ın iç yön
# kodlarıdır. Ek dosyasının adı firmanın ANLAYACAĞI terimi taşır:
#
#     M  (müşteri / FBL5H)      → Receivable  → 4009668_Receivable_ekstre.xlsx
#     S  (satıcı / FBL1H)       → Payable     → 4009668_Payable_ekstre.xlsx
#     X  (S ile aynı, FBL1H)    → Payable
#
# ETİKET MAİL GÖVDESİYLE TUTARLIDIR — kural budur:
#     M → "The amount must be paid by YOU"    (firma bize öder → receivable)
#     S/X → "The amount must be paid by TOFAS" (biz firmaya öderiz → payable)
# X'i "Receivable" diye adlandırmak, aynı mailin gövdesi "TOFAŞ ödeyecek"
# derken ekin "alacak" demesi anlamına gelirdi; karşı tarafa giden çelişkili
# bir belge olurdu. X zaten ``effective_ms`` ile S'ye indirgenir (X == S).
_DIRECTION_LABEL = {
    "M": "Receivable",
    "S": "Payable",
    "X": "Payable",
    "": "TUM",
}

# Yönün insan tarafından okunur açıklaması (özet bloğunda).
# Yön artık HANGİ DOSYADAN geldiğine göre belirlenir (hesap numarasına değil):
# FBL5H'a yüklenen satırlar M, FBL1H'a yüklenenler S/X sayılır.
_DIRECTION_TEXT = {
    "M": "M — müşteri ekstresi (FBL5H) kayıtları",
    "S": "S/X — satıcı ekstresi (FBL1H) kayıtları",
    "": "Yön belirlenemedi — tüm kayıtlar",
}

_STATUS_TEXT = {
    BalanceStatus.UNCHANGED: "Değişmedi (mutabakat raporuyla aynı)",
    BalanceStatus.UPDATED_FROM_FBL1H: "FBL1H ile güncellendi",
    BalanceStatus.NEW_IN_FBL1H: "Mutabakat raporunda yok",
    BalanceStatus.MISSING_IN_FBL1H: "FBL1H dosyasında satırı yok",
}

# Not: "Belge numarası" (FBL1H K kolonu) TofasRecord'da taşınmıyor ve
# domain.py'a dokunulmadığı için ekstreye alınmadı. Karşı taraf için anlamlı
# olan alan zaten Referans'tır (tedarikçinin kendi fatura numarası).
_COLUMNS: tuple[tuple[str, int], ...] = (
    ("Sıra", 7),
    ("Belge Tarihi", 14),
    ("Kayıt Tarihi", 14),
    ("Net Vade", 14),
    ("Referans", 26),
    ("Belge Türü", 12),
    ("Ana Hesap", 16),
    ("Tutar", 18),
    ("Para Birimi", 12),
    ("Açıklama", 46),
)

_AMOUNT_COL = 8      # 1 tabanlı: "Tutar"
_DATE_COLS = (2, 3, 4)


def segment_file_name(draft: CompanyPackageDraft, segment: StatementSegment) -> str:
    """Segment dosya adı: firma kodu + yön bilgisi içerir."""
    label = _DIRECTION_LABEL.get(segment.ms, segment.ms or "TUM")
    return f"{draft.company_code}_{label}_ekstre.xlsx"


class StatementExcelWriter:
    """Segment bazlı Excel ekstre yazıcısı (Qt'siz, saf dosya işlemi)."""

    SHEET_NAME = "Ekstre"

    def write_segment(
        self,
        draft: CompanyPackageDraft,
        segment: StatementSegment,
        output_dir: str | Path,
    ) -> Path:
        """Tek bir segment için Excel üret ve yazılan yolu döndür."""
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter

        out_dir = Path(output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        target = out_dir / segment_file_name(draft, segment)

        wb = Workbook()
        ws = wb.active
        ws.title = self.SHEET_NAME

        bold = Font(bold=True)
        white_bold = Font(bold=True, color="FFFFFFFF")
        header_fill = PatternFill("solid", fgColor=_HEADER)
        right = Alignment(horizontal="right")

        row = 1

        # -- Özet bloğu (result_writer deseni) ------------------------------
        ws.cell(row=row, column=1, value="EKSTRE ÖZETİ").font = bold
        row += 1

        statement = segment.statement
        summary: list[tuple[str, object]] = [
            ("Firma Kodu", draft.company_code),
            ("Firma Adı", draft.company_name or "-"),
            ("Yön", _DIRECTION_TEXT.get(segment.ms, segment.ms)),
            ("Kayıt sayısı", segment.row_count),
            ("Durum", _STATUS_TEXT.get(segment.balance_status,
                                       segment.balance_status.value)),
            ("Mutabakat No (RUN-ID)", draft.source_run_id or "-"),
            ("Kaynak dosya", Path(statement.source_file).name
             if statement.source_file else "-"),
        ]
        for label, value in summary:
            ws.cell(row=row, column=1, value=label).font = bold
            ws.cell(row=row, column=2, value=safe_excel_value(value))
            row += 1

        # Bakiye satırları: yalnızca TUTARI OLAN dövizler (kural 12).
        ws.cell(row=row, column=1, value="Bakiye").font = bold
        if segment.display_balances:
            first = True
            for currency, amount in segment.display_balances.items():
                if not first:
                    row += 1
                cell = ws.cell(row=row, column=2, value=amount)
                cell.number_format = _MONEY_FORMAT
                ws.cell(row=row, column=3, value=safe_excel_value(currency))
                first = False
        else:
            ws.cell(row=row, column=2, value="0,00")
            ws.cell(row=row, column=3,
                    value=safe_excel_value(draft.zero_balance_currency))
        row += 2

        # -- Detay tablosu --------------------------------------------------
        header_row = row
        for col, (title, _width) in enumerate(_COLUMNS, start=1):
            cell = ws.cell(row=row, column=col, value=title)
            cell.font = white_bold
            cell.fill = header_fill
        row += 1

        # FBL1H satır sırası KORUNUR: hiçbir sıralama uygulanmaz.
        for seq, rec in enumerate(statement.rows, start=1):
            values = (
                seq,
                rec.belge_tarihi,
                rec.kayit_tarihi,
                rec.net_vade,
                rec.reference_raw or rec.reference or "",
                rec.belge_turu or "",
                rec.main_account or "",
                rec.amount,
                rec.currency or "",
                rec.metin or "",
            )
            for col, value in enumerate(values, start=1):
                cell = ws.cell(row=row, column=col,
                               value=safe_excel_value(value))
                if col == _AMOUNT_COL:
                    cell.number_format = _MONEY_FORMAT
                    cell.alignment = right
                elif col in _DATE_COLS and isinstance(value, date):
                    cell.number_format = _DATE_FORMAT
            row += 1

        # -- Kolon genişlikleri + donmuş başlık -----------------------------
        for i, (_title, width) in enumerate(_COLUMNS, start=1):
            ws.column_dimensions[get_column_letter(i)].width = width
        ws.freeze_panes = ws.cell(row=header_row + 1, column=1)

        try:
            ResultWriter._atomic_save(wb, target)
        finally:
            wb.close()
        return target

    def write_package(
        self,
        draft: CompanyPackageDraft,
        output_dir: str | Path,
    ) -> list[Path]:
        """Firmanın TÜM segmentleri için Excel üret.

        M + S taşıyan firma iki dosya alır; mail yine tektir.
        """
        return [
            self.write_segment(draft, segment, output_dir)
            for segment in draft.segments
        ]

    def write_all(
        self,
        drafts: Iterable[CompanyPackageDraft],
        output_dir: str | Path,
    ) -> dict[str, list[Path]]:
        """Tüm firmalar için üret; firma kodu -> dosya yolları."""
        return {
            draft.company_code: self.write_package(draft, output_dir)
            for draft in drafts
        }
