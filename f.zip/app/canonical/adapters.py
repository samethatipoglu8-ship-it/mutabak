"""Adapters between V4 domain records and the canonical model.

These are the compatibility layer required by the integration plan:

    EXISTING RECONCILIATION  ->  ADAPTER / DOMAIN  ->  CANONICAL MODEL
                                                            |
    NEW EXTRACTION / CONNECTORS  ------------------->  (same model)
                                                            |
                                                    SAME RECONCILER

The mapping is **lossless**: every original field is preserved under
``source_fields['_v4']`` so a canonical record produced from a V4 record can be
turned back into a byte-identical V4 record. That is what lets the untouched
``Reconciler`` be driven through the canonical boundary and still produce
exactly the current behaviour (verified by regression tests).
"""

from __future__ import annotations

from decimal import Decimal

from app.models.domain import (
    FirmaRecord,
    MatchStatus,
    TofasRecord,
)

from .evidence import ExtractionMethod, FieldEvidence
from .model import (
    CanonicalMatchStatus,
    DocumentType,
    ReconciliationRecord,
    RecordSide,
)

_V4_TYPE_TOFAS = "tofas"
_V4_TYPE_FIRMA = "firma"

# V4 colour-coded status -> generic engine status.
_STATUS_MAP: dict[MatchStatus, CanonicalMatchStatus] = {
    MatchStatus.MATCHED: CanonicalMatchStatus.MATCHED,
    MatchStatus.AMOUNT_DIFF: CanonicalMatchStatus.REVIEW,
    MatchStatus.ONLY_FIRMA: CanonicalMatchStatus.UNMATCHED,
    MatchStatus.ONLY_TOFAS: CanonicalMatchStatus.UNMATCHED,
}


def map_match_status(v4_status: MatchStatus) -> CanonicalMatchStatus:
    """Project a V4 colour-coded status onto the generic canonical status."""
    return _STATUS_MAP[v4_status]


# --------------------------------------------------------------------------
# V4 record  ->  canonical
# --------------------------------------------------------------------------

def _evidence(field: str, value, row: int, method: ExtractionMethod) -> FieldEvidence:
    return FieldEvidence(
        field_name=field,
        value=value,
        source_row=row,
        extraction_method=method,
    )


def tofas_to_canonical(rec: TofasRecord) -> ReconciliationRecord:
    """Convert a TOFAŞ (our-books) record into a canonical record."""
    method = ExtractionMethod.DETERMINISTIC_TABULAR
    refs = list(rec.all_references or ([rec.reference] if rec.reference else []))
    return ReconciliationRecord(
        side=RecordSide.OURS,
        counterparty_id=rec.firma_kodu,
        document_number=rec.reference,
        reference_candidates=refs,
        document_date=rec.belge_tarihi,
        due_date=rec.net_vade,
        amount=rec.amount,
        currency=rec.currency,
        account_code=rec.main_account,
        document_type=DocumentType.ACCOUNT_STATEMENT,
        description=rec.metin,
        source_row=rec.row_index,
        extraction_method=method.value,
        evidence={
            "document_number": _evidence("document_number", rec.reference, rec.row_index, method),
            "amount": _evidence("amount", rec.amount, rec.row_index, method),
        },
        source_fields={"_v4_type": _V4_TYPE_TOFAS, "_v4": rec.model_dump()},
    )


def firma_to_canonical(rec: FirmaRecord) -> ReconciliationRecord:
    """Convert a firma (counterparty) record into a canonical record."""
    method = ExtractionMethod.DETERMINISTIC_TABULAR
    refs = list(rec.all_references or ([rec.reference] if rec.reference else []))
    return ReconciliationRecord(
        side=RecordSide.COUNTERPARTY,
        counterparty_id=rec.account,
        document_number=rec.reference,
        reference_candidates=refs,
        document_date=rec.inv_date,
        due_date=rec.due_date,
        amount=rec.amount,
        currency=rec.currency,
        account_code=rec.account,
        document_type=DocumentType.ACCOUNT_STATEMENT,
        description=rec.comment,
        source_row=rec.row_index,
        extraction_method=method.value,
        evidence={
            "document_number": _evidence("document_number", rec.reference, rec.row_index, method),
            "amount": _evidence("amount", rec.amount, rec.row_index, method),
        },
        source_fields={"_v4_type": _V4_TYPE_FIRMA, "_v4": rec.model_dump()},
    )


# --------------------------------------------------------------------------
# canonical  ->  V4 record  (exact reconstruction)
# --------------------------------------------------------------------------

def canonical_to_tofas(rec: ReconciliationRecord) -> TofasRecord:
    """Rebuild the original TofasRecord from a canonical record.

    Uses the preserved ``_v4`` payload when present (lossless path); otherwise
    reconstructs from the semantic canonical fields (for records that came from
    a non-V4 source, e.g. a future extractor or connector).
    """
    payload = rec.source_fields.get("_v4")
    if payload is not None and rec.source_fields.get("_v4_type") == _V4_TYPE_TOFAS:
        return TofasRecord(**payload)
    return TofasRecord(
        row_index=rec.source_row if rec.source_row is not None else 0,
        main_account=rec.account_code,
        firma_kodu=rec.counterparty_id,
        reference=rec.document_number,
        all_references=list(rec.reference_candidates),
        belge_tarihi=rec.document_date,
        net_vade=rec.due_date,
        amount=rec.amount if rec.amount is not None else Decimal("0"),
        currency=rec.currency,
        metin=rec.description,
    )


def canonical_to_firma(rec: ReconciliationRecord) -> FirmaRecord:
    """Rebuild the original FirmaRecord from a canonical record."""
    payload = rec.source_fields.get("_v4")
    if payload is not None and rec.source_fields.get("_v4_type") == _V4_TYPE_FIRMA:
        return FirmaRecord(**payload)
    return FirmaRecord(
        row_index=rec.source_row if rec.source_row is not None else 0,
        account=rec.account_code,
        reference=rec.document_number,
        all_references=list(rec.reference_candidates),
        inv_date=rec.document_date,
        due_date=rec.due_date,
        amount=rec.amount if rec.amount is not None else Decimal("0"),
        comment=rec.description,
    )


def to_canonical(rec) -> ReconciliationRecord:
    """Dispatch a V4 record to the right adapter by side."""
    if isinstance(rec, TofasRecord):
        return tofas_to_canonical(rec)
    if isinstance(rec, FirmaRecord):
        return firma_to_canonical(rec)
    raise TypeError(f"Unsupported record type: {type(rec)!r}")


